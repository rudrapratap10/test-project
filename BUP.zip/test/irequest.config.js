const fs = require('fs');
const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const { ScriptsWebpackPlugin, NamedLazyChunksWebpackPlugin, BaseHrefWebpackPlugin } = require('@angular/cli/plugins/webpack');

const webpackMerge = require('webpack-merge');
const commonConfig = require('./src/dd-common/common.config.js');
const prodConfig = require('./src/dd-common/prod.config.js');
const devConfig = require('./src/dd-common/dev.config.js');
const randomStringGenerator = require('uuid/v4');

const { CommonsChunkPlugin } = require('webpack').optimize;
const { AngularCompilerPlugin } = require('@ngtools/webpack');

const nodeModules = path.join(process.cwd(), 'node_modules');
const realNodeModules = fs.realpathSync(nodeModules);
const genDirNodeModules = path.join(process.cwd(), 'src', '$$_gendir', 'node_modules');
const ddCoreModules = path.join(process.cwd(), 'src', 'core');
const ddCommonModules = path.join(process.cwd(), 'src', 'common');
const entryPoints = ["inline","polyfills","sw-register","styles","vendor","dd-core", "main"];

const hostReplacementPaths = {};
const environment = path.join('environments','environment.ts');
hostReplacementPaths[environment] = environment;

const projectRoot = process.cwd();
const appRoot = path.join(process.cwd(), 'src', 'irequest');

const isProdMode = (process.env.NODE_ENV == 'production');
let config = devConfig;
if (isProdMode) {
  const randomString = randomStringGenerator();
  const asset = require('./build-configs/asset');
  asset.addAssetHashSupport(randomString);
  config = prodConfig;
}
config = webpackMerge(commonConfig, config);

module.exports = webpackMerge(
  config,
{
  "entry": {
    "main": [
      path.join(appRoot, "irequest.main.ts"),
    ],
    "polyfills": [
      path.join(projectRoot, "src", "polyfills.ts")
    ],
    "styles": [
      path.join(projectRoot, "src", "styles.scss")
    ]
  },
  "output": {
    "path": path.join(process.cwd(), "dist", "irequest"),
    "filename": "[name].bundle.[chunkhash:20].js",
    "chunkFilename": "[chunkhash:20].chunk.[id].js",
    "crossOriginLoading": false
  },
  "plugins": [
    new ScriptsWebpackPlugin({
    "name": "scripts",
    "sourceMap": true,
    "filename": "scripts.bundle.js",
    "scripts": [
       //  path.join(process.cwd(), "node_modules\\jquery\\dist\\jquery.min.js"),
      //   path.join(process.cwd(), "node_modules\\jquery-ui-dist\\jquery-ui.min.js"),
         //path.join(process.cwd(), "node_modules\\slickgrid\\lib\\jquery.event.drag-2.3.0.j"),
        // path.join(process.cwd(), "node_modules\\bootstrap\\dist\\js\\bootstrap.js"),
        // path.join(process.cwd(), "src\\assets\\lib\\multiple-select\\multiple-select.js"),
        // path.join(process.cwd(), "src\\scripts\\detect-browser.js")
        path.join(projectRoot, "src", "scripts", "detect-browser.js"),
        path.join(projectRoot, "src", "scripts", "jquery-1.9.0.min.js")
    ],
    "basePath": "D:\\sandbox\\IrequestS2P"
  }),

    new CleanWebpackPlugin([
      path.join("dist", "irequest")
    ]),
    new CopyWebpackPlugin([
      {
        "context": "src",
        "to": "assets",
        "from": path.join(projectRoot, "src", "assets")
      },
      {
        "context": "src",
        "to": "assets",
        "from": path.join(projectRoot, "src", "dd-common", "assets")
      },
      {
        "context": "src",
        "to": "",
        "from": {
          "glob": path.join(projectRoot, "src", "favicon.ico"),
          "dot": true
        }
      },
      {
        "context": "src",
        "to": path.join("assets", "app"),
        "from": path.join(appRoot, "assets")
      },
      {
        "context": "src",
        "to": "locale",
        "from": path.join(appRoot, "locale")
      }
    ], {
      "ignore": [
        ".gitkeep",
        "**/.DS_Store",
        "**/Thumbs.db"
      ],
      "debug": "warning"
    }),
    new HtmlWebpackPlugin({
      "template": path.join(projectRoot, "src", "index.html"),
      "filename": "./index.html",
      "hash": false,
      "inject": true,
      "compile": true,
      "favicon": false,
      "minify": false,
      "cache": true,
      "showErrors": true,
      "chunks": "all",
      "excludeChunks": [],
      "title": "Webpack App",
      "xhtml": true,
      "chunksSortMode": function sort(left, right) {
        let leftIndex = entryPoints.indexOf(left.names[0]);
        let rightindex = entryPoints.indexOf(right.names[0]);
        if (leftIndex > rightindex) {
            return 1;
        }
        else if (leftIndex < rightindex) {
            return -1;
        }
        else {
            return 0;
        }
    }
    }),
    new CommonsChunkPlugin({
      "name": [
        "inline"
      ],
      "minChunks": null
    }),
    new CommonsChunkPlugin({
      "name": [
        "vendor"
      ],
      "minChunks": (module) => {
                return module.resource
                    && (module.resource.startsWith(nodeModules)
                        || module.resource.startsWith(genDirNodeModules)
                        || module.resource.startsWith(realNodeModules));
            },
      "chunks": [
        "main"
      ]
    }),
    new CommonsChunkPlugin({
      "name": [
        "dd-core"
      ],
      "minChunks": (module) => {
                return module.resource
                  && module.resource.startsWith(ddCoreModules);
            },
      "chunks": [
        "main"
      ]
    }),
    new CommonsChunkPlugin({
      "name": [
        "main"
      ],
      "minChunks": 2,
      "async": "common"
    }),
    new AngularCompilerPlugin({
      "mainPath": path.join("irequest", "irequest.main.ts"),
      "platform": 0,
      "hostReplacementPaths": hostReplacementPaths,
      "sourceMap": !isProdMode,
      "tsConfigPath": path.join("src", "tsconfig.irequest.json"),
      "skipCodeGeneration": !isProdMode,
      "compilerOptions": {}
    })
  ]
});
