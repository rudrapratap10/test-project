import {
  Component,
  ChangeDetectionStrategy
} from '@angular/core';

import { IMG_CON_ERROR } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-connection-error',
  templateUrl: './connection-error.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConnectionErrorComponent {

  _imgPath: string;

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_CON_ERROR;
  }

}
