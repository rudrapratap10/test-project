import {
  Component,
  ChangeDetectionStrategy
} from '@angular/core';

import { IMG_NOT_FOUND } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-page-not-found',
  templateUrl: './page-not-found.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PageNotFoundComponent {

  _imgPath: string;

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_NOT_FOUND;
  }
}
