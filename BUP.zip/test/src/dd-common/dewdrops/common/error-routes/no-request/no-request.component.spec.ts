import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NoRequestComponent } from './no-request.component';

describe('NoRequestComponent', () => {
  let component: NoRequestComponent;
  let fixture: ComponentFixture<NoRequestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NoRequestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
