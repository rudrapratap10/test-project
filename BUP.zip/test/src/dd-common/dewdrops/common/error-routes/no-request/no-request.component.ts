import {
  Component,
  ChangeDetectionStrategy
 } from '@angular/core';

import { IMG_NO_REQ } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-no-request',
  templateUrl: './no-request.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NoRequestComponent {

  _imgPath: string;

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_NO_REQ;
  }

}
