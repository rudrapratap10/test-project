import {
  Component,
  ChangeDetectionStrategy
} from '@angular/core';

import { IMG_SERVER_ERROR } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-server-error',
  templateUrl: './server-error.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServerErrorComponent {

  _imgPath: string;

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_SERVER_ERROR;
  }

}
