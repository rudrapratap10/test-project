import { Injectable } from '@angular/core';
import { APIClientService, SessionAuthService } from '@dewdrops/services';
import { Observable } from 'rxjs/Observable';
import * as config from '../config';
import { HttpParams, HttpHeaders, HttpClient } from '@angular/common/http';
import { filter } from 'rxjs/operators/filter';
import { TranslateService } from 'ng2-translate';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class ActivityService {

  docId: string;

  constructor(private api: APIClientService,
    private http: HttpClient,
    private _translate: TranslateService,
    private sessionAuthService: SessionAuthService) { }

  fetchActivities(id, type, version = '-1', url): Observable<any> {
    const data = {
      'entityType': type,
      'entityId': id,
      'entityVersion': version
    };
    return this.api.list(url.auditListURL, data)
      ._catch(error => Observable.throw(error))
      .map(data => data ? data.data.records : false);
  }

  addComment(data,url): Observable<any> {
    return this.api.list(url.createCommentURL, data)
      ._catch(error => Observable.throw(error))
      .map(data => data ? data.data.records : false);
  }

  addReply(data,url): Observable<any> {
    return this.api.list(url.createReplyURL, data)
      ._catch(error => Observable.throw(error))
      .map(data => data ? data.data.records : false);
  }

  setAttachment(files,url): Observable<any> {
    let fileArr = [];
    for (const file of files) {
      fileArr.push(file);
    }
    return Observable.from(fileArr)
      .mergeMap(file => {
        const formData: FormData = new FormData();
        formData.append('file', file);
        return this.http.post(url.addAttachmentURL, formData, {
          headers: new HttpHeaders({
            'modulename': 'requisition'
          })
        }).catch(error => Observable.throw(error));
      });
  }

  retResponse(input, output) {
    const res = input.map(element => {
      return {
        id: element['id'],
        name: element['name'],
        size: (element['size'] / 1024).toFixed(2),
        path: element['path'],
        max: 2000,
        saved: false,
        comments: '',
        visibility: 'INTERNAL'
      };
    });
    return [...output, ...res];
  }

  startRawFilesUpload(input, output, id) {
    input = Array.from(input);
    const res = input.map((element, i) => {
      return {
        id: id + '' + i,
        name: element['name'],
        size: (element['size'] / 1024).toFixed(2),
        path: '',
        max: 2000,
        saved: false,
        comments: '',
        visibility: 'INTERNAL',
        isRaw: true,
        refer: id
      };
    });
    return [...output, ...res];
  }

  completeRawFilesUpload(output, id) {
    return output.map(element => {
      if (element.refer && element.refer === id) {
        element.progress._value = 100;
      }
      return element;
    });
  }

  removeRawFilesUpload(output, id) {
    return output.filter(element => !(element.refer && (element.refer === id)));
  }

  checkFilter(event, autoId, filters, linkAutoIds, auditTrailMap) {
    const filterArr = [];
    const filterCases = Object.keys(config.FILTER_CASES);
    for (let filter in filters) {
      if (filters[filter]) {
        filterArr.push(filter);
      }
    }
    if (!filterArr.length) {
      return true;
    }
    if (filterArr.includes('version')) {
      const auditTrail = auditTrailMap[autoId];
      return linkAutoIds[auditTrail['version']] === autoId;
    }
    else if (filterArr.includes('others')) {
      let othersArr = [];
      for (let fcase in config.FILTER_CASES) {
        othersArr.push(config.FILTER_CASES[fcase].includes(event));
      }
      return !othersArr.some(ele => ele);
    }
    else {
      for (let fcase in config.FILTER_CASES) {
        if (filterArr.includes(fcase)) {
          return config.FILTER_CASES[fcase].includes(event);
        }
      }
    }
  }

  searchUsers(term) {
    if (!term) {
      return Observable.of([]);
    }
    const options = {
      perPageRecords: 10,
      pageNo: 1,
      criteriaGroup: {
        logicalOperator: 'AND',
        criteria: [
          {
            fieldName: 'nameOrEmail',
            operation: 'CONTAINS',
            value: term
          }
        ]
      },
      sorts: [
        {
          fieldName: 'name',
          direction: 'ASC'
        }
      ]
    };
    const userId = this.sessionAuthService.getSessionData()['userDetails']['userId'];
    return this.api.list('api/a/eproc/users/list', options)
      .map(d => {
        return d.data && d.data.records ? d.data.records.filter(data => data.userId !== userId) : [];
      });
  }

  prepareLink(auditKey, auditValue, auditVariable, auditTrails) {
    const version = auditVariable['VERSION'] ? '?version=' + auditVariable['VERSION'] : '';
    if (!auditValue) {
      return auditValue;
    }
    switch (auditKey) {
      case 'RECEIPT_NO':
        auditValue = auditValue ? '#' + auditValue : '';
        return '<a href="#/receipt/viewReceipt/' + this.docId + '/' + auditVariable['RECEIPT_ID'] + version + '" class="scLnk auditLink" target="_blank">' + auditValue + '</a>';
      case 'PO_NO':
        auditValue = auditValue ? '#' + auditValue : '';
        return '<a href="javascript:void(0)" data-entity-id="' + (auditVariable['PURCHASE_ORDER_ID'] || auditVariable['DOC_ID']) + '"  data-entity-url="common/entity/show" data-entity-version="-1" data-source-entity="" class="scLnk auditLink">' + auditValue + '</a>';
      case 'REQ_NO':
        auditValue = auditValue ? '#' + auditValue : '';
        return '<a href="#/requisition/' + (auditVariable['REQUISITION_ID'] || auditVariable['DOC_ID']) + version + '" class="scLnk auditLink"  target="_blank">' + auditValue + '</a>';
      case 'OWNER_TYPE':
        return this._translate.instant('DEWDROPS_ACTIVITY_CARD_ROLE_TYPES_' + auditVariable['OWNER_TYPE']);
      case 'REPLACE_MESSAGE':
        return '<a href="javascript:void(0)" data-entity-id="' + auditTrails['entityId'] + '" data-replacing-item-id="' + auditVariable['ITEM_ID_1'] + '" data-new-item-id="' + auditVariable['ITEM_ID_2'] + '" data-url="common/default/compareReplaceItem" data-entity-version="' + auditTrails['auditVersion'] + '" class="scLnk compareReplaceItemLink">' + auditValue + '</a>';
      case 'RETURN_NOTE_NO':
        auditValue = auditValue ? '#' + auditValue : '';
        return '<a href="#/receipt/viewReturnNotes/' + this.docId + '/' + auditVariable['RECEIPT_ID'] + version + '" class="scLnk auditLink"  target="_blank">' + auditValue + '</a>';
      default:
        return auditValue;
    }
  }

  parseLang(action, parse) {
    for (let key in parse) {
      action = action.replace(new RegExp('{' + key + '}', "g"), parse[key]);
    }
    return action;
  }
}
