import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { ActivityService } from '../activity.service';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'dew-reply',
  templateUrl: './reply.component.html'
})
export class ReplyComponent implements OnInit {

  @Input() item: any;
  @Input() showSection: any;
  @Input() auditTrailApi: string;
  @Output() cancelReplyOutput = new EventEmitter();
  reply: string;
  @Output()
  addReply = new EventEmitter<any>();
  fileUploaded = [];
  attachmentObj = [];
  file = [];
  showPostModal = false;
  modalData: any;
  validate: boolean;
  fileUploadStarted: boolean;
  errorMsgAttach: any = '';

  constructor(private service: ActivityService, private _translate: TranslateService) { }

  ngOnInit() {
  }

  addAttatchment(file) {
    const id = new Date().getTime();
    this.errorMsgAttach = {};
    this.file = file.target.files;
    this.fileUploaded = this.service.startRawFilesUpload(this.file, this.fileUploaded, id);
    this.fileUploadStarted = true;
    if (this.fileUploaded.length > 40) {
      this.fileUploadStarted = false;
      this.errorMsgAttach = {
        error:
          {
            message:
              {
                description:
                  this._translate.instant('DEWDROPS_CHECKOUT_MAX_UPLOAD_ADD_ATTACHMENTS')
              }
          }
      };
      this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
      return;
    }
    this.service.setAttachment(this.file, this.auditTrailApi)
      .filter(() => {
        if (this.fileUploaded.length > 40) {
          this.fileUploadStarted = false;
          this.errorMsgAttach = {
            error:
              {
                message:
                  {
                    description:
                      this._translate.instant('DEWDROPS_CHECKOUT_MAX_UPLOAD_ADD_ATTACHMENTS')
                  }
              }
          };
        }
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        return this.fileUploaded.length <= 40;
      })
      .subscribe((data) => {
        this.fileUploadStarted = false;
        this.fileUploaded = this.service.completeRawFilesUpload(this.fileUploaded, id);
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        if (data.data && data.data.records.length > 0) {
          this.fileUploaded = this.service.retResponse(data.data.records, this.fileUploaded);
        }
        if (data.error) {
          this.errorMsgAttach = {};
          this.errorMsgAttach = {
            error:
              {
                message:
                  {
                    description:
                      this._translate.instant('DEWDROPS_CHECKOUT_SOME_INVALID_FILES_ADD_ATTACHMENTS')
                  }
              }
          };
        }
        this.attachmentObj = [];
        for (let i = 0; i < this.fileUploaded.length; i++) {
          this.attachmentObj.push(this.fileUploaded[i].id);
        }
      },
      errors => {
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        this.fileUploadStarted = false;
        this.errorMsgAttach = errors.error;
      });
  }

  removeAttach(id) {
    this.fileUploaded = this.fileUploaded.filter(el => el.id !== id);
    this.attachmentObj = [];
    for (let i = 0; i < this.fileUploaded.length; i++) {
      this.attachmentObj.push(this.fileUploaded[i].id);
    }
  }

  submit() {
    const data = {
      comment: this.reply,
      attachments: this.attachmentObj
    }
    this.validate = true;
    if (this.reply) {
      this.addReply.emit(data);
      this.refreshData();
    }
  }

  refreshData() {
    this.reply = '';
    this.fileUploaded = [];
    this.attachmentObj = [];
    this.file = [];
    this.validate = false;
  }

  getFileType(name) {
    let temp = name.split('.');
    return temp[temp.length - 1];
  }

  cancelReply(event) {
    this.refreshData();
    this.cancelReplyOutput.emit(event)
  }
}
