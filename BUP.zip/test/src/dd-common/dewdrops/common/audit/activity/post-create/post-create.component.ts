import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import { ActivityService } from '../activity.service';
import { Observable } from 'rxjs/Observable';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'dew-post-create',
  templateUrl: './post-create.component.html'
})
export class PostCreateComponent implements OnInit {

  @Input()
  auditTrailApi: string;
  @Output()
  addComment = new EventEmitter<any>();
  searchUserStream = new EventEmitter<string>();
  userItems: Observable<any>;
  fileUploaded = [];
  attachmentObj = [];
  file = [];
  showPostModal = false;
  modalData: any;
  validate: boolean;
  fileUploadStarted: boolean;
  visibleToDefault = { key: 'ALL', val: 'DEWDROPS_ACTIVITY_NEW_CONV_OPTS_VISIBLETO_ALL' };
  visibleTo = [{
    key: 'REQUESTER',
    val: 'DEWDROPS_ACTIVITY_NEW_CONV_OPTS_VISIBLETO_REQUESTER'
  }, {
    key: 'APPROVER',
    val: 'DEWDROPS_ACTIVITY_NEW_CONV_OPTS_VISIBLETO_APPROVER'
  }, {
    key: 'BUYER',
    val: 'DEWDROPS_ACTIVITY_NEW_CONV_OPTS_VISIBLETO_BUYER'
  }];
  isAllModel = true;
  allChanged = true;
  visibleToModel = {};
  static toUsers = [];
  userIds = [];
  comment = '';
  errorMsgAttach: any = '';
  constructor(private service: ActivityService, private _translate: TranslateService) { }


  ngOnInit() {
    this.visibleTo.forEach(v => this.visibleToModel[v.key] = v.val);
    this.userItems = this.searchUserStream
      .debounceTime(250)
      .distinctUntilChanged()
      .switchMap(term => this.service.searchUsers(term));
  }

  addAttatchment(file) {
    const id = new Date().getTime();
    this.errorMsgAttach = {};
    this.file = file.target.files;
    this.fileUploaded = this.service.startRawFilesUpload(this.file, this.fileUploaded, id);
    this.fileUploadStarted = true;
    if (this.fileUploaded.length > 40) {
      this.fileUploadStarted = false;
      this.errorMsgAttach = {
        error:
          {
            message:
              {
                description:
                  this._translate.instant('DEWDROPS_CHECKOUT_MAX_UPLOAD_ADD_ATTACHMENTS')
              }
          }
      };
      this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
      return;
    }
    this.service.setAttachment(this.file, this.auditTrailApi)
      .filter(() => {
        if (this.fileUploaded.length > 40) {
          this.fileUploadStarted = false;
          this.errorMsgAttach = {
            error:
              {
                message:
                  {
                    description:
                      this._translate.instant('DEWDROPS_CHECKOUT_MAX_UPLOAD_ADD_ATTACHMENTS')
                  }
              }
          };
        }
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        return this.fileUploaded.length <= 40;
      })
      .subscribe((data) => {
        this.fileUploadStarted = false;
        this.fileUploaded = this.service.completeRawFilesUpload(this.fileUploaded, id);
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        if (data.data && data.data.records.length > 0) {
          this.fileUploaded = this.service.retResponse(data.data.records, this.fileUploaded);
        }
        if (data.error) {
          this.errorMsgAttach = {};
          this.errorMsgAttach = {
            error:
              {
                message:
                  {
                    description:
                      this._translate.instant('DEWDROPS_CHECKOUT_SOME_INVALID_FILES_ADD_ATTACHMENTS')
                  }
              }
          };
        }
        this.attachmentObj = [];
        for (let i = 0; i < this.fileUploaded.length; i++) {
          this.attachmentObj.push(this.fileUploaded[i].id);
        }
      },
      errors => {
        this.fileUploaded = this.service.removeRawFilesUpload(this.fileUploaded, id);
        this.fileUploadStarted = false;
        this.errorMsgAttach = errors.error;
      });
  }

  removeAttach(id) {
    this.fileUploaded = this.fileUploaded.filter(el => el.id !== id);
    this.attachmentObj = [];
    for (let i = 0; i < this.fileUploaded.length; i++) {
      this.attachmentObj.push(this.fileUploaded[i].id);
    }
  }

  toggleFSModalState(event) {
    this.showPostModal = false;
  }

  selectUser(user) {
    let name = '@' + user.firstName + ' ' + user.lastName;
    PostCreateComponent.toUsers.push({
      id: user.userId,
      name: name
    });
    return name;
  }

  searchUsers(term) {
    this.searchUserStream.emit(term);
  }

  submit(value) {
    const data = {
      comment: this.comment,
      attachments: this.attachmentObj,
      visibleTo: [],
      userIds: []
    }
    let userIdsTemp = [];
    this.userIds = [];
    this.validate = true;
    if (this.comment) {
      if (!this.isAllModel) {
        for (const key in this.visibleToModel) {
          if (this.visibleToModel[key]) {
            data.visibleTo.push(key);
          }
        }
      }
      PostCreateComponent.toUsers.forEach((v, k) => {
        let i = this.comment.indexOf(v.name);
        if (i > -1) {
          userIdsTemp.push({ id: v.id, seq: i });
        }
      });
      if (userIdsTemp.length) {
        userIdsTemp = userIdsTemp.sort((a, b) => (a.seq - b.seq));
        this.userIds = userIdsTemp.map(item => item.id)
          .filter((value, index, self) => self.indexOf(value) === index);
      }
      data.userIds = this.userIds;
      data.visibleTo = this.isAllModel ? [this.visibleToDefault.key] : data.visibleTo;
      if (data.userIds.length) {
        this.addComment.emit(data);
        this.refreshPost();
      }
    }
  }

  refreshPost() {
    this.userIds = [];
    PostCreateComponent.toUsers = [];
    this.userIds = [];
    this.comment = '';
    this.fileUploaded = [];
    this.attachmentObj = [];
    this.file = [];
    this.validate = false;
  }

  openPostModal(addpostData) {
    this.showPostModal = true;
    this.modalData = addpostData;
  }

  allSelected(target) {
    if (this.allChanged) {
      return this.isAllModel;
    }
    else {
      return this.visibleToModel[target];
    }
  }

  toggleAll() {
    for (const key in this.visibleToModel) {
      this.visibleToModel[key] = this.isAllModel;
    }
  }

  toggleRest() {
    const temp: Array<boolean> = Object.values(this.visibleToModel);
    this.isAllModel = !temp.some(_ => !_);
  }

  getVisibleDDText() {
    let count = 0;
    let selected = '';
    for (const key in this.visibleToModel) {
      if (this.visibleToModel[key]) {
        count++;
        selected = key;
      }
    }
    if (this.isAllModel) {
      return this.visibleToDefault.val;
    }
    else if (count === 1) {
      return this.visibleTo.find(ele => ele.key === selected)['val'];
    }
    else if (count) {
      return 'Multiple';
    }
    return 'None';
  }
}
