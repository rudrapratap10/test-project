/**
 * @module CompositeTaxModule
 *
 * @description This module defines services for managing overlays, dialogs etc as
 * dynamic components.
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormControlModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { UtilitiesModule } from '@dewdrops/core/utilities';
import { TranslateModule } from 'ng2-translate';
import { TaxModule } from '../tax/tax.module';
import { CompositeTaxComponent } from './composite-tax.component';
import { UtilityModule } from '../utility/utility.module';


const declarationsArray = [
  CompositeTaxComponent
];

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    UtilitiesModule,
    ReactiveFormsModule,
    TaxModule,
    FormControlModule,
    GlobalUIModule,
    UtilityModule
  ],
  declarations: declarationsArray,
  exports: declarationsArray,
  entryComponents: [
  ]
})
export class CompositeTaxModule {

}
