import { IParentLineLevelData, ILineItems } from "@dewdrops/common";

export function generateUniqueIdForParent(prefix?: string) : string {
   return 'tmp_' + (prefix ? (prefix + '_') : '') + Math.floor(Math.random() * 1000000001);
}

export function createObjectInLocalStorage(data: IParentLineLevelData) {
    localStorage.setItem(data.parentId, JSON.stringify(data.lineItems));
}

export function updateObjectInLocalStorage(data: IParentLineLevelData) {
    localStorage.removeItem(data.parentId);
    createObjectInLocalStorage(data);
}

export function destroyObjectInLocalStorage(parentId: string){
    localStorage.removeItem(parentId);
}

export function isStorageExistForId(parentId: string): boolean {
    return localStorage.getItem(parentId) !== null;
}

export function getParentLineLevelData(parentId: string): ILineItems[] {
    return JSON.parse(localStorage.getItem(parentId)) as ILineItems[];
}