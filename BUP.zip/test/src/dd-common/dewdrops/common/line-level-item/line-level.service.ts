import { Injectable } from '@angular/core';
import { APIClientService, GetCommonApiService } from '@dewdrops/services';
import { Observable } from 'rxjs/Observable';
import { IParentLineLevelData } from './interface/parent-linelevel-data.interface';

@Injectable()
export class ItemsForInvoicesService {

  constructor(private apiClient: APIClientService,
              private _getCommonApi: GetCommonApiService) { }

  parentLineItemData: IParentLineLevelData;
  getUOM(nm: any, pNo: any): Observable<any> {
    const url = '/api/a/cmd/uom/list';
    const body = {
        name: nm,
        perPageRecords: 3,
        pageNo: pNo
      };

    return this.apiClient.list(url, body);
  }

  getCategory(product: any,val: string, pNo: any): Observable<any> {
    const url = '/api/a/'+product+'/categories/list';
    const body = {
        perPageRecords: 3,
        pageNo: pNo,
        criteriaGroup: {
        logicalOperator: 'AND',
        criteria: [
            {
            fieldName: 'SEARCH_BY_NAME',
            operation: 'CONTAINS',
            value: val
            }
        ]
        }
    };

    return this.apiClient.list(url, body);
  }

  setParentLineItemData(parentLineItemData: IParentLineLevelData) {
    this.parentLineItemData = parentLineItemData;
  }

  getParentLineItemData() {
    return this.parentLineItemData;
  }
}
