export interface ILineLevel {
    itemName: string;
    itemQuantity: number;
    srNo: number;
    marketPrice: number;
    category: string;
    uom: string;
    currency: string;
    itemSubtotal: number;
    lineItemId: string;
    itemno:any;
    type:any;
    desc:string;
    taxes: number;
}