import { ILineItems } from "@dewdrops/common";


export interface IParentLineLevelData {
    parentId;
    lineItems: ILineItems[];
}