import { ILineLevel } from "@dewdrops/common";

export interface ILineItems {
    lineItemData: ILineLevel;
    attachements: string[];
    comment: string;
    lineItemTax: any[],
    contractItemData: number;
    additionalDetailsItem: any[];
}