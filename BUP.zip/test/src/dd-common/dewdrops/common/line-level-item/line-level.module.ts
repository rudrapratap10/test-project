import { NgModule } from '@angular/core';
import {
  RouterModule,
} from '@angular/router';

import {CommonModule} from '@angular/common';
import {GlobalUIModule } from '@dewdrops/bootstrap';
import {DewLineItemComponent} from './line-level.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UtilitiesModule } from '@dewdrops/core/utilities';
import { TranslateModule } from 'ng2-translate';
import { UtilityModule } from '../utility/utility.module';
import { ItemModalComponent } from './item-modal.component';
import { ItemsForInvoicesService } from './line-level.service';


@NgModule({
  imports: [
    RouterModule,
    CommonModule,
    GlobalUIModule,
    TranslateModule,
    FormsModule,
    UtilityModule,
    UtilitiesModule,
    ReactiveFormsModule
  ],
  declarations: [
    DewLineItemComponent,
    ItemModalComponent
  ],
  exports: [
    DewLineItemComponent,
  ],
  providers:[ItemsForInvoicesService]
})
export class DewLineItemModule {
}
