import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { List } from 'lodash';
import { map } from 'rxjs/operators';
import { FormGroup, FormBuilder } from '@angular/forms';
import { APIClientService } from '../../core/services/api-client/api-client.service';
import { of } from 'rxjs/observable/of';
import { CollectionFactory } from '../../core/factories/collection/collection.factory';

@Component({
  selector: 'dew-autocomplete-currency',
  templateUrl: './autocomplete-currency.component.html',
  styleUrls: ['./autocomplete-currency.component.scss']
})
export class AutocompleteCurrencyComponent implements OnInit {

  currencies: any = [];
  currencyModel: any;
  staticArrData: any = [];

  public loader: boolean;

  @Input()
  minLength: number = 1;

  public _datasource: Array<any> | CollectionFactory<any>;
  @Input() set datasource(value: CollectionFactory<any>) {
    this._datasource = value;
    if (this._datasource instanceof Array) {
      this.currencies = this._datasource.map(
        (item, index) => {         
          return item;
        }
      );
      this.staticArrData = this.currencies;
    }
  }

  @Input()
  isLeafNode: boolean;

  @Input()
  freeTextMode: boolean = true;

  @Input()
  searchByActive: boolean;

  @Input()
  requestUserIds: List<String>;

  @Output()
  onSelect = new EventEmitter();

  @Output()
  onInvalid = new EventEmitter();

  @Input() currency: any;

  @Input() currencyFormGroupInstance: FormGroup = this.formBuilder.group({
    currency: [{ value: {}, disabled: false }]
  });

  constructor(private apiClient: APIClientService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    //this.onChanges();
  }

  currencyModelFnFactory() {
    return (data: any) => {
      return data;
    };
  }

  currencyDisplayFn() {
    return (data: any) => {
      return data.name;
    };
  }

  currencyViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  modelValueChanged(form,field){   
    if(!form.get(field).value && !this.freeTextMode){
      this.onInvalid.emit();
    }
  }

  onCurrencyChange() {
    return  (query:  string)  =>  {
      this.loader = true;
      this.currencies =  [];
      if (this._datasource instanceof Array) {      
        this.currencies = this.search(query);
        return of(this.currencies);
      }
      else{     
        if(query.trim().length>0){
        this._datasource.extraParameters["nameORcode"] = query;        
        this._datasource.applyExtraParameters();
        this._datasource.commit();
        }
        if(this.minLength > 0 && query.trim().length == 0){
         
        }
        return   this._datasource.list$.pipe(map(
          (response) =>   {         
            this.loader = false;           
            this.currencies =  response  ?  response.map((currencyModel)  =>
            currencyModel
            )  :  this.currencies;
            return  this.currencies;
          }
        )).catch((error)  =>  {
          this.currencies =  [];
          this.loader = false;
          return  error;
        });
      }

    };

  }

  search(searchedText: string) {   
    if (searchedText) {
      this.currencies = this.staticArrData;
      return this.currencies.filter(
        (dataList) => {
          // case insensitive comparision
          let found = -1;
          const displayName = dataList.name;
          if (displayName) {
            found = displayName.toLowerCase().indexOf(searchedText.toLowerCase());
          }
          return found > -1;
        }
      );
    } else {
      return this.currencies;
    }
  }

  setCurrency(data) {
    this.onSelect.emit(data);
  }
}
