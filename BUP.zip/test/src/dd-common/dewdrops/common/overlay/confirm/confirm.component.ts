import {
  Component,
  Output,
  EventEmitter,
  Input
} from '@angular/core';
import {
  ConfirmDialog,
  ConfirmEventType
} from '../overlay';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ReplaySubject } from 'rxjs/ReplaySubject';

@Component({
  selector: 'dew-confirm',
  templateUrl: './confirm.component.html',
  styleUrls: ['./confirm.component.scss']
})
export class ConfirmComponent implements ConfirmDialog {

  // custom width that can be set to the dialog box
  @Input() maxWidth: string;

  @Input() rejectBtnLabel: string;

  @Input() confirmBtnLabel: string;

  @Input() confirmTxt: string;

  @Input() confirmTitle: string;

  @Input() showCancelBtn: boolean;

  // tslint:disable-next-line:no-output-on-prefix
  @Output() onClear: EventEmitter<any>;

  close$: Subject<any>;

  clearFn: any;

  constructor() {
    this.confirmTxt = '';
    this.confirmTitle = '';
    this.close$ = new ReplaySubject(0);
    this.onClear = new EventEmitter();
  }

  onConfirm() {
    const confirmEvent = {
      type: ConfirmEventType.CONFIRM
    };
    this.close$.next(confirmEvent);
    this.onClear.emit(confirmEvent);
    this.clear();
  }

  onReject() {
    const confirmEvent =  {
      type: ConfirmEventType.REJECT
    };
    this.close$.next(confirmEvent);
    this.onClear.emit(confirmEvent);
    this.clear();
  }

  dismiss(){
    const confirmEvent =  {
      type: ConfirmEventType.DISMISS
    };
    this.close$.next(confirmEvent);
    this.onClear.emit(confirmEvent);
    this.clear();
  }

  clear (): void {
    if (this.clearFn) {
      this.clearFn();
    }
  }

  registerClearFn(clearFn: any): void {
    this.clearFn = clearFn;
  }

}
