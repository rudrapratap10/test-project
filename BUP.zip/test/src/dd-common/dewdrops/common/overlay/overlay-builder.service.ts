import { Injectable, ViewContainerRef } from '@angular/core';
import { OverlayService } from './overlay.service';
import { ProgressOverlayComponent } from './progress-overlay/progress-overlay.component';
import { AlertComponent } from './alert/alert.component';
import {
  AlertDialog,
  ConfirmDialog,
  ConfirmEventType,
  ConfirmEvent,
  AlertErrorHandlerEvent
} from './overlay';
import { ConfirmComponent } from './confirm/confirm.component';

/**
 *
 */
@Injectable()
export class CommonOverlayBuilder {

  constructor(private _overlayService: OverlayService) {
  }

  alert(type: string, viewContainerRef?: ViewContainerRef) {
    return (options: any) => {
      options.type = type;
      let errorAlert;
      if (viewContainerRef) {
        errorAlert = this._overlayService.createIn(
          viewContainerRef
        )(AlertComponent);
      } else {
        try {
          errorAlert = this._overlayService.create(AlertComponent);
        } catch (e) {
          console.error(e);
          return ;
        }
      }

      (errorAlert as AlertComponent).errorHandler = options.errorHandler;
      (errorAlert as AlertComponent).autoClose = options.autoClose || false;
      (errorAlert as AlertComponent).closeIn = options.closeIn || 0;
      (errorAlert as AlertComponent).alertText = options.alertText;
      (errorAlert as AlertComponent).alertTitle = options.alertTitle;
      (errorAlert as AlertComponent).type = options.type;
      (errorAlert as AlertComponent).mainActionBtnLabel = options.btnText;
      (errorAlert as AlertComponent).clearBtnLabel = options.clearBtn;
      return (errorAlert as AlertComponent);
    };
  }

  confirm(viewContainerRef?: ViewContainerRef) {
    return (options: any) => {
      let confirmDialog;
      if (viewContainerRef) {
        confirmDialog = this._overlayService.createIn(
          viewContainerRef
        )(ConfirmComponent);
      } else {
        try {
          confirmDialog = this._overlayService.create(ConfirmComponent);
        } catch (e) {
          console.error(e);
          return ;
        }
      }

      (confirmDialog as ConfirmComponent).close$.subscribe(
        (event: ConfirmEvent) => {
          if (event.type === ConfirmEventType.CONFIRM) {
            options.confirmFn = options.confirmFn || function() {};
            options.confirmFn();
          }
          if (event.type === ConfirmEventType.REJECT) {
            options.rejectFn = options.rejectFn || function() {};
            options.rejectFn();
          }
        }
      );
      (confirmDialog as ConfirmComponent).confirmTitle = options.confirmTitle;
      (confirmDialog as ConfirmComponent).confirmTxt = options.confirmTxt;
      (confirmDialog as ConfirmComponent).confirmBtnLabel = options.confirmBtnLabel;
      (confirmDialog as ConfirmComponent).rejectBtnLabel = options.rejectBtnLabel;
      (confirmDialog as ConfirmComponent).showCancelBtn = options.showCancelBtn;
      return (confirmDialog as ConfirmDialog);
    };
  }

  confirmStream(viewContainerRef?: ViewContainerRef) {
    return (options: any) => {
      let confirmDialog;
      if (viewContainerRef) {
        confirmDialog = this._overlayService.createIn(
          viewContainerRef
        )(ConfirmComponent);
      } else {
        try {
          confirmDialog = this._overlayService.create(ConfirmComponent);
        } catch (e) {
          console.error(e);
          return ;
        }
      }
      confirmDialog.confirmTxt = options.confirmTxt;
      confirmDialog.confirmBtnLabel = options.confirmBtnLabel;
      confirmDialog.rejectBtnLabel = options.rejectBtnLabel;
      confirmDialog.confirmTitle = options.confirmTitle;
      return confirmDialog.close$;
    };
  }

  error(viewContainerRef?: ViewContainerRef) {
    return this.alert('failure', viewContainerRef);
  }

  progress(viewContainerRef?: ViewContainerRef):
  (string) => ProgressOverlayComponent {
  return (helpText: string) => {
    let progressOverlay;
    if (viewContainerRef) {
      progressOverlay = this._overlayService.createIn(
        viewContainerRef
      )(ProgressOverlayComponent);
    } else {
      try {
        progressOverlay = this._overlayService.create(ProgressOverlayComponent);
      } catch (e) {
        console.error(e);
        return ;
      }
    }

    (progressOverlay as ProgressOverlayComponent).spinnerText = helpText;
    return (progressOverlay as ProgressOverlayComponent);
  };
}

  success (viewContainerRef?: ViewContainerRef) {
    return this.alert('success', viewContainerRef);
  }


  warning(viewContainerRef?: ViewContainerRef) {
    return this.alert('warning', viewContainerRef);
  }

}
