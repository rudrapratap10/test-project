import {
  Injectable,
  ComponentFactoryResolver,
  Injector,
  ViewContainerRef,
  Inject,
  Optional,
  Type
} from '@angular/core';
import { OverlayService } from './overlay.service';
import {
  DEW_ALERT_DLG,
  ConfirmDialog,
  AlertDialog,
  DEW_CONFIRM_DLG,
} from './overlay';
import { LocationService } from './location.service';

@Injectable()
export class DialogService extends OverlayService {

  constructor(
    componentFactoryResolver: ComponentFactoryResolver,
      @Optional()
      @Inject(DEW_ALERT_DLG)
      private alertDialog: Type<AlertDialog>,
      @Optional()
      @Inject(DEW_CONFIRM_DLG)
      private confirmDialog: Type<ConfirmDialog>,
     _locationService: LocationService
    ) {
    super(componentFactoryResolver, _locationService);
  }

  confirm(confirmTxt: string, confirmBtnLabel: string, rejectBtnLabel: string) {
    if (this.confirmDialog) {
      return (confirmFn: () => void, rejectFn: () => void) => {
        const dialog = this.create(this.confirmDialog);
        dialog.confirmTxt = confirmTxt;
        dialog.confirmBtnLabel = confirmBtnLabel;
        dialog.rejectBtnLabel = rejectBtnLabel;
        /* dialog.close$.subscribe(
          (event: ConfirmEvent) => {
            if (event.type === ConfirmEventType.CONFIRM) {
              confirmFn = confirmFn || function() {};
              confirmFn();
            }
            if (event.type === ConfirmEventType.CANCEL) {
              rejectFn = rejectFn || function() {};
              rejectFn();
            }
          }
        ); */
        return dialog;
      };
    } else {
      throw new Error(`No class provided for confirm dialog,
        please ensure that the class is registered as ${DEW_CONFIRM_DLG}`);
    }
  }

  confirmStream(confirmTxt: string, confirmBtnLabel: string, rejectBtnLabel: string) {
    return () => {
      const dialog = this.create(this.confirmDialog);
      dialog.confirmTxt = confirmTxt;
      dialog.confirmBtnLabel = confirmBtnLabel;
      dialog.rejectBtnLabel = rejectBtnLabel;
      return dialog.close$;
    };
  }

  alert(alertTxt: string) {
    if (this.alertDialog) {
      const dialog = this.create(this.alertDialog);
      dialog.alertText = alertTxt;
      return dialog;
    }
  }
}
