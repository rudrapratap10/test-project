import {
  Component
} from '@angular/core';
import { Overlay } from '../overlay';

@Component({
  selector: 'dew-progress-overlay',
  templateUrl: './progress-overlay.component.html',
  styleUrls: ['./progress-overlay.component.scss']
})
export class ProgressOverlayComponent implements Overlay {

  public spinnerText: string;

  private _clearFn;

  constructor() {}

  clear() {
    if (this._clearFn) {
      this._clearFn();
    }
  }

  registerClearFn(clearFn: any): void {
    this._clearFn = clearFn;
  }
}
