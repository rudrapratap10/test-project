import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IAttachmentApiOptions } from './models/attachment-api-options.model';

@Component({
  selector: 'dew-attachment',
  templateUrl: './attachment.component.html',
  styleUrls: ['./attachment.component.scss']
})
export class AttachmentComponent implements OnInit {

  /**
   * @default add
   * @example 'view' or 'add'
   */
  @Input()
  mode = 'add';

  @Input()
  attachmentApiOptions: IAttachmentApiOptions;

  @Input()
  canAddDetails: boolean;

  @Input()
  attachmentList: string[];

  @Input()
  enableWebLink: boolean;

  @Output()
  createAttachmentIds: EventEmitter<string[]> = new EventEmitter<string[]>();

  @Output()
  createAttachmentObjects: EventEmitter<any[]> = new EventEmitter<any[]>();

  constructor() { }

  ngOnInit() {
  }

}
