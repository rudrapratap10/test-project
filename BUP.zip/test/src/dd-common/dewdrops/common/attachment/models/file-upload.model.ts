export class FileUploadModel {
  id: string;
  path: string;
  type: string;
  percentageUploaded: number;
  size: number;
  name: string;
  uploaded: boolean;
  totalUploaded: number;

  constructor() {
    this.percentageUploaded = 0;
    this.size = 0;
    this.name = '';
    this.uploaded = false;
    this.totalUploaded = 0;
  }
}
