import { HttpEventType, HttpHeaders, HttpParams, HttpRequest, HttpResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AUTH_API } from '@dewdrops/globals';
import { LanguageTranslateService, RestClientService, UserService } from '@dewdrops/services';
import { each } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { Observable } from 'rxjs/Observable';
import { Attachment } from '../enums/attachment.enum';
import { IAttachmentApiOptions } from '../models/attachment-api-options.model';
import { AttachmentVisibilityOptions } from '../models/attachment-visibility-options.model';
import { AttachmentModel } from '../models/attachment.model';
import { FileSupportedFormat } from '../models/file-type.model';
import { FileUploadModel } from '../models/file-upload.model';
import { AttachmentService } from '../service/attachment.service';

@Component({
  selector: 'dew-add-attachments',
  templateUrl: './add-attachments.component.html',
  styleUrls: ['./add-attachments.component.scss'],
  providers: [AttachmentService, LanguageTranslateService]
})
export class AddAttachmentsComponent implements OnInit {

  @Input()
  attachmentApiOptions: IAttachmentApiOptions;

  @Input()
  canAddDetails: boolean;

  @Input()
  attachmentList: string[];

  @Input()
  enableWebLink: boolean;

  @Output()
  createAttachmentIds: EventEmitter<string[]>;

  @Output()
  createAttachmentObjects: EventEmitter<any[]>;

  @ViewChild('webLink') webLink: ElementRef;

  public attachmentVisibilityOptions: AttachmentVisibilityOptions;
  public fileUploadObj: FileUploadModel = new FileUploadModel();
  public visibilityRadioOptions: Array<{ label: string, value: string }>;
  public path: string;
  public isFileLimitExceeded: boolean;
  public indexFileOpen: number;

  public fileUploadStart: boolean;
  public isInvalidURL: boolean;
  public isFileEmpty: boolean;
  public isFileUploadValid = true;
  public supportedFileFormat: any;
  public invalidFile: boolean;

  public fileUploadCharacterLimit = false;
  public fileUploaded = [];
  public uploadedFileToBackend = [];
  public uploadedFile = {};
  public tempCurrentfile: any;

  readonly MAXUPLOADS = 10;

  constructor(
    private _translate: TranslateService,
    private _language: LanguageTranslateService,
    private _userService: UserService,
    private rest: RestClientService,
    private _attachService: AttachmentService) {

    this.attachmentVisibilityOptions = new AttachmentVisibilityOptions(this._translate);
    this.createAttachmentIds = new EventEmitter<string[]>();
    this.createAttachmentObjects = new EventEmitter<any[]>();
    this._language.switchLanguage(_userService.locale);

  }

  ngOnInit() {
    this.supportedFileFormat = FileSupportedFormat.commonFileUploadFormat;
    this._attachService.attachmentObj = [];
    if (!this.attachmentList) {
      this.attachmentList = [];
    }
    this.getExistingFileDetails(this.attachmentList);
  }

  validateURL(path) {
    let urlValidationStr = path.trim();
    if (urlValidationStr.length === 0) {
      return true;
    }
    if (!/^(https?|ftp):\/\//i.test(urlValidationStr)) {
      urlValidationStr = 'http://' + urlValidationStr;
      this.path = urlValidationStr;
    }
    // tslint:disable-next-line:max-line-length
    return /^(ftp|https?)?(:\/\/)?(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})|((|([A-Za-z0-9\.]+)\.)([A-Za-z0-9\.]+[\-]*[\.A-Z0-9a-z]+)\.([A-Za-z\-\.]+[A-za-z]+)))(\:[0-9]+)?($|(\/|\?|#)[A-Za-z0-9\!\*\'\(\%\)\;\:\@\&\=\+\$\,\/\?\#\[\]\-\_\.\~]*)?$/.test(urlValidationStr);
  }

  addWebLink() {
    if (this._attachService.attachmentObj.length + 1 > this.MAXUPLOADS) {
      this.isFileLimitExceeded = true;
      const removeAlerts = Observable.timer(3000);
      removeAlerts.subscribe(() => {
        this.isFileLimitExceeded = false;
      });
      return;
    }
    this.path = this.webLink.nativeElement.value;
    if (this.path === '') {
      return;
    }
    if (!this.validateURL(this.path)) {
      this.isInvalidURL = true;
      const removeAlerts = Observable.timer(3000);
      removeAlerts.subscribe(() => {
        this.isInvalidURL = false;
      });
      return;
    } else {
      this.isInvalidURL = false;
    }
    let webLinkName;
    this._translate.get('DEWDROPS_WEBLINK_FILENAME').subscribe(
      (translatedValue: string) => {
        webLinkName = translatedValue;
      });
    const webItem = new AttachmentModel('', webLinkName,
      0, this.path, Attachment.WEBLINK, '', false);
    this.fileUploaded.push(webItem);
    // this._changeDetectorRef.detectChanges();
    this.webLink.nativeElement.value = '';
    const body = this.attachmentApiOptions.weblink.body;
    body.path = this.path;
    this._attachService.addWeblink(this.attachmentApiOptions.weblink.url, body);
  }

  getExistingFileDetails(attachmentArr) {
    for (const attachment of attachmentArr) {
      const tempAttachmentArr = [];
      const options: any = {};
      options.url = `${this.attachmentApiOptions.getAttachmentDetailsById.url}/${attachment}`;
      options.method = this.attachmentApiOptions.getAttachmentDetailsById.method;
      // const url = copy.url.replace(':', attachmentArr[i]);
      // copy.url = url;
      this.rest.request(options).subscribe((response) => {
        tempAttachmentArr.push(new AttachmentModel(
          response.data.attachmentId,
          response.data.name,
          response.data.fileSize,
          response.data.path,
          response.data.type,
          '',
          false));
        this.fileUploaded = this.retResponse(tempAttachmentArr, this.fileUploaded);
        this.updateAttachServiceObj(this.fileUploaded);
        // this._changeDetectorRef.detectChanges();
      });
    }
  }

  saveAttachment(attachmentId, visibility, comments) {
    this.attachmentVisibilityOptions.attachModal = false;
    this.rest.request(this.attachmentApiOptions.updateorSaveAttachment).subscribe((response) => {
    });
    this._attachService.attachmentObj[this.indexFileOpen].comments = comments;
    this._attachService.attachmentObj[this.indexFileOpen].visibility = visibility;
    this.fileUploaded[this.indexFileOpen].comments = comments;
    this.fileUploaded[this.indexFileOpen].visibility = visibility;
    this.fileUploaded[this.indexFileOpen].saved = true;
  }

  public toggleModalState(state, fileObject, index, attachmentId): void {
    this.addVisibilityOption();
    if (state === false) {
      this.uploadedFile = {};
    } else {
      this.uploadedFile = fileObject;
      this.getuploadedfileDetails(attachmentId);
      this.indexFileOpen = index;
    }
    this.attachmentVisibilityOptions.attachModal = state;
  }

  fileSelected(event) {
    const currentFile = event.currentFile;
    this.isFileLimitExceeded = false;
    if (currentFile.length > 0) {
      this.fileUploadCharacterLimit = false;
      // tslint:disable-next-line:no-shadowed-variable
      for (let i = 0; i < currentFile.length; i++) {
        if (!this.validateAttachment(currentFile[i])) {
          currentFile.splice(i, 1);
        }
      }

      if (currentFile.length === 0) {
        this.fileUploadCharacterLimit = true;
      } else {
        this.fileUploadCharacterLimit = false;
      }

      if (this._attachService.attachmentObj.length + currentFile.length > this.MAXUPLOADS) {
        this.isFileLimitExceeded = true;
      }

      if (!this.fileUploadCharacterLimit && !this.isFileLimitExceeded) {
        // tslint:disable-next-line:prefer-for-of
        for (let i = 0; i < currentFile.length; i++) {
          const fileArr = [];
          fileArr.push(currentFile[i]);

          this.uploadAttachment(fileArr, 'headerAttachment');

        }
      }
    }
    const removeAlerts = Observable.timer(3000);
    removeAlerts.subscribe(() => {
      this.isFileLimitExceeded = false;
      this.fileUploadCharacterLimit = false;
    });
  }

  validateAttachment(currentFile) {
    const ext = this.getFileExtension(currentFile);
    if (this.supportedFileFormat.indexOf(ext) === -1) {
      this.invalidFile = true;
      return false;
    }
    this.isFileUploadValid = false;
    if (currentFile.name.length > 255) {
      this.fileUploadCharacterLimit = true;
    } else if (currentFile.size === 0) {
      this.isFileEmpty = true;
    } else if (currentFile.size >= 10000) {
      this.isFileLimitExceeded = true;
    } else {
      this.isFileUploadValid = true;
    }
    return this.isFileUploadValid;
  }

  getFileExtension(uploadedFile) {
    return uploadedFile.name.substr(uploadedFile.name.lastIndexOf('.') + 1, uploadedFile.name.length).toLowerCase();
  }

  public uploadAttachment(files, moduleName) {
    if (moduleName === 'headerAttachment') {
      each(files, (file) => {
        this.fileUploadStart = true;
        this.fileUploadObj.percentageUploaded = 0;
        this.fileUploadObj.totalUploaded = 0;
        this.setAttachmentOneByOne(file).subscribe(
          (data) => {
            if (data.type === HttpEventType.UploadProgress) {
              this.fileUploadObj.percentageUploaded = Math.round(100 * data.loaded / data.total);
              this.fileUploadObj.totalUploaded = +(this.fileUploadObj.percentageUploaded *
                (this.fileUploadObj.size / 100)).toFixed(2);
            } else if (data instanceof HttpResponse) {
              this.fileUploadStart = false;
              this.fileUploadObj.uploaded = true;
              this.fileUploadObj.id = data.body.data.records[0].id;
              this.fileUploadObj.path = data.body.data.records[0].path;
              this.fileUploadObj.type = data.body.data.records[0].type;
              if (data.body.data && data.body.data.records.length > 0) {
                this.fileUploaded = this.retResponse(data.body.data.records, this.fileUploaded);
              }
              this.updateAttachServiceObj(this.fileUploaded);
            }
          });
        return this.fileUploadObj;
      });
    }
  }

  setAttachmentOneByOne(file): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', file.file);
    const requestOptions = {
      params: new HttpParams()
    };
    const url = `${AUTH_API}/${this.attachmentApiOptions.updateorSaveAttachment.url}`;
    const req = new HttpRequest(this.attachmentApiOptions.updateorSaveAttachment.method, url, formData, {
      reportProgress: true,
      headers: this.attachmentApiOptions.updateorSaveAttachment.httpHeaders
    });
    return this._attachService.addAttachmentOneByOne(req);
  }

  public setAttachment(files): Observable<any> {
    const formData: FormData = new FormData();
    for (const file of files) {
      formData.append('file', file.file);
    }
    return this._attachService.uploadAttachment(
      `${AUTH_API}/${this.attachmentApiOptions.updateorSaveAttachment.url}`, formData, {
      reportProgress: true,
      headers: this.attachmentApiOptions.updateorSaveAttachment.httpHeaders
    });
  }

  downloadAttachment(filePath, fileType) {
    try {
      if (fileType === Attachment.WEBLINK) {
        window.open(filePath, '_blank');
      }
      const url = `${AUTH_API}/${this.attachmentApiOptions.downloadAttachment.url}/`;
      window.open(`${url}${filePath}`);
    } catch (ex) {
      // to do
    }

  }

    //delete attachment
    deleteAttachment(attachmentId) {
      const url = `${AUTH_API}/${this.attachmentApiOptions.deleteAttachment.url}/${attachmentId}`;
      this._attachService.deleteAttachment(url).subscribe((res) => {
        for (let i = 0; i < this.fileUploaded.length; i++) {
          if (attachmentId === this.fileUploaded[i].path) {
            this.fileUploaded.splice(i, 1);
            this._attachService.attachmentObj.splice(i, 1);
          }
        }
        this.updateAttachServiceObj(this.fileUploaded);
      });
  }

  public getuploadedfileDetails(attachmentId) {
    this.uploadedFileToBackend = [];
    this.attachmentApiOptions.getAttachmentDetailsById.url =
    `${this.attachmentApiOptions.getAttachmentDetailsById.url}/${attachmentId}`;
    this.rest.request(this.attachmentApiOptions.getAttachmentDetailsById).subscribe((response) => {
      this.uploadedFileToBackend = response.data;
      // this._changeDetectorRef.detectChanges();
    });
  }

  updateAttachServiceObj(attachmentInfo: any[]) {
    this._attachService.attachmentObj = [];
    const attachmentId = [];
    for (let i = 0; i < attachmentInfo.length; i++) {
      this._attachService.attachmentObj.push({
        attachmentId: '',
        comments: '',
        visibility: this.attachmentVisibilityOptions.attachmentVisibilityInternal
      });
      this._attachService.attachmentObj[i].attachmentId = attachmentInfo[i].id;
      // this._changeDetectorRef.detectChanges();
      attachmentId.push(attachmentInfo[i].id);
    }
    this.createAttachmentIds.emit(attachmentId);
    this.createAttachmentObjects.emit(this.fileUploaded);
  }

  retResponse(input, output) {
    const res = input.map((element: AttachmentModel) => {
      return {
        id: element.id,
        name: element.name,
        size: (element.size / 1024).toFixed(2),
        path: element.path,
        type: element.type,
        max: 2000,
        saved: false,
        comments: '',
        visibility: this.attachmentVisibilityOptions.attachmentVisibilityInternal
      };
    });
    return [...output, ...res];
  }

  addVisibilityOption() {
    this.visibilityRadioOptions = [];
    this.visibilityRadioOptions.push({
      value: this.attachmentVisibilityOptions.attachmentVisibilityInternal,
      label: this.attachmentVisibilityOptions.attachmentLabelInternal,
    },
      {
        value: this.attachmentVisibilityOptions.attachmentVisibilitySupplier,
        label: this.attachmentVisibilityOptions.attachmentLabelSupplier
      });
  }

}
