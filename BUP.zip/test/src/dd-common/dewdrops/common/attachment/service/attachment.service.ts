import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AUTH_API } from '@dewdrops/globals';
import { APIClientService } from '@dewdrops/services';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AttachmentService {

  public attachEditFlag = false;
  public attachmentObj = [];
  public fileList = [];

  constructor(
    private http: HttpClient,
    private _apiClient: APIClientService) { }

  addWeblink(url: string, body: any) {
    this.http.post(`${AUTH_API}/${url}`, body).subscribe((res: any) => {
      if (res.statusCode !== 200) {
        // console.log(res);
      }
    });
  }

  public copyApi(productName?: string) {
    const copyApiParams: any = {};
    const attachmentIds = [];
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.attachmentObj.length; i++) {
      attachmentIds.push(this.attachmentObj[i].attachmentId);
    }
    if (attachmentIds.length > 0) {
    copyApiParams.ids = attachmentIds;
    this._apiClient.create(`api/a/${productName}/attachments/copy`, copyApiParams).subscribe((res) => {});
    }
  }

  public addAttachmentOneByOne(request) {
    return this.http.request(request)/* .catch(error => Observable.throw(error)) */;
  }

  public uploadAttachment(url, body, options) {
    return this.http.post(url, body, options).catch((error) => Observable.throw(error));
  }

  public deleteAttachment(url): Observable<any>{
    return this.http.delete(url);
  }
}
