export class SupplierDetails {

    supplierName:suppllierInfoFormItem;
      payment:suppllierInfoFormItem;
      address: suppllierInfoFormItem;
      remitAddress: suppllierInfoFormItem;
      currency:suppllierInfoFormItem;
      contact:suppllierInfoFormItem;
      refrenceNo: suppllierInfoFormItem;
      supplierERPid: suppllierInfoFormItem;
      abnNumnber : suppllierInfoFormItem;
      isTaxExempt : suppllierInfoFormItem;
    constructor(type, inputObj?)
    {
    this.supplierName = new suppllierInfoFormItem({label: 'Buyer', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.supplierName.value : ''});
    this.address =  new suppllierInfoFormItem({label: 'Address', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.address.value : ''});
    this.remitAddress = new suppllierInfoFormItem({label: 'RemitAddress', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.remitAddress.value : ''});
    this.currency = new  suppllierInfoFormItem({label: 'Payment', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.currency.value : ''});
    this.contact = new suppllierInfoFormItem({label: 'Contact', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.contact.value : ''});
    this.refrenceNo = new suppllierInfoFormItem({label: 'Reference No', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.refrenceNo.value : ''});

    if (type === '1' ) {
         this.payment = new suppllierInfoFormItem({label: 'Payment', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.payment.value : ''});
    }
    else if (type === '2' || type === '3' )
    {
         this.supplierERPid = new suppllierInfoFormItem({label: 'Supplier ERP Id', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.supplierERPid.value : ''});
    }
    else{
        this.abnNumnber = new suppllierInfoFormItem({label: 'ABN Number', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.abnNumnber.value : ''});
        this.isTaxExempt = new  suppllierInfoFormItem({label: 'Is Tax Atempt', disable : true,mandatory: true, visible : true ,value: inputObj ? inputObj.isTaxExempt.value : ''});    
    }
      
    }
  };

  export class suppllierInfoFormItem {
    label: string;
    disable : boolean;
    mandatory: boolean;
    visible : boolean;
    value: string;
    constructor(data) {
      this.label =  data.label;
      this.disable = data.disable;
      this.mandatory = data.mandatory;
      this.visible = data.visible;
      this.value = data.value;

    }
  }
