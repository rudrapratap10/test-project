import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AutocompleteSupplierAddressComponent } from './autocomplete-supplier-address.component';
import { AddressViewModule } from '../address-view/address-view.module';
import { TranslateModule } from 'ng2-translate';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule } from '../../core/bootstrap/autocomplete/autocomplete.module';
import { ProgressModule } from '../../core/bootstrap/progress/progress.module';
import { ExtendModule } from '../../core/bootstrap/extend/extend.module';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';


@NgModule({
  imports: [
    CommonModule,
    AutoCompleteModule,
    AddressViewModule,
    TranslateModule,
    ProgressModule,
    FormsModule,
    ReactiveFormsModule,
    ExtendModule,
    LayoutModule
  ],
  declarations: [AutocompleteSupplierAddressComponent],
  exports: [AutocompleteSupplierAddressComponent]
})
export class AutoCompleteSupplierAddressModule { }
