import { Component, OnInit, ViewChild, Input, AfterViewInit, Output, EventEmitter, AfterContentInit, OnDestroy, ElementRef } from '@angular/core';
import { CollectionFactory } from '../../core/factories';
import { FormGroup, FormBuilder } from '@angular/forms';
import { map } from 'rxjs/operators';
import { Subscriber } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { includes, filter, indexOf } from 'lodash';
import { SupplierAddressService } from '../address-view/supplier-address-view/supplier-address.service';

@Component({
  selector: 'dew-autocomplete-supplier-address',
  templateUrl: './autocomplete-supplier-address.component.html',
  styleUrls: ['./autocomplete-supplier-address.component.scss']
})
export class AutocompleteSupplierAddressComponent {

  supplierAddressList: any = [];
  supplierAddressModel: any;
  staticArrData: any = [];

  public loader: boolean;

  public _datasource: Array<any> | CollectionFactory<any>;
  @Input() set datasource(value: CollectionFactory<any>) {
    this._datasource = value;
    if (this._datasource instanceof Array) {
      this.supplierAddressList = this._datasource.map(
        (item, index) => {
          return item;
        }
      );
      this.staticArrData = this.supplierAddressList;
    }
  }

  @Input()
  minLength: number = 0;

  @Input()
  format: string = "SINGLE"; //SINGLE or MULTILINE

  addressViewFormat: string = 'LINE';

  @Output()
  public onSelected = new EventEmitter();

  @Input() supplierAddressObj: any;

  @Input() saFormGroupInstance: FormGroup = this.formBuilder.group({
    supplierAddressObj: [{ value: {}, disabled: false }]
  });

  @ViewChild("supplierAddressInput")
  supplierAddressInput: ElementRef;

  constructor(private formBuilder: FormBuilder, private supplierAddrService: SupplierAddressService) {
    
  }

  saDisplayFn() {
    return (data: any) => {
      return this.generateViewValue(data);
    };
  }

  saModelFnFactory() {
    return (data: any) => {
      this.supplierAddressModel = data;
      return data;
    };
  }

  setInputFocus() {  
    this.supplierAddressInput.nativeElement.focus();
  }

  saViewToModelTranformFactoryFn() {
    return (value: string, model: any) => {
      if (!model) {
        model = {};
      }
      console.log(model,value);
      model = value;
      return model;
    };
  }

  modelValueChanged(form, field) {
    if (!form.get(field).value) {
      this.supplierAddressModel = null;
      this.onSelected.emit(null);
    }
  }

  generateViewValue(d) {
    return this.supplierAddrService.generateLine1Address(d);
  }

  suggestionStreamFactoryFn() {

    return (query: string) => {

      this.loader = true;
      this.supplierAddressList = [];
      if (this._datasource instanceof Array) {

        if (this.supplierAddressModel) {

          this.supplierAddressList = this.staticArrData.filter((o) => {
            const hasChar = this.supplierAddrService.generateAddressString(o).toLowerCase().includes(query.toLowerCase());
            return hasChar;
          });

        }
        else {
          this.supplierAddressList = this.search(query);
        }

        this.loader = false;
        return of(this.supplierAddressList);
      }
      else {
        return this._datasource.list$.pipe(map(
          (response) => {
            this.loader = false;
            this.supplierAddressList = response ? response.map((currencyModel) =>
              currencyModel
            ) : this.supplierAddressList;
            return this.supplierAddressList;
          }
        )).catch((error) => {
          this.supplierAddressList = [];
          this.loader = false;
          return error;
        });
      }

    };

  }

  search(searchedText: string) {
    this.supplierAddressList = this.staticArrData;
    if (searchedText) {
      try {

        return this.supplierAddressList.filter((o) => {
          const hasChar = this.supplierAddrService.generateAddressString(o).toLowerCase().includes(searchedText.toLowerCase());
          return hasChar;
        });

      }
      catch (e) {
        console.log(e);
      }
    } else {
      return this.supplierAddressList;
    }
  }

  setSupplierAddress(data) {
    this.onSelected.emit(data);
  }

  generateSingleLineAddress(value): any {
    return this.supplierAddrService.generateSingleLineAddress(value);
  }

}
