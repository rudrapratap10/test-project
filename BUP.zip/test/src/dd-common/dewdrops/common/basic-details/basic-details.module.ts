/**
 * @module SupplierModule
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { GlobalUIModule } from '../../core/bootstrap/global-ui.module';
import { TranslateModule } from 'ng2-translate';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DewBasicEinvoiceDetailsComponent } from './basic-details.component';

const declarationsArray = [
    DewBasicEinvoiceDetailsComponent
];

@NgModule({
  imports: [CommonModule,
            GlobalUIModule,
            TranslateModule,
            FormsModule,
            ReactiveFormsModule],
  declarations: declarationsArray,
  providers: [
    
  ],
  exports: declarationsArray,
  entryComponents: [
  ]
})
export class BasicEinvoiceDetailModule {

}
