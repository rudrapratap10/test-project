export class CreateBasicDetails {
    invoiceNumber: BasicDetailsFormItem;
    buyerName: BasicDetailsFormItem | string;
    buyerId: BasicDetailsFormItem;
    requesterName: BasicDetailsFormItem | string;
    requesterId: BasicDetailsFormItem;
    invoiceDate: BasicDetailsFormItem;
    invoiceDueDate: BasicDetailsFormItem;
    discountDueDate: BasicDetailsFormItem;
    purchaseType: BasicDetailsFormItem;
    purchaseTypeCode: BasicDetailsFormItem;
    discountDays : BasicDetailsFormItem;
    invoiceDescription: BasicDetailsFormItem;
    note: BasicDetailsFormItem;
    creditMemoNumber:BasicDetailsFormItem;
    creditMemoDate : BasicDetailsFormItem;
    refference : BasicDetailsFormItem;
    creditMemoDescription :BasicDetailsFormItem;
    creditDays : BasicDetailsFormItem;
    purchase : BasicDetailsFormItem;
    constructor(type, inputObj?)
    {
      this.buyerName = new BasicDetailsFormItem({label: 'Buyer', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.buyerName ? inputObj.buyerName.value : ''});
      this.requesterName = new BasicDetailsFormItem({label: 'Requester', disable : inputObj.requesterName.disable,mandatory: true, visible : true ,value:inputObj && inputObj.requester ? inputObj.requester.value : ''});
      this.purchaseType  = new BasicDetailsFormItem({label: 'Purchase type', disable : inputObj.purchaseType.disable,mandatory: true, visible : inputObj.purchaseType.visible ,value: inputObj && inputObj.purchaseType ? inputObj.purchaseType.value : ''});
      this.purchaseTypeCode = new BasicDetailsFormItem({label: 'code', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.purchaseTypeCode ? inputObj.purchaseTypeCode.value : ''});
      this.note = new BasicDetailsFormItem({label: 'Notes', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.notes ? inputObj.notes.value : ''})
      this.purchase = new BasicDetailsFormItem({label: 'purchase', disable : true,mandatory: true, visible : inputObj.purchase.visible ,value: inputObj && inputObj.purchase ? inputObj.purchase.value : ''})
      if (type === '1') {
        this.invoiceNumber = new BasicDetailsFormItem({label: 'Invoice Number', disable : true,mandatory: true, visible : true ,value:inputObj && inputObj.invoiceNumber ? inputObj.invoiceNumber.value : '' });
        this.invoiceDate = new BasicDetailsFormItem({label: 'Invoice date', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.invoiceDate ? inputObj.invoiceDate.value : null});
        this.invoiceDueDate   = new BasicDetailsFormItem({label: 'Invoice due date', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.invoiceDueDate ? inputObj.invoiceDueDate.value : null});
        this.discountDueDate   = new BasicDetailsFormItem({label: 'Discount due date', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.discountDueDate ? inputObj.discountDueDate.value : null});
        this.invoiceDescription = new BasicDetailsFormItem({label: 'Invoice description', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.invoiceDescription ? inputObj.invoiceDescription.value : ''});     
        this.creditDays = new BasicDetailsFormItem({label: '', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.creditDays ? inputObj.creditDays.value : ''});
        this.discountDays = new BasicDetailsFormItem({label: '', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.discountDays ? inputObj.discountDays.value : ''});
      }
      else
      {
        this.creditMemoNumber =new BasicDetailsFormItem({label: 'Credit memo Number', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.creditMemoNumber ? inputObj.creditMemoNumber.value : ''});
        this.creditMemoDate     = new BasicDetailsFormItem({label: 'Credit Memo date', disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.creditMemoDate ?  inputObj.creditMemoDate.value : null});
        this.refference  =  new BasicDetailsFormItem({label: 'Reference no', disable : inputObj && inputObj.refference ? inputObj.refference.disable : true,mandatory: true, visible : true ,value: inputObj && inputObj.refference ? inputObj.refference.value : ''}),
        this.creditMemoDescription = new BasicDetailsFormItem({label: 'Credit Memo Description', disable : true,mandatory: true, visible : true ,value:inputObj && inputObj.creditMemoDescription ?  inputObj.creditMemoDescription.value : ''});
      }
    }
  };

  export class BasicDetailsFormItem {
    label: string;
    disable : boolean;
    mandatory: boolean;
    visible : boolean;
    value: string;
    constructor(data) {
      this.label =  data.label;
      this.disable = data.disable;
      this.mandatory = data.mandatory;
      this.visible = data.visible;
      this.value = data.value;

    }
  }
