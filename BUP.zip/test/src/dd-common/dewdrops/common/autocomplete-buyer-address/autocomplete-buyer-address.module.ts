import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AutocompleteBuyerAddressComponent } from './autocomplete-buyer-address.component';
import { AddressViewModule } from '../address-view/address-view.module';
import { TranslateModule } from 'ng2-translate';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutoCompleteModule } from '../../core/bootstrap/autocomplete/autocomplete.module';
import { ProgressModule } from '../../core/bootstrap/progress/progress.module';

@NgModule({
  imports: [
    CommonModule,
    AutoCompleteModule,
    AddressViewModule,
    TranslateModule,
    ProgressModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [AutocompleteBuyerAddressComponent],
  exports: [AutocompleteBuyerAddressComponent]
})
export class AutoCompleteBuyerAddressModule { }
