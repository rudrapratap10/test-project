import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { List } from 'lodash';
import { map } from 'rxjs/operators';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CollectionFactory } from '../../core/factories/collection/collection.factory';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'dew-autocomplete-buyer-address',
  templateUrl: './autocomplete-buyer-address.component.html',
  styleUrls: ['./autocomplete-buyer-address.component.scss']
})
export class AutocompleteBuyerAddressComponent implements OnInit {

  buyerAddressList: any = [];
  buyerAddressModel: any;

  staticArrData: any = [];

  public loader: boolean;

  @Input()
  minLength: number = 1;

  public _datasource: Array<any> | CollectionFactory<any>;
  @Input() set datasource(value: CollectionFactory<any>) {
    this._datasource = value;
    if (this._datasource instanceof Array) {
      this.buyerAddressList = this._datasource.map(
        (item, index) => {         
          return item;
        }
      );
      this.staticArrData = this.buyerAddressList;
    }
  }

  @Input()
  format : string = 'MULTI';

  @Input()
  isLeafNode: boolean;

  @Input()
  freeTextMode: boolean = true;

  @Input()
  searchByActive: boolean;

  @Input()
  requestUserIds: List<String>;

  @Input() buyerAddress: any;

  @Input() buyerAddressFormGroupInstance: FormGroup = this.formBuilder.group({
    buyerAddress: [{ value: {}, disabled: false }]
  });

  @Output()
  onSelect = new EventEmitter();

  @Output()
  onInvalid = new EventEmitter();

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    
  }

  buyerAddressModelFnFactory() {
    return (data: any) => {
      return data;
    };
  }

  buyerAddressDisplayFn() {
    return (data: any) => {
      return data.name;
    };
  }

  buyerAddressViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  modelValueChanged(form,field){   
    if(!form.get(field).value && !this.freeTextMode){
      this.onInvalid.emit();
    }
  }

  onBuyerAddressChange() {
    return  (query:  string)  =>  { 
      this.loader = true;   
      this.buyerAddressList =  [];
      if (this._datasource instanceof Array) {      
        this.buyerAddressList = this.search(query);
        return of(this.buyerAddressList);
      }
      else{                   
        this._datasource.extraParameters["name"] = query;
        this._datasource.applyExtraParameters();
        this._datasource.customResponse = true;
        return this._datasource.list$.pipe(map(
          (response) =>   {
            this.loader = false;           
            this.buyerAddressList =  response  ?  response["addresses"].map((buyerAddressModel)  =>
              buyerAddressModel
            )  :  this.buyerAddressList;
            return  this.buyerAddressList;
          }
        )).catch((error)  =>  {
          this.buyerAddressList =  [];
          this.loader = false;
          return  error;
        });
      }

    };
  }

  onSelectBuyerAddress(data) {
    this.onSelect.emit(data);
  }

  setBuyerAddressModel(model, value) {
    if(this.buyerAddressModel){
    this.buyerAddressModel.name = value;
    if (this.buyerAddressModel.name === null) {
      this.onInvalid.emit(this.buyerAddressModel.name);
    }
   }
  }

  search(searchedText: string) {   
    this.loader = false;
    if (searchedText) {
      this.buyerAddressList = this.staticArrData;
      return this.buyerAddressList.filter(
        (dataList) => {         
          let found = -1;
          const displayName = dataList.name;
          if (displayName) {
            found = displayName.toLowerCase().indexOf(searchedText.toLowerCase());
          }          
          return found > -1;
        }
      );
    } else {
      return this.buyerAddressList;
    }
  }
}
