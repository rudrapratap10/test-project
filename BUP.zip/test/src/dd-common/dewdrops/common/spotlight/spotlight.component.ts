import {
  Component,
  OnInit,
  Input
} from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'dew-spotlight',
  templateUrl: './spotlight.component.html',
  styleUrls: ['./spotlight.component.scss']
})
export class SpotlightComponent implements OnInit {

  @Input() backOption:boolean;

  tpl: any;
  constructor(private _location: Location) {
    // this.tpl = 'home';
  }

  ngOnInit() {
  }

  navigateBack() {
    this._location.back();
  }
}
