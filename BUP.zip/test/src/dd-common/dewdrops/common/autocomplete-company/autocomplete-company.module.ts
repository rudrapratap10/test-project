import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutocompleteCompanyComponent } from './autocomplete-company.component';
import { TranslateModule } from 'ng2-translate';
import {  ProgressModule } from '@dewdrops/bootstrap';
import { AutoCompleteModule } from '../../core/bootstrap/autocomplete/autocomplete.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    AutoCompleteModule,
    ProgressModule,
    FormsModule,
    ReactiveFormsModule 
  ],
  declarations: [AutocompleteCompanyComponent],
  exports: [AutocompleteCompanyComponent],
})
export class AutocompleteCompanyModule { }
