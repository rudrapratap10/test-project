import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AutocompleteAssetCodeComponent } from './autocomplete-asset-code.component';
import { AutoCompleteModule } from '../../core/bootstrap/autocomplete/autocomplete.module';
import { TranslateModule } from 'ng2-translate';
import { ProgressModule } from '../../core/bootstrap/progress/progress.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    AutoCompleteModule,
    TranslateModule,
    ProgressModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [AutocompleteAssetCodeComponent],
  exports: [AutocompleteAssetCodeComponent]
})
export class AutoCompleteAssetCodeModule { }