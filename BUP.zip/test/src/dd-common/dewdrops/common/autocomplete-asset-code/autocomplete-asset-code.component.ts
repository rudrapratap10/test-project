import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { List } from 'lodash';
import { map } from 'rxjs/operators';
import { APIClientService } from '../../core/services/api-client/api-client.service';
import { CollectionFactory } from '../../core/factories/collection/collection.factory';
import { of } from 'rxjs/observable/of';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'dew-autocomplete-asset-code',
  templateUrl: './autocomplete-asset-code.component.html',
  styleUrls: ['./autocomplete-asset-code.component.scss']
})
export class AutocompleteAssetCodeComponent implements OnInit {

  assetCodeList: any = [];
  assetCodeModel: any;

  staticArrData: any = [];
  public loader: boolean;

  @Input()
  minLength: number = 1;

  public _datasource: Array<any> | CollectionFactory<any>;
  @Input() set datasource(value: CollectionFactory<any>) {
    this._datasource = value;
    if (this._datasource instanceof Array) {
      this.assetCodeList = this._datasource.map(
        (item, index) => {         
          return item;
        }
      );
      this.staticArrData = this.assetCodeList;
    }
  }

  @Input()
  isLeafNode: boolean;

  @Input()
  freeTextMode: boolean = true;

  @Input()
  searchParam: string = "assetCode";  

  @Input()
  searchByActive: boolean;

  @Input()
  requestUserIds: List<String>;

  @Output()
  onSelect = new EventEmitter();

  @Output()
  onInvalid = new EventEmitter();

  @Input() assetCode: any;

  @Input() assetCodeFormGroupInstance: FormGroup = this.formBuilder.group({
    assetCode: [{ value: {}, disabled: false }]
  });

  constructor(private apiClient: APIClientService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loader = true;
  }

  assetCodeModelFnFactory() {
    return (data: any) => {
      return data;
    };
  }

  assetCodeDisplayFn() {
    return (data: any) => {
      return data[this.searchParam];
    };
  }

  assetCodeViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  modelValueChanged(form,field){   
    if(!form.get(field).value && !this.freeTextMode){
      this.onInvalid.emit();
    }
  }

  onAssetCodeChange() {
    return  (query:  string)  =>  {    
      this.loader = true;
      this.assetCodeList =  [];
      if (this._datasource instanceof Array) {      
        this.assetCodeList = this.search(query);
        this.loader = false;     
        return of(this.assetCodeList);
      }
      else{
        if(query.trim().length>0){
        if(this.searchParam == 'code'){         
          this._datasource.extraParameters = {
            codes: [query]
          };
        }
        else{
          this._datasource.extraParameters = {
            assetCode: query
          };
        }   
        }
        this._datasource.applyExtraParameters();
        this._datasource.commit();
        return   this._datasource.list$.pipe(map(
          (response) =>   {         
            this.loader = false;          
            this.assetCodeList =  response  ?  response.map((assetCodeModel)  =>
              assetCodeModel
            )  :  this.assetCodeList;
            return  this.assetCodeList;
          }
        )).catch((error)  =>  {
          this.assetCodeList =  [];
          this.loader = false;
          return  error;
        });
      }

    };
  }

  setAssetCode(data) {
    this.onSelect.emit(data);
  }

  search(searchedText: string) {   
    if (searchedText) {
      this.assetCodeList = this.staticArrData;
      return this.assetCodeList.filter(
        (dataList) => {
          // case insensitive comparision
          let found = -1;
          const displayName = this.searchParam == 'code' ? dataList.code : dataList.assetCode;
          if (displayName) {
            found = displayName.toLowerCase().indexOf(searchedText.toLowerCase());
          }
          return found > -1;
        }
      );
    } else {
      return this.assetCodeList;
    }
  }

}
