import { Injectable, ComponentFactoryResolver, Injector, ViewContainerRef } from '@angular/core';
import { Closable } from './closable';
import { Dialog } from './dialog';
import { DialogMediator } from './dialog-mediator.service';
import { SpinnerComponent } from './spinner/spinner.component';
import { ConfirmDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ConfirmEventType, ConfirmEvent } from './confirmation-dialog/confirm-event';

@Injectable()
export class DialogService {

  constructor(private dialogMediator: DialogMediator,
    private componentFactoryResolver: ComponentFactoryResolver) {
  }

  showDialog(componentClass: any) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
    const componentRef = this.dialogMediator.dialogHostViewContainer.createComponent(componentFactory);
    (<Closable> componentRef.instance).saveCloseHandler(() => componentRef.destroy());
    return (<Dialog> componentRef.instance);
  }


  showOverlay(componentClass: any) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
    const componentRef = this.dialogMediator.dialogHostViewContainer.createComponent(componentFactory);
    (<Closable> componentRef.instance).saveCloseHandler(() => componentRef.destroy());
    return (<Closable> componentRef.instance);
  }

  spinner(helpText: string) {
    const dialog = this.showOverlay(SpinnerComponent);
    (<SpinnerComponent> dialog).spinnerText = helpText;
    return dialog;
  }


  confirm(confirmTxt: string, confirmBtnLabel: string, rejectBtnLabel: string, isWide?:boolean) {
    return (confirmFn: () => void, rejectFn: () => void) => {
      const dialog = this.showDialog(ConfirmDialogComponent);
      (<ConfirmDialogComponent> dialog).confirmTxt = confirmTxt;
      (<ConfirmDialogComponent> dialog).confirmBtnLabel = confirmBtnLabel;
      (<ConfirmDialogComponent> dialog).rejectBtnLabel = rejectBtnLabel;
      (<ConfirmDialogComponent> dialog).isWide = isWide;
      dialog.close.subscribe(
        (event: ConfirmEvent) => {
          if (event.type === ConfirmEventType.CONFIRM) {
            confirmFn = confirmFn || function() {};
            confirmFn();
          }
          if (event.type === ConfirmEventType.CANCEL) {
            rejectFn = rejectFn || function() {};
            rejectFn();
          }
        }
      );
    };
  }

  confirmStream(confirmTxt: string, confirmBtnLabel: string, rejectBtnLabel: string) {
    return () => {
      const dialog = this.showDialog(ConfirmDialogComponent);
      (<ConfirmDialogComponent> dialog).confirmTxt = confirmTxt;
      (<ConfirmDialogComponent> dialog).confirmBtnLabel = confirmBtnLabel;
      (<ConfirmDialogComponent> dialog).rejectBtnLabel = rejectBtnLabel;
      return dialog.close;
    };
  }

}
