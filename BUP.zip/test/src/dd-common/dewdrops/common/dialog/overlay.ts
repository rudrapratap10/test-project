import { Observable } from 'rxjs/Observable';

export interface Overlay {
  clear: () => void;
}

export interface Dialog extends Overlay {
  close$: Observable<any>;
}
