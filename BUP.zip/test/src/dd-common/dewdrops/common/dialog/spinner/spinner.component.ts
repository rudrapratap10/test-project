import { Component } from '@angular/core';
import { Dialog } from '../dialog';
import { DialogService } from '../dialog.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Closable } from '../closable';
@Component({
  selector: 'dew-spinner',
  templateUrl: './spinner.component.html',
  styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements Closable {

  spinnerText: string;

  // holds a reference to close function provided by dialog service
  closeFn;

  constructor() {}

  clear() {
    if (this.closeFn) {
      this.closeFn();
    }
  }

  saveCloseHandler(closeFn) {
    this.closeFn = closeFn;
  }
}
