import { Injectable, ViewContainerRef } from '@angular/core';

@Injectable()
export class DialogMediator {

  dialogHostViewContainer: ViewContainerRef;

}
