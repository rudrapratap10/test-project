import { Directive, ViewContainerRef } from '@angular/core';
import { DialogMediator } from './dialog-mediator.service';

@Directive({
  selector: '[dewDlgHost]',
})
export class DialogHostDirective {

  constructor(private dialogMediator: DialogMediator, private viewContainer: ViewContainerRef) {
    this.dialogMediator.dialogHostViewContainer = viewContainer;
  }

}
