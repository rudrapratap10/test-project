export interface Closable {
  saveCloseHandler: (closeFn) => void;
  clear?: () => void;
}
