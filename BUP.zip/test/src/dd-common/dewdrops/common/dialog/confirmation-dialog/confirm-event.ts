/**
 * Defines types of confirm event
 */
export enum ConfirmEventType {
  CANCEL = -1,
  CONFIRM = 1
}

/**
 * The confirm event class
 */
export class ConfirmEvent {

  // the type of this event object
  private _type: ConfirmEventType;

  // the data accosiated with this event object
  private _data: any;

  /**
   * getter and setter for event type
   */
  set type(value: ConfirmEventType) {
    this._type = value;
  }

  get type(): ConfirmEventType {
    return this._type;
  }


  /**
   * getter and setter for data
   */
  set data(value: any) {
    this._data = value;
  }

  get data(): any {
    return this._data;
  }
}
