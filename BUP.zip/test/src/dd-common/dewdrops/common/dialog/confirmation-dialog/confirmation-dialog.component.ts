import { Component } from '@angular/core';
import { Dialog } from '../dialog';
import { DialogService } from '../dialog.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { ConfirmEvent, ConfirmEventType } from './confirm-event';

@Component({
  selector: 'dew-confirm-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmDialogComponent extends Dialog {

  confirmTxt: string;

  confirmBtnLabel: string;

  rejectBtnLabel: string;

  // used for adjusting width of the dialog box as per pre-defined wide width
  isWide?: boolean;

  // holds a reference to close function provided by dialog service
  closeFn;

  constructor() {
    super();
    this.close = new ReplaySubject(0);
  }

  onConfirm() {
    const confirmEvent = new ConfirmEvent();
    confirmEvent.type = ConfirmEventType.CONFIRM;
    this.close.next(confirmEvent);
    this.closeDialog();
  }

  onCancel() {
    const confirmEvent = new ConfirmEvent();
    confirmEvent.type = ConfirmEventType.CANCEL;
    this.close.next(confirmEvent);
    this.closeDialog();
  }

  closeDialog() {
    if (this.closeFn) {
      this.closeFn();
    }
  }

  saveCloseHandler(closeFn) {
    this.closeFn = closeFn;
  }

}
