import { Component } from '@angular/core';
import { Dialog } from '../dialog';
import { DialogService } from '../dialog.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Closable } from '../closable';
@Component({
  selector: 'dew-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent extends Dialog implements Closable {

  alertText: string;

  // holds a reference to close function provided by dialog service
  closeFn;

  constructor() {
    super();
    this.close = new ReplaySubject(0);
  }

  onClose() {
    this.close.next();
    if (this.closeFn) {
      this.closeFn();
    }
  }

  saveCloseHandler(closeFn) {
    this.closeFn = closeFn;
  }
}
