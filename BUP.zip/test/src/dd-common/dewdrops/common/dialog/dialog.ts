import { Subject } from 'rxjs/Subject';

export class Dialog {

  // holds the close stream of dialog
  private _close$: Subject<any>;

  public set close(value: Subject<any>) {
    this._close$ = value;
  }

  public get close() {
    return this._close$;
  }
}
