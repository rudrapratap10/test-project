import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ElementRef,
  ChangeDetectorRef
} from '@angular/core';
import { DragulaService } from 'ng2-dragula';
import { PopoverToggleComponent } from '../../core/bootstrap/popover/popover-toggle/popover-toggle.component';
import { ModalComponent } from '../../core/bootstrap/modal/modal.component';
@Component({
  selector: 'dew-multiselect-ordered-list',
  templateUrl: './mselect-order-list.html',
  styleUrls: ['./mselect-order-list.component.scss']
})
export class MultiSelectOrderedListComponent implements OnInit {
  @Input() listItems = [] as any[];

  @Input() listHeader: string;
  @Input() okButtonText = 'Apply' as string;
  @Input() nOkButtonText = 'Reset' as string;
  @Input() selectAllListTitle = 'Select All' as string;

  @Input() sourceButtonTemplate: TemplateRef<any>;

  @Input() labelField = 'label' as string;
  @Input() idField = 'label' as string;
  @Input() cbModalField = 'selected' as string;
  @Input() disabledField = 'disable' as string;

  @Input() isSortable = false as boolean;
  @Input() isFilterable = true as boolean;
  @Input() selectAllNeeded = true as boolean;

  @Input() popWidth = 340 as number;
  @Input() type = 'popup' as string;
  @Input() dragId = 'xyz' as string;

  @Input() excludeDefault = true as boolean;

  @Input() min = 2;
  @Input() max = 4;

  @Output() afterActionList = new EventEmitter();

  @ViewChild (PopoverToggleComponent) popToggle: PopoverToggleComponent;

  @ViewChild (ModalComponent) popup: ModalComponent;

  selectAll = false as boolean;
  copyOfList = [] as any[];
  searchTerm = '' as string;
  testModal: boolean;

  headerInfo = '' as string;
  constructor(private dragulaService: DragulaService, private cdr: ChangeDetectorRef) {
  }
  ngOnInit() {
    // Destroy existing group if any
    try {
      this.dragulaService.destroy(this.dragId);
    } catch {

    }
    // init
    this.dragulaService.createGroup(this.dragId, {
      moves: (el, container, handle) => {
        return handle.classList.contains('handle') && !handle.classList.contains('no-drag');
      }
    });
    this.popWidth = 400;
    this.copyOfList = JSON.parse(JSON.stringify(this.listItems));
    this.validateAndSyncSelectAll();
    if (this.min && this.max) {
      this.headerInfo  = `You can select min ${this.min} and max ${this.max} fields`;
    } else if (this.min) {
      this.headerInfo  = `You need to select atleast ${this.min} fields`;
    } else if (this.max) {
      this.headerInfo  = `You can select upto ${this.max} fields`;
    }
  }

  private selectorDeselect() {
    if (this.listItems) {
      if (this.min && !this.selectAll) {
        // show min error
      }

      if (this.max && this.max < this.listItems.length && this.selectAll) {
        // show max error
      }
      let i = 0;
      for (; i < this.listItems.length; ++i) {
        if (this.listItems[i][this.disabledField] !== true) {
            this.listItems[i][this.cbModalField] = this.selectAll;
        }
      }
    }
  }

  private validateAndSyncSelectAll(item?: any) {
    if (this.listItems) {
      let i = 0;
      const selectedItems = [];
      for (; i < this.listItems.length; i++) {
        if (this.listItems[i][this.cbModalField]) {
          selectedItems.push(this.listItems[i]);
        }
      }
      if (this.min > selectedItems.length) {
        // show min error
       // item[this.cbModalField] = true;
        this.cdr.detectChanges();
      } else if (this.max < selectedItems.length) {
        // show max error
      //  item[this.cbModalField] = false;
        this.cdr.detectChanges();
      }
      this.selectAll = selectedItems.length === this.listItems.length;
    }
  }

  private onOKDone() {
    this.afterActionList.emit(this.listItems);
    if (this.type === 'popover') {
      this.popToggle.state.emit();
    } else {
      this.toggleModalState(false);
    }
  }

  private onCancelDone() {
    this.selectAll = false;
    this.listItems = JSON.parse(JSON.stringify(this.copyOfList));
    this.afterActionList.emit(this.copyOfList);
    if (this.type === 'popover') {
      this.popToggle.state.emit();
    } else {
      this.toggleModalState(false);
    }
  }

  private toggleModalState(state): void {
    if (state === false) {
      // this.popup._closeModal();
      // this.message = 'Modal Closed';
    } else {
       // this.message = 'This message will be changed after modal is closed';
    }
    this.testModal = state;
  }
}
