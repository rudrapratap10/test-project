import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FormControlModule, PopoverModule, ButtonsModule, ModalModule } from '@dewdrops/bootstrap';
import { DragulaModule } from 'ng2-dragula';
import { NgPipesModule } from 'ngx-pipes';
import { MultiSelectOrderedListComponent } from './mselect-order-list.component';

@NgModule({
  imports: [
    CommonModule,
    DragulaModule.forRoot(),
    FormControlModule,
    FormsModule,
    ButtonsModule,
    PopoverModule,
    ModalModule,
    NgPipesModule
  ],
  declarations: [
    MultiSelectOrderedListComponent
  ],
  exports: [
    MultiSelectOrderedListComponent
  ]
})
export class MultiSelectOrderListModule { }
