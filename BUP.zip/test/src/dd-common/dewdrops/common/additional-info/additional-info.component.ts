import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormArray
} from '@angular/forms';
@Component({
  selector: 'dew-additional-info',
  templateUrl: './additional-info.component.html',
  styleUrls: ['./additional-info.component.scss']
})
export class AdditionalInfoComponent implements OnInit {

  @Input() mode = 'VIEW';
  @Input() additionalInfoObj;
  @Input() createAdditionalInfo: FormGroup;
  @Input() invoiceType ='PO';
  @Output() save: EventEmitter<any> = new EventEmitter<any>();

  constructor( private formBuilder: FormBuilder ) { 
  }

  ngOnInit() {
   
  }
  add2Input() {
    return this.formBuilder.group({
      specifications1: new FormControl(''),
      specifications2: new FormControl('')
  });
}
  addInputBoxes() {
    const control = < FormArray > this.createAdditionalInfo.controls['specifications'];
    control.push(this.add2Input());
}

whenSaved(event){
  this.save.emit(this.createAdditionalInfo.value);
}

}
