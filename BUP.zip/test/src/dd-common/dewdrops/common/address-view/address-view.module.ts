import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';
import { BuyerAddressViewComponent } from './buyer-address-view/buyer-address-view.component';
import { SupplierAddressViewComponent } from './supplier-address-view/supplier-address-view.component';
import { SupplierAddressService } from './supplier-address-view/supplier-address.service';

@NgModule({
  imports: [
    CommonModule,
    LayoutModule
  ],
  providers:[
    SupplierAddressService
  ],
  declarations: [SupplierAddressViewComponent,BuyerAddressViewComponent],
  exports: [SupplierAddressViewComponent,BuyerAddressViewComponent]
})
export class AddressViewModule { }