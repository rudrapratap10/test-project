import { Injectable } from '@angular/core';
import { pick, toArray, pickBy, identity } from 'lodash';
import { SupplierAddressInterface } from '../../../core/interfaces/address/supplier-address.interface';

@Injectable()
export class SupplierAddressService {

constructor() { }

generateSingleLineAddress(value): any {

    //Pick only keys which are required for address line structure
    let addressFields = pick(value, ["street1", "street2", "street3", "poBox", "city", "state", "country", "zip", "phone"]);

    //Remove data which values are null / undefined
    let uniqAddressArr = toArray(pickBy(addressFields, identity));

    //Join the array data with ", "
    let formattedAddress = uniqAddressArr.join(', ');

    return formattedAddress;
  }

generateAddressString(addrObj:SupplierAddressInterface){    
    return this.generateLine1Address(addrObj) + this.generateSingleLineAddress(addrObj);
}

generateLine1Address(addrObj:SupplierAddressInterface){
    let addr1 = addrObj.city;
    if(addrObj.addressAccountGroupId){
        addr1 = addr1+'('+addrObj.addressAccountGroupId+')';
    }
    return addr1;
}



}
