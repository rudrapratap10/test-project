import { CollectionFactory } from "@dewdrops/factories";

export class DataSource{
    companyDataSource: CollectionFactory;
    businessUnitDataSource: CollectionFactory;
    locationDataSource: CollectionFactory;
}

export class Company{
    name: string;
    code: string;
}

export class BusinessUnit{
    name: string;
    code: string;
}

export class Location{
    name: string;
    code: string;
}
export class OUModel{
    company: Company;
    businessUnit:BusinessUnit;
    location:Location;
}
