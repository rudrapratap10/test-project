import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { map } from 'rxjs/operators';
import { Tax } from '../tax';
import { TaxService } from '../tax.service';

@Component({
  selector: 'dew-tax-input',
  templateUrl: './tax-input.component.html',
  styleUrls: ['./tax-input.component.scss']
})
export class TaxInputComponent implements OnInit {

  taxTypes: string[];
  taxNames: string[];

  @Input()
  fieldType: string;

  @Input()
  freeTextMode: boolean;

  @Input()
  taxModel: Tax;

  @Input()
  taxFormGroup: FormGroup;

  @Input() isInValid: boolean

  @Output()
  taxModelChange: EventEmitter<Tax> = new EventEmitter<Tax>();

  constructor(private taxService: TaxService) { }

  ngOnInit() {
  }

  /**
   * ==========================================================================
   * -----------------Methods related to TAX TYPE------------------------------
   * ==========================================================================
   */

  taxTypeModelFnFactory() {
    return (data: any) => {
      return data;
    };
  }

  taxTypedisplayFn() {
    return (data: any) => {
      return data;
    };
  }

  taxTypeViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  onTaxTypeSelect(taxObject) {
    const taxReqObj = {
      taxType: taxObject
    };
    this.taxService.getTaxNameAndRate(taxReqObj).subscribe((response) => {
      if (response.data.records && response.data.records.length === 1) {
        const taxNameEntry = response.data.records[0];
        this.taxModel.name = taxNameEntry.name;
        this.taxModel.rate = taxNameEntry.rate;
        this.taxModel.isUseTaxType = taxNameEntry.isUseTaxType;
      } else {
        this.clearRowOnTaxTypeChange(); // revisit
      }
      this.taxModelChange.emit(this.taxModel);
    },
      (error) => {
        this.clearRowOnTaxTypeChange(); // re visit
      });
  }

  clearRowOnTaxTypeChange() {
    // re visit
  }

  onTaxTypeChange() {
    return (query: string) => {
      if (!query) {
        this.taxModelChange.emit(this.taxModel);
      }
      return this.taxService.getTaxTypes(query).pipe(
        map(
          (response) => {
            this.taxTypes = response.data.records ? response.data.records.map((tax) => tax.name) : this.taxTypes;
            return this.taxTypes;
          }
        )
      );
    };
  }

  setTaxType(tax, value) {
    tax.type = value;
    this.taxModelChange.emit(this.taxModel);
  }

  /**
   * ==========================================================================
   * -----------------Methods related to TAX NAME------------------------------
   * ==========================================================================
   */

  onTaxNameChange() {
    return (query: string) => {
        const taxReqObj = {
          name: query,
          taxType: this.taxModel.type
        };
        this.taxModel.isUseTaxType = undefined;
        if (!query) {
          this.taxModelChange.emit(this.taxModel);
        }
        return this.taxService.getTaxNameAndRate(taxReqObj).pipe(
          map(
            (response) => {
              // this.taxNames = response.data.records ? response.data.records.map((tax) => tax.name) : this.taxNames;
              this.taxNames = response.data.records;
              return this.taxNames;
            }
          )
        );
    };
  }

  onTaxNameSelect(taxObject) {
    try {
      this.taxModel.isUseTaxType = taxObject.isUseTaxType;
      this.taxModel.name = taxObject.name;
    } catch {}
    
  }

  setTaxName(value) {
    this.taxModel.name = value;
    this.taxModelChange.emit(this.taxModel);
  }

  taxNameModelFnFactory() {

    return (data: any) => {

      return data.name;
    };
  }

  taxNamedisplayFn() {
    return (data: any) => data.name;
  }

  taxNameViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  isNotGrpFieldValid(field: string): boolean {
    try {
      if (this.taxFormGroup) {
        return (!this.taxFormGroup.controls[field].valid && this.taxFormGroup.controls[field].touched);
      } else {
        return true;
      }
    } catch {
        return false;
    }
  }
}
