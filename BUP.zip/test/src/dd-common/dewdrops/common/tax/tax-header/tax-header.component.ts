import {
    ChangeDetectionStrategy,
    Component
} from '@angular/core';

@Component({
    selector: 'dew-tax-header',
    template: '<ng-content></ng-content>',
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TaxHeaderComponent { }
