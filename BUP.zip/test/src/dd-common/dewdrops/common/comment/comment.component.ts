import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter
} from '@angular/core';

@Component({
  selector: 'dew-comments',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.scss']
})
export class DewCommentComponent implements OnInit {
public max = 1000;
public internalTeamComment = '';
  @Input() comment;
  @Input() viewMode;
  @Output() internalComment = new EventEmitter<any>();
  ngOnInit() {
  }
  addComment() {
    this.internalComment.emit(this.internalTeamComment);
  }
}
