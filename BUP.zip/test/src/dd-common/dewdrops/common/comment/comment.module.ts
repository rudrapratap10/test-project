import { NgModule } from '@angular/core';
import {DewCommentComponent} from './comment.component'
import { LayoutModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    TranslateModule,
    LayoutModule,
    CommonModule,
    FormsModule
  ],
  declarations: [
    DewCommentComponent
  ],
  exports: [
    DewCommentComponent
  ]
})
export class DewCommentModule { }
