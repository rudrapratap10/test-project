import { Component, OnInit, HostBinding, Input } from '@angular/core';
@Component({
  selector: 'dew-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

/**
  for footer logo path
**/
  @Input()
  public logoFooter: string;

  public year: number;
  @HostBinding('class.d-flex')
  @HostBinding('class.align-items-center')
  @HostBinding('class.justify-content-between') flex = true;

  constructor() {
    const today = new Date();
    this.year = today.getFullYear();
   }

  ngOnInit() {
  }

}

