import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  RouterModule
} from '@angular/router';
 
import {DewDetailsInfoComponent} from './details-info.component';
import {CommonAddressComponent} from './common-address/common-address.component';
import { TabsModule, LayoutModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    TabsModule,
    TranslateModule,
    LayoutModule
  ],
  declarations: [
    DewDetailsInfoComponent,
    CommonAddressComponent
  ],
  exports: [
    DewDetailsInfoComponent
  ]
})
export class DewDetailsInfoModule { }
