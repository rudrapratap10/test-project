import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'einvoice-common-address',
  templateUrl: './common-address.component.html',
  styleUrls: ['./common-address.component.scss']
})
export class CommonAddressComponent implements OnInit {

  @Input() commonAddress;

  constructor() { }

  ngOnInit() {
  }

}
