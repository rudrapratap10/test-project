import { NgModule } from '@angular/core';
import {DateformatPipe} from './dateformat.pipe';

@NgModule({
  declarations: [DateformatPipe],
  exports: [DateformatPipe]
})

export class DateformatPipeModule {}