import { Pipe, PipeTransform } from '@angular/core';
import { TimezoneService } from '../../core/services/timezone/timezone.service';

@Pipe({
  name: 'dateformat'
})
export class DateformatPipe implements PipeTransform {
  constructor(private tzService: TimezoneService) {}
  transform(inp: string, filter: string): any {
    if (inp) {
      let v;

      if (filter ? filter.toLowerCase() === 'datetime' : false) {
        v = this.tzService.convertTimestampToDate(inp, true, filter);
      } else {
        v = this.tzService.convertTimestampToDate(inp,true);
      }
      return v;
    } else {
      return null;
    }
  }
}
