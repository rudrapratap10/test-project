import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ProgressModule } from '@dewdrops/bootstrap';

import { RouteLoaderComponent } from './route-loader.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    ProgressModule
  ],
  declarations: [RouteLoaderComponent],
  exports: [RouteLoaderComponent]
})
export class RouteLoaderModule { }
