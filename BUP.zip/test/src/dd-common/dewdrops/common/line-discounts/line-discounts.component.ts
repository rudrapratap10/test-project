import {
  Component,
  Input,
  OnInit,
  EventEmitter,
  Output
} from '@angular/core';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'dew-line-discounts',
  templateUrl: './line-discounts.component.html',
  styleUrls: ['./line-discounts.component.scss']
})

export class DewLineDiscountsComponent implements OnInit {
  @Input() lineDiscObj;
  @Input() totalPrice = 0;
  @Input() quantity = 0;
  @Input() mktprice = 0;
  @Input() mode = 'EDIT';
  @Input() currency = 'INR';
  @Output() discountCaluclated = new EventEmitter<any>();
  minValue: number;
  maxValue: number;
  discountAmount = 0 as number;
  discountedPrice = 0 as number;
  discountedViewPrice = 0 as number;
  discountViewAmount = 0 as number;
  discountStr = '';
  discountValue: any ;
  discountType: number ;
  public unit: string;
  public selectModel: number;
  testDataSelect: any = [{
    id: 1,
    name: this._language.instant('DEWDROPS_LBL_DISCOUNT_PERCENTAGE')
  },
  {
    id: 2,
    name: this._language.instant('DEWDROPS_LBL_DISCOUNT_AMOUNT')
  },
  {
    id: 3,
    name: this._language.instant('DEWDROPS_LBL_DISCOUNT_PEr_ITEM')
  },
  ];
  constructor(  private _language: TranslateService ) {
  }
  ngOnInit() {
    if (this.lineDiscObj.discountType === 1) {
      this.discountStr = 'Amount';
      this.discountViewAmount = (this.lineDiscObj.discountValue / 100) * this.lineDiscObj.total;
    } else if (this.lineDiscObj.discountType === 2) {
      this.discountStr = 'Percentage';
      this.discountViewAmount = this.lineDiscObj.discountValue;
    } else if (this.lineDiscObj.discountType === 3) {
      this.discountStr = 'Per Item';
      this.discountViewAmount = this.lineDiscObj.quantity * this.lineDiscObj.discountValue;
    }
    this.discountedViewPrice = this.lineDiscObj.total - this.discountAmount;
  }
  discountValueChange(event) {
    this.discountValue = event;
    this.discountAmount = 0;
    this.discountedPrice = 0;
    this.calculateTheDiscount();
   }
  setUnit(id: number) {
    this.discountValue = '';
    this.discountType = id;
    this.discountAmount = 0;
    this.discountedPrice = 0;
    this.calculateTheDiscount();
  }

  private calculateTheDiscount() {
    if (this.discountValue) {
      switch (this.discountType) {
        case 1:
          this.unit = '%';
          // calc for %
          this.minValue = 0;
          this.maxValue = 100;
          if ( this.discountValue <= 100 ) {
            this.discountAmount = ( this.discountValue / 100 ) * this.totalPrice;
            this.discountedPrice = this.totalPrice - this.discountAmount;
           }
           else {
            this.discountAmount = 0;
            this.discountedPrice = 0;
          }
          break;
        case 2:
          this.unit = '';
          this.minValue = 0;
          this.maxValue = this.totalPrice;
          if (this.discountValue <= this.totalPrice) {
          // calc for amount
          this.discountAmount = this.discountValue;
          this.discountedPrice = this.totalPrice - this.discountAmount;
          }
          else {
            this.discountAmount = 0;
            this.discountedPrice = 0;
          }
          break;
        case 3:
          this.unit = '';
          this.minValue = 0;
          this.maxValue = this.mktprice;
          // calc for per item
          if ( this.discountValue <= this.mktprice) {
            this.discountAmount = this.quantity * this.discountValue;
            this.discountedPrice = this.totalPrice - this.discountAmount;
          }
          else {
            this.discountAmount = 0;
            this.discountedPrice = 0;
          }

          break;
      }
      this.discountCaluclated.emit(this.discountAmount);
    }
  }
}
