import { NgModule } from '@angular/core';

import {CommonModule} from '@angular/common';
import { GlobalUIModule } from '@dewdrops/bootstrap';
import {DewLineDiscountsComponent} from './line-discounts.component';
import { TranslateModule } from 'ng2-translate';

import { FormsModule } from '@angular/forms';
import { UtilityModule } from '@dewdrops/common';
import { UtilitiesModule } from '@dewdrops/core/utilities';

// import { FormControlModule } from '@dewdrops/core/bo';

@NgModule({
  imports: [
    CommonModule,
    GlobalUIModule,
    TranslateModule,
    FormsModule,
    UtilityModule,
    UtilitiesModule
  ],
  declarations: [
    DewLineDiscountsComponent,

  ],
  exports: [
    DewLineDiscountsComponent
  ]
})
export class DewLineDiscountsModule {
}
