import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter
} from '@angular/core';
import { APIClientService} from '@dewdrops/services';
import { ContractsService } from './contracts.service'
import { FormGroup, FormControl } from '@angular/forms';
import { map } from 'rxjs/operators';
import { of} from 'rxjs/observable/of';
@Component({
  selector: 'dew-contracts',
  templateUrl: './contracts.component.html',
  styleUrls: ['./contracts.component.scss']
})

export class ContractsComponent implements OnInit {

  @Input() contractObj;
  @Input() contractURL;
  @Input() mode ='VIEW';
  @Input() vendorId : string;
  @Output()
  contractModelChange: EventEmitter<any> = new EventEmitter<any>();
  public contractData;
  public contractId;
  public baseUrl = '';
  public contractsFormGroup: FormGroup;
  public contractNumbers=[];
  public showViewButton = false;

  constructor(private apiClient: APIClientService, private contractService: ContractsService) { 
    this.contractsFormGroup = new FormGroup ({
      contractNumber : new FormControl('')
    });
  }

  ngOnInit() {
    if(this.mode === 'VIEW' && this.contractObj.contractid ){
      this.getContractURL(this.contractObj.contractid);
    }
  }

  getContractURL(contractID){

    this.contractService.getContractURL(contractID,this.contractURL).subscribe((resOuter) => {
        const secondurl = resOuter.data.viewUrl;
        this.contractService.tmsUrl().subscribe((resInner) => {
        const firsturl = resInner.data .filter(
          (tmsData) => tmsData.productInfo.name === 'iContract' ).map(
          (tmsData) => tmsData.productInfo.url
          );
        this.baseUrl = firsturl + secondurl;
      });
      });
  }

  getUrl() {
    if (this.baseUrl ! = "") {
      window.open(this.baseUrl, '_blank');
    }
  }

  contractsTypeDisplayFn(){
    return (data: any) => {
      return data;
    };
  }

  contractsTypeModelFnFactory(){
    return (data: any) => {
      return data;
    };
  }

  contractsTypeViewToModelTranformFactoryFn(){
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  onContractChange() {
    return (query: string) => {
      return this.contractService.getContractTypes(query,this.vendorId).pipe(
        map(
          (response) => {
            this.contractNumbers = response.data ?
              response.data
                .filter(
                  (contract) => contract.contractStatus === 'Active'
                ).map(
                    (contract) => contract.contractNumber
                  ) :
                 this.contractNumbers;

              this.contractData = response.data ?
              response.data.filter(
                (contract) => contract.contractStatus === 'Active'
              ): this.contractData;

              return this.contractNumbers;
          }
        )
      );
    };
  }

setContract(contarctObj) {
  this.showViewButton = false;
  this.contractId = '';
  this.contractModelChange.emit(contarctObj);
  for( let i = 0; i < this.contractData.length; i++){
    if(contarctObj.contractNumber === this.contractData[i].contractNumber){
      this.contractId = this.contractData[i].contractId;
      this.showViewButton = true;
      if(this.contractId || this.contractId!= ''){
        this.getContractURL(this.contractId);
      } 
      break;
    }
  } 
}

}
