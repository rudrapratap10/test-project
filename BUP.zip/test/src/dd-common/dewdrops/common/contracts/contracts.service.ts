import { Injectable } from '@angular/core';
import { APIClientService } from '@dewdrops/services';

const cmdURL = 'cmd';

@Injectable()
export class ContractsService {
  
    constructor(private _apiClient: APIClientService) {

    }

    getContractURL(contractID,contractURL){
        const url = contractURL.replace(':',contractID);
        return this._apiClient.read(url);
    }

    tmsUrl(){
        const url = `/api/a/tms/users/getRoles`;
        return this._apiClient.read(url);
      }

      getContractTypes(query,vendorId) {
        const params = {
          "perPageRecords": 20,
          "pageNo": 1,
          "vendorId": vendorId
        };
        const url = `/api/a/icontract/contracts/getContractList`;
        return this._apiClient.list(url, params);
      }

}
