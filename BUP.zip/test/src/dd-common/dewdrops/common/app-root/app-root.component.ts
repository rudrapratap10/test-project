import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dew-app-root, app-root',
  templateUrl: './app-root.component.html',
  styleUrls: ['./app-root.component.scss']
})
export class AppRootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
