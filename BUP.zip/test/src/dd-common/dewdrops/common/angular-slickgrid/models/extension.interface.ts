export interface Extension {
  name: string;
  service: any;
}
