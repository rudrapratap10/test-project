export enum SortDirection {
  asc = 'asc',
  ASC = 'ASC',
  desc = 'desc',
  DESC = 'DESC'
}
