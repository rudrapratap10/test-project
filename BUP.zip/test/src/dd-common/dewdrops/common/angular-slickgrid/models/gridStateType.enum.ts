export enum GridStateType {
  columns = 'columns',
  filter = 'filter',
  pagination = 'pagination',
  sorter = 'sorter'
}
