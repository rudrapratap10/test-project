export enum FileType {
  csv = 'csv',
  doc = 'doc',
  docx = 'docx',
  pdf = 'pdf',
  txt = 'txt',
  xls = 'xls',
  xlsx = 'xlsx'
}
