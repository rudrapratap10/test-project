export interface SortChangedArgs {
  multiColumnSort?: boolean;
  sortAsc: boolean;
  sortCol?: any;
  sortCols?: any[];
}
