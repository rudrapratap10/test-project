export interface QueryArgument {
  field: string;
  value: string | number | boolean;
}
