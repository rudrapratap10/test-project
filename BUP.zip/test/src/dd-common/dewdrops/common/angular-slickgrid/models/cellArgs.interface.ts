export interface CellArgs {
  row: number;
  cell: number;
  grid: any; // TODO replace by the Slickgrid Object
  item?: any;
}
