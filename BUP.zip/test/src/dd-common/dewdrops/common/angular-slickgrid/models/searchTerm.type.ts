export type SearchTerm = string | number | boolean;
