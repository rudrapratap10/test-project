import { ColumnFilter } from './columnFilter.interface';

export interface ColumnFilters {
  [key: string]: ColumnFilter;
}
