export interface HtmlElementPosition {
  top?: number;
  bottom?: number;
  left?: number;
  right?: number;
}
