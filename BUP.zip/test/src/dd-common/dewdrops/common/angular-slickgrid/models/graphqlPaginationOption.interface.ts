export interface GraphqlPaginationOption {
  first?: number;
  last?: number;
  offset?: number;
}
