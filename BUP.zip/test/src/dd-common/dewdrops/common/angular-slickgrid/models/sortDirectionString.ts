export type SortDirectionString = 'asc' | 'ASC' | 'desc' | 'DESC';
