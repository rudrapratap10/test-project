export enum CaseType {
  camelCase,
  pascalCase,
  snakeCase
}
