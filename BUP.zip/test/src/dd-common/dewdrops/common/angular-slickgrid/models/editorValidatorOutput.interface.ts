export interface EditorValidatorOutput {
  valid: boolean;
  msg?: string | null;
}
