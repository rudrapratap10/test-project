export type FilterMultiplePassTypeString = 'merge' | 'chain';
