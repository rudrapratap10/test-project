export enum SortDirectionNumber {
  asc = 1,
  desc = -1,
  neutral = 0,
}
