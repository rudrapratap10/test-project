export interface Pagination {
  pageNumber?: number;
  pageSizes: number[];
  pageSize: number;
  totalItems: number;
}
