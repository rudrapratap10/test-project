export enum FilterMultiplePassType {
  merge = 'merge',
  chain = 'chain'
}
