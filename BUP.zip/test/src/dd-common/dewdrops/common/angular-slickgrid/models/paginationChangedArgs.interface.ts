export interface PaginationChangedArgs {
  newPage: number;
  pageSize: number;
}
