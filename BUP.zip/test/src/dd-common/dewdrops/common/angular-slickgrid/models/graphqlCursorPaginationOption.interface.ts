export interface GraphqlCursorPaginationOption {
  after?: string;
  before?: string;
  first?: number;
  last?: number;
}
