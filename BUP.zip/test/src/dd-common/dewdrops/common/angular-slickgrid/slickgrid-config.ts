import { GlobalGridOptions } from './global-grid-options';

export class SlickgridConfig {
  options: any;

  constructor() {
    this.options = GlobalGridOptions;
  }
}
