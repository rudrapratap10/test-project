"use strict";
const authorization = require('@hook/authorization').Authorization,
  rm = require('@service/require.module')();

class DewDropsHandler{
  constructor(options) {
    this.message = [];
    this.errors = [];   
    this.options = options;    
  }

  myPre(request, callback) {
    try {
      callback(null, request, {});
    } catch (error) {
      callback(error, null);
    }
  }

  pre(request, input, callback) { callback(null, request, input); }
  process(request, input, callback) { callback(null, request, input); }
  post(request, input, callback) { callback(null, request, input); }
  myPost(request, input, callback) { callback(null, request, input); }

  handleInput(args) {
    if (rm.lodash.isEmpty(args)) return null;

    if (!rm.lodash.isEmpty(args.message)) {
      if (rm.lodash.isArray(args.message)) {
        this.message = rm.lodash.union(this.message, args.message);
      } else if (rm.lodash.isString(args.message)) {
        this.message.push({ "description": args.message });
      }
      delete args.message;
    }

    if (!rm.lodash.isEmpty(args.errors)) {
      if (rm.lodash.isArray(args.errors)) {
        this.errors = rm.lodash.union(this.errors, args.errors);
      } else if (rm.lodash.isObject(args.errors)) {
        this.errors.push(args.errors);
      }
      delete args.errors;
    }
    return args;
  }

  handle() {
    const request = this.options.request,
          path = request.routerPath,
          pathSplit = path.split("/"),
          tag = pathSplit[0] + '_' + pathSplit[1] + '_' + pathSplit[2],
          productName = request.productName;
    let accessControls = null;  
    const productSetting = rm.productSetting(this.options.request);
    if (productSetting && productSetting['modules'] && productSetting['modules'][pathSplit[1]] && productSetting['modules'][pathSplit[1]][pathSplit[2]]) {
        const prodObj = productSetting['modules'][pathSplit[1]][pathSplit[2]];
        accessControls = (!rm.lodash.isEmpty(prodObj.accessControls)) ? prodObj.accessControls : null;
    }
     
    return new Promise((resolve, reject) => {
      try {

        //Generate task here
        const tasks = [
          (callback) => {
            const auth = new authorization();
            auth.productName = productName;
            auth.accessControls = accessControls;
            auth.authorize(request, callback);
          },
          (input, callback) => { 
            this.myPre(request, callback)
          },
          (request, input, callback) => {
            if (this.options.pPre) {
              this.options.pPreClass[this.options.pPre](request, input, callback);
            }else{
              this.pre(request, input, callback);
            } 
          },
          (request, input, callback) => {
            if (this.options.pProcess) {
              this.options.pProcessClass[this.options.pProcess](request, input, callback);
            }else{
              this.process(request, this.handleInput(input), callback);
            }
          },
          (request, input, callback) => {
            if (this.options.pPost) {
              this.options.pPostClass[this.options.pPost](request, input, callback);
            }else{
              this.post(request, this.handleInput(input), callback);
            }
          },
          (request, input, callback) => {
            this.myPost(request, this.handleInput(input), callback)
          }
        ];

        rm.async.waterfall(tasks, (error, req, result) => {
          if (error) {
            // call the method to translate error message.
            error = rm.utils.translateErrorMsg(error, request);

            const resMsg = new rm.responseMsg(request.getLocale(), tag, request);
            //timeout & unauthorized error status code
            if (typeof error.statusCode != "undefined") {
              resMsg.statusCode = error.statusCode;              
            }
            resMsg.errorRes(error, null, rm.utils.translate(request, 'dd-error-500'), (err, data) => {
              if (data) {
                reject(data);
              }
            });
          } else {
            //Making response here
            const resMsg = new rm.responseMsg(request.getLocale(), tag, request);
            if (this.message.length > 0) {
              const message = handleResMsg(request, this.message);
              resMsg.message = (message.length > 1) ? message : message[0];
            }

            if (this.errors.length > 0) {
              const errors = rm.utils.translateErrorMsg(this.errors, request);
              resMsg.error = (errors.length > 1) ? errors : errors[0];
            }
            //const output = (rm.lodash.isObject(result) && !rm.lodash.isEmpty(result.data)) ? result.data : null;
            const output = result.data;
            resMsg.successRes(output, (err, data) => {
              if (data) {
                resolve(data);
              }
            });
          }
        });

      } catch (error) {
        const resMsg = new rm.responseMsg(request.getLocale(), tag, request);
        resMsg.errorRes(error, null, rm.utils.translate(request, 'dd-error-500'), (err, data) => {
          if (data) {
            reject(data);
          }
        });
      }
    });
  }

};

const handleResMsg = (request, args) => {
  if (rm.lodash.isArray(args) && !rm.lodash.isEmpty(args)) {
    args.forEach((msg, index) => {
      msg.description = rm.utils.translate(request, msg.description);
    });
  }
  return args;
}

module.exports = DewDropsHandler;
