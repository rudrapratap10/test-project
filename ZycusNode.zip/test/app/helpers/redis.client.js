
const redisConfig = require('@helper/configuration').redis(),
    redisConnection = require('@helper/redis.connection.js').getRedisConnection,
    lodash = require("lodash");

class RedisClient {
    getRedisData(token, callback) {
        try {
            if (!lodash.isEmpty(token)) {
                redisConnection((error, connection) => {
                    if(error){
                        return callback(error, null);
                    } else {
                        connection.get(token, (err, result) => {
                            if (err || lodash.isEmpty(result)) {
                                return callback(err || 'Empty_Data', null);
                            }
                            else {
                                return callback(null, result);
                            }
                        });
                    }
                });
            }
            else {
                return callback('Empty_Data', null);
            }
        }
        catch (error) {
            return callback(error, null);
        }
    }

    setRedisData(token, input, expTime, callback) {
        try {
            if (!lodash.isEmpty(token) && !lodash.isEmpty(input)) {
                redisConnection((error, connection) => {
                    if(!error) {
                       let expireTime = expTime || redisConfig.expireTime;
                       connection.set(token, JSON.stringify(input), 'EX', expireTime, (err,res)=>{
                        if(err){
                            return callback(err, null);
                        }
                        else {
                            return callback(null, res);
                        }
                       });
                    }else {
                        return callback(error, null);
                    } 
                });
            }
        }
        catch (error) {
            return callback(error, null);
        }
    }

    removeRedisData(token, callback) {
        try {
            if (!lodash.isEmpty(token)) {
                redisConnection((error, connection) => {
                    if(!error){
                        connection.del(token, (err,res)=>{
                            if(err){
                                return callback(err, null);
                            }
                            else {
                                return callback(null, res);
                            }
                        }); //multiple keys can be removed in one shot
                    }else {
                        return callback(error, null);
                    } 
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    }
 /**
 * @name: getRedisKeys
 * @description: Match and retrive redis matching keys 
 */
    getRedisKeys(pattern, callback) {
        try {
            if (!lodash.isEmpty(pattern)) {
                redisConnection((error, connection) => {
                    if (!error) {
                        connection.keys(pattern, (err, res) => {
                            if (err) {
                                return callback(err, null);
                            }
                            else {
                                return callback(null, res);
                            }
                        });
                    } else {
                        return callback(error, null);
                    }
                });
            }
            else {
                return callback('Empty_Data', null);
            }
        } catch (error) {
            return callback(error, null);
        }
    }    

    setExpire(token, callback){
        redisConnection((error, connection) => {
            if(!error){
                connection.expire(token, redisConfig.ttl,(err,res)=>{
                    if(err){
                        return callback(err, null);
                    }else{
                        return callback(null, res);
                    }
                });
            }else {
                return callback(error, null);
            } 
        });
    }
}

exports.RedisClient = new RedisClient();