"use strict";
const rm = require('@service/require.module')(),
      winstonLog = require('@provider/winston'),
      grayLog = require('@provider/graylog'),
      setting = require('@config/setting.json');

class LoggerUtility {

    constructor(options = {}) {
        this.server = options.server;
    }

    getServer(input) {
        try {
            switch (input) {
                case 'graylog':
                    return grayLog;
                case 'winston':
                    return winstonLog;
            }
        } catch (error) {
            return false;
        }
    };

    log(input) {
        try {
            const logger = this.getServer(this.server);
            logger.exec(input, (error, response) => {
                if (response) {
                    return false;
                }
                else {
                    //connect with graylog log
                    const logger = this.getServer("graylog");
                    logger.exec(input, (error, response) => {
                        if (response) {
                            return false;
                        }
                    });
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    debugger(input, isOffline = false) {
        try {
            if (rm.settingConfig.debug || isOffline) {
                if (input) {
                    console.log(input);
                    this.log({ level: "debug", data: { data: input, dateTime: rm.utils.dateUtility.timestampToDate(Date.now()) } });
                }
            }
        } catch (error) {
            return false;
        }
    }

    /**
    * @Name: log 
    * 
    * @Description: This function is used to parse and formate input then log to logger.
    */
    requestResponseLog(logData = {}) {

        if (!rm.settingConfig.requestResponseLog) return;
        
        logData.input = (!rm.lodash.isEmpty(logData.input))? JSON.stringify(logData.input) : undefined;
        
        let data = {
            type: logData.type,
            requestID: logData.request.requestID || undefined,
            dateTime: rm.utils.dateUtility.timestampToDate(Date.now()),
            userID: (logData.request.user) ? logData.request.user.userId : undefined
        }

        switch (logData.type) {
            case 1:
                data.request = logData.input;
                data.URL = logData.request.url || logData.request.path || undefined;
                data.Method = logData.request.method || undefined;
                break;
            case 2:
                data.request = logData.input;
                data.URL = logData.productOption.uri || undefined;
                data.Method = logData.productOption.method || undefined;               
                data.productName = rm.utils.getProductName({url : data.URL});
                break;
            case 3:
                data.response = logData.input;
                data.URL = logData.productOption.uri || undefined;
                data.Method = logData.productOption.method || undefined;
                data.productResponseTime = logData.productResponseTime || undefined;               
                data.productName = rm.utils.getProductName({url : data.URL});
                break;
            case 4:
                data.response = logData.input;
                data.URL = logData.request.url || logData.request.path || undefined;
                data.Method = logData.request.method || undefined;
                break;
        }

        this.log({ level: "info", data: data })
    }

};

const options = { 
    "server": rm.appConstant.logModules[setting.loggerModule] || rm.appConstant.logModules.winston
};
module.exports = new LoggerUtility(options);