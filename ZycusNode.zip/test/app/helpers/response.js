"use strict";
const rm = require('@service/require.module')(),
    packages = require('@root/package.json'),
    cookieSetting = require('@helper/configuration').session().cookie;
/**
* Response Helper
*
* @description :: This method is used to send all types of HTTP response in the application. 
*/
module.exports = (req, res, result) => {
    try {
        
        if (result.data && result.data['content-type'] != 'sse') {
            // Set the node version in the response header
            res.setHeader('version', packages.version);
            res.setHeader('buildNo', packages.buildNo);
            // cache-control for GET request
            if (req.method === "GET") {
                if (!rm.lodash.isUndefined(result.data) && result.data['isCached']) {
                    res.setHeader('Cache-Control', 'public, max-age=' + cookieSetting.maxAge);
                } else {
                    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate, max-age=0");
                }
            }
        }

        const cookie = { domain: rm.settingConfig.domainName, path: cookieSetting.path, httpOnly: cookieSetting.httpOnly },
            allTypes = ["jsonp", "redirect", "sse", "fileStream"],
            contentType = (!rm.lodash.isEmpty(result.data) && !rm.lodash.isEmpty(result.data['content-type'])) ? result.data['content-type'] : null,
            contentTypeName = (rm.lodash.isEmpty(contentType)) ? null : (rm.lodash.indexOf(allTypes, contentType) === -1) ? "other" : contentType;

        if (!rm.lodash.isUndefined(req.tokenId)) {
            //res.cookie('SAAS_COMMON_BASE_TOKEN_ID', req.tokenId, cookie);
        }

        switch (contentTypeName) {
            case 'jsonp':
                delete result.data['content-type'];
                res.status(result.statusCode).jsonp(result);
                break;
            case 'redirect':
                if (result.data.statusCode) {
                    res.redirect(result.data.statusCode, result.data['URL']);
                } else {
                    res.redirect(result.data['URL']);
                }
                break;
            case 'other':
                const file = new Buffer(result.data['file-data'], 'base64');
                res.writeHead(200, {
                    'Content-Type': result.data['content-type'],
                    'Content-Length': file.length,
                    'Content-Disposition': "filename=" + (result.data['fileName'] || '')
                });
                res.end(file);// Send the file data to the browser.
                break;
            case 'sse':
                delete result.data['content-type'];             
                let output = null, data = result.data, id = result.id, eventName = result.eventName;
                if (typeof data === "object") {
                    let result = JSON.stringify(data);
                    result = result ? result.split(/[\r\n]+/).map(str => 'data: ' + str).join('\n') : '';
                    output = (
                        (id ? "id: " + id + "\n" : "") +
                        (eventName ? "event: " + eventName + "\n" : "") +
                        (result || "Not available") + '\n\n'
                    );
                }
                res.write(output || data || "");
                res.flush();
                break;
            case 'fileStream':
                const filename = result.data['filename'],
                fileStream = result.data['file-data'],
                mimetype = result.data['mimetype'];
                res.setHeader('Content-Description', 'File Transfer');
                res.setHeader('Content-Type', mimetype);
                res.setHeader('Content-Disposition', 'attachment; charset=utf-8; filename='+filename); 
                res.setHeader('Content-Transfer-Encoding', 'binary');
                fileStream.pipe(res);
            break;
            case 'json':
            default:
                // log response come from BFF to UI 
                rm.logger.requestResponseLog({ "request": req, "input": result, "type": 4 });
                res.status(result.statusCode).json(result);
                break;
        }
    } catch (error) {
        res.status(500).send(error);
    }
}