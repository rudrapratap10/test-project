"use strict";

/**
 * Utility function to decrypt strings that were encrypted using the zycus-secureDS jar.
 * This is a direct port of the java service "common.doDecodeSecret".
 *
 * @param string secret The encrypted password string
 * @return string The decrypted password string
 */
exports.doDecodeSecret = (secret) => {
    try {
        if (!secret || secret.length === 0) {
            return null;
        }
    
        // The hardcoded key that was used to encrypt data (simple character string, highly insecure)
        const key = '-5f0cf48fcfae2bb';
    
        // The data is hexadecimal encoded, with negative values possible
        // Converting the encoded string into a binary string is same for both positive and negative numbers
        let negate = false;
        if (secret.charAt(0) === '-') {
            negate = true;
            secret = secret.substr(1);
        }
    
        // Pair of hex digits corresponds to a single byte, so the given string must haven an even length
        // If not, prefix a padding '0' character (NOTE: different from null byte) to the string
        if (secret.length % 2 === 1) {
            // Otherwise hex conversion will fail
            secret = '0' + secret;
        }
    
        // Convert the hexadecimal encoded string into a binary buffer
        let data = Buffer.from(secret, 'hex');
    
        if (negate) {
            // If it was originally a negative value, calculate two's complement of the data
            // This is done to correspond with how the Java service processes negative values via BigInteger::toByteArray.
            for (let i = 0; i < data.length; ++i) {
                data[i] = ~data[i];
            }
            data[data.length - 1] = data[data.length - 1] + 1;
        }
    
        // Module is required at the very last instant; only if decryption actually proceeds to this point
        const crypto = require('crypto');
    
        // Decrypt the data with Blowfish using ECB (highly insecure) mode
        const decipher = crypto.createDecipheriv('bf-ecb', key, '');
    
        let decrypted = decipher.update(data, null, 'utf8');
        decrypted += decipher.final();
    
        return decrypted;
    } catch (error) {
        return null;
    }    
}