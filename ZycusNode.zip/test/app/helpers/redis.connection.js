"use strict";
const redis = require('redis'),
      redisConfig = require('@helper/configuration').redis(),
      rm = require('@service/require.module')({type: "singleton"});

let connection;

class RedisConnection {

  constructor(){
    this.redisClient = {};
  }

  connection(callback){
    this.redisClient = redis.createClient({
      host: redisConfig.host, port: redisConfig.port, retry_strategy: (options) => {
        if (rm.lodash.isEmpty(options.error)) {
          const errorMsg = "Connection to Redis Server not established";
          rm.logger.debugger(errorMsg, true);
          options.error = {message:errorMsg};          
        }
        return callback(options.error, null);       
      }
    });      
      
    this.redisClient.once("error", error => {
      return callback(error, null);
    });

    this.redisClient.once("ready", () => {
      rm.logger.debugger("Connected to Redis Server Successfully!", true);
      return callback(null,  this.redisClient);
    });
  }

 create(callback) {
   try {
     if (rm.lodash.isEmpty(this.redisClient) || this.redisClient.connected === false) {
       return this.connection(callback);
     }
     else {
       return callback(null, this.redisClient);
     }
   } catch (error) {
     return error;
   }
  }
}

exports.getRedisConnection = (callback) => {
  try {
    if (!connection) {
      connection = new RedisConnection();
    }
    connection.create(callback);   
  } catch (error) {    
    return callback(error, null);
  }
}