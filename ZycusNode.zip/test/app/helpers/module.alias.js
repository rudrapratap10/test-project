const moduleAlias = require('module-alias'),
    root = `${__dirname}/../../`,
    app = `${root}/app`,
    aliasConfig = {
        "@root": root,
        "@app": app,
        "@product": `${app}/products`,
        "@helper": `${app}/helpers`,
        "@hook": `${app}/hooks`,
        "@middleware": `${app}/middlewares`,
        "@service": `${app}/services`,
        "@config": `${root}/config`,        
        "@provider": `${app}/providers`
    };

module.exports.load = () => moduleAlias.addAliases(aliasConfig);