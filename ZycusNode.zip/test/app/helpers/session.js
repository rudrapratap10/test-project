/*"use strict";
const session = require("express-session"),
redisStore = require("connect-redis")(session),
config = require('@helper/configuration'),
redisConfig = config.redis(),
sessionConfig = config.session();

exports.config = (isSessionStoreToRedis) =>{
  let attr = sessionConfig;
  if(isSessionStoreToRedis) {
    const redisClient =  require('@helper/redis.connection.js').getRedisConnection();
    attr.store = new redisStore({ host: redisConfig.host, port: redisConfig.port, client: redisClient, ttl :  redisConfig.ttl});
  }
  return session(attr);
}
*/