"use strict";
const rm = require('@service/require.module')();

exports.errorFormat = (option) => {
    const resMsg = new rm.responseMsg(option.lang, "middleware", option.request),
        errorType = option.errorType || null,
        error = option.error || new rm.customError(option.errorMsg, errorType, option.statusCode),
        serverError = option.serverError || null,
        data = option.data || null;
    resMsg.statusCode = option.statusCode;
    resMsg.errorRes(error, data, serverError, (err, result) => {
        if (result) {            
            rm.response(option.request, option.response, result);
        }
    });
}