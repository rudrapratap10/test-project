/**
 * @NAME: Utils Class
 * 
 * @Description:  This class provides a set of common utility properties & functions.
**/

const rm = require('@service/require.module')(),
    uuidService = require('@service/uuid'),
    dateUtility = require('@helper/date.utility'),
    validationUtility = require('@service/validation.utility'),
    numberUtility = require('@helper/number.utility'),
    cryptoJS = require("crypto-js"),
    appConstant = require('@config/app.constant'),
    _ = require("lodash");

class Utils {

    get staticValue() {
        return "dewdrops-123";
    }

    /**
    * @Name: uuid
    *
    * @Description: This function is used return UUID with conditional concatination alongwith ip address or userId
    *
    * @return: string
    */
    uuid(request) {
        try {
            if (rm.lodash.isEmpty(request)) {
                const uniqueId = new uuidService().unique;
                return uniqueId;
            }
            const id = new uuidService().value;
            const result = id + '-' + ((rm.lodash.isEmpty(request.user)) ? this.getIpAddress(request) : request.user.userId);
            return result;
        }
        catch (error) {
            return null;
        }
    }

    /**
   * @Name: getIpAddress
   *
   * @Description: This function is used return the ip address of requesting server
   *
   * @return: string
   */
    getIpAddress(request) {
        try {
            const ip = request.headers['true-client-ip'] || request.headers['x-forwarded-for'] || request.connection.remoteAddress || request.socket.remoteAddress || request.connection.socket.remoteAddress;
            return ip;
        }
        catch (error) {
            return null;
        }
    }

    /**
    * @Name: formatResponse
    *
    * @Description: This function is used format the properties vlaue within the product api response object
    *
    * @return: object
    */
    formatResponse(args) {
        try {
            if (!rm.lodash.isEmpty(args) && rm.lodash.isPlainObject(args)) {
                if (rm.lodash.has(args, 'modifiedOn') && !rm.lodash.isNull(args.modifiedOn)) {
                    args.modifiedOn = this.dateUtility.timestampToDate(args.modifiedOn, 'gmt');
                }
                if (rm.lodash.has(args, 'createdOn') && !rm.lodash.isNull(args.createdOn)) {
                    args.createdOn = this.dateUtility.timestampToDate(args.createdOn, 'gmt');
                }
                if (rm.lodash.has(args, 'submittedOn') && !rm.lodash.isNull(args.submittedOn)) {
                    args.submittedOn = this.dateUtility.timestampToDate(args.submittedOn, 'gmt');
                }
            }
            return (args || {});
        }
        catch (error) {
            return args;
        }
    };

    //Custom Utility Properties - Starts

    /**
     * @Name: dateUtility
     *
     * @Description: This function is used to provide a new instance of date utility.
     *
     * @return: object
     */

    get dateUtility() {
        return dateUtility;
    }

    /**
   * @Name: validationUtility
   *
   * @Description: This function is used to provide a new instance of joi validation utility.
   *
   * @return: object
   */
    validationUtility(request) {
        let validation = new validationUtility(request);
        return validation;
    };

    /**
    * @Name: numberUtility
    *
    * @Description: This function is used to provide a new instance of number utility.
    *
    * @return: object
    */
    numberUtility(input = {}) {
        return new numberUtility(input);
    }

    //Custom Utility Properties - Ends

    tryParse(input) {
        try {
            const output = JSON.parse(input);
            return output;
        } catch (error) {
            return false;
        }
    }

    /**
    * @Name: encrypt
    *
    * @Description: This function is used to encrypt the input string
    *
    * @return: string
    */
    encrypt(input, key, isStatic = false) {
        try {
            if (isStatic) {
                const Key = cryptoJS.enc.Base64.parse(key.slice(0, 22)),
                    iv = cryptoJS.enc.Base64.parse(rm.settingConfig.cryptoKey),
                    ciphertext = cryptoJS.AES.encrypt(input, Key, { iv: iv });
                return ciphertext.toString();
            }
            const ciphertext = cryptoJS.AES.encrypt(input, key);
            return ciphertext.toString();
        } catch (error) {
            return null;
        }
    }

    /**
    * @Name: decrypt
    *
    * @Description: This function is used to decrypt input encrypted string
    *
    * @return: string
    */
    decrypt(input, key, isStatic = false) {
        try {
            if (isStatic) {
                const Key = cryptoJS.enc.Base64.parse(key.slice(0, 22)),
                    iv = cryptoJS.enc.Base64.parse(rm.settingConfig.cryptoKey),
                    bytes = cryptoJS.AES.decrypt(input.toString(), Key, { iv: iv });
                return bytes.toString(cryptoJS.enc.Utf8);
            }
            const bytes = cryptoJS.AES.decrypt(input.toString(), key),
                plaintext = bytes.toString(cryptoJS.enc.Utf8);
            return plaintext;
        } catch (error) {
            return null;
        }
    }

    /**
     * @Name: getDetailsByRequest
     * 
     * @Description: This function is used to get the user & other details by request
     */
    getDetailsByRequest(request) {
        try {
            return rm.lodash.pick(request, ['user', 'path', 'headers', 'connection', 'socket', 'method', 'params', 'body', 'query', 'requestID', 'tokenId', 'productsURL', '__', 'routerPath', 'productName']);
        } catch (error) {
            return null;
        }
    }

    /**
     * @Name: formPaginateRequest
     * 
     * @Description: This function is used to generate pagination request structure for calling Product APIs.
     */
    formPaginateRequest(input = {}) {
        try {
            const output = {
                perPageRecords: input.perPageRecords || rm.settingConfig.perPageRecords,
                pageNo: input.pageNo || rm.settingConfig.pageNo,
            }
            return output;
        } catch (error) {
            return { perPageRecords: rm.settingConfig.perPageRecords, pageNo: rm.settingConfig.pageNo };
        }
    }

    /**
    * @Name: splitMsg
    * 
    * @Description: This function is used to slpit the message code for translation.
    */
    splitMsg(input = null) {
        try {
            let output = { code: "", msg: "" };
            if (rm.lodash.isString(input)) {
                if (input.includes('__')) {
                    const splitString = input.split('__');
                    output.code = splitString[0];
                    output.msg = splitString.pop();
                }
            }
            return output;
        } catch (error) {
            return { code: "", msg: "" };
        }
    }

    /**
    * @Name: translate
    * @Description: This function is used to translate the message by using i18. This method now will support object and array mapping of the incoming phrase.
    */
    translate(request, input = null, phraseArgs = null) {
        try {
            return request.__(input, this.getI18nArgs(phraseArgs));
        } catch (error) {
            return null;
        }
    }

    /**
     * @Name getI18nArgs
     * @Description: returns either an object or a string from the input param
     */
    getI18nArgs(input = null) {
        try {
            if (!rm.lodash.isArray(input))
                return input;

            const data = {};
            for (const [index, value] of input.entries()) {
                data[index] = value;
            }
            return data;
        } catch (err) {
            return input;
        }
    }

    /**
    * @Name: checkEachSeries
    * 
    * @Description: This function is used to check while looping an array whether the iteration reaches to the last array element.
    */
    checkEachSeries(count, length, output, callback) {
        if (count === length) {
            return callback(null, output);
        }
    }

    /**
    * @Name: isOriginAllowed
    * 
    * @Description: This function is used to check the allowed origin.
    */
    isOriginAllowed(origin, allowedOrigin) {
        if (rm.lodash.isArray(allowedOrigin)) {
            for (var i = 0; i < allowedOrigin.length; ++i) {
                if (this.isOriginAllowed(origin, allowedOrigin[i])) {
                    return true;
                }
            }
            return false;
        } else if (/^[.].*$/.test(allowedOrigin)) {
            if (typeof origin != "undefined") {
                let originSplit = origin.split('.');
                let domain = "." + originSplit.slice(-2).join('.');
                return domain === allowedOrigin;;
            } else {
                return false;
            }
        } else if (rm.lodash.isString(allowedOrigin)) {
            return origin === allowedOrigin;
        } else if (rm.lodash.isRegExp(allowedOrigin)) {
            return allowedOrigin.test(origin);
        } else {
            return !!allowedOrigin;
        }
    }

    /**
    * @Name: getFilePath
    * 
    * @Description: This function is used to get the actual file path from the encoded file path string.
    */
    getFilePath(request, filePath) {
        try {
            if (!rm.lodash.isEmpty(filePath)) {
                const decodedPath = this.decrypt(filePath.replace(/@/g, "/"), request.tokenId, true),
                    filePathSplit = decodedPath.split("~"),
                    path = filePathSplit[0];
                return path;
            }
            else {
                return null;
            }
        } catch (error) {
            return null;
        }

    }

    /**
    * @Name: createBufferData
    * 
    * @Description: This function is used to fetch buffer data from file stream received from SFTP server
    *               It will be used while sending attachments via email
    */
    createBufferData(fileStream) {
        try {
            const output = new Buffer.from(fileStream._readableState.buffer.head.data);
            return output;
        } catch (error) {
            return null;
        }
    }

    /**
    * @Name: extractObjPropsFromArray
    * 
    * @Description: This function is used to get the perticular property from an array.
    */

    extractObjPropsFromArray(arr, props) {
        //Extract property from an array
        let extractArr = arr.map((bval, inx) => {
            return _.pick(bval, props);
        });
        return extractArr;
    }

    /**
    * @Name: mergeArray
    * 
    * @Description: This function is used to merge the two array based on keys.
    * 
    * @argument: a-> Array (objects), b -> Array (objects), 
    *            matchkeys -> Array (string with max two values : 1st item should be the keyname of object falling inside a 
    *                 and 2nd item should be the keyname of object falling inside b)
    */
    mergeArray(a, b, matchkeys, isOverrideAll = false) {
        const mergedList = _.map(a, (item) => {
            const valueMatched = _.find(b, [matchkeys[1], item[matchkeys[0]]]);
            if (isOverrideAll === false) {
                if (valueMatched) {
                    item[matchkeys[0]] = valueMatched;
                }
                else {
                    item[matchkeys[0]] = {
                        [matchkeys[1]]: item[matchkeys[0]] || null
                    }
                }
            } else {
                if (valueMatched) {
                    item = _.merge(item, valueMatched);;
                }
            }
            return item;
        });
        return mergedList;
    }

    /**
    * @Name: mergeObject
    * 
    * @Description: This function is used to merge the two objects based on keys.
    * 
    * @argument: a-> Object, b -> Object, 
    *            matchkeys -> Object (string with max two values : 1st item should be the keyname of object falling inside a 
    *                 and 2nd item should be the keyname of object falling inside b)
    */
    mergeObject(a, b, matchKeys) {
        let valueMatched = _.find(b, [matchKeys[1], a[matchKeys[0]]]);
        if (valueMatched) {
            a[matchKeys[0]] = valueMatched;
        }
        else {
            a[matchKeys[0]] = null;
        }
        return a;
    }

    /**
    * @Name: Redis key generator
    * 
    * @Description: This function is used to generate the redis store key.
    */
    prepareRedisKey(request, moduleName) {
        return 'dewdropsBFF_' + (request.userEmail || request.user.emailId) + "_" + request.tokenId + "_" + moduleName;
    }

    /**
    * @Name: encodeURI
    * 
    * @Description: This function is used to encodeURI.
    */
    encodeURI(input) {
        return encodeURIComponent(input);
    }

    /**
    * @Name: Strip slash
    * 
    * @Description: This function is used to Strip the last slash.
    */
    stripTrailingSlash(url) {
        return url.replace(/\/+$/, "");
    }

    /**
    * @Name: errorNotification
    * 
    * @Description: This function is used to send 500 error info to client.
    */
    errorNotification(request, productRequestParams, productResponseParams) {
        try {
            const config = rm.productConfig.dd.ErrorNotification;
            if (!config.enabled) return;
            const emailService = new (rm.emailService)({ productName: 'dd', type: "template" }),
                options = {
                    from: config.from,
                    to: config.to,
                    cc: config.cc || [],
                    subject: config.subject,
                    context: {
                        "uiRequest": request || {},
                        "productRequest": productRequestParams || {},
                        "productResponse": productResponseParams || {},
                    },
                    body: "error.notification"
                };
            emailService.sendMail(options, (error, result) => {
                if (error) {
                    //call log service to track this error. 
                    rm.logger.log({ level: "error", data: error });
                }
            });

        } catch (error) {
            rm.logger.log({ level: "error", data: error });
        }
    }

    /**
    * @Name: translateErrorMsg
    * 
    * @Description: This method is used to translate error message based on the user locale.
    */
    translateErrorMsg(error, request) {
        //Product Error
        if (error.name === 'ProductError') {
            if (rm.lodash.isArray(error.message)) {
                if (error.message.length > 0) {
                    error.message.forEach((value) => {
                        let translateParms = [];
                        if (value.additionalInfo) {
                            const additionalInfo = this.tryParse(value.additionalInfo);
                            translateParms = additionalInfo || [];
                        }
                        value.description = this.translate(request, value.description, translateParms);
                    });
                }
            } else {
                error.internalMsg = error.message.internalMsg || undefined;
                error.message = this.translate(request, error.message.description);
            }
        }
        //App Error
        else if (error.name === 'AppError') {
            error.message.description = this.translate(request, error.message.description);
        }
        //Validation Error
        else if (error.name === 'ValidationError') {
            error.message.forEach((value) => {
                const splitMsg = this.splitMsg(value.description);
                if (splitMsg.code !== "") {
                    value.description = this.translate(request, splitMsg.code) + splitMsg.msg;
                }
                delete value.path;
            });
        }
        //It occurs when sending success response data with errors
        else if (rm.lodash.isArray(error)) {
            error.forEach((value) => {
                value = this.translateErrorMsg(value, request);
            });
        }
        return error;
    }

    /**
     * @Name: addProxy
     * 
     * @Description: This method is used to add or remove proxy based on the setting.
     */
    addProxy(url) {
        if (rm.settingConfig.isProxyEnabled === true) {
            const productName = url.split("/")[3].toLowerCase(),
                proxyUrl = rm.settingConfig.proxyURL;
            if (proxyUrl[productName])
                return proxyUrl[productName];
            else if (productName === "services" && url.split("/")[3].toLowerCase()[4] === "rainbow")
                return proxyUrl['rainbow'];
            else if (productName === "imaster")
                return proxyUrl['cmd'];
        } else {
            return undefined;
        }
    }
    /**
     * @method getProductName
     * @param {*} options - Object having mentioned product name & Calling URL
     * @description - Check options object, If product name is mentioned, then check in productMap & return corresponding key
     *                Else check the URL, get param & find corresponding product name from productMap
     *                If first url param is services, then check next URL param
     */
    getProductName(options){
        const productMap = appConstant.productMap;
        const mentionedProduct = options.productName;
        if(!rm.lodash.isEmpty(mentionedProduct) && !rm.lodash.isEmpty(productMap[productName].toLowerCase())){
            return productMap[productName];
        }else if(!rm.lodash.isEmpty(options.url)){
            const urlSplit = options.url.split('/')[3];
            const productName = urlSplit.toLowerCase();
            if(productName === "services" && !rm.lodash.isEmpty(productMap[urlSplit[4]])){
                return productMap[urlSplit[4]];
            }else if(!rm.lodash.isEmpty(productMap[productName])){
                return productMap[productName];
            }else{
                return null;
            }
        }else{
            return null;
        }
    }
}

module.exports = new Utils();
