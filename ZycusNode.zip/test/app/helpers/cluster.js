const cluster = require('cluster');

exports.enableCluster = (params) => {
   if(params){
     if(cluster.isMaster) {
         let numWorkers = require('os').cpus().length;

         for(let i = 0; i < numWorkers; i++) {
             cluster.fork();
         }

         cluster.on('online', worker => {
         });

         cluster.on('exit', (worker, code, signal) => {
             cluster.fork();
         });
         return false;
     }else{
       return true;
     }
   }else{
     return true;
   }
}
