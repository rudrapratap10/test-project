"use strict";
const i18n = require('i18n'),
i18nConfig = require('@helper/configuration').i18n();
exports.config = () =>{
  i18n.configure(i18nConfig);
  return i18n.init;
}
