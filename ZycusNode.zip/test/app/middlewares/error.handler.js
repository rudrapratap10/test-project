"use strict";
const rm = require('@service/require.module')();

exports.applicationError = (error, req, res, next) => {    
    if(error==='dd-error-15'){
      rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, error), "statusCode":401, "lang":req.getLocale()});      
    }else if(error){
      const statusCode = error.statusCode ||  500;
      rm.errorMsg.errorFormat({"request":req,"response":res, "error":error, "serverError":rm.utils.translate(req, 'dd-error-500'),"statusCode":statusCode,"lang":req.getLocale()});              
    }else{
      next();
    }
};
