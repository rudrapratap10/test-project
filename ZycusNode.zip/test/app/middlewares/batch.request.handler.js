"use strict";
const cookieSetting = require('@helper/configuration').session().cookie,
  rm = require('@service/require.module')(),
  routeParser = require('@service/route.parser');

class BatchRequestHandler {
  constructor(request, response) {
    this.request = request;
    this.response = response;
    this.tag = "batch-API"
  }

  async execute() {
    try {
      //Step 1: Validate the request body using joi schema
      const result = this.validation();
      if (result) return this.errorRes({ error: result });

      //Step 2: 
      let routes = [],
        cacheKey = "batchRequest_" + ((this.request.params && this.request.params.requestId) ? this.request.params.requestId : this.request.requestID) + "_" + this.request.tokenId;       
      //a) Check If the http method type is POST and it is SSE request intitialliser
      if (this.request.method === "POST" && this.request.body.sse === true) {
        //Asynchronous Batch API initiator using SSE
        //Insert data to the cache
        await (this.setRedisData(cacheKey));
        //Send the acknowdlegement to the client
        return this.successRes({ message: rm.utils.translate(this.request, "dd-msg-4"), success: true });
      }
      //b) The http method type is will be GET and it is an EventSource request for SSE
      else if (this.request.method === "GET") {
        //Asynchronous Batch API call using SSE
        //Fetch the data from cache
        const cachedData = await (this.getRedisData(cacheKey));
        routes = cachedData.data;        
        if (!rm.lodash.isArray(routes)) return this.errorRes({ errorMsg: rm.utils.translate(this.request, "dd-error-26") });
        //Clear the cache
        await (this.deleteRedisData(cacheKey));
      }
      //c) The http method type is will be POST and it is synchronous batch api call  
      else {
        //Synchronous Batch API call
        routes = this.request.body.data;
      }

      //Step 3: Loop through each API url present inside route objects array
      const syncResponse = [];

      routes.forEach(async (item, index) => {
        try {
          item.method = item.method.toUpperCase();
          const dewDropsHandler = new routeParser({ "request": this.request }).parse(item);
          if (dewDropsHandler.success === false) throw dewDropsHandler;
          //Step 4: 
          //a) If http method type is GET then response will be served by using SSE.
          if (this.request.method === "GET") {
            //Asynchronous Batch API
            const output = dewDropsHandler.handle();
            output.then((ddHandlerResult) => {
              ddHandlerResult = rm.lodash.merge(ddHandlerResult, this.prepareRes(item, index));
              //sending response using SSE              
              return this.successRes(ddHandlerResult);             
            }).catch((error) => {
              error = rm.lodash.merge(error, this.prepareRes(item, index));
              return this.errorRes({ error: error });
            });
          }
          //b) else response will be sent at once after executing and collecting each of the routes
          else {
            //Synchronous Batch API
            let output = await dewDropsHandler.handle();
            output = rm.lodash.merge(output, this.prepareRes(item, index));
            syncResponse.push(output);
            //Sending response using conventional way
            if (routes.length === syncResponse.length) return this.successRes(syncResponse);
          }
        } catch (error) {
          let option = {"error": error, "serverError": rm.utils.translate(this.request, 'dd-error-500'),"request": {},"data": {}};
          option = rm.lodash.merge(option, this.prepareRes(item, index));
          if (this.request.method === "POST") {
            this.prepareErrorRespone(option, (result) => {
              syncResponse.push(result);
              if (routes.length === syncResponse.length) return this.successRes(syncResponse);
            });
          } else {
            return this.errorRes(option);
          }
        }
      });
    } catch (error) {
      return this.errorRes({"error": error,"serverError": rm.utils.translate(this.request, 'dd-error-500')});
    }
  }

  validation() {
    const validationUtility = rm.utils.validationUtility(this.request);
    //handle using joi schema
    if (this.request.method === "GET") {
      //validate requestID should present as query params
      const schema = { "requestId": "joi.required().label('dd-lable-14__')" };
      validationUtility.addInternalSchema(schema);
      let result = validationUtility.validate({ "requestId": this.request.params.requestId });
      if (result) {        
        let errorMsg = new (rm.customError)(result, 'ValidationError', 3);
        errorMsg = rm.utils.translateErrorMsg(errorMsg, this.request);
        return errorMsg;
      }
    }
    else {
      const max = ((this.request.body.sse === true) ? ".max(" + rm.settingConfig.batchAPI.maxAsync + ")." : ".max(" + rm.settingConfig.batchAPI.maxSync + ").");
      const schema = {
        "sse": "joi.boolean().required().label('dd-lable-13__')",
        "data": "joi.array().items(joi.object().keys({url:joi.string().required().label('dd-lable-15__'), method:joi.string().required().valid('POST','PUT','DELETE','GET').insensitive().label('dd-lable-16__'), body:joi.object().when('method', {is: joi.string().valid('post','put','delete').insensitive(), then: joi.object().required().label('dd-lable-17__'), otherwise : joi.object().optional().label('dd-lable-17__')})})).min(1)" + max + "required().unique().label('dd-lable-18__')",
      };
      validationUtility.addInternalSchema(schema);
      let result = validationUtility.validate(this.request.body);
      if (result) {
        let errorMsg = new (rm.customError)(result, 'ValidationError', 3);
        errorMsg = rm.utils.translateErrorMsg(errorMsg, this.request);        
        return errorMsg;
      }
    }
    return false;
  }

  successRes(params) {
    const resMsg = new rm.responseMsg(this.request.getLocale(), this.tag, this.request);
    resMsg.successRes(params, (err, result) => {
      if (result) {
        if (this.request.method === "GET") {
          result["content-type"] = "sse";
          result = {
            "id": rm.utils.uuid(this.request),
            "eventName": "DD-SSE-Batch-" + this.request.tokenId,
            "data": result
          };
        }
        return rm.response(this.request, this.response, result);
      }
    });
  }

  prepareErrorRespone(option, callback) {
    const resMsg = new rm.responseMsg(this.request.getLocale(), this.tag, this.request),
      errorType = option.errorType || null,
      error = option.error || new rm.customError(option.errorMsg, errorType, option.statusCode),
      serverError = option.serverError || null,
      data = option.data || null,
      request = option.request || undefined;
    resMsg.statusCode = option.statusCode;
    resMsg.errorRes(error, data, serverError, (err, result) => {
      if (result) {
        result.request = request;
        callback(result);
      }
    });
  }

  errorRes(option) {
    this.prepareErrorRespone(option, (result) => {
      if (result) {
        if (this.request.method === "GET") {
          result["content-type"] = "sse";
          result = {
            "id": rm.utils.uuid(this.request),
            "eventName": "DD-SSE-Batch-Error-" + this.request.tokenId,
            "data": result
          };
        }
        rm.response(this.request, this.response, result);
      }
    });
  }

  prepareRes(input, index) {
    const output = {};
    output.request = rm.lodash.pick(input, ["url", "method"]);
    output.request.index = index;
    return output;
  }

  getRedisData(key) {
    return new Promise((resolve, reject) => {
      rm.redisClient.getRedisData(rm.utils.prepareRedisKey(this.request, key), (error, result) => {
        if (error) return resolve({ "success": false, "error": error });
        const data = rm.utils.tryParse(result);
        return resolve({ "success": true, "data": data });
      });
    });
  }

  setRedisData(key) {
    let data = this.request.body.data;
    return new Promise((resolve, reject) => {
      rm.redisClient.setRedisData(rm.utils.prepareRedisKey(this.request, key), data, null, (error, result) => {
        if (error) return resolve({ "success": false, "error": error });
        return resolve({ "success": true, "data": result });
      });
    });
  }

  deleteRedisData(key) {
    return new Promise((resolve, reject) => {
      rm.redisClient.removeRedisData(rm.utils.prepareRedisKey(this.request, key), (error, result) => {        
        if (error) return resolve({ "success": false, "error": error });
        return resolve({ "success": true, "data": result });
      });
    });
  }

}

exports.batchRequestHandler = (req, res) => {
  return new BatchRequestHandler(req, res).execute();
}