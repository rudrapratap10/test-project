"use strict";
const rm = require('@service/require.module')();

//Check whether UserData available in the Request Object
exports.getDataFrmReq = (req, res, next) => {
  try {     
    //Check User Data availablity in request object
    if(req.user){
      next();
    }else{
      const data = {"redirectUrl" : rm.uiConfig.TMS_Web.SMT_LOGIN_URL};         
      rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'tms-error-401'), "statusCode":401, "lang":req.getLocale(), "data":data});
    }    
  } catch (error) {
      next(error);
  }
}