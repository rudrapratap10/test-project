"use strict";
const cors = require('cors'),
    rm = require('@service/require.module')();

exports.checkOrigin = (req, res, next) => {
    try {
        const whitelistOrigin = rm.settingConfig.allowOrigin,
            whiteListURL = rm.settingConfig.allowURL,
            requestUrl = req.url;
        let isWhitelistURL = true,
            options = {
            methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'PATCH', 'DELETE'],
            allowedHeaders: ['Origin', 'X-Requested-With', 'Content-Type', 'Accept', 'xsrf-token', 'X-CSRF-Token', 'modulename'],
            credentials: true
        };
        if (rm.lodash.isArray(whiteListURL) && whiteListURL.length>0) {
            rm.lodash.forEach(whiteListURL, (url) => {
                let regExp = new RegExp(url),
                    findMatch = regExp.test(requestUrl);
                if (findMatch) isWhitelistURL = false;
                return;
            });
        }

        if (rm.lodash.isArray(whitelistOrigin) && isWhitelistURL) {
            options.origin = (origin, callback) => {
                if (rm.utils.isOriginAllowed(origin, whitelistOrigin)) {
                    callback(null, true);
                } else {
                    callback('dd-error-15');
                }
            };
        }
        return cors(options)(req, res, next);
    } catch (error) {
        next(error);
    }
};
