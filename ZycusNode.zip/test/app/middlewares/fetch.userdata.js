"use strict";
const rm = require('@service/require.module')();

//Fetch User Data from Redis & Set to the Request object
exports.setDataFrmRedis = (req, res, next) => {
  try {   
    const emailAddress = req.userEmail,
          tokenId = req.tokenId;
    //Step 1: Check Token availablity in request object && whether it is valid
    if(tokenId && emailAddress){
      //Step 2: Check Data in Redis
       rm.redisClient.getRedisData(rm.utils.prepareRedisKey(req,"userDetails"), (error, result)=>{
          const tms = new (rm.tmsHook({request: req}))();
          if(error && error!=="Empty_Data") {
            let err = rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":error.message, "statusCode":500, "lang":req.getLocale()});            
            next(err);
          } else {
            if(result){
              //Step 2(a): Parse the data fetched from redis
              const data = JSON.parse(result);            
              //Step 2(b):Set data into request object
              tms.setUserData(req, data);
              //Step 2(c):Set Expiry Time (Idle Timeout)
              rm.redisClient.setExpire(tokenId,(err,res)=>{
                if (err) {              
                  next(err);
                }else {
                  //Step 2(d): Procced to next callback
                  next();
                }
              });
            }       
            else {
              //Step 2(a): Fetch user related data from TMS and load into redis
              tms.fetchUserData(req, emailAddress, (error, data) => {
                if (error) {              
                  next(error);
                }else {            
                  //Step 2(b):Set data into request object
                  tms.setUserData(req, data);     
                  //Step 2(c): Procced to next callback  
                  next();
                }
              });
            }
          }
       });
    }else{
      next();
    }    
  } catch (error) {
      next(error);
  }
}