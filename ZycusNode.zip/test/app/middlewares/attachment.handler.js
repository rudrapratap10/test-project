"use strict"; 
const mime = require('mime'),
rm = require('@service/require.module')(),
cookieSetting = require('@helper/configuration').session().cookie;

 exports.handler = (req, res, next) => { 
    // check the file path value here.
    let validationUtility = rm.utils.validationUtility(req);          
    let schema = {
        "filePath": "joi.string().required().label(request.__('dd-error-14'))"
    };
    validationUtility.addInternalSchema(schema);    
    let result = validationUtility.validate({"filePath": req.params.filePath});   
    if (result) {
        const errorMsg = new (rm.customError)(result, 'ValidationError', 3);
        next(errorMsg);
    } else {    
        let productName = req.params.product;    
        let filePath = req.params.filePath;        
        // Decode the file path by SAAS token   
        let decodedPath = rm.utils.decrypt(filePath.replace(/@/g, "/"), req.tokenId, true);         
        if(decodedPath){
            // Split the file path and file name  by ~ symbol.
            let filePathSplit = decodedPath.split("~");             
            if(filePathSplit.length==2){
                let path = filePathSplit[0];                                 
                const sftp = new (require('@provider/sftp'))(productName);    
                sftp.get(path, (error, filestream)=>{ 
                    res.setHeader('Cache-Control', 'public, max-age=' + cookieSetting.maxAge);
                    if(error){ // file does not exist from the sftp server/other issue.
                        rm.logger.log({"level":"error", "data": error});
                        let filename =filePathSplit[1]; 
                        let imageTypes=['image/png','image/jpeg', 'image/jpeg', 'image/jpeg', 'image/gif', 'image/bmp', 'image/vnd.microsoft.icon', 'image/tiff','image/tiff', 'image/svg+xml', 'image/svg+xml'];
                        let mimetype = mime.getType(filename);  
                        //if image file doesn't exist in the sftp server, we provide/load a no-image file from node server to the client.                      
                        if(rm.lodash.includes(imageTypes, mimetype)){
                            filename = 'no-image.jpg';
                            res.set('Default-Image', true);
                            return res.status(404).download(filename);  
                        }else{ //if other format file doesn't exist in the sftp server, we throw an error(json fromat way) to the client.
                           return rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-404.1'), "statusCode":404, "lang":req.getLocale()});                              
                        }                                                 
                    }else if(filestream){ //file exist in the sftp server, we load and download it to the client.
                        let filename =filePathSplit[1];    
                        let mimetype = mime.getType(filename);
                        res.setHeader('Content-Description', 'File Transfer');
                        res.setHeader('Content-Type', mimetype);
                        res.setHeader('Content-Disposition', 'attachment; charset=utf-8; filename='+filename); 
                        res.setHeader('Content-Transfer-Encoding', 'binary');
                        return filestream.pipe(res);
                    }           
                });
            }else{                
                return rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-404.1'), "statusCode":404, "lang":req.getLocale()});    
            }
        }else{
             return rm.errorMsg.errorFormat({"request":req, "response":res, "errorMsg":rm.utils.translate(req, 'dd-error-404.1'), "statusCode":404, "lang":req.getLocale()});  
        }    
    }          
}