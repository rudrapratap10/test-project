"use strict";
const utils = require('@helper/utils'),
productDomain = require('@service/product.domain'),
rm = require('@service/require.module')();

 exports.setValue = (req, res, next) => {
   req.requestID = req.headers['requestid'] || utils.uuid(req);  
   // Inject products URL object to every request 
   req.productsURL = new productDomain().get();
     
   //Get the Product Name 
   req.productName = req.path.split("/")[2];
   req.headers.origin = req.headers.origin || utils.stripTrailingSlash(rm.settingConfig.WEB_URL);
   
   // log request body come from UI to BFF
   rm.logger.requestResponseLog({"request": req, "input": req.body, "type": 1});
   
   next();
}

