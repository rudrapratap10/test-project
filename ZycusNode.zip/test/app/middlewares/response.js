"use strict";
const setting = require('@helper/configuration').setting();
exports.setValue = (req, res, next) => {
    // Pass to next layer of middleware
    next();
}
