"use strict";
const rm = require('@service/require.module')();

module.exports = (req, res, next) => {
  //check swagger is enable or not in settingConfig
  try {
    if (rm.settingConfig.enableSwagger) {
      const swaggerSpec = require('@helper/swagger').init();
      swaggerSpec.statusCode = 200;
      rm.response(req, res, swaggerSpec);
    } else {
      next();
    }
  } catch (error) {
    next(error);
  }
}