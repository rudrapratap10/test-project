"use strict";

module.exports = {    
    
    /**
    * @swagger
    * /a/ecatalog/items/list:
    *   post:
    *     tags:
    *       - Ecatalog API
    *     summary: Get the item list
    *     operationId: getEcatalogItems
    *     description: Get the item list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the ecatalog items ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "item.getList",
        post: null,
        method: 'POST'
    } 
};