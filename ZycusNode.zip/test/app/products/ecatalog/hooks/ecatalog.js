"use strict";
const rm = require('@service/require.module')(), 
commonCatalogResponseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "createdOn": { "type": "date" }, "favourite": { "type": "boolean" }, "modifiedOn": { "type": "date" }, "releaseDate": { "type": "date" }, "publishedOn": { "type": "date" }, "supplierValidFrom": { "type": "date" }, "supplierValidTo": { "type": "date" }, "validFrom": { "type": "date" }, "validTo": { "type": "date" }, "submittedOn": { "type": "date" }, "status": { "type": "number" }, "version": { "type": "number" }, "contractType": { "type": "number" }, "totalCount": { "type": "number" }, "errorCount": { "type": "number" }, "addedCount": { "type": "number" }, "updatedCount": { "type": "number" }, "removedCount": { "type": "number" }, "supplierContactType": { "type": "number" }, "source": { "type": "number" }, "catalogType": { "type": "number" }, "itemMasterType": { "type": "number" }, "extendedVersion": { "type": "number" }, "supplierName": { "type": "string" }, "supplierId": { "type": "string" }, "supplierVersion": { "type": "string" }, "supplierCatalogName": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierEmail": { "type": "string" }, "transactionId": { "type": "string" }, "contractNo": { "type": "string" }, "contractId": { "type": "string" }, "catalogId": { "type": "string" }, "warehouseCode": { "type": "string" }, "name": { "type": "string" }, "processing": { "type": "boolean" }, "description": { "type": "string" }, "systemAttributesString": { "type": "string" }, "multipleSuppliers": { "type": "boolean" }, "updated": { "type": "boolean" }, "publishing": { "type": "boolean" }, "sendToReadyForApproval": { "type": "boolean" }, "approvalRequired": { "type": "boolean" }, "buyerAmend": { "type": "boolean" } } } } };

/**
 * Ecatalog Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class Ecatalog {

    /*
     * Get List Method
     * This method to get the Catalog  details.
    */
   getCatalogList(request, input, callback) {

    try {
        const http = new (rm.httpService)(request, rm.appConstant.reqHandler.filter, rm.appConstant.resHandler.filter);            
        const eCatalog = request.productsURL.eCatalog;
        const url = eCatalog+'/catalog/filter';    
        http.post(url,input, request.body, (error, result) => {
            if (error) {
                return callback(error, null);
            } else if (result) {
                const responseSchema = commonCatalogResponseSchema,
                output = (new (rm.responseHandler)(request, result, responseSchema));
               output.addCommonSchema('pagination', output.responseSchema.properties);
               const schemaRes = output.execute();
               if (schemaRes.data) {
                   schemaRes.data.facetResult = result.data.facetResult;
                   schemaRes.data.statResult = result.data.statResult;
               }
               return callback(null, request, schemaRes);                 
            }
        });
    } catch (error) {
        return callback(error, null);
    }

}

}

module.exports = Ecatalog;