/**
 * Catalog Controller
 *
 * @description :: It deals with Catalog related actions.
 */

"use strict";
module.exports = (parentClass)=> {
  class Catalog extends parentClass {
     /**
       * Get the eCatalog items list.
     */ 
      getList(request, input, callback) {
            try {                
                const validationUtility = super.utils.validationUtility(request);         
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');    
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const ecatalogHook = new (super.ecatalogHook({request: request}))();                  
                    ecatalogHook.getCatalogList(request, 'getCatalogList', (error, request, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {                     
                            return callback(null, request, result);
                        }
                    });   

                }                
            } catch (error) {               
                return callback(error, null);
            }
        }

  }
  return Catalog;
};

