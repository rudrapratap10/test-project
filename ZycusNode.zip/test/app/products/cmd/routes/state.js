/**
   * State Controller
   * Provides this controller to get the state list and details.
*/

"use strict";

module.exports = {

  /**
   * @swagger
   * /a/cmd/states/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get State list
   *     operationId: getStateList
   *     description: Fetch all the state List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Fetch the state list(based on those options filter, pagination).
   *         in: body
   *         schema:
   *           properties:
   *             name: 
   *               type: string
   *             code: 
   *               type: string
   *             countryCode: 
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *             sortColumn:
   *               type: string
   *             ascending:
   *               type: boolean
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "state.getList",
    post: null,
    method: 'POST'
  } 
  
}