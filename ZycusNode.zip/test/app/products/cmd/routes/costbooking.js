"use strict";

module.exports = {

        /**
* @swagger
* /a/cmd/costBookings/ruleMap:
*   post:
*     tags:
*       - CMD API
*     summary: costbooking ruleMap
*     operationId: costBookingRuleMap
*     description: Fetch the cost booking Rule Map
*     produces:
*       - application/json
*     parameters:
*       - name: body
*         description:  Fetch the cost booking Rule Map(based on search criteria & pagination).
*         type: string
*         in: body
*         schema:
*             allOf:
*                - $ref: '#/definitions/pagination'
*                - type: object
*                  properties:
*                    isActive:
*                      type: boolean
*                    purchaseType:
*                      type: string
*     responses:
*       200:
*         description: successful operation
*/
ruleMap: {
    pre: null,
    process: "costbooking.ruleMap",
    post: null,
    method: 'POST'
}

}
