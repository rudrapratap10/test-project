"use strict";

module.exports = {

    /**
    * @swagger
    * /a/cmd/exchangeRates/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Search CurrencyExchange Rates
    *     operationId: searchCurrencyExchangeRates
    *     description: search for current currency exchange rates
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide details for currency.
    *         type: string
    *         in: body
    *         schema:
    *             properties:
    *               startIndex:
    *                 type: string
    *               noOfRecords:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "exchangerate.getList",
        post: null,
        method: 'POST'
    },

     /**
    * @swagger
    * /a/cmd/exchangeRates/getRates:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Exchange Rate
    *     operationId: getExchangeRate
    *     description: Get exchange rate details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide the name for address.
    *         type: string
    *         in: body
    *         schema:
    *             properties:
    *               fromCurrency:
    *                 type: string
    *               toCurrency:
    *                 type: string
    *             required:
    *              - fromCurrency
    *              - toCurrency
    *     responses:
    *       200:
    *         description: successful operation
    */
    getRates: {
        pre: null,
        process: "exchangerate.getRates",
        post: null,
        method: 'POST'
    }, 

    /**
    * @swagger
    * /a/cmd/exchangeRates/getRateMaps:
    *   get:
    *     tags:
    *       - CMD API
    *     summary: Get Exchange Rate Map
    *     operationId: getExchangeRateMap
    *     description: Get exchange rate map details
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getRateMaps: {
        pre: null,
        process: "exchangerate.getRateMaps",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/cmd/exchangeRates/addOrUpdateExchangeRates:
    *   get:
    *     tags:
    *       - CMD API
    *     summary: Add Or Update Exchange Rates
    *     operationId: addOrUpdateExchangeRates
    *     description: Add Or Update Exchange Rates
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    addOrUpdateExchangeRates: {
        pre: null,
        process: "exchangerate.getList",
        post: null,
        method: 'GET'
    },
};