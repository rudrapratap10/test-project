/**
   * Country Controller
   * Provides this controller to get the country lists and details.
*/

"use strict";

module.exports = {
  /**
   * @swagger
   * definitions:
   *   countryfields:
   *     properties:
   *       name:
   *         type: string
   */

  /**
   * @swagger
   * /a/cmd/countries/list:
   *   post:
   *     tags:
   *       - CMD API
   *     summary: Get Country List
   *     operationId: getcountryList
   *     description: Fetch the country List
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Find the country List(based on name and code).
   *         in: body
   *         schema:
   *           properties:
   *             name:
   *               type: string
   *             code:
   *               type: string
   *             perPageRecords:
   *               type: integer
   *             pageNo:
   *               type: integer
   *             sortColumn:
   *               type: string
   *             ascending:
   *               type: boolean
   *     responses:
   *       200:
   *         description: successful operation
   */

  getList:{
    pre: null,
    process: "country.getList",
    post: null,
    method: 'POST'
  }, 

  /**
   * @swagger
   * /a/cmd/countries:
   *   get:
   *     tags:
   *       - CMD API
   *     summary: Get Country List
   *     operationId: getcountryLists
   *     description: Fetch all the country List
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *         description: successful operation
   */

  getRecords:{
    pre: null,
    process: "country.getRecords",
    post: null,
    method: 'GET'
  }
}