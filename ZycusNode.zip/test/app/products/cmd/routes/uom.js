"use strict";

module.exports = {

    /**
    * @swagger
    * /a/cmd/uom/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: search the UOM
    *     operationId: searchUOM
    *     description: Search the UOM
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the UOM list(based on name and code).
    *         in: body
    *         schema:
    *           properties:
    *             name:
    *               type: string
    *             code:
    *               type: string
    *             nameORcode:
    *               type: string
    *             perPageRecords:
    *               type: integer
    *             pageNo:
    *               type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "uom.getList",
        post: null,
        method: 'POST'
    }

}