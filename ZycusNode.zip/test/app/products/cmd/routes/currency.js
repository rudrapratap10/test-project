"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/currencies/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get Currency List
    *     operationId: getCurrencyList
    *     description: Get Currency List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Currency List(based on search criteria & pagination).
    *         in: body
    *         schema:
    *             properties:  
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               nameORcode:
    *                 type: string
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "currency.getList",
        post: null,
        method: 'POST'
    } 
};