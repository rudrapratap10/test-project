"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/cmd/procurementScopes/getScope:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: Get a user Procurement Scopes
    *     operationId: getProcurementScopes
    *     description: Get a user procurement scopes
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the user scopes(based on UserId).
    *         in: body
    *         schema:
    *           properties:
    *             userId:
    *               type: string
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getScope: {
        pre: null,
        process: "procurementscope.getScope",
        post: null,
        method: 'POST'
    } 
};