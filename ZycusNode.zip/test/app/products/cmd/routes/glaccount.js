/**
   * @Name: GlAccountController   
   * @Description : It is used for handling Glaccount related operations.
**/
"use strict";

module.exports = {
    /**
    * @swagger
    * /a/cmd/glAccounts/list:
    *   post:
    *     tags:
    *       - CMD API
    *     summary: GL Account List
    *     operationId: glaccountList
    *     description: Fetch the glaccount list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the glaccount list(based on search criteria & pagination).
    *         type: string
    *         in: body
    *         schema:
    *             properties:
    *               name:
    *                 type: string
    *               code:
    *                 type: string
    *               codes:
    *                 type: array
    *                 items:
    *                   type: string
    *               isActive:
    *                 type: boolean
    *               perPageRecords:
    *                 type: integer
    *               pageNo:
    *                 type: integer
    *               accountTypeCode:
    *                 type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "glaccount.getList",
        post: null,
        method: 'POST'
    },

    /**
     * @swagger
     * /a/cmd/glAccounts/allowedList:
     *   post:
     *     tags:
     *       - CMD API
     *     summary: Search Allowed Genarl Ledger Account
     *     operationId: searchAllowedGLAccount
     *     description: Search Allowed Genarl Ledger Account
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find the Genarl Ledger Account based on those inputs(pagination, sorting & filter).
     *         in: body
     *         required: true
     *         schema:
     *             allOf:
     *                - $ref: '#/definitions/pagination'
     *                - $ref: '#/definitions/cmdSort'
     *                - type: object
     *                  properties:  
     *                    companyCode:
     *                      type: string
     *                    businessUnitCode:
     *                      type: string
     *                    costCentercode:
     *                      type: string
     *                    amount:
     *                      type: number
     *                    purchaseType:
     *                      type: string
     *                    categoryCode:
     *                      type: string
     *                    leaf:
     *                      type: boolean 
     *                    name:
     *                      type: string
     *                  required: [companyCode, businessUnitCode, costCentercode, amount, purchaseType, categoryCode ]
     *     responses:
     *       200:
     *         description: successful operation
     */

    allowedList: {
        pre: null,
        process: "glaccount.allowedList",
        post: null,
        method: 'POST'
    },

    /**
* @swagger
* /a/cmd/glAccounts/ruleMap:
*   post:
*     tags:
*       - CMD API
*     summary: GL Account ruleMap
*     operationId: glaccountRuleMap
*     description: Fetch the glaccount Rule Map
*     produces:
*       - application/json
*     parameters:
*       - name: body
*         description: Fetch the glaccount Rule Map(based on search criteria & pagination).
*         type: string
*         in: body
*         schema:
*             properties:
*               isActive:
*                 type: boolean
*               isArchive:
*                 type: boolean
*               ascending:
*                 type: boolean
*               perPageRecords:
*                 type: integer
*               pageNo:
*                 type: integer
*     responses:
*       200:
*         description: successful operation
*/
    ruleMap: {
        pre: null,
        process: "glaccount.ruleMap",
        post: null,
        method: 'POST'
    }
}

