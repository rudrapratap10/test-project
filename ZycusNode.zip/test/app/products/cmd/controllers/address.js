"use strict";

module.exports = (parentClass) => {

    class Address extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used for fetching address list
        * @param1 name  
        * @return : object
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().max(30).allow('').label('cmd-lable-1__')",
                    "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')",
                    "isActive": "joi.boolean().allow('').label('cmd-lable-39__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmd = new (super.cmdHook({request: request}))();
                    cmd.getAddress(request, request.body, (error, request, response) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { } } } };
                            let output = (new (super.responseHandler)(request, response, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            output.addCommonSchema('address', output.responseSchema.properties.result.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : create
        * @Description : It is used to add new address
        * @param1 name, street1, street2, street3, street4, city, county, state, postal, country, oneTime, shipTo, billTo, invoiceTo  
        * @return : object
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().min(1).max(40).required().label('cmd-lable-1__')",
                    "street1": "joi.string().min(1).max(100).required().label('cmd-lable-2__')",
                    "street2": "joi.string().min(1).max(100).required().label('cmd-lable-3__')",
                    "street3": "joi.string().max(100).empty('').label('cmd-lable-4__')",
                    "street4": "joi.string().max(100).empty('').label('cmd-lable-5__')",
                    "city": "joi.string().max(100).empty('').label('cmd-lable-9__')",
                    "county": "joi.string().max(100).empty('').label('cmd-lable-10__')",
                    "state": "joi.object({ code: joi.string().required().label('cmd-lable-18__')}).label('cmd-lable-11__')",
                    "postal": "joi.string().max(10).empty('').label('cmd-lable-8__')",
                    "country": "joi.object({code: joi.string().required().label('cmd-lable-22__')}).required().label('cmd-lable-12__')",
                    "oneTime": "joi.boolean().label('cmd-lable-13__')",
                    "custom": "joi.boolean().label('cmd-lable-39__')",
                    "shipTo": "joi.boolean().required().label('cmd-lable-14__')",
                    "billTo": "joi.boolean().required().label('cmd-lable-15__')",
                    "invoiceTo": "joi.boolean().required().label('cmd-lable-16__')"
                }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd;
                    const requestData = {
                        tenantId: request.user.tenantId,
                        createdBy: request.user.userId,
                        name: request.body.name,
                        line1: request.body.street1,
                        line2: request.body.street2,
                        line3: request.body.street3 || null,
                        line4: request.body.street4 || null,
                        city: request.body.city || null,
                        county: request.body.county || null,
                        state: request.body.state,
                        zip: request.body.postal || null,
                        country: request.body.country,
                        oneTime: request.body.oneTime || false,
                        custom : request.body.custom || false,
                        shipTo: request.body.shipTo,
                        billTo: request.body.billTo,
                        invoiceTo: request.body.invoiceTo
                    };
                    const http = new (super.httpCmdService)(request);
                    const url = cmdURL + '/geography/addAddress?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + "&countryIsoCode=" + requestData.country.code + "&stateIsoCode=" + (requestData.state ? requestData.state.code : '') + "&contentType=application/json";
                    http.post(url, 'addAddress', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const output = {};
                            if (!super.lodash.isEmpty(result.data) && super.lodash.isObject(result.data)) {
                                output.message = "cmd-msg-1";
                                output.data = result.data;
                                return callback(null, request, output);
                            } else {
                                return callback(new (super.customError)('cmd-error-4', 'AppError'), null);
                            }
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : update
        * @Description : It is used to update address
        * @param1 name, street1, street2, street3, street4, city, county, state, postal, country, oneTime, shipTo, billTo, invoiceTo  
        * @return : object
        */
        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().min(1).max(30).required().label('cmd-lable-1__')",
                    "code": "joi.string().min(2).max(30).required().label('cmd-lable-18__')",
                    "street1": "joi.string().min(1).max(50).required().label('cmd-lable-2__')",
                    "street2": "joi.string().min(1).max(50).required().label('cmd-lable-3__')",
                    "street3": "joi.string().max(50).empty('').label('cmd-lable-4__')",
                    "street4": "joi.string().max(50).empty('').label('cmd-lable-5__')",
                    "city": "joi.string().max(30).empty('').label('cmd-lable-9__')",
                    "county": "joi.string().max(30).empty('').label('cmd-lable-10__')",
                    "state": "joi.object({ code: joi.string().required().label('cmd-lable-18__')}).required().label('cmd-lable-11__')",
                    "postal": "joi.string().max(30).empty('').label('cmd-lable-8__')",
                    "country": "joi.object({code: joi.string().required().label('cmd-lable-22__')}).required().label('cmd-lable-12__')",
                    "oneTime": "joi.boolean().label('cmd-lable-13__')",
                    "custom": "joi.boolean().label('cmd-lable-39__')",
                    "shipTo": "joi.boolean().required().label('cmd-lable-14__')",
                    "billTo": "joi.boolean().required().label('cmd-lable-15__')",
                    "invoiceTo": "joi.boolean().required().label('cmd-lable-16__')"
                }
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd;
                    const requestData = [{
                        tenantId: request.user.tenantId,
                        createdBy: request.user.userId,
                        name: request.body.name,
                        code: request.body.code,
                        line1: request.body.street1,
                        line2: request.body.street2,
                        line3: request.body.street3 || null,
                        line4: request.body.street4 || null,
                        city: request.body.city || null,
                        county: request.body.county || null,
                        state: request.body.state.code,
                        zip: request.body.postal || null,
                        country: request.body.country.code,
                        oneTime: request.body.oneTime || false,
                        custom : request.body.custom || false,
                        shipTo: request.body.shipTo,
                        billTo: request.body.billTo,
                        invoiceTo: request.body.invoiceTo
                    }];
                    const http = new (super.httpCmdService)(request);
                    const url = cmdURL + '/geography/addUpdateAddresses?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId;
                    http.post(url, 'updateAddress', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const output = {};
                            if (!super.lodash.isEmpty(result.data) && super.lodash.isObject(result.data)) {
                                output.message = (result.data.FAILURE.error == true) ? "cmd-error-4" : "cmd-msg-2";
                                output.data = result.data;
                                return callback(null, request, output);
                            } else {
                                return callback(new (super.customError)('cmd-error-4', 'AppError'), null);
                            }
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : allowedList     
        * @Description : Search Allowed Address
        * @return object / Throw Error
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "name": "joi.string().allow('').label('cmd-lable-1__')",
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "businessUnitCode": "joi.string().required().label('cmd-lable-28__')",
                        "userId": "joi.string().allow('').max(100).label('cmd-lable-34__')",
                        "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')",
                        "isActive": "joi.boolean().allow('').label('cmd-lable-40__')",
                        "custom": "joi.boolean().label('cmd-lable-39__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('cmdSort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const tmsURL = request.productsURL.eProc["web"],
                        http = new (super.httpTmsService)(request),
                        sortColumn = request.body.sortColumn || 'SORT_BY_NAME',
                        ascending = request.body.ascending || true,
                        perPageRecords = request.body.perPageRecords || super.settingConfig.perPageRecords,
                        pageNo = request.body.pageNo || (super.settingConfig.pageNo - 1),
                        name = request.body.name || '',
                        url = tmsURL +
                            '?responseType=json' +
                            '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                            '&scopeName=eProcjQuery' +
                            '&userId=' + super.utils.encodeURI(request.user.userId) +
                            '&userName=' + super.utils.encodeURI(request.user.displayName) +
                            '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                            '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
                            '&method=master.geography.searchAllowedAddresses' +
                            '&sortColumn=' + super.utils.encodeURI(sortColumn) +
                            '&ascending=' + super.utils.encodeURI(ascending) +
                            '&column1=SEARCH_BY_NAME' +
                            '&value1=' + super.utils.encodeURI(name) +
                            '&column2=SEARCH_BY_ACTIVE' +
                            '&value2=1' +
                            '&column3=SEARCH_BY_ARCHIVE' +
                            '&value3=' +
                            '&column4=SEARCH_BY_ONE_TIME' +
                            '&value4=' +
                            '&column5=SEARCH_BY_UNIQUE_ADDRESS' +
                            '&value5=1' +
                            '&column6=SEARCH_BY_BU_OR_CUSTOM'+
                            '&value6=1' +
                            '&company=' + super.utils.encodeURI(request.body.companyCode) +
                            '&buCodes=' + super.utils.encodeURI(request.body.businessUnitCode) +
                            '&startIndex=' + super.utils.encodeURI(pageNo) +
                            '&noOfRecords=' + super.utils.encodeURI(perPageRecords) +
                            '&mode=2' +
                            '&userIds=' + (super.utils.encodeURI(request.body.userId ||  request.user.userId) );
                    http.get(url, 'allowedProjectList', (error, response) => {
                        if (error) {
                            return callback(error, null);
                        } else if (response) {
                            const output = {};
                            if (super.lodash.isEmpty(response.result.addresses)) {
                                output.errors = new (super.customError)('dd-common-error-1', "AppError");
                                output.data = {};
                            } else{
                                output.data = super.lodash.merge(response.result, super.utils.formPaginateRequest(request.body));
                            }
                            let responseSchema = { "type": "object", "properties": { "addresses": { "type": "array", "key": "records", "properties": { "line1": { "type": "string" }, "line2": { "type": "string" }, "line3": { "type": "string" }, "line4": { "type": "string" }, "oneTime": { "type": "boolean" }, "city": { "type": "string" }, "county": { "type": "string" }, "state": { "type": "string" }, "zip": { "type": "string" }, "country": { "type": "string" }, "phone": { "type": "number" }, "fax": { "type": "number" }, "email": { "type": "string" }, "url": { "type": "none" }, "shipTo": { "type": "boolean" }, "billTo": { "type": "boolean" }, "invoiceTo": { "type": "boolean" }, "locationCode": { "type": "none" }, "locationName": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "tenantId": { "type": "string" } } } } },
                                result = (new (super.responseHandler)(request, output, responseSchema));
                                result.addCommonSchema('cmd-pagination', result.responseSchema.properties);
                            return callback(null, request, result.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }

    return Address;
};