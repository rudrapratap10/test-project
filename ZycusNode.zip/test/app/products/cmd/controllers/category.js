/**
 * Category Controller
 *
 * @description :: Provides Category related operations
 */

"use strict";

module.exports = (parentClass)=> {   
    class Category extends parentClass {
        /**
        * @Method Name : getList
        *
        * @Description : Display the category lists
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request), 
                schema = {
                    "name" : "joi.string().label('cmd-lable-1__')",
                    "code": "joi.string().max(30).label('cmd-lable-10__')",
                    "parentCategoryName": "joi.string().max(30).label('cmd-lable-25__')"
                };                      
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const cmdURL = request.productsURL.cmd,                   
                    http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                    url = cmdURL+'/category/searchCategories?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + '&locale='+request.user.userSettings.locale;                 
                    http.post(url, 'getCategoryList', request.body, (error, response) => {
                    if(error){
                        callback(error, null);
                    }else if(response){                                                                                         
                        let responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"categoryCode":{"type":"string"},"parentCategoryName":{"type":"string"},"parentCategoryCode":{"type":"string"},"description":{"type":"string"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"}}}}};
                        let output =  (new (super.responseHandler)(request, response, responseSchema));
                        output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                        return callback(null, request, output.execute());
                    }
                });
            }                
        } catch (error) {
            return callback(error, null);
        }
    }


        /**
        * @Method Name : getRecords
        *
        * @Description : Display the all category lists
        * @return object / Throw Error
        */
        getRecords(request, input, callback){
            try {
                const http =  new (super.httpCmdService)(request),
                      cmdURL = request.productsURL.cmd,
                      url = cmdURL+'/category/searchCategories?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + '&locale='+request.user.userSettings.locale; 
                http.post(url, 'categoryList', request.body, (error, response) => {
                if(error){
                    return callback(error, null);
                }else if(response){                                                                                         
                        let responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"categoryCode":{"type":"string"},"parentCategoryName":{"type":"string"},"parentCategoryCode":{"type":"string"},"description":{"type":"string"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"}}}}};
                        let output =  (new (super.responseHandler)(request, response, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        } 

    }   
    return Category;
};