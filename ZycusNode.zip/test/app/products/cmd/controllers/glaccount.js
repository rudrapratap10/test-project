/**
   * @Name: GlAccountController   
   * @Description : It is used for handling Glaccount related operations.
**/
"use strict";

module.exports = (parentClass) => {

    class Glaccount extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used for fetching account Types list
        * @param1 name  
        * @return : object
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "accountTypeCode": "joi.string().max(30).label('cmd-lable-52__')",
                    "name": "joi.string().max(30).label('cmd-lable-1__')",
                    "code": "joi.string().max(30).label('cmd-lable-10__')",
                    "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')",
                    "isActive": "joi.boolean().allow('').label('cmd-lable-39__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        "name": request.body.name,
                        "code":request.body.code,
                        "codes": request.body.codes,
                        "isActive":request.body.isActive,
                        conditions: []
                    }
                    if (!super.lodash.isEmpty(request.body.accountTypeCode)) {
                      requestData.conditions.push({
                          "column": "SEARCH_BY_GENERAL_LEDGER_CODE",
                          "value": request.body.accountTypeCode
                      });
                  }
                    const cmdURL = request.productsURL.cmd,
                     http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                     url = cmdURL + '/accounting/searchGeneralLedgers?tenantId=' + request.user.tenantId + '&code=' + request.body.code+'&locale='+request.user.userSettings.locale;
                    http.post(url, 'getGlAccount', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdOn": { "type": "date" }, "createdBy": { "type": "string" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "id": { "type": "number" }, "accountTypeCode": { "type": "string" }, "generalLedgerCode": { "type": "string" }, "parentGeneralLedgerCode": { "type": "string" }, "description": { "type": "string" }, "erpId": { "type": "string" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : allowedList     
        * @Description : Search Allowed Genarl Ledger Account
        * @return object / Throw Error
        */
        /*allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "businessUnitCode": "joi.string().required().label('cmd-lable-28__')",
                        "name": "joi.string().max(30).label('cmd-lable-1__')",
                        "code": "joi.string().max(30).label('cmd-lable-18__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('cmdSort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd,
                        scopeParams = JSON.stringify([{ "ORST_ORG_LVL_1": [request.body.companyCode], "ORST_ORG_LVL_2": [request.body.businessUnitCode] }]),
                        http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                        url = cmdURL + '/accounting/searchAllowedGeneralLedgers?tenantId=' + request.user.tenantId + '&userId=' + request.user.userId + '&scopeParams=' + scopeParams + '&searchParams=null',
                        input = super.lodash.merge({}, { "ascending": true, "sortColumn": "SORT_BY_NAME" }, request.body);
                    http.post(url, 'allowedGLAccountList', input, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"tenantId":{"type":"string"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"active":{"type":"boolean"},"id":{"type":"number"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"parentGeneralLedgerCode":{"type":"string"},"scopeGroupCode":{"type":"string"},"description":{"type":"string"},"erpId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }*/


        /**
        * @Method Name : allowedList       
        * @Description : Search Allowed Genarl Ledger Account
        * @return object / Throw Error
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "businessUnitCode": "joi.string().required().label('cmd-lable-28__')",
                        "costCentercode": "joi.string().required().label('cmd-lable-33__')",
                        "amount": "joi.number().required().label('cmd-lable-32__')",
                        "purchaseType": "joi.string().required().label('cmd-lable-35__')",
                        "categoryCode": "joi.string().required().label('cmd-lable-36__')",
                        "leaf": "joi.boolean().label('cmd-lable-37__')",
                        "name": "joi.string().label('cmd-lable-1__')",
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('cmdSort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
                        tmsURL = request.productsURL.eProc["web"],
                        paginate = super.utils.formPaginateRequest(request.body),
                        url = tmsURL +
                            '?responseType=json' +
                            '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                            '&scopeName=eProcjQuery' +
                            '&userId=' + super.utils.encodeURI(request.user.userId) +
                            '&userName=' + super.utils.encodeURI(request.user.displayName) +
                            '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                            '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
                            '&method=master.accounting.searchAllowedGeneralLedgers' +
                            '&sortColumn=' + (super.utils.encodeURI(request.body.sortColumn || "SORT_BY_NAME")) +
                            '&ascending=' + (super.utils.encodeURI(request.body.ascending || true)) +
                            '&column1=SEARCH_BY_ACTIVE' +
                            '&value1=true' +
                            '&column2=SEARCH_BY_ARCHIVE' +
                            '&value2=' +
                            '&column3=SEARCH_BY_COMPANY_CODE' +
                            '&value3=' + (super.utils.encodeURI(request.body.companyCode)) +
                            '&column4=SEARCH_IN_BUSINESS_UNIT_CODES' +
                            '&value4=' + (super.utils.encodeURI(request.body.businessUnitCode)) +
                            '&column5=SEARCH_BY_COST_CENTER_CODE' +
                            '&value5=' + (super.utils.encodeURI(request.body.costCentercode)) +
                            '&column6=SEARCH_BY_AMOUNT' +
                            '&value6=' + (super.utils.encodeURI(request.body.amount))+
                            '&column7=SEARCH_BY_LEAF' +
                            '&value7= ' + (super.utils.encodeURI(request.body.leaf || 1))+
                            '&column8=SEARCH_BY_PURCHASE_TYPE' +
                            '&value8=' + (super.utils.encodeURI(request.body.purchaseType)) +
                            '&column9=SEARCH_BY_CATEGORY_CODE' +
                            '&value9=' + (super.utils.encodeURI(request.body.categoryCode)) +
                            '&column10=SEARCH_BY_NAME' +
                            '&value10=' + (super.utils.encodeURI(request.body.name || '')) +
                            '&startIndex=' + (super.utils.encodeURI(paginate.pageNo - 1)) +
                            '&noOfRecords=' + super.utils.encodeURI(paginate.perPageRecords) +
                            '&mode=2';
                    http.get(url, 'allowedGLAccountList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"accountTypeCode":{"type":"string"},"parentGeneralLedgerCode":{"type":"string"},"companyGeneralLedgerCode":{"type":"string"},"companyCode":{"type":"string"},"description":{"type":"string"},"erpId":{"type":"string"},"businessUnitCodes":{"type":"string"},"scopeGroupCode":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"active":{"type":"boolean"},"archive":{"type":"boolean"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
* @Name : ruleMap
* @Description : It is used for fetching ruleMap  
* @return : object
*/
        ruleMap(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "isActive": "joi.boolean().allow('').label('cmd-lable-39__')",
                    "isArchive": "joi.boolean().allow('').label('cmd-lable-42__')",
                    "ascending" : "joi.boolean().label('cmd-lable-30__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd;
                    const http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
                    const url = cmdURL + '/accounting/searchCategoryGeneralLedgers?locale=' + request.user.userSettings.locale + '&tenantId=' + request.user.tenantId;
                    http.post(url, 'getGlAccount', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "none" }, "createdOn": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "id": { "type": "number" }, "purchaseType": { "type": "string" }, "category": { "type": "string" }, "generalLedger": { "type": "string" }, "accountType": { "type": "string" }, "costCenter": { "type": "string" }, "amount": { "type": "number" }, "scopeGroupCode": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "unResolvedScope": { "type": "none" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
    return Glaccount;
};

