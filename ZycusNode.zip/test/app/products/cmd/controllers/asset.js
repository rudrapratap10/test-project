/**
   * Asset Controller
   * Provides this controller to search the asset codes.
*/

"use strict";

module.exports = (parentClass) => {

  class Asset extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Search the Asset Codes
    * @return object / Throw Error
    */
    getList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "assetCode": "joi.string().label('cmd-lable-26__')",
            "codes": "joi.array().items(joi.string().min(1).required().label('cmd-lable-21__')).unique().label('cmd-lable-20__')",
            "isActive": "joi.boolean().allow('').label('cmd-lable-39__')"
          };
        validationUtility.addInternalSchema(schema);
        validationUtility.addCommonSchema('pagination');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const cmdURL = request.productsURL.cmd,
            http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
            url = cmdURL + '/accounting/asset/getAllAssets?tenantId=' + request.user.tenantId + '&locale='+request.user.userSettings.locale;
          http.post(url, 'assetMaster', request.body, (error, result) => {
            if (error) {
              return callback(error, null);
            } else if (result) {
              const responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "active": { "type": "boolean" }, "id": { "type": "string" }, "assetCode": { "type": "string" }, "erpCode": { "type": "string" }, "scopeGroupCode": { "type": "string" }, "resolvedOU": { "type": "string" }, "description": { "type": "string" }, "createdOn": { "type": "date" }, "modifiedOn": { "type": "date" } } } } },
                output = (new (super.responseHandler)(request, result, responseSchema));
              output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }

    /**
    * @Method Name : allowedList       
    * @Description : Search Allowed Asset
    * @return object / Throw Error
    */
    allowedList(request, input, callback) {
      try {
        const validationUtility = super.utils.validationUtility(request),
          schema = {
            "name": "joi.string().max(30).label('cmd-lable-1__')",
            "companyCode": "joi.string().label('cmd-lable-27__')"
          };
        validationUtility.addInternalSchema(schema);
        validationUtility.addCommonSchema('pagination');
        validationUtility.addCommonSchema('cmdSort');
        const result = validationUtility.validate(request.body);
        if (result) {
          const errorMsg = new (super.customError)(result, 'ValidationError', 3);
          return callback(errorMsg, null);
        } else {
          const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
            tmsURL = request.productsURL.eProc["web"],
            paginate = super.utils.formPaginateRequest(request.body),
            url = tmsURL +
              '?responseType=json' +
              '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
              '&scopeName=eProcjQuery' +
              '&userId=' + super.utils.encodeURI(request.user.userId) +
              '&userName=' + super.utils.encodeURI(request.user.displayName) +
              '&tokenId=' + super.utils.encodeURI(request.tokenId) +
              '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
              '&method=master.asset.getAllowedAssets' +
              '&column1=SEARCH_BY_ACTIVE' +
              '&value1=true' +
              '&column2=SEARCH_BY_ARCHIVE' +
              '&value2=' +
              '&column3=SEARCH_BY_COMPANY_CODE' +
              '&value3=' + (super.utils.encodeURI(request.body.companyCode || '')) +
              '&column4=SEARCH_BY_TERM' +
              '&value4=' + (super.utils.encodeURI(request.body.name || '')) +
              '&startIndex=' + (super.utils.encodeURI(paginate.pageNo - 1)) +
              '&noOfRecords=' + super.utils.encodeURI(paginate.perPageRecords) +
              '&locale=' + super.utils.encodeURI(request.user.userSettings.locale) +
              '&mode=2';
          http.get(url, 'allowedAssetList', (error, result) => {
            if (error) {
              return callback(error, null);
            } else {
              const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"code":{"type":"string"},"active":{"type":"boolean"},"archive":{"type":"boolean"},"id":{"type":"string"},"assetCode":{"type":"string"},"erpCode":{"type":"string"},"scopeGroupCode":{"type":"string"},"resolvedOU":{"type":"string"},"description":{"type":"string"},"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"}}}}},
              output = (new (super.responseHandler)(request, result, responseSchema));
              output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
              return callback(null, request, output.execute());
            }
          });
        }
      } catch (error) {
        return callback(error, null);
      }
    }
  }

  return Asset;
}