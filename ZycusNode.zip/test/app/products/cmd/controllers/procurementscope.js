/**
 * ProcurementScope Controller
 *
 * @description :: Provides to get the Procurement Scope
 */

"use strict";

module.exports = (parentClass)=> {   
    class ProcurementScope extends parentClass {
        /* Fetch the user procurement scope */
        getScope(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "userId" : "joi.string().label('cmd-lable-34__')"
                    };                      
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd,
                    http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                    url = cmdURL+'/user/getUserScope?tenantId=' + request.user.tenantId + '&userId='+  (request.body.userId || request.user.userId); 
                    http.post(url, 'getUserScope', {}, (error, response) => {
                        if(error) {
                            return callback(error, null);
                        }else{
                            const responseSchema = {"type":"object","properties":{"active":{"type":"boolean"},"costCenterCode":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"locationCode":{"type":"string"},"procurementScope":{"type":"none"},"tenantId":{"type":"string"},"userDefaultScope":{"type":"none"},"userId":{"type":"string"},"userScope":{"type":"none"}}},
                            output =  (new (super.responseHandler)(request, response, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
    }
}   
    return ProcurementScope;
};