/**
   * exchangerates Controller
   * Provides this controller to get the exchangerates lists and details.
*/

"use strict";

const httpService = require('@service/http.cmd'),
      async = require('async');

module.exports = (parentClass)=> {
  
  class Exchangerate extends parentClass {   

    /**
    * @Method Name : getList
    *
    * @Description : search Currency Exchange Rates
    * @return object / Throw Error
    */
    getList(request, input, callback) {
        try {           
            const cmdURL = request.productsURL.cmd;
            
            let data = {
                "mode":2,
                "conditions":[{"column":"SEARCH_BY_ACTIVE","value":true}],
                "startIndex":0,
                "noOfRecords":10,
                "ascending":false,
                "searchCondition":""
            };                

            let url = cmdURL+'/exchangerate/searchCurrencyExchangeRates?tenantId='+request.user.tenantId+'&userId='+request.user.userId;
            let http =  new httpService(request);
            http.post(url, 'searchCurrencyExchangeRates', data, (error, response) => {
                if(error){
                    return callback(error, null);
                }else{
                    if(response.data != null){
                        let output = {data : {}};
                        output.data.totalRecords = response.data.totalCount;       
                        output.data.records = response.data.result;
                        return callback(null, request, output); 
                    }else{
                        return callback(null, request, response);
                    }                    
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }
    
    /**
    * @Method Name : getExchangeRate
    *
    * @Description : get currency conversion exchange rate
    * @return object / Throw Error
    */
    getRates(request, input, callback) {
        try {
            let validationUtility = super.utils.validationUtility(request);   
            let schema = {
                "fromCurrency" : "joi.string().required().label('cmd-lable-10__')",
                "toCurrency" : "joi.string().required().label('cmd-lable-11__')"
            };              
            validationUtility.addInternalSchema(schema);    
            let result = validationUtility.validate(request.body);       
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            }else{ 
                let http =  new httpService(request);                               
                const cmdURL = request.productsURL.cmd;
                let url = cmdURL+'/exchangerate/getExchangeRate?fromCurrency='+request.body.fromCurrency+'&toCurrency='+request.body.toCurrency+'&purpose=system&tenantId=-1';
                http.post(url, 'getExchangeRate', null, (error, data) => {                    
                    if(error){
                        callback(error, null);
                    }else{
                        let responseSchema = {"type":"object","properties":{"fromCurrency":{"type":"object","properties":{"code":{"type":"string"},"name":{"type":"string"}}},"toCurrency":{"type":"object","properties":{"code":{"type":"string"},"name":{"type":"string"}}},"rate":{"type":"number"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"}}};
                        let output =  (new (super.responseHandler)(request, data, responseSchema)).execute();
                        return callback(null, request, output);
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
    * @Method Name : getExchangeRateMap
    *
    * @Description : get currency conversion master data
    * @return object / Throw Error
    */
    getRateMaps(request, input, callback) {
        try { 
            const CommonMasterData = new (super.cmdHook({request: request}))();
            CommonMasterData.getMasterData(request, input, (error, request, response)=>{
                if(error){
                    callback(error, null);
                }
                else{
                    if(!super.lodash.isEmpty(response.data)){
                        let output = {"data" : { "records" : []}};   
                        for (let key in response.data) {
                            const result = {};
                            result[key] = super.utils.formatResponse(response.data[key]);
                            output.data.records.push(result);                             
                        }
                        return callback(null, request, output);
                    }else{
                        return callback(null, request, response);
                    }
                    
                }
            });          
        } catch (error) {
            return callback(error, null);
        }
    }
  }
  return Exchangerate;
}