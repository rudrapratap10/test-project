/**
   * @Name: TaxTypeController   
   * @Description : It is used for handling Tax Type related operations.
**/
"use strict";
const rm = require('@service/require.module')();
module.exports = (parentClass) => {

    class Tax extends parentClass {

        /**
        * @Name : getTypes
        * @Description : It is used for fetching tax types
        * @param1 name  
        * @return : object
        */
        getTypes(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().allow('').max(30).label('cmd-lable-1__')",
                    "isActive": "joi.boolean().label('cmd-lable-48__')",
                    "isArchive": "joi.boolean().label('cmd-lable-49__')",
                    "includeUseTax": "joi.boolean().label('cmd-lable-50__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmd = new (super.cmdHook({ request: request }))(),
                        requestData = {
                            mode: 2,
                            conditions: [],
                            noOfRecords: request.body.perPageRecords || rm.settingConfig.perPageRecords,
                            startIndex: ((request.body.pageNo || request.body.pageNo === 0) ? request.body.pageNo : rm.settingConfig.pageNo) - 1,
                            ascending: request.body.ascending || false,
                            sortColumn: (request.body.sortColumn) ? sortColumn[request.body.sortColumn] : request.body.sortColumn || undefined,
                            searchCondition: ""
                        };
                    if (!super.lodash.isEmpty(request.body.name)) {
                        requestData.conditions.push({ "column": "SEARCH_BY_NAME", "value": request.body.name });
                    }
                    if (request.body.isActive != null) {
                        requestData.conditions.push({ "column": "SEARCH_BY_ACTIVE", "value": request.body.isActive });
                    }
                    if (request.body.isArchive != null) {
                        requestData.conditions.push({ "column": "SEARCH_BY_ARCHIVE", "value": request.body.isArchive });
                    }
                    if (request.body.includeUseTax != null) {
                        requestData.conditions.push({ "column": "SEARCH_INCLUDING_USE_TAX", "value": request.body.includeUseTax });
                    }
                    cmd.getTaxType(request, requestData, (error, request, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            let responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "useTax": { "type": "boolean" }, "createdOn": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "id": { "type": "number" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Name : getList
        * @Description : It is used for fetching tax list
        * @param1 name  
        * @return : object
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().allow('').label('cmd-lable-1__')",
                    "taxType": "joi.string().allow('').label('cmd-lable-38__')",
                    "applicableFor": "joi.number().label('cmd-lable-43__')",
                    "isActive": "joi.boolean().label('cmd-lable-48__')",
                    "isArchive": "joi.boolean().label('cmd-lable-49__')",
                    "useTaxType": "joi.boolean().label('cmd-lable-51__')",
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmd = new (super.cmdHook({ request: request }))(),
                        requestData = {
                            mode: 2,
                            conditions: [],
                            noOfRecords: request.body.perPageRecords || rm.settingConfig.perPageRecords,
                            startIndex: ((request.body.pageNo || request.body.pageNo === 0) ? request.body.pageNo : rm.settingConfig.pageNo) - 1,
                            ascending: request.body.ascending || false,
                            sortColumn: (request.body.sortColumn) ? sortColumn[request.body.sortColumn] : request.body.sortColumn || undefined,
                            searchCondition: ""
                        };

                    if (!super.lodash.isEmpty(request.body.taxType)) {
                        requestData.conditions.push({ "column": "SEARCH_BY_TYPE", "value": request.body.taxType });
                    }
                    if (request.body.applicableFor) {
                        requestData.conditions.push({ "column": "SEARCH_BY_APPLICABLE_FOR", "value": request.body.applicableFor });
                    }
                    if (request.body.isActive != null) {
                        requestData.conditions.push({ "column": "SEARCH_BY_ACTIVE", "value": request.body.isActive });
                    }
                    if (request.body.isArchive != null) {
                        requestData.conditions.push({ "column": "SEARCH_BY_ARCHIVE", "value": request.body.isArchive });
                    }
                    if (request.body.useTaxType != null) {
                        requestData.conditions.push({ "column": "SEARCH_INCLUDING_USE_TAX_TYPE", "value": request.body.useTaxType });
                    }
                    cmd.getTaxList(request, requestData, (error, request, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "createdOn": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "rate": { "type": "number" }, "type": { "type": "string" }, "taxTypeCode": { "type": "string" }, "county": { "type": "string" }, "applicableFor": { "type": "number" }, "isUseTaxType": { "type": "boolean" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
    return Tax;
}


