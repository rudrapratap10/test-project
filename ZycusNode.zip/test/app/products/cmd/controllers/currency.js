/**
 * Currency Controller
 *
 * @description :: Provides currency related operations
 */

"use strict";

module.exports = (parentClass)=> {   
    class currency extends parentClass {
        /* Fetch the currency List */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name" : "joi.string().max(30).label('cmd-lable-1__')",
                    "code" : "joi.string().max(30).label('cmd-lable-10__')",
                    "nameORcode" : "joi.string().max(30).label('cmd-lable-38__')",
                    "perPageRecords" : "joi.number().min(1).integer().label('dd-lable-3__')",
                    "pageNo" : "joi.number().min(0).integer().label('dd-lable-4__')"
                };                      
                validationUtility.addInternalSchema(schema);
               // validationUtility.addCommonSchema('pagination'); 
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{                   
                    const cmdURL = request.productsURL.cmd;
                    const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
                    const url = cmdURL+'/component/searchCurrency?tenantId=' + request.user.tenantId + '&activeCondition=true'; 
                    const requestData = {
                        name: request.body.name || '',
                        conditions: [],
                        pageNo: (request.body.pageNo===undefined)?1:request.body.pageNo,
                        perPageRecords: request.body.perPageRecords 
                    };
                    if(request.body.code){
                        requestData.conditions.push({ "column": "SEARCH_BY_LIKE_CODE", "value": request.body.code });
                    }
                    if(request.body.nameORcode){
                        requestData.conditions.push({ "column": "SEARCH_BY_NAME_OR_ISOCODE", "value": request.body.nameORcode });
                    }

                    http.post(url, 'getcurrencyList', requestData, (error, response) => {
                        if(error){
                            callback(error, null);
                        }else{                                                                                        
                            let responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"perPageRecords":{"type":"number"},"pageNo":{"type":"number"},"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"code":{"type":"string"},"decimalPrecision":{"type":"number"},"enabled":{"type":"boolean"},"erpId":{"type":"string"},"symbol":{"type":"string"},"isoCode":{"type":"string"},"active":{"type":"boolean","key":"status"},"createdOn":{"type":"none"}}}}};
                            let output =  (new (super.responseHandler)(request, response, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
            }                
        } catch (error) {
            return callback(error, null);
        }
    }

}   
    return currency;
};