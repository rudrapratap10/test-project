/**
 * Business Unit Controller
 *
 * @description :: Provides currency related operations
 */

"use strict";

module.exports = (parentClass) => {
    class BusinessUnit extends parentClass {
        /* Fetch the Business Unit List */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().max(30).label('cmd-lable-1__')",
                    "codes": "joi.array().items(joi.string().min(1).required().label('cmd-lable-21__')).unique().label('cmd-lable-20__')",
                    "isActive": "joi.boolean().allow('').label('cmd-lable-39__')",
                    "parentCode": "joi.string().max(30).label('cmd-lable-19__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmd = new (super.cmdHook({request: request}))();                   
                    cmd.getBusinessUnit(request, request.body, (error, request, response)=>{
                        if (error) {
                            callback(error, null);
                        } else{
                            const responseSchema = { "type": "object", "properties": {"result": { "type": "array", "key": "records", "properties": { "name": { "type": "string" }, "code": { "type": "string" }, "archive": { "type": "boolean" }, "erpId": { "type": "string" }, "leftValue": { "type": "string" }, "rightValue": { "type": "string" }, "hqLocation": { "type": "string" }, "operatingLocations": { "type": "none" }, "orgLevelConfigCode": { "type": "string" }, "parentOrgLevelCode": { "type": "string" }, "parentOrgLevelDefCode": { "type": "string" }, "parentOrgLevelDefName": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "legalName": { "type": "string" }, "currency": { "type": "string" }, "symbol": { "type": "string" }, "isoCode": { "type": "string" }, "active": { "type": "boolean", "key": "status" }, "createdOn": { "type": "date" } } } } };
                            const output = (new (super.responseHandler)(request, response, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : allowedList     
        * @Description : Search Business Unit 
        * @return object / Throw Error
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                      schema = {
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "name": "joi.string().max(30).label('cmd-lable-1__')",
                        "userId": "joi.string().max(100).label('cmd-lable-34__')"
                      };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('cmdSort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
                          tmsURL = request.productsURL.eProc["web"],
                          paginate = super.utils.formPaginateRequest(request.body),
                          url = tmsURL +
                                '?responseType=json' +
                                '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                                '&scopeName=eProcjQuery' +
                                '&userId=' + super.utils.encodeURI(request.user.userId) +
                                '&userName=' + super.utils.encodeURI(request.user.displayName) +
                                '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                                '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
                                '&method=master.organization.searchAllowedBusinessUnits' + 
                                '&sortColumn=' +  (super.utils.encodeURI(request.body.sortColumn || "SORT_BY_NAME")) + 
                                '&ascending=' + (super.utils.encodeURI(request.body.ascending || true)) +
                                '&column1=SEARCH_BY_NAME' +
                                '&value1=' + (super.utils.encodeURI(request.body.name || '')) +
                                '&column2=SEARCH_BY_ACTIVE'+
                                '&value2=true'+
                                '&column3=SEARCH_BY_ARCHIVE'+
                                '&value3=' +                                
                                '&startIndex=' + (super.utils.encodeURI(paginate.pageNo -1)) +
                                '&noOfRecords=' + super.utils.encodeURI(paginate.perPageRecords) +
                                '&mode=2' +
                                '&requestUserIds=' + (super.utils.encodeURI(request.body.userId ||  request.user.userId)) +
                                '&companyCode=' + super.utils.encodeURI(request.body.companyCode) ;
                    http.get(url, 'allowedBusinessUnitList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"code":{"type":"string"},"archive":{"type":"boolean"},"erpId":{"type":"string"},"locationCode":{"type":"string"},"customCollectionId":{"type":"none"},"active":{"type":"boolean","key":"status"},"createdOn":{"type":"none"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
    return BusinessUnit;
};