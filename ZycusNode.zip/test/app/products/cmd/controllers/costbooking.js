/**
   * @Name: CostBookingController   
   * @Description : It is used for handling costBooking related operations.
**/
"use strict";

module.exports = (parentClass) => {

    class CostBooking extends parentClass {
                 /**
       * @Name : ruleMap
       * @Description : It is used for fetching ruleMap  
       * @return : object
       */
        ruleMap(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isActive": "joi.boolean().allow('').label('cmd-lable-39__')",
                        "purchaseType": "joi.string().label('cmd-lable-35__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const requestData = {
                        conditions: []
                    }
                    if (!super.lodash.isEmpty(request.body.purchaseType)) {
                        requestData.conditions.push({ "column": "SEARCH_BY_PURCHASE_TYPE", "value": request.body.purchaseType });
                    }
                    const cmdURL = request.productsURL.cmd,
                        http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                        url = cmdURL + '/costbookingrulemap/searchCostBookingRuleMap?tenantId=' + request.user.tenantId;
                    http.post(url, 'costbookingrulemap', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "none" }, "createdOn": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "id": { "type": "number" }, "purchaseType": { "type": "string" }, "category": { "type": "string" }, "generalLedger": { "type": "string" }, "accountType": { "type": "string" }, "costCenter": { "type": "string" }, "amount": { "type": "number" }, "scopeGroupCode": { "type": "string" }, "purchaseTypeCode": { "type": "string" }, "unResolvedScope": { "type": "none" }, "visiblityRule": { "type": "string" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    }
   return CostBooking;
}