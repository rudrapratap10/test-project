/**
 * Region Controller
 *
 * @description :: Provides Region related operations
 */

"use strict";

module.exports = (parentClass) => {
    class Region extends parentClass {
        /* Fetch the Region List */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "name": "joi.string().max(30).label('cmd-lable-1__')",
                    "code": "joi.string().max(30).label('cmd-lable-10__')",
                    "codes": "joi.array().items(joi.string().min(1).required().label('cmd-lable-21__')).unique().label('cmd-lable-20__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmd = new (super.cmdHook({request: request}))();
                    cmd.getRegion(request, request.body, (error, request, response) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"parentRegionCode":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"active":{"type":"boolean"},"archive":{"type":"boolean"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"},"erpId":{"type":"string"},"userId":{"type":"string"},"unEditable":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, response, responseSchema));
                                output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : allowedList     
        * @Description : Get Region allowedList
        * @return object / Throw Error
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    super.async.waterfall([
                        (methodCallback) => {   
                            //Step 1: Call getLocation method from CMD Hook                      
                            const cmd = new (super.cmdHook({request: request}))(),
                            requestData = {
                                mode: 2,
                                conditions: [{"column":"SEARCH_BY_ACTIVE","value":true}]
                            };
                            cmd.getAllLocation(request, requestData, (error, request, response) => {
                                if (error) {
                                    return methodCallback(error, null);
                                } else {
                                    return methodCallback(null, request, response);
                                }
                            })
                        }],

                        (error, request, response) => {
                            if(error) return callback(error,null);
                    
                            const cmd = new (super.cmdHook({request: request}))();
                            super.lodash.merge(request.body, {"codes": response.data.result.map((loc) => { return loc.regionCode }).filter((elem, index, self) => {
                                    return index == self.indexOf(elem);
                                    })
                                });
                            cmd.getRegion(request, request.body, (error, request, response) => {
                                if (error) {
                                    callback(error, null);
                                } else {
                                    const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"parentRegionCode":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"active":{"type":"boolean"},"archive":{"type":"boolean"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"},"erpId":{"type":"string"},"userId":{"type":"string"},"unEditable":{"type":"string"}}}}},
                                        output = (new (super.responseHandler)(request, response, responseSchema));
                                        output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                                        return callback(null, request, output.execute());
                                }
                            });                            
                        }
                    ) 
                } 
            }catch (error) {
                return callback(error, null);
            }
        }

    }
    return Region;
};