/**
   * Country Controller
   * Provides this controller to get the country lists and details.
*/

"use strict";

module.exports = (parentClass)=> {
  
  class Country extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Display the country lists
    * @return object / Throw Error
    */

    getList(request, input, callback) {
      try {
          //ToDo: we will change/follow the sorting option to the request object, as per the dewdrops API signature for sorting fields.
          const validationUtility = super.utils.validationUtility(request);
          const schema = {
              "name" : "joi.string().max(30).label('cmd-lable-1__')",
              "code" : "joi.string().max(30).label('cmd-lable-10__')",
              "sortColumn" : "joi.string().label('cmd-lable-29__')",
              "ascending" : "joi.boolean().label('cmd-lable-30__')"
          };                      
          validationUtility.addInternalSchema(schema);
          validationUtility.addCommonSchema('pagination');
          const result = validationUtility.validate(request.body);
          
          if (result) {
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              return callback(errorMsg, null);
          } else {
              const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
              cmdURL = request.productsURL.cmd;
              const url = cmdURL+'/component/searchCountry?tenantId='+request.user.tenantId+'&activeCondition=true&locale='+request.user.userSettings.locale;

              http.post(url, 'getCountryList', request.body, (error, result) => {
                  if(error){
                      return callback(error, null);
                  }else if(result){
                      let responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"result":{"type":"array","key":"records","properties":{"code":{"type":"string"},"name":{"type":"string"},"isoCode":{"type":"string"}}}}};
                      const output = (new (super.responseHandler)(request, result, responseSchema));
                      output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                      let records = output.execute();
                      return callback(null, request,records);                 
                  }
              });
          }
      } catch (error) {
          return callback(error, null);
      }
  };

   /**
    * @Method Name : getRecords
    *
    * @Description : Display the country lists
    * @return object / Throw Error
    */
    getRecords(request, input, callback){
      try {
        //ToDo: we will change/follow the sorting option to the request object, as per the dewdrops API signature for sorting fields.
        const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
        const cmdURL = request.productsURL.cmd;
        const requestData = {
            "ascending": true,
            "sortColumn": "name",
        };
        const url = cmdURL+'/component/searchCountry?tenantId='+request.user.tenantId+'&activeCondition=true&locale='+request.user.userSettings.locale;
        http.post(url, 'countryList', requestData, (error, response) => {
          if(error){
            return callback(error, null);
          }else if(response){               
            const responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"result":{"type":"array","key":"records","properties":{"code":{"type":"string"},"name":{"type":"string"},"isoCode":{"type":"string"}}}}};
            const output =  (new (super.responseHandler)(request, response, responseSchema)).execute();
            return callback(null, request, output);
          }
        });
      } catch (error) {
         return callback(error, null);
      }
  }  
       
  }
  return Country;
}