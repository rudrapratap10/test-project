/**
   * State Controller
   * Provides this controller to get the state list and details.
*/

"use strict";

module.exports = (parentClass)=> {
  
  class State extends parentClass {

    /**
    * @Method Name : getList
    *
    * @Description : Display the state lists
    * @return object / Throw Error
    */
    getList(request, input, callback){
        try {
          const validationUtility = super.utils.validationUtility(request);
          const schema = {
              "name" : "joi.string().max(30).label('cmd-lable-1__')",
              "code" : "joi.string().max(30).label('cmd-lable-10__')",
              "countryCode" : "joi.string().max(30).label('cmd-lable-11__')",
              "sortColumn" : "joi.string().label('cmd-lable-29__')",
              "ascending" : "joi.boolean().label('cmd-lable-30__')"
          };
          validationUtility.addInternalSchema(schema);
          validationUtility.addCommonSchema('pagination'); 
          const result = validationUtility.validate(request.body);
          if(result){
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              callback(errorMsg, null);
          }else{
            const cmdURL = request.productsURL.cmd;
            const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
            const url = cmdURL+'/component/searchState?tenantId='+request.user.tenantId+'&activeCondition=true&locale='+request.user.userSettings.locale;
             
            http.post(url, 'stateList', request.body, (error, result) => {
               if(error){
                 callback(error, null);
               }else if(result){
                const responseSchema = {"type":"object","properties":{"totalCount":{"type":"number","key":"totalRecords"},"perPageRecords":{"type":"number"},"pageNo":{"type":"number"},"result":{"type":"array","key":"records","properties":{"code":{"type":"string"},"name":{"type":"string"},"isoCode":{"type":"string"},"country":{"type":"object","properties":{"code":{"type":"string"},"name":{"type":"string"},"isoCode":{"type":"string"}}}}}}};
                const output =  (new (super.responseHandler)(request, result, responseSchema)).execute();
                return callback(null, request, output);
               }
             });
          }         
        } catch (error) {
          callback(error, null);
        }
    } 

  }
  return State;
}