/**
 * Buyer Controller
 *
 * @description :: Provides user and userGroup related search operation.
 */
"use strict";

module.exports = (parentClass)=> {
    
        class UOM extends parentClass {          
    
            getList(request, input, callback) {
                try {
                    const validationUtility = super.utils.validationUtility(request);
                    const schema = {
                        "name" : "joi.string().max(30).label('cmd-lable-1__')",
                        "code" : "joi.string().max(30).label('cmd-lable-18__')",
                        "nameORcode" : "joi.string().max(30).label('cmd-lable-41__')",
                        "perPageRecords" : "joi.number().min(1).integer().label('dd-lable-3__')",
                        "pageNo" : "joi.number().min(0).integer().label('dd-lable-4__')"
                    };                      
                    validationUtility.addInternalSchema(schema);
                   // validationUtility.addCommonSchema('pagination');
                    const result = validationUtility.validate(request.body);
                    
                    if (result) {
                        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                        return callback(errorMsg, null);
                    } else {
                        const http =  new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                        cmdURL = request.productsURL.cmd;
                        const url = cmdURL+'/component/searchUOM?tenantId='+request.user.tenantId+'&activeCondition=true&locale='+request.user.userSettings.locale;
                        request.body.pageNo = (request.body.pageNo===undefined)?1:((request.body.pageNo===0)?0:request.body.pageNo+1);
                        const requestData = {
                            name: request.body.name || '',
                            pageNo:request.body.pageNo,
                            conditions: [],
                            perPageRecords: request.body.perPageRecords
                        };
                        if(!super.lodash.isEmpty(request.body.code)) {
                            requestData.conditions.push({ "column": "SEARCH_BY_LIKE_CODE", "value": request.body.code });
                        }
                        if(!super.lodash.isEmpty(request.body.nameORcode)) {
                            requestData.conditions.push({ "column": "SEARCH_BY_CODE_OR_NAME", "value": request.body.nameORcode });
                        }
                        
                        http.post(url, 'searchUOM', requestData, (error, result) => {
                            if(error){
                                return callback(error, null);
                            }else if(result){
                                let responseSchema = {"type":"object","properties":{"perPageRecords":{"type":"number","key":"noOfRecords"},"pageNo":{"type":"number","key":"startIndex"},"result":{"type":"array","key":"records","properties":{"name":{"type":"string"},"code":{"type":"string"},"active":{"type":"boolean"},"erpId":{"type":"string"},"uomCode":{"type":"string"},"enabled":{"type":"boolean"},"parentCategoryName":{"type":"string"},"quantityType":{"type":"number"},"decimalPrecision":{"type":"number"},"parentCategoryCode":{"type":"string"},"description":{"type":"string"},"createdOn":{"type":"none"},"modifiedOn":{"type":"none"},"flagModifiedName":{"type":"boolean"},"flagTenantUOM":{"type":"boolean"},"flagModifiedQuantityType":{"type":"boolean"}}}}};
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                                let records = output.execute();
                                if(!super.lodash.isEmpty(records.data)){
                                    records.data.pageNo = (records.data.pageNo===1)?1:records.data.pageNo-1;
                                }
                                return callback(null, request,records);                 
                            }
                        });
                    }
                } catch (error) {
                    return callback(error, null);
                }
            };
        }

    return UOM;    
};
    