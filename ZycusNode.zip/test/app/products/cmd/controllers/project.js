/**
   * Project Controller
   * Provides this controller to get the project lists and details.
*/

"use strict";

module.exports = (parentClass) => {

    class Project extends parentClass {

        /**
        * @Method Name : getList
        *
        * @Description : Display the project lists
        * @return object / Throw Error
        */

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "name": "joi.string().max(30).label('cmd-lable-1__')",
                    "code": "joi.string().max(30).label('cmd-lable-10__')",
                    "projectNo": "joi.string().max(30).label('cmd-lable-10__')",
                    "codes": "joi.array().items(joi.string().allow('').label('cmd-lable-20__')).unique().label('cmd-lable-20__')",
                    "isActive": "joi.boolean().allow('').label('cmd-lable-39__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);

                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch),
                        cmdURL = request.productsURL.cmd;

                    const url = cmdURL + '/project/searchProjects?tenantId=' + request.user.tenantId + '&searchParams=[]&locale='+request.user.userSettings.locale;

                    http.post(url, 'getProjectList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            let responseSchema = { "type": "object", "properties": { "totalCount": { "type": "number", "key": "totalRecords" }, "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "date" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "projectNo": { "type": "string" }, "description": { "type": "string" }, "scopeGroupCode": { "type": "string" }, "projectManagerId": { "type": "string" }, "startDate": { "type": "date" }, "endDate": { "type": "date" }, "projectType": { "type": "number" }, "parentProjectCode": { "type": "string" }, "erpCode": { "type": "string" }, "status": { "type": "number" }, "valid": { "type": "boolean" }, "scope": { "type": "string" } } } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            let records = output.execute();
                            return callback(null, request, records);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * @Method Name : allowedList     
         * @Description : Search Allowed Project
         * @return object / Throw Error
         */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "bUCCMap": "joi.string().required().label('cmd-lable-31__')",
                        "projectNameOrCode": "joi.string().label('cmd-lable-1__')",
                        "userId": "joi.string().max(100).label('cmd-lable-34__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('cmdSort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const tmsURL = request.productsURL.eProc["web"],
                        http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
                        sortColumn = request.body.sortColumn || 'SORT_BY_NAME',
                        ascending = request.body.ascending || true,
                        perPageRecords = request.body.perPageRecords || super.settingConfig.perPageRecords,
                        pageNo = request.body.pageNo || (super.settingConfig.pageNo - 1),
                        url = tmsURL +
                            '?responseType=json' +
                            '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                            '&scopeName=eProcjQuery' +
                            '&userId=' + super.utils.encodeURI(request.user.userId) +
                            '&userName=' + super.utils.encodeURI(request.user.displayName) +
                            '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                            '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
                            '&method=master.project.searchAllowedProjects' +
                            '&sortColumn=' + super.utils.encodeURI(sortColumn) +
                            '&ascending=' + super.utils.encodeURI(ascending) +
                            '&column1=SEARCH_BY_COMPANY_CODE' +
                            '&value1=' + super.utils.encodeURI(request.body.companyCode) +
                            '&column2=SEARCH_BY_ACTIVE' +
                            '&value2=1' +
                            '&column3=SEARCH_BY_ARCHIVE' +
                            '&value3=' +
                            '&column4=SEARCH_BY_STATUS' +
                            '&value4=1' +
                            '&column5=SEARCH_BY_BU_CC_MAP' +
                            '&value5=' + super.utils.encodeURI(request.body.bUCCMap) +
                            '&column6=SEARCH_BY_NAME_OR_CODE' +
                            '&value6=' + (super.utils.encodeURI(request.body.projectNameOrCode || ""))  +
                            '&startIndex=' + super.utils.encodeURI(pageNo) +
                            '&noOfRecords=' + super.utils.encodeURI(perPageRecords) +
                            '&mode=2' +
                            '&requestUserIds=' + (super.utils.encodeURI(request.body.userId ||  request.user.userId) ) ;
                    http.get(url, 'allowedProjectList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"projectNo":{"type":"string"},"description":{"type":"string"},"companyCode":{"type":"string"},"projectManagerId":{"type":"string"},"startDate":{"type":"none"},"endDate":{"type":"none"},"projectType":{"type":"number"},"parentProjectCode":{"type":"string"},"erpCode":{"type":"string"},"status":{"type":"number"},"valid":{"type":"boolean"},"businessUnitCodes":{"type":"string"},"mapOfBUCostCenters":{"type":"string"},"code":{"type":"string"},"name":{"type":"string"},"archive":{"type":"boolean"},"active":{"type":"boolean","key":"status"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
 * @Method Name : searchProject     
 * @Description : Search Project
 * @return object / Throw Error
 */
        searchProject(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "companyCode": "joi.string().required().label('cmd-lable-27__')",
                        "bUCode": "joi.string().required().label('cmd-lable-28__')",
                        "CCCode": "joi.string().required().label('cmd-lable-33__')",
                        "projectName": "joi.string().max(100).label('cmd-lable-47__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const cmdURL = request.productsURL.cmd;
                    const http = new (super.httpCmdService)(request, super.appConstant.reqHandler.cmdSearch, super.appConstant.resHandler.cmdSearch);
                    const url = cmdURL + '/project/searchProjects?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + '&locale=' + request.user.userSettings.locale + '&searchParams='+(super.utils.encodeURI(`[{"ORST_ORG_LVL_1":["${request.body.companyCode}"], "ORST_ORG_LVL_2":["${request.body.bUCode}"], "COCE":["${request.body.CCCode}"]}]`) ),
                    requestData = {
                        conditions: []
                    };
                    if (!super.lodash.isEmpty(request.body.projectName)) {
                        requestData.conditions.push({ "column": "SEARCH_BY_NAME", "value": request.body.projectName });
                    }
                    http.post(url, 'searchProject', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "result": { "type": "array", "key": "records", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "none" }, "createdOn": { "type": "none" }, "code": { "type": "string" }, "name": { "type": "string" }, "active": { "type": "boolean" }, "archive": { "type": "boolean" }, "projectNo": { "type": "string" }, "description": { "type": "string" }, "scopeGroupCode": { "type": "string" }, "projectManagerId": { "type": "string" }, "startDate": { "type": "none" }, "endDate": { "type": "none" }, "projectType": { "type": "number" }, "parentProjectCode": { "type": "string" }, "erpCode": { "type": "string" }, "status": { "type": "number" }, "valid": { "type": "boolean" }, "scope": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }
    return Project;
}