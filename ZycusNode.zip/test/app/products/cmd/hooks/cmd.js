"use strict";
const rm = require('@service/require.module')();

class CommonMasterData {

    getMasterData(request, input, callback) {
        try {
            const http = new rm.httpCmdService(request);
            const cmdURL = request.productsURL.cmd;
            const url = cmdURL + '/exchangerate/getExchangeRateMap?purpose=system&tenantId=-1';
            http.post(url, 'getExchangeRate', null, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Company or Organization List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getCompany(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd;
            const http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch);
            const url = cmdURL + '/organization/getOrgLevelDefinition?tenantId=' + request.user.tenantId + '&userId=' + request.user.userId + '&orgLevelCode=ORG_LVL_1';
            http.post(url, 'getCompanyList', input, (error, response) => {
                if (error) {
                    callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Business Unit List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getBusinessUnit(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd;
            const http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch);
            const url = cmdURL + '/organization/getOrgLevelDefinition?tenantId=' + request.user.tenantId + '&userId=' + request.user.userId + '&orgLevelCode=ORG_LVL_2';
            http.post(url, 'getBusinessUnitList', input, (error, response) => {
                if (error) {
                    callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Location List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getLocation(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd;
            const http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch);
            const url = cmdURL + '/geography/getLocations?tenantId=' + request.user.tenantId;
            http.post(url, 'getLocationList', input, (error, response) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Address List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getAddress(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd;
            const http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch);
            const url = cmdURL + '/geography/getAddresses?tenantId=' + request.user.tenantId;
            http.post(url, 'getAddressList', input, (error, response) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get All Address List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getAllAddress(request, input, callback) {
        try {
            const data = Object.keys(input).map(val => input[val]),
                filterData = { "codes": Array.from(new Set(data)), "isActive" : ""  },
                cmdURL = request.productsURL.cmd,
                http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch),
                url = cmdURL + '/geography/getAddresses?tenantId=' + request.user.tenantId+ '&locale='+request.user.userSettings.locale;
            http.post(url, 'getAllAddressList', filterData, (error, response) => {
                if (error) {
                    return callback(error, null);
                } else {
                    const address = {},
                        codes = response.data.result.map(loc => loc.code);
                    Object.keys(input).map(key => {
                        const index = codes.indexOf(input[key])
                        if (index !== -1) {
                            return address[key] = response.data.result[index];
                        } else {
                            return address[key] = {};
                        }
                    })

                    response.data.result[0] = address
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Region List by search parameters
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getRegion(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd,
                http = new rm.httpCmdService(request, rm.appConstant.reqHandler.cmdSearch, rm.appConstant.resHandler.cmdSearch),
                url = cmdURL + '/geography/searchRegions?tenantId=' + request.user.tenantId;
            http.post(url, 'getRegionList', input, (error, response) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * Get Location List without pagination
     * @param {*} request 
     * @param {*} input 
     * @param {*} callback 
     */
    getAllLocation(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd;
            const http = new rm.httpCmdService(request);
            const url = cmdURL + '/geography/getLocations?tenantId=' + request.user.tenantId;
            http.post(url, 'getAllLocationList', input, (error, response) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, response);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    getTaxList(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd,
                http = new rm.httpCmdService(request),
                url = cmdURL + '/component/searchTaxes?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + '&locale=' + request.user.userSettings.locale;

            http.post(url, 'getTaxRate', input, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null)
        }
    }

    getTaxType(request, input, callback) {
        try {
            const cmdURL = request.productsURL.cmd,
                http = new rm.httpCmdService(request),
                url = cmdURL + '/component/getTaxTypes?tenantId=' + request.user.tenantId + "&userId=" + request.user.userId + '&locale=' + request.user.userSettings.locale;
            http.post(url, 'getTaxType', input, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }
}

module.exports = CommonMasterData;