/**
 * Dynamic Form Controller
 *
 * @description :: This controller is Provides Dynamic Form related crud operation.
 */

module.exports = (parentClass)=> {
    
        class DynamicForm extends parentClass {          
    
            getDynamicFormForCOA(request, input, callback) {
                try {
                    const http = new (super.httpEformService)(request, null, null),                    
                    eformURL = request.productsURL.eForm['web'],            
                    url = eformURL + '/getDynamicFormForCOA/tenantId/'+request.user.tenantId+'/processCode/COA'; 
                    http.get(url, 'getDynamicFormForCOA', (error, response) => {
                        if(error){
                            return callback(error, null);
                        }else if(response) {
                            const responseSchema = {"type":"object","properties":{"status":{"type":"boolean"},"result":{"type":"string","key":"FormId"}}},
                            output = (new (super.responseHandler)(request, response, responseSchema));
                            return callback(null, request, output.execute());                 
                        }
                    });
                    
                } catch (error) {
                    return callback(error, null);
                }
            };

            /**
            * @Name : getInstance
            * @Description : It is used to get the form Instance
            * @return : object / Throw Error
            */    
            getInstance(request, input, callback) {
                try {                
                    const validationUtility = super.utils.validationUtility(request), 
                    schema = {
                        "formId": "joi.string().required().label('eform-lable-1__')",
                        "instanceId": "joi.string().allow('', null).label('eform-lable-2__')",
                        "instanceVersion": "joi.number().allow('', null).label('eform-lable-3__')"
                    };
                    validationUtility.addInternalSchema(schema); 
                    const result = validationUtility.validate(request.body);
                    if(result){
                        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                        return callback(errorMsg, null);
                    }else{
                        const http =  new (super.httpService)(request),
                            eformURL = request.productsURL.eForm['soa'],
                            url = eformURL+'/form/instance';
                        http.post(url, 'getFormInstance', request.body, (error, result) => {
                            if(error){
                                return callback(error, null);
                            }else{
                                return callback(null, request, result);                           
                            }
                        });
                    }                
                } catch (error) {
                    return callback(error, null);
                }
            };  
        }
    return DynamicForm;    
};
    