/**
 * Rule Controller
 * 
 * @description :: This controller provides rules
 */

module.exports = (parentClass) => {

    class Rule extends parentClass {
        /**
        * @name ::getRules
        *
        * @description :: Function is used to get the rules
        * @param {object} request
        * @return :: rules corresponds to request.
        */
        getRules(request, input, callback) {
            try {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, super.appConstant.resHandler.businessEntities),
                    eformURL = request.productsURL.eForm['soa'],
                    url = eformURL + '/rule';
                http.post(url, 'getRule', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, result);
                    }
                });
            }
            catch (error) {
                return callback(error, null);
            }
        }
    }
    return Rule;
};