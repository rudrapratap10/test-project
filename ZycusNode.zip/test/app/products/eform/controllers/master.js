/**
 * Master Controller
 * 
 * @description :: This controller provides master related operations
 */

module.exports = (parentClass) => {

    class Master extends parentClass {
        /**
        * @name ::getList
        *
        * @description :: Function is used to get the master list 
        * @param {object} request
        *        @param {string} masterType
        *        @param {string} masterInfo
        *        @param {object} criteriaGroup
        *        @param {array} sorts
        *        @param {number} perPageRecords
        *        @param {number} pageNo
        * @return :: list out the master data(s).
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request),
                schema = {
                    "masterType": "joi.string().required().valid('STANDARD','CUSTOM').label('eform-lable-4__')",
                    "masterInfo": "joi.string().required().invalid(['', null]).label('eform-lable-5__')"
                };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    eformURL = request.productsURL.eForm['soa'],
                    masterType = request.body.masterType,
                    masterInfo = request.body.masterInfo,
                    url = eformURL + '/masterdata?masterType='+masterType+'&masterInfo='+masterInfo;
                    delete request.body['masterType'];
                    delete request.body['masterInfo'];
                    http.post(url, 'getMasterData', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else{
                            return callback(null, request, result);                           
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    }
    return Master;
};