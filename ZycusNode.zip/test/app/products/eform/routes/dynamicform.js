"use strict";
module.exports = {   
    /**
        * @swagger
        * /a/eform/dynamicforms/getDynamicFormForCOA:
        *   get:
        *     tags:
        *       - Eform API
        *     summary: Get the Dynamic Form For COA
        *     operationId: getDynamicFormForCOA
        *     description: Get the Dynamic Form For COA
        *     produces:
        *       - application/json
        *     responses:
        *       200:
        *         description: successful operation
    */
    getDynamicFormForCOA: {
        pre: null,
        process: "dynamicform.getDynamicFormForCOA",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eform/dynamicforms/getInstance:
    *   post:
    *     tags:
    *       - Eform API
    *     summary: Get the form Instance
    *     operationId: getFormInstance
    *     description: Get the form Instance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the dynamic form Instance.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               formId:
    *                 type: string
    *               instanceId:
    *                 type: string
    *               instanceVersion:
    *                 type: number
    *             required: [formId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getInstance: {
        pre: null,
        process: "dynamicform.getInstance",
        post: null,
        method: "POST"
    } 
}
