"use strict";
module.exports = {
   /**
     * @swagger
     * /a/eform/rules/getRules:
     *   post:
     *     tags:
     *       - Eform API
     *     summary: Get rules
     *     operationId: getRules
     *     description: Get rules
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the rules
     *         in: body
     *         schema:
     *           type: array
     *           items:
     *            properties:
     *             selectedField:
     *               type: string
     *             fields:
     *               type: object
     *               properties:
     *                 fieldName:
     *                   type: object
     *                   properties:
     *                     name:
     *                      type: string
     *                     editable:
     *                      type: boolean
     *                     mandatory:
     *                      type: boolean
     *                     show:
     *                      type: boolean
     *                     visible:
     *                      type: boolean
     *                     value:
     *                      type: string
     *                     searchCriteria:
     *                      type: object
     *                      properties:
     *                          startIndex:
     *                             type: number  
     *                          endIndex:
     *                             type: number 
     *                          logicalOperator:
     *                              type: string
     *                          searchClause:
     *                                type: string
     *     responses:
     *       200:
     *         description: successful operation
     */
    getRules: {
        pre: null,
        process: "rule.getRules",
        post: null,
        method: 'POST'
    },
}

