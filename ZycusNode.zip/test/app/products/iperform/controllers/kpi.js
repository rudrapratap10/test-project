/**
 * KPI Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload');

module.exports = (parentClass) => {

    class Kpi extends parentClass {

        /*
        * getList Method
        * This method is used to get the KPI list.
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iPerformURL = request.productsURL.iPerform,
                    url = iPerformURL + '/kpi/filter';
                    http.post(url, 'getKPIList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {"status":{"type":"none"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"modifiedOn":{"type":"string"},"modifiedBy":{"type":"string"},"archiveStatus":{"type":"none"},"kpiId":{"type":"none"},"name":{"type":"none"},"description":{"type":"none"},"formulaType":{"type":"none"},"formulaSyntax":{"type":"none"},"clientId":{"type":"none"},"template":{"type":"boolean"},"requestDocumentId":{"type":"none"},"requestDocument":{"type":"none"},"attachments":[],"autoScores":{"type":"none"},"targets":{"type":"none"},"questionWeightsType":{"type":"number"},"autoScoreType":{"type":"number"},"baseVersionID":{"type":"number"},"parentVersionID":{"type":"number"},"kpiCategoryId":{"type":"number"},"previousCreatedBy":{"type":"none"},"commentId":{"type":"none"},"ytdCustomFormula":{"type":"none"},"isAutoScored":{"type":"number"},"createdByName":{"type":"none"},"previousCreatedByName":{"type":"none"},"kpiCategoryName":{"type":"none"},"kpiCategoryStatus":{"type":"none"},"havingCustomQuestionWeights":{"type":"boolean"},"owner":{"type":"string"}} } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getDetails
        * @Description : Fetch/Get an KPI Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "kpiId": "joi.number().integer().required().label('iperform-lable-1__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "kpiId": request.params.kpi_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iPerformURL = request.productsURL.iPerform,
                        url = iPerformURL + '/kpi/' + request.params.kpi_Id;
                    http.get(url, 'KPIDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": {"status":{"type":"none"},"createdOn":{"type":"none"},"createdBy":{"type":"none"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"none"},"archiveStatus":{"type":"none"},"kpiId":{"type":"none"},"name":{"type":"none"},"description":{"type":"none"},"formulaType":{"type":"none"},"formulaSyntax":{"type":"none"},"clientId":{"type":"string"},"template":{"type":"boolean"},"requestDocumentId":{"type":"none"},"requestDocument":{"type":"none"},"attachments":{"type":"none"},"autoScores":{"type":"none"},"targets":{"type":"none"},"questionWeightsType":{"type":"none"},"autoScoreType":{"type":"none"},"baseVersionID":{"type":"none"},"parentVersionID":{"type":"none"},"kpiCategoryId":{"type":"none"},"previousCreatedBy":{"type":"none"},"commentId":{"type":"none"},"ytdCustomFormula":{"type":"none"},"isAutoScored":{"type":"none"},"createdByName":{"type":"none"},"previousCreatedByName":{"type":"none"},"kpiCategoryName":{"type":"string"},"kpiCategoryStatus":{"type":"none"},"havingCustomQuestionWeights":{"type":"boolean"}} },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    };

    return Kpi;
};