/**
 * ScoreCard Controller
 *
 * @description :: Provides ScoreCard related operations
 */
const upload = require('@service/upload');

module.exports = (parentClass) => {

    class Scorecard extends parentClass {

        /*
        * getList Method
        * This method is used to get the KPI list.
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iPerformURL = request.productsURL.iPerform,
                    url = iPerformURL + '/scorecard/filter';
                    http.post(url, 'getScoreCardList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {"status":{"type":"none"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"modifiedOn":{"type":"string"},"modifiedBy":{"type":"string"},"archiveStatus":{"type":"none"},"kpiId":{"type":"none"},"name":{"type":"none"},"description":{"type":"none"},"formulaType":{"type":"none"},"formulaSyntax":{"type":"none"},"clientId":{"type":"none"},"template":{"type":"boolean"},"requestDocumentId":{"type":"none"},"requestDocument":{"type":"none"},"attachments":[],"autoScores":{"type":"none"},"targets":{"type":"none"},"questionWeightsType":{"type":"number"},"autoScoreType":{"type":"number"},"baseVersionID":{"type":"number"},"parentVersionID":{"type":"number"},"kpiCategoryId":{"type":"number"},"previousCreatedBy":{"type":"none"},"commentId":{"type":"none"},"ytdCustomFormula":{"type":"none"},"isAutoScored":{"type":"number"},"createdByName":{"type":"none"},"previousCreatedByName":{"type":"none"},"kpiCategoryName":{"type":"none"},"kpiCategoryStatus":{"type":"none"},"havingCustomQuestionWeights":{"type":"boolean"},"owner":{"type":"string"}} } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getDetails
        * @Description : Fetch/Get an KPI Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "scoreCardId": "joi.number().integer().required().label('eproc-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "scoreCardId": request.params.scorecard_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iPerformURL = request.productsURL.iPerform,
                        url = iPerformURL + '/scorecard/' + request.params.scoreCard_Id;
                    http.get(url, 'getScoreCardDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {"status":{"type":"none"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"modifiedOn":{"type":"string"},"modifiedBy":{"type":"string"},"archiveStatus":{"type":"none"},"kpiId":{"type":"none"},"name":{"type":"none"},"description":{"type":"none"},"formulaType":{"type":"none"},"formulaSyntax":{"type":"none"},"clientId":{"type":"none"},"template":{"type":"boolean"},"requestDocumentId":{"type":"none"},"requestDocument":{"type":"none"},"attachments":[],"autoScores":{"type":"none"},"targets":{"type":"none"},"questionWeightsType":{"type":"number"},"autoScoreType":{"type":"number"},"baseVersionID":{"type":"number"},"parentVersionID":{"type":"number"},"kpiCategoryId":{"type":"number"},"previousCreatedBy":{"type":"none"},"commentId":{"type":"none"},"ytdCustomFormula":{"type":"none"},"isAutoScored":{"type":"number"},"createdByName":{"type":"none"},"previousCreatedByName":{"type":"none"},"kpiCategoryName":{"type":"none"},"kpiCategoryStatus":{"type":"none"},"havingCustomQuestionWeights":{"type":"boolean"},"owner":{"type":"string"}} } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    };

    return Scorecard;
};