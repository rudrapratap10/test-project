/**
 * Event Controller
 *
 * @description :: Provides event related operations
 */
const upload = require('@service/upload');

module.exports = (parentClass) => {

    class Event extends parentClass {

        /*
        * getList Method
        * This method is used to get the Event list.
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iPerformURL = request.productsURL.iPerform,
                    url = iPerformURL + '/event/filter';
                    
                    http.post(url, 'getKPIList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": {"status":{"type":"none"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"archiveStatus":{"type":"none"},"eventId":{"type":"none"},"name":{"type":"string"},"description":{"type":"string"},"scorecard":{"type":"none"},"supplierIds":{"type":"none"},"eventStartDate":{"type":"none"},"eventEndDate":{"type":"none"},"eventType":{"type":"none"},"performanceFromDate":{"type":"none"},"performanceToDate":{"type":"none"},"clientId":{"type":"string"},"template":{"type":"boolean"},"parentEventId":{"type":"number"},"repeatTillDate":{"type":"string"},"remindBefore":{"type":"none"},"remindBeforeClose":{"type":"none"},"remindBeforeCloseType":{"type":"none"},"remindBeforeCloseTimeStamp":{"type":"none"},"recalled":{"type":"boolean"},"updating":{"type":"boolean"},"userWeightsType":{"type":"none"},"eventKpiTeams":{"type":"none"},"previousCreatedBy":{"type":"none"},"commentId":{"type":"none"},"defineScope":{"type":"none"},"eventMessage":{"type":"none"},"buyerDownloadPermission":{"type":"boolean"},"supplierDownloadPermission":{"type":"boolean"},"eventTypeForm":{"type":"none"},"isAutoScored":{"type":"none"},"recurringParentEvent":{"type":"boolean"},"oneTimeEvent":{"type":"boolean"},"recurringChildEvent":{"type":"boolean"}} } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    };

    return Event;
};