"use strict";

module.exports = {    
    /**
     * @swagger
    * /a/iperform/scoreCards/list:
    *   post:
    *     tags:
    *       - IPerform API
    *     summary: Get the scoreCard list
    *     operationId: getScoreCard
    *     description: Get the scoreCard list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the scoreCard list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "scorecard.getList",
        post: null,
        method: 'POST'
    },

   /**
   * @swagger
   * /a/iperform/scoreCards/{scoreCard_Id}:
   *   get:
   *     tags:
   *       - IPerform API
   *     summary: Get an scoreCard Details
   *     operationId: getscoreCardDetails
   *     description: Get an scoreCard Details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: scoreCard_Id
   *         description: Provide an scoreCard ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetails:{
    pre: null,
    process: "scorecard.getDetails",
    post: null,
    method: 'GET'
  },
};