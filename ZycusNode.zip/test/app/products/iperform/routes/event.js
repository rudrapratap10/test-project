"use strict";

module.exports = {    
    /**
     * @swagger
    * /a/iperform/events/list:
    *   post:
    *     tags:
    *       - IPerform API
    *     summary: Get the event list
    *     operationId: getEventsList
    *     description: Get the event list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the event list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "event.getList",
        post: null,
        method: 'POST'
    }
};