"use strict";

module.exports = {    
    /**
     * @swagger
    * /a/iperform/kpis/list:
    *   post:
    *     tags:
    *       - IPerform API
    *     summary: Get the kpi list
    *     operationId: getkpis
    *     description: Get the kpi list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the kpi list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "kpi.getList",
        post: null,
        method: 'POST'
    },
 /**
   * @swagger
   * /a/iperform/kpis/{kpi_Id}:
   *   get:
   *     tags:
   *       - IPerform API
   *     summary: Get an KPI Details
   *     operationId: getKPIDetails
   *     description: Get an KPI Details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: kpi_Id
   *         description: Provide an kpi ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetails:{
    pre: null,
    process: "kpi.getDetails",
    post: null,
    method: 'GET'
  },
};