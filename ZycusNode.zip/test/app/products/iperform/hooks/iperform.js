"use strict";
const rm = require('@service/require.module')();
/**
 * Eproc Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class Iperform {


   
}

module.exports = Iperform;