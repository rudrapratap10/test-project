"use strict";
module.exports = (parentClass) => {
    class Phase extends parentClass {

        /**
       * @Method Name : getList
       * @Description : Search for Phase list
       * @return object / Throw Error
       */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        iManageUrl = request.productsURL.iManage,
                        url = iManageUrl + '/projectstage/filter';
                    http.post(url, 'searchphase', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"projectStageID":{"type":"number"},"projectStageTitle":{"type":"string"},"projectStageDescription":{"type":"string"},"stagePlannedStartDate":{"type":"string"},"stagePlannedEndDate":{"type":"string"},"stageActualStartDate":{"type":"string"},"stageActualEndDate":{"type":"string"},"stageCompletionPercentage":{"type":"number"},"stageStatusId":{"type":"number"},"stageStatusName":{"type":"string"},"projectTitle":{"type":"string"},"customerProjectID":{"type":"string"},"projectPriorityName":{"type":"string"},"projectOwnerName":{"type":"string"},"projectOwnerID":{"type":"string"},"projectStatusId":{"type":"number"},"delayed":{"type":"boolean"}}}}},
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
           * @Method Name : getPhase
           * @Description : Get Phase Details by phase_id
           * @return object / Throw Error
           */
          getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "phaseId": "joi.number().integer().required().label('imanage-label-3__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "phaseId": request.params.phase_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iManageUrl = request.productsURL.iManage,
                        phaseId = request.params.phase_Id,
                        url = `${iManageUrl}/projectstage/${phaseId}`;
                    http.get(url, 'getPhaseDetails', (error, result) => {                     
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"projectStageID":{"type":"number"},"projectStageTitle":{"type":"string"},"projectStageDescription":{"type":"string"},"stagePlannedStartDate":{"type":"string"},"stagePlannedEndDate":{"type":"string"},"stageActualStartDate":{"type":"string"},"stageActualEndDate":{"type":"string"},"stageCompletionPercentage":{"type":"number"},"stageStatusId":{"type":"number"},"stageStatusName":{"type":"string"},"numberOfTasksInStage":{"type":"array","properties":{"statusId":{"type":"number"},"count":{"type":"number"},"statusName":{"type":"string"}}},"projectTitle":{"type":"string"},"customerProjectID":{"type":"string"},"projectOwnerID":{"type":"string"},"projectOwnerName":{"type":"string"},"projectStatusId":{"type":"number"},"projectStatusName":{"type":"string"},"projectStageDocumentsCount":{"type":"number"},"projectStageApproverNames":{"type":"none"},"projectStageReviewerNames":{"type":"none"}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };


    };
    return Phase;
};
