"use strict";
module.exports = (parentClass) => {
    class Program extends parentClass {

        /**
       * @Method Name : getList
       * @Description : Search for Program list
       * @return object / Throw Error
       */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        iManageUrl = request.productsURL.iManage,
                        url = iManageUrl + '/program/filter';
                    http.post(url, 'searchprogram', request.body, (error, result) => {                        
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"programId":{"type":"number"},"customerProgramId":{"type":"string"},"programName":{"type":"string"},"programDescription":{"type":"string"},"programCreationDate":{"type":"string"},"programCreatorName":{"type":"string"},"programStatusName":{"type":"string"},"programStatusId":{"type":"number"},"programCreatorId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
       * @Method Name : updateStatus
       * @Description : Change status of the program as per the action
       * @return object / Throw Error
       */
        updateStatus(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "action": "joi.string().valid([ 'activate', 'deactivate', 'complete' ]).label('imanage-label-1__')",
                        "programId": "joi.number().integer().required().label('imanage-label-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "programId": request.params.program_Id }));

                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iManageUrl = request.productsURL.iManage,
                        url = `${iManageUrl}/program/${request.body.action}`;
                    //remove action attribute as its not required on the backend
                    super.lodash.unset(request.body, 'action');

                    http.post(url, 'updateProgramStatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(null, request, result);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }

        };

        /**
   * @Method Name : delete
   * @Description : Deletes program by program_Id
   * @return object / Throw Error
   */
        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "programId": "joi.number().integer().required().label('imanage-label-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "programId": request.params.program_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iManageUrl = request.productsURL.iManage,
                        programId = request.params.program_Id,
                        url = `${iManageUrl}/program/${programId}/delete`;

                    http.delete(url, 'deleteProgram', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(null, request, result);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };



        /**
           * @Method Name : getProgram
           * @Description : Get Program Details by prodram_id
           * @return object / Throw Error
           */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "programId": "joi.number().integer().required().label('imanage-label-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "programId": request.params.program_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iManageUrl = request.productsURL.iManage,
                        programId = request.params.program_Id,
                        url = `${iManageUrl}/program/${programId}`;
                    http.get(url, 'getProgramDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"programId":{"type":"number"},"customerProgramId":{"type":"string"},"programName":{"type":"string"},"programDescription":{"type":"string"},"programCreationDate":{"type":"string"},"programCreatorName":{"type":"string"},"programStatusName":{"type":"string"},"numberOfProjectsInProgram":{"type":"number"}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };


        
    /**
       * @Method Name : userList
       * @Description : Search for Program Users
       * @return object / Throw Error
       */
      userList(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request);
            validationUtility.addCommonSchema('sort');
            validationUtility.addCommonSchema('pagination');
            validationUtility.addCommonSchema('criteriaGroup');
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iManageUrl = request.productsURL.iManage,
                    url = iManageUrl + '/program/getProgramUsers';
                http.post(url, 'searchprogramusers', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"userId":{"type":"string"},"userEmail":{"type":"string"},"userFirstName":{"type":"string"},"userLastName":{"type":"string"},"userDisplayName":{"type":"string"},"userActive":{"type":"boolean"}}}}},
                        output = (new (super.responseHandler)(request, result, responseSchema));
                        output.addCommonSchema('pagination', output.responseSchema.properties);
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

    };
    return Program;
};
