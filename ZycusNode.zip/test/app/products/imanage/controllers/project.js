"use strict";
module.exports = (parentClass) => {
    class Project extends parentClass {

        /**
       * @Method Name : getList
       * @Description : Search for Project list
       * @return object / Throw Error
       */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        iManageUrl = request.productsURL.iManage,
                        url = iManageUrl + '/project/filter';
                    http.post(url, 'searchproject', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"projectId":{"type":"number"},"customerProjectId":{"type":"string"},"projectTitle":{"type":"string"},"projectOwnerID":{"type":"string"},"projectTargetStartDate":{"type":"string"},"projectTargetEndDate":{"type":"string"},"projectStatusId":{"type":"string"},"projectStatusName":{"type":"string"},"projectCompletionPercentage":{"type":"number"},"actualStartDate":{"type":"string"},"projectActualStartDate":{"type":"string"},"projectActualEndDate":{"type":"string"},"projectPriorityName":{"type":"string"},"projectTypeId":{"type":"string"},"programTitle":{"type":"string"},"projectOwnerName":{"type":"string"},"sharedOwnerIdNames":{"type":"none"},"projectProgramId":{"type":"number"},"customerProgramId":{"type":"string"},"delayed":{"type":"boolean"}}}}},
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
           * @Method Name : getProject
           * @Description : Get Project Details by project_id
           * @return object / Throw Error
           */
          getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "projectId": "joi.number().integer().required().label('imanage-label-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "projectId": request.params.project_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        iManageUrl = request.productsURL.iManage,
                        projectId = request.params.project_Id,
                        url = `${iManageUrl}/project/${projectId}`;
                    http.get(url, 'getProjectDetails', (error, result) => {                  
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"projectId":{"type":"number"},"customerProjectId":{"type":"string"},"projectTitle":{"type":"string"},"projectOwnerID":{"type":"string"},"projectTargetStartDate":{"type":"string"},"projectTargetEndDate":{"type":"string"},"projectActualStartDate":{"type":"string"},"projectActualEndDate":{"type":"string"},"projectCompletionPercentage":{"type":"number"},"projectStatusId":{"type":"number"},"projectStatusName":{"type":"string"},"projectPriorityId":{"type":"number"},"projectPriorityName":{"type":"string"},"testProjectFlag":{"type":"boolean"},"projectTypeId":{"type":"number"},"projectTypeName":{"type":"string"},"programTitle":{"type":"string"},"customerProgramId":{"type":"string"},"projectDescription":{"type":"string"},"projectOwnerName":{"type":"string"},"sharedOwnerIdNames":{"type":"string"},"categoryName":{"type":"string"},"businessUnitNames":{"type":"string"},"projectCreationSource":{"type":"string"},"numberOfTasksInProject":{"type":"array","properties":{"statusId":{"type":"number"},"count":{"type":"number"},"statusName":{"type":"string"}}},"numberOfPhasesInProject":{"type":"array","properties":{"statusId":{"type":"number"},"count":{"type":"number"},"statusName":{"type":"string"}}},"linkedActivityDetails":{"type":"array","properties":{"activityTitle":{"type":"string"},"activityURL":{"type":"string"},"productName":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };  
        
        
       /**
       * @Method Name : updateStatus
       * @Description : Change status of the project as per the action
       * @return object / Throw Error
       */
      updateStatus(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "action": "joi.string().valid([ 'continue', 'terminate', 'suspend', 'complete' ]).label('imanage-label-1__')",
                    "comment": "joi.string().required().label('imanage-label-5__')",
                    "projectId": "joi.number().integer().required().label('imanage-label-4__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, { "projectId": request.params.project_Id }));

            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    iManageUrl = request.productsURL.iManage,
                    url = `${iManageUrl}/project/${request.body.action}`;
                //remove action attribute as its not required on the backend
                super.lodash.unset(request.body, 'action');

                http.post(url, 'updateProjectStatus', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else if (result.errors) {
                        return callback(null, request, result);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }

    };

    /**
   * @Method Name : delete
   * @Description : Deletes project by project_Id
   * @return object / Throw Error
   */
  destroy(request, input, callback) {
    try {
        const validationUtility = super.utils.validationUtility(request),
            schema = {
                "projectId": "joi.number().integer().required().label('imanage-label-4__')"
            };
        validationUtility.addInternalSchema(schema);
        const result = validationUtility.validate({ "projectId": request.params.project_Id });
        if (result) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
        } else {
            const http = new (super.httpService)(request),
                iManageUrl = request.productsURL.iManage,
                projectId = request.params.project_Id,
                url = `${iManageUrl}/project/${projectId}/delete`;

            http.delete(url, 'deleteProject', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else if (result.errors) {
                    return callback(null, request, result);
                } else {
                    const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                        output = (new (super.responseHandler)(request, result, responseSchema));
                    return callback(null, request, output.execute());
                }
            });
        }
    } catch (error) {
        return callback(error, null);
    }
};


    /**
       * @Method Name : userList
       * @Description : Search for Project Users
       * @return object / Throw Error
       */
      userList(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request);
            validationUtility.addCommonSchema('sort');
            validationUtility.addCommonSchema('pagination');
            validationUtility.addCommonSchema('criteriaGroup');
            const result = validationUtility.validate(request.body);
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iManageUrl = request.productsURL.iManage,
                    url = iManageUrl + '/project/getProjectUsers';
                http.post(url, 'searchprojectusers', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"userId":{"type":"string"},"userEmail":{"type":"string"},"userFirstName":{"type":"string"},"userLastName":{"type":"string"},"userDisplayName":{"type":"string"},"userActive":{"type":"boolean"}}}}},
                        output = (new (super.responseHandler)(request, result, responseSchema));
                        output.addCommonSchema('pagination', output.responseSchema.properties);
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };


    };
    return Project;
};
