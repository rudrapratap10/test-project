"use strict";

module.exports = {   

    /**
    * @swagger
    * /a/imanage/projects/list:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Search projects
    *     operationId: searchProjects
    *     description: Search projects
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for projects ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
        pre: null,
        process: "project.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/imanage/projects/{project_Id}:
    *   get:
    *     tags:
    *       - iManage API
    *     summary: Fetch project details
    *     operationId: getProjectDetails
    *     description: Fetch project details by project_id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: project_Id
    *         description: provide project id
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
   getDetails: {
    pre: null,
    process: "project.getDetails",
    post: null,
    method: 'GET'
},

    /**
    * @swagger
    * /a/imanage/projects/{project_Id}/updateStatus:
    *   put:
    *     tags:
    *       - iManage API
    *     summary: Updates status of Project
    *     operationId: updateStatus
    *     description: Activate, Deactivate, complete project
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: project_Id
    *         description: provide project id
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: continue, terminate, suspend, complete project
    *         type: string
    *         in: body
    *         required: true
    *         schema: 
    *           properties:
    *             action:
    *               type: string
    *             comment:
    *               type: string
    *           required: [action,comment]
    *     responses:
    *       200:
    *         description: successful operation
    */    
   updateStatus: {
    pre: null,
    process: "project.updateStatus",
    post: null,
    method: 'PUT'
},

/**
    * @swagger
    * /a/imanage/projects/{project_Id}:
    *   delete:
    *     tags:
    *       - iManage API
    *     summary: Delete Project
    *     operationId: deleteProject
    *     description: Delete Project
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: project_Id
    *         description: provide project id
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */    
   destroy: {
    pre: null,
    process: "project.destroy",
    post: null,
    method: 'DELETE'
},

  /**
    * @swagger
    * /a/imanage/projects/userList:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Fetch users for project
    *     operationId: getProjectUsers
    *     description: Fetch Users list for project
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for project users( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'     
    *     responses:
    *       200:
    *         description: successful operation
    */
   userList: {
    pre: null,
    process: "project.userList",
    post: null,
    method: 'POST'
  }

};    
