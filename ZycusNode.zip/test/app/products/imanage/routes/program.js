"use strict";

module.exports = {   

    /**
    * @swagger
    * /a/imanage/programs/list:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Search programs
    *     operationId: searchPrograms
    *     description: Search programs
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for programs ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
        pre: null,
        process: "program.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/imanage/programs/{program_Id}/updateStatus:
    *   put:
    *     tags:
    *       - iManage API
    *     summary: Updates status of Program
    *     operationId: updateStatus
    *     description: Activate, Deactivate, complete program
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: program_Id
    *         description: provide program id
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Activate, Deactivate, complete program
    *         type: string
    *         in: body
    *         required: true
    *         schema: 
    *           properties:
    *             action:
    *               type: string
    *           required: [action]
    *     responses:
    *       200:
    *         description: successful operation
    */    
   updateStatus: {
    pre: null,
    process: "program.updateStatus",
    post: null,
    method: 'PUT'
},

/**
    * @swagger
    * /a/imanage/programs/{program_Id}:
    *   delete:
    *     tags:
    *       - iManage API
    *     summary: Delete Program
    *     operationId: deleteProgram
    *     description: Delete Program
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: program_Id
    *         description: provide program id
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */    
   destroy: {
    pre: null,
    process: "program.destroy",
    post: null,
    method: 'DELETE'
},



    /**
    * @swagger
    * /a/imanage/programs/{program_Id}:
    *   get:
    *     tags:
    *       - iManage API
    *     summary: Fetch program details
    *     operationId: getProgramDetails
    *     description: Fetch program details by program_id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: program_Id
    *         description: provide program id
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
   getDetails: {
    pre: null,
    process: "program.getDetails",
    post: null,
    method: 'GET'
},



  /**
    * @swagger
    * /a/imanage/programs/userList:
    *   post:
    *     tags:
    *       - iManage API
    *     summary: Fetch users for program
    *     operationId: getProgramUsers
    *     description: Fetch Users list for program
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search for program users ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'     
    *     responses:
    *       200:
    *         description: successful operation
    */
   userList: {
    pre: null,
    process: "program.userList",
    post: null,
    method: 'POST'
  }



};    
