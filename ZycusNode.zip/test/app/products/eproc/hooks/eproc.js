"use strict";
const rm = require('@service/require.module')();
/**
 * Eproc Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class Eproc {

    /*
     * Add Attachment Method
     * This method to create an entry into the attachment table.
    */
    addAttachment(request, input, callback) {
        try {
            const http = new (rm.httpService)(request);
            const eProcURL = request.productsURL.eProc["soa"];
            const url = eProcURL + '/attachment/add';
            http.post(url, 'addAttachment', input, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else if (result) {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /*
     * Get UserScope Method
     * This method to get the user scope details.
    */
    getUserScope(request, input, callback) {
        try {
            const http = new (rm.httpService)(request),
                eProcURL = request.productsURL.eProc["soa"],
                userId = request.params.user_Id || request.user.userId,
                url = eProcURL + '/user/scope/' + userId;
            http.get(url, 'getUserScope', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    if (!rm.lodash.isEmpty(result.data)) {
                        const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "requestUserId": { "type": "string" }, "emailAddress": { "type": "string" }, "salutation": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "displayName": { "type": "string" }, "name": { "type": "string" }, "controlCurrency": { "type": "string" }, "spendLimit": { "type": "number" }, "approvalLimit": { "type": "number" }, "invoiceApprovalLimit": { "type": "number" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "purchasingScopeCode": { "type": "string" }, "reportingManagerId": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "deliveryScope": { "type": "string" }, "behalfScope": { "type": "string" }, "active": { "type": "boolean" }, "erpId": { "type": "string" }, "procurementScopes": { "type": "none" }, "userScopeDefault": { "type": "none" } } },
                            output = (new (rm.responseHandler)(request, result, responseSchema)).execute();
                        return callback(null, request, output);
                    } else {
                        const errorMsg = new rm.customError("eproc-error-10", 'AppError', 9);
                        return callback(errorMsg, null);
                    }
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }



    /*
      * Get List Method
      * This method to get the fav Catalog  details.
     */
    getfavoriteList(request, input, callback) {
        try {
            const http = new (rm.httpService)(request);
            const eProcURL = request.productsURL.eProc["soa"];
            const url = eProcURL + '/favourites/check';
            http.post(url, 'getfavoriteList', input, (error, result) => {
                if (error) {
                    return callback(error, null);
                } else if (result) {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /*
     * getpurchseOrderList Method
     * This method to get the purchase order list.
    */
    getpurchseOrderList(request, input, callback) {
        try {
            const http = new (rm.httpService)(request, rm.appConstant.reqHandler.filter, rm.appConstant.resHandler.filter);
            const eProcURL = request.productsURL.eProc["soa"];
            const url = eProcURL + '/purchaseOrder/filter';
            http.post(url, 'purchaseOrder', request.body, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "enitity.totalOrderValue": { "type": "number", "key": "totalOrderValue" }, "enitity.consumedOrderValue": { "type": "number", "key": "consumedOrderValue" }, "enitity.createdBy": { "type": "string", "key": "createdBy" }, "enitity.validityTo": { "type": "none", "key": "validityTo" }, "enitity.createdOn": { "type": "none", "key": "createdOn" }, "enitity.type": { "type": "number", "key": "type" }, "enitity.status": { "type": "number", "key": "status" }, "enitity.modifiedOn": { "type": "none", "key": "modifiedOn" }, "enitity.releasedOn": { "type": "none", "key": "releasedOn" }, "enitity.deliverOn": { "type": "none", "key": "deliverOn" }, "enitity.checkoutBuyer": { "type": "string", "key": "checkoutBuyer" }, "enitity.submittedAmount": { "type": "none", "key": "submittedAmount" }, "enitity.businessUnitCode": { "type": "string", "key": "businessUnit" }, "enitity.purchaseOrderId": { "type": "string", "key": "purchaseOrderId" }, "enitity.parentPurchaseOrderId": { "type": "string", "key": "parentPurchaseOrderId" }, "enitity.purchaseOrderNumber": { "type": "string", "key": "purchaseOrderNo" }, "enitity.name": { "type": "string", "key": "name" }, "enitity.supplierId": { "type": "number", "key": "supplierId" }, "enitity.supplierName": { "type": "string", "key": "supplierName" }, "enitity.purchaseType": { "type": "string", "key": "purchaseType" }, "enitity.suppAddressId": { "type": "string", "key": "suppAddressId" }, "enitity.suppPOContact": { "type": "string", "key": "suppPOContact" }, "enitity.suppPOContactEmail": { "type": "string", "key": "suppPOContactEmail" }, "enitity.supplierPOContactType": { "type": "number", "key": "supplierPOContactType" }, "enitity.suppAddress": { "type": "object", "key": "suppAddress", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "number" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "enitity.totalAmount": { "type": "currency", "key": "totalAmount" }, "enitity.suppCurrency": { "type": "string", "key": "suppCurrency" }, "enitity.grossTotalAmount": { "type": "number", "key": "grossTotalAmount" }, "enitity.statusText": { "type": "i18n", "key": "statusText" }, "enitity.submittedOn": { "type": "none", "key": "submittedOn" }, "enitity.requester": { "type": "string", "key": "requester" }, "enitity.receiptStatus": { "type": "number", "key": "receiptStatus" }, "enitity.invoiceStatus": { "type": "number", "key": "invoiceStatus" }, "enitity.confirmStatus": { "type": "number", "key": "confirmStatus" }, "enitity.paymentStatus": { "type": "number", "key": "paymentStatus" }, "enitity.supplierDeliveryStatus": { "type": "number", "key": "supplierDeliveryStatus" }, "enitity.sourceType": { "type": "number", "key": "sourceType" }, "enitity.approvalIntegrationStatus": { "type": "number", "key": "approvalIntegrationStatus" }, "enitity.orderAuthorizationType": { "type": "string", "key": "orderAuthorizationType" }, "enitity.workflowInstanceId": { "type": "string", "key": "workflowInstanceId" }, "enitity.external": { "type": "boolean", "key": "external" }, "enitity.paymentMethod": { "type": "number", "key": "paymentMethod" }, "enitity.allowInvoice": { "type": "boolean", "key": "allowInvoice" }, "enitity.einvoiceIntegrationStatus": { "type": "number", "key": "einvoiceIntegrationStatus" }, "enitity.validityFrom": { "type": "string", "key": "validityFrom" }, "enitity.expectedReleasedDate": { "type": "string", "key": "expectedReleasedDate" }, "enitity.estimatedDeliverOn": { "type": "string", "key": "estimatedDeliverOn" },"enitity.rejectedItemCount":{"type":"number","key":"rejectedItemCount"} } } } },
                        output = (new (rm.responseHandler)(request, result, responseSchema));
                    output.addCommonSchema('pagination', output.responseSchema.properties);
                    return callback(null, request, output.execute());
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }


    /*
     * getAmendPurchseOrderList Method
     * This method to get the purchase order list.
    */
    getAmendPurchseOrderList(request, input, callback) {
        try {
            const http = new (rm.httpService)(request, rm.appConstant.reqHandler.filter, rm.appConstant.resHandler.filter);
            const eProcURL = request.productsURL.eProc["soa"];
            const url = eProcURL + '/purchaseOrder/amendPurchaseOrderFilter';
            http.post(url, 'amendPurchaseOrderFilter', request.body, (error, result) => {
                if (error) {
                    callback(error, null);
                } else {
                    return callback(null, request, result);
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /*
     * getrequisitionList Method
     * This method to get the requisition list.
    */
    getrequisitionList(request, input, callback) {
        try {
            const http = new (rm.httpService)(request, rm.appConstant.reqHandler.filter, rm.appConstant.resHandler.filter),
                eProcURL = request.productsURL.eProc["soa"],
                url = eProcURL + '/requisition/filter';

            http.post(url, 'requisitions', request.body, (error, requisitions) => {
                if (error) {
                    return callback(error, null);

                } else {
                    const loadash = rm.lodash;
                    let shipToCodes = [],
                        groupIds = [],
                        userIds = [],
                        userList = [],
                        groupList = []

                    if (!loadash.isEmpty(requisitions.data.records)) {
                        requisitions.data.records.forEach((record, index, originalArray) => {
                            if (!loadash.isEmpty(record.enitity)) {
                                //push the behalfUserId
                                userIds = loadash.union(userIds, [record.enitity.behalfUserId]);
                                shipToCodes = loadash.union(shipToCodes, [record.enitity.shipToCode]);
                                if (record.enitity.assignedBuyers) {
                                    loadash.each(record.enitity.assignedBuyers, (value) => {
                                        (value.assignedBuyerType === 1) ? userIds = loadash.union(userIds, [value.assignedBuyer]) : groupIds = loadash.union(groupIds, [value.assignedBuyer]);
                                    });
                                }
                            }
                            originalArray[index] = record.enitity;
                        });
                    }

                    const tasks = [
                        // Pass the shipTo ids and Collect the address data
                        (methodCallback) => {
                            if (!loadash.isEmpty(shipToCodes)) {
                                const cmd = new (rm.cmdHook({ request: request }))();
                                cmd.getAddress(request, { codes: shipToCodes }, (error, request, addresses = {}) => {
                                    if (error) return methodCallback(error, null);
                                    // Merge address details with requisition details.                    
                                    const utilsMerge = rm.utils.mergeArray(requisitions.data.records, addresses.data.result, ['shipToCode', 'code']);
                                    requisitions.data.records = utilsMerge;
                                    return methodCallback(null, request, requisitions);
                                });
                            } else {
                                return methodCallback(null, request, requisitions);
                            }
                        },
                        // Merge the requisition and userdetails
                        (request, requisitionWithAddress, methodCallback) => {
                            if (!loadash.isEmpty(userIds)) {
                                const tms = new (rm.tmsHook({ request: request }))(),
                                    reqData = { "ids": userIds };
                                tms.getUsersDetails(request, reqData, (error, request, userDetails) => {
                                    if (error) return methodCallback(error, null);
                                    // Merge users with requisition details.
                                    userList = loadash.union(userList, userDetails);
                                    let utilsMerge = rm.utils.mergeArray(requisitionWithAddress.data.records, userDetails, ['behalfUserId', 'id']);
                                    utilsMerge = rm.utils.mergeArray(utilsMerge, userDetails, ['createdBy', 'id']);
                                    requisitionWithAddress.data.records = utilsMerge;
                                    return methodCallback(null, request, requisitionWithAddress);
                                });
                            } else {
                                return methodCallback(null, request, requisitionWithAddress)
                            }
                        },
                        (request, requisitionWithUsers, methodCallback) => {
                            if (!loadash.isEmpty(userIds)) {
                                const tms = new (rm.tmsHook({ request: request }))();
                                tms.getUserGroups(request, userIds, (error, request, groupDetailsWithUsers) => {
                                    if (error) return methodCallback(error, null);
                                    groupList = loadash.union(groupList, groupDetailsWithUsers);
                                    if (loadash.isArray(groupDetailsWithUsers)) {
                                        let groupUsers = loadash.map(groupDetailsWithUsers, (obj) => {
                                            if (loadash.isObject(obj) && obj.active) {
                                                return obj.users;
                                            }
                                        });
                                        userList = loadash.flattenDeep([userList, groupUsers]);
                                    }
                                    return methodCallback(null, request, requisitionWithUsers);
                                });
                            } else {
                                return methodCallback(null, request, requisitionWithUsers)
                            }
                        },
                        (request, requisitionWithUsers, methodCallback) => {
                            if (!loadash.isEmpty(groupIds)) {
                                const tms = new (rm.tmsHook({ request: request }))();
                                tms.getUserGroup(request, groupIds, (error, request, groupDetails) => {
                                    if (error) return methodCallback(error, null);
                                    if (loadash.isArray(groupDetails)) {
                                        groupList = loadash.union(groupList, groupDetails);
                                    }
                                    return methodCallback(null, request, requisitionWithUsers);
                                });
                            } else {
                                return methodCallback(null, request, requisitionWithUsers)
                            }
                        },
                        (request, result, methodCallback) => {
                            let valueMatched;
                            if (!loadash.isEmpty(result.data.records)) {
                                result.data.records.forEach((record, index, originalArray) => {
                                    record.supportObject = { users: {}, userGroups: {} };
                                    if (record.assignedBuyers) {
                                        loadash.each(record.assignedBuyers, (value, index) => {
                                            if (value.assignedBuyerType === 1) {
                                                valueMatched = loadash.find(userList, { 'id': value.assignedBuyer });
                                                record.assignedBuyers[index].assignedBuyerName = loadash.isObject(valueMatched) ? valueMatched.displayName : "";
                                                record.supportObject.users[value.assignedBuyer] = loadash.isObject(valueMatched) ? valueMatched : {};
                                            } else if (value.assignedBuyerType === 2) {
                                                valueMatched = loadash.find(groupList, { 'id': value.assignedBuyer });
                                                record.assignedBuyers[index].assignedBuyerName = loadash.isObject(valueMatched) ? valueMatched.name : "";
                                                record.supportObject.userGroups[value.assignedBuyer] = loadash.isObject(valueMatched) ? valueMatched : {};
                                            }
                                        });
                                    }
                                });
                            }
                            return methodCallback(null, request, result)
                        }
                    ];

                    rm.async.waterfall(tasks, (error, request, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "requisitionId": { "type": "string", "key": "requisitionId" }, "name": { "type": "string", "key": "name" }, "requisitionNo": { "type": "string", "key": "requisitionNo" }, "requisitionType": { "type": "number", "key": "requisitionType" }, "currency": { "type": "string", "key": "currency" }, "totalAmount": { "type": "none", "key": "totalAmount" }, "status": { "type": "number", "key": "status" }, "statusText": { "type": "i18n", "key": "statusText" }, "createdOn": { "type": "none", "key": "createdOn" }, "modifiedOn": { "type": "none", "key": "modifiedOn" }, "submittedOn": { "type": "none", "key": "submittedOn" }, "grossTotalAmount": { "type": "none", "key": "grossTotalAmount" }, "['grossTotalAmount']": { "type": "currency", "key": "grossTotalFormattedAmount" }, "['totalAmount']": { "type": "currency", "key": "totalAmountFormatted" }, "urgent": { "type": "boolean" }, "shipToCode": { "type": "object", "key": "address", "properties": {} }, "groupStatus": { "type": "number" }, "guided": { "type": "boolean" }, "receivedOn": { "type": "none" }, "assignedBuyers": { "type": "array", "properties": { "tenantId": { "type": "string" }, "assignedBuyer": { "type": "string" }, "assignedBuyerType": { "type": "number" }, "assignedBuyerName": { "type": "string" } } }, "buyerAmount": { "type": "none" }, "workflowInstanceId": { "type": "string" }, "behalfUserId": { "type": "object", "properties": { "id": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" } }, "key": "behalfUser" }, "createdBy": { "type": "object", "properties": { "id": { "type": "string" }, "emailId": { "type": "string" }, "displayName": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" } }, "key": "createdBy" }, "canResubmit": { "type": "boolean" }, "transferredTo": { "type": "string" }, "orderStatus": { "type": "number" }, "receiptStatus": { "type": "number" }, "hasBuyerItem": { "type": "boolean" }, "linkedPurchaseOrderId": { "type": "string" }, "linkedPurchaseOrderNo": { "type": "string" }, "supportObject": { "type": "none" } } } } },
                                output = (new (rm.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            output.addCommonSchema('address', output.responseSchema.properties.records.properties.shipToCode.properties);
                            const schemaRes = output.execute();
                            return callback(null, request, schemaRes);
                        }
                    });
                }
            });
        } catch (error) {
            return callback(error, null);
        }
    }

    /**
     * 
     * getAttachmentDetails
     * This method will return the Attachment details based on attachment id
     */
    getAttachmentDetails(request, input, callback) {
        try {
            const validationUtility = rm.utils.validationUtility(request),
                schema = {
                    "attachmentId": "joi.required().label('eproc-lable-194__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate({ "attachmentId": request.params.attachment_Id });
            if (result) {
                const errorMsg = new (rm.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (rm.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/attachment/' + request.params.attachment_Id;
                http.get(url, 'attachmentDetails', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "date" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "attachmentId": { "type": "string" }, "referenceAttachmentId": { "type": "string" }, "name": { "type": "string" }, "encoding": { "type": "string" }, "fileSize": { "type": "number" }, "path": { "type": "filePathEncode" }, "type": { "type": "number" }, "visibility": { "type": "string" }, "comments": { "type": "string" }, "errorReasonsStr": { "type": "none" } } },
                            output = (new (rm.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };


}

module.exports = Eproc;