"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/receipts/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the receipts list
    *     operationId: getReceipts
    *     description: Get the receipts list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the receipts list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "receipt.getList",
        post: null,
        method: 'POST'
    },

   /**
   * @swagger
   * /a/eproc/receipts/{receipt_Id}:
   *   get:
   *     tags:
   *       - Eproc API
   *     summary: Fetch/Get a Receipt Details
   *     operationId: getReceiptDetails
   *     description: Fetch/Get a Receipt Details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: receipt_Id
   *         description: Provide a receipt ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetails:{
    pre: null,
    process: "receipt.getDetails",
    post: null,
    method: 'GET'
  },

   /**
   * @swagger
   * /a/eproc/receipts/details:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get Receipt Details to Render UI
   *     operationId: getReceiptDetails
   *     description: Get Receipt Details to Render UI
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Get Receipt Details to Render UI
   *         in: body
   *         required: true
   *         schema:
   *          properties:
   *           requisitionId:
   *            type: string
   *           receiptId:
   *            type: string
   *          required: [requisitionId]  
   *     responses:
   *       200:
   *         description: successful operation
   */

  details:{
    pre: null,
    process: "receipt.receiptDetails",
    post: null,
    method: 'POST'
  },

    /**
    * @swagger
    * definitions:
    *   receipt:
    *      properties:
    *        receiptId:
    *          type: string
	*        airwayBillNo:
    *          type: string
	*        consignmentNo:
    *          type: string
	*        shipInfo:
    *          type: string
	*        receivedOn:
    *          type: string
	*        referenceType:
    *          type: integer
	*        referenceValue:
    *          type: string
	*        comments:
    *          type: string
	*        lastReceipt:
    *          type: boolean
	*        allowInvoice:
    *          type: boolean
	*        totalItems:
    *          type: integer
	*        workflowId:
    *          type: integer
	*        assetCodeSetting:
    *          type: boolean
	*        attachmentIds:
    *          type: array
    *          items:
    *            type: string
    */

    /**
    * @swagger
    * definitions:
    *   receiptItems:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *         itemId:
    *           type: string
	*         lineItemId:
    *           type: string
	*         requisitionId:
    *           type: string
	*         purchaseOrderId:
    *           type: string
	*         receivedQuantity:
    *           type: integer
	*         approvedQuantity:
    *           type: string
	*         itemComment:
    *           type: string
	*         receivedRating:
    *           type: integer
	*         assetCode:
    *           type: string
	*         assetCodeType:
    *           type: integer
	*         supplierComment:
    *           type: string
	*         attachmentIds:
    *           type: array
    *           items:
    *             type: string
    */

    /**
    * @swagger
    * definitions:
    *   returnNoteItems:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          lineItemId:
    *             type: string
    *          itemId:
    *             type: string
    *          returnedQuantity:
    *             type: integer
    *          reasonForReturn:
    *             type: string
    *          returnMethod:
    *             type: string
    *          requisitionId:
    *             type: string
    *          purchaseOrderId:
    *             type: string
	*          attachmentIds:
    *             type: array
    *             items:
    *               type: string
    */

    /**
    * @swagger
    * definitions:
    *   returnNote:
    *      properties:
    *        rmaNumber:
    *          type: string
	*        referenceNumber:
    *          type: string
	*        attachmentIds:
    *          type: array
    *          items:
    *            type: string
    */

    /**
    * @swagger
    * definitions:
    *   returnNoteDetails:
    *       properties:
    *         returnNoteItems:
    *            $ref: '#/definitions/returnNoteItems'
    *         returnNote:
    *            $ref: '#/definitions/returnNote'
    */

    /**
    * @swagger
    * definitions:
    *   attachReceipt:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          attachmentId:
    *             type: string
    *          comments:
    *             type: string
    *          visibility:
    *             type: string
    */

    /**
    * @swagger
    * definitions:
    *   rmaPoDetails:
    *     type: array
    *     items:
    *       type: object
    *       properties:
    *          rmaPoId:
    *             type: string
    *          rmaPoNumber:
    *             type: string
    */

    /**
    * @swagger
    * /a/eproc/receipts:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Create/Update a receipt
    *     operationId: createReceipts
    *     description: Create/Update a receipt
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create/Update a receipt
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           submit:
    *            type: boolean
    *           doProceed:
    *            type: boolean
    *           referrerModule:
    *            type: string
    *           receipt:
    *             $ref: '#/definitions/receipt'
    *           receiptItems:
    *             $ref: '#/definitions/receiptItems'
    *           returnNoteDetails:
    *             $ref: '#/definitions/returnNoteDetails'
    *           supportObjects:
    *             type: object
    *           attachmentsDetails:
    *             $ref: '#/definitions/attachReceipt'  
    *           rmaPoDetails:
    *             $ref: '#/definitions/rmaPoDetails'             
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "receipt.create",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/receipts/{receipt_Id}:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete Receipt
    *     operationId: deleteReceipt
    *     description: Delete Receipt
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: receipt_Id
    *         description: Provide the receiptId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy : {  
      pre: null,
      process : "receipt.destroy",
      post: null,
      method: 'DELETE'
  },

  /**
    * @swagger
    *  /a/eproc/receipts/cancel:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: cancel a receipt
    *     operationId: cancelReceipt
    *     description: cancel a receipt
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: cancel a receipt
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           receiptId:
    *            type: string
    *           roleType:
    *            type: string
    *           comments:
    *            type: string
    *           referrerModule:
    *            type: string
    *          required: [receiptId, roleType, comments]     
    *     responses:
    *       200:
    *         description: successful operation
    */
    cancel: {
      pre: null,
      process: "receipt.cancel",
      post: null,
      method: 'POST'
  },

   /**
   * @swagger
   * /a/eproc/receipts/receiptView:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get Receipt View to Render UI
   *     operationId: getreceiptView
   *     description: Get Receipt View to Render UI
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Get Receipt View to Render UI
   *         in: body
   *         required: true
   *         schema:
   *          properties:
   *           requisitionId:
   *            type: string
   *           receiptId:
   *            type: string
   *           version:
   *            type: integer
   *          required: [requisitionId]  
   *     responses:
   *       200:
   *         description: successful operation
   */

  receiptView:{
    pre: null,
    process: "receipt.receiptView",
    post: null,
    method: 'POST'
  },

  /**
   * @swagger
   * /a/eproc/receipts/receiptPOView:
   *   post:
   *     tags:
   *       - Eproc API
   *     summary: Get PO Receipt View
   *     operationId: getreceiptPOView
   *     description: Get PO Receipt View
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Get PO Receipt View
   *         in: body
   *         required: true
   *         schema:
   *          properties:
   *           purchaseOrderId:
   *            type: string
   *           receiptId:
   *            type: string
   *           referrerModule:
   *            type: string
   *          required: [purchaseOrderId, referrerModule]
   *     responses:
   *       200:
   *         description: successful operation
   */

  receiptPOView:{
    pre: null,
    process: "receipt.receiptPOView",
    post: null,
    method: 'POST'
  }

};
