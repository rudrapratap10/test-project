"use strict";

module.exports = {

    /**
    * @swagger
    * /a/eproc/exchangeRates:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get the exchange rates list
    *     operationId: getExchangeRates
    *     description: Get the exchange rates list
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getRecords: {
        pre: null,
        process: "exchangerate.getRecords",
        post: null,
        method: 'GET'
    }
};