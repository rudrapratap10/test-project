"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/eproc/eforms/getCategoryForms:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Eform Items
    *     operationId: getCategoryForms
    *     description: Get Eform Items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Eform items(based on those options filter, sorting & pagination).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
   getCategoryForms: {
        pre: null,
        process: "eform.getCategoryForms",
        post: null,
        method: 'POST'
    } 
};