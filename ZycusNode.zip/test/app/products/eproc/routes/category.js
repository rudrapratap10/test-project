"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/eproc/categories/getRelated:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Related Category List
    *     operationId: getRelatedCategoryList
    *     description: Get Related Category List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Related Category List
    *         in: body
    *         required: true
    *         schema:
    *             properties:  
    *               description:
    *                 type: string
    *               topCount:
    *                 type: integer
    *               useMaster:
    *                 type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */   
   getRelated: {
        pre: null,
        process: "category.getRelated",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/eproc/categories/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get  Category List
    *     operationId: getList
    *     description: Get  Category List
    *     produces:
    *       - application/json
   *     parameters:
    *       - name: body
    *         description: Fetch all PreviouslyUsed/favourites/All catalog list ( Based on those options filter, sorting & pagination ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
   getList: {
    pre: null,
    process: "category.getList",
    post: null,
    method: 'POST'
}

};