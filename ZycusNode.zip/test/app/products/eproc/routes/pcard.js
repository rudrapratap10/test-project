"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/pcards/{id}/getpCards:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get pCards
    *     operationId: getpCards
    *     description: Get the pCard of user.
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: id
    *         description: Provide a request user ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getpCards: {
        pre: null,
        process: "pcard.getpCards",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/eproc/pcards/pCardStats:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get a PCard Stats
    *     operationId: pCardStats
    *     description: Get a PCard Stats
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get a PCard Stats based on (requestUserId,pcardId,roleType,currency and amount )
    *         in: body
    *         schema:
    *             properties:
    *               requestUserId:
    *                   type: string
    *               pcardId:
    *                   type: string
    *               roleType:
    *                   type: string
    *               currency:
    *                   type: string
    *               amount:
    *                   type: number
    *             required: [requestUserId, pcardId, roleType, currency]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    pCardStats: {
        pre: null,
        process: "pcard.pCardStats",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/pcards/allowedList:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Search Allowed PCards list
    *     operationId: searchAllowedpCards
    *     description: Search Allowed PCards list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Search Allowed PCards list based on (requestUserId, companyCode, businessUnitCode and locationCode )
    *         in: body
    *         schema:
    *             properties:
    *               requestUserId:
    *                   type: string
    *               companyCode:
    *                   type: string
    *               businessUnitCode:
    *                   type: string
    *               locationCode:
    *                   type: string
    *             required: [requestUserId, companyCode, businessUnitCode, locationCode]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    allowedList: {
        pre: null,
        process: "pcard.allowedList",
        post: null,
        method: 'POST'
    }
    // /**
    // * @swagger
    // * /a/eproc/pcards/getCardTypes:
    // *   get:
    // *     tags:
    // *       - Eproc API
    // *     summary: Get Card Types
    // *     operationId: cardTypes
    // *     description: Fetch the card types
    // *     produces:
    // *       - application/json
    // *     responses:
    // *       200:
    // *         description: successful operation
    // */
    /*getCardTypes: {
        pre: null,
        process: "pcard.getCardTypes",
        post: null
    }*/    
};