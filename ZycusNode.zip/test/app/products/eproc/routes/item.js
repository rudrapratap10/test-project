"use strict";

module.exports = { 

    /**
     * @swagger
     * definitions:
     *   itemIds:
     *     required: [ids]
     *     properties:
     *       ids:
     *          schema:
     *            type: array
     *            items:
     *              type: string
     *              
     */
    
    /**
    * @swagger
    * /a/eproc/items/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Catalog Items
    *     operationId: getCatalogItems
    *     description: Fetch all Items of Catalog
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide the item ID(s).
    *         in: body
    *         schema:
    *           $ref: '#/definitions/itemIds'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "item.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/eproc/items/{item_Id}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Item Details
    *     operationId: getItemDetails
    *     description: Fetch an Item Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: item_Id
    *         description: Provide an Item ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "item.getDetails",
        post: null,
        method: 'GET'
    },
    
      /**
	* @swagger
	* /a/eproc/items/validate:
	*   post:
	*     tags:
	*       - Eproc API
	*     summary: Validate Item(s)
	*     operationId: validateItems
	*     description: Validate item(s).
	*     produces:
	*       - application/json
	*     parameters:
	*       - name: body
    *         description: Validate items.
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
	*     responses:
	*       200:
	*         description: successful operation
	*/
	validate: {
        pre: null,
        process: "item.validate",
        post: null,
        method: 'POST'
    },
        /**
    * @swagger
    * /a/eproc/items/getPreviouslyUsedList:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get PreviouslyUsed List
    *     operationId: Get Previously Used List
    *     description: Get Previously items List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Previously items(based on those options filter, sorting & pagination)..
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */    
   getPreviouslyUsedList: {
    pre: null,
    process: "item.getPreviouslyUsedList",
    post: null,
    method: 'POST'
   }
};