"use strict";

module.exports = {
    /**
        * @swagger
        * /a/eproc/returnnotes/getReturnNoteDetails:
        *   get:
        *     tags:
        *       - Eproc API
        *     summary: Get Return Note Details
        *     operationId: getReturnNoteDetails
        *     description: Fetch a Return Note Details
        *     produces:
        *       - application/json
        *     parameters:
        *       - name: returnNote_Id
        *         description: Find a Return Note Details.
        *         in: path
        *         required: true
        *         type: integer
        *       - name: body
        *         description: Get Return Note Details
        *         in: body
        *         required: true
        *         schema:
        *           required: [ referrerModule ]
        *           properties:
        *             referrerModule:
        *               type: string
        *             version:
        *               type: number
        *             requisitionId:
        *               type: string
        *     responses:
        *       200:
        *         description: successful operation
    */
    getReturnNoteDetails: {
        pre: null,
        process: "returnnote.getReturnNoteDetails",
        post: null,
        method: 'POST'
    },
    /**
       * @swagger
       * /a/eproc/returnNotes/{returnNote_Id}/getDetails:
       *   post:
       *     tags:
       *       - Eproc API
       *     summary: Get Return Note Details
       *     operationId: getReturnNoteDetails
       *     description: Fetch a Return Note Details
       *     produces:
       *       - application/json
       *     parameters:
       *       - name: returnNote_Id
       *         description: Find a Return Note Details.
       *         in: path
       *         required: true
       *         type: integer
       *       - name: body
       *         description: Get Return Note Details
       *         in: body
       *         required: true
       *         schema:
       *           required: [ referrerModule ]
       *           properties:
       *             referrerModule:
       *               type: string
       *             version:
       *               type: number
       *             requisitionId:
       *               type: string
       *     responses:
       *       200:
       *         description: successful operation
   */
    getDetails: {
        pre: null,
        process: "returnnote.getReturnNoteViewDetails",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/eproc/returnNotes/{returnnote_Id}:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete ReturnNotes
    *     operationId: deleteReturnNotes
    *     description: Delete ReturnNotes
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: returnnote_Id
    *         description: Provide the returnnoteId to delete
    *         required: true
    *         type: integer
    *         in: path
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "returnnote.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/eproc/returnNotes/getReturnNoteAttachment :
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Return Note Attachment
    *     operationId: getReturnNoteAttachment
    *     description: Get Return Note Attachment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Return Note Attachment
    *         type: string
    *         in: body
    *         schema: 
    *          properties:
    *           returnNoteId:
    *            type: string
    *           requisitionId:
    *            type: string
    *          required: [returnNoteId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getReturnNoteAttachment: {
        pre: null,
        process: "returnnote.getReturnNoteAttachment",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/eproc/returnnotes/getReturnEligiblePOsByRequisitionId:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Return Note Details
    *     operationId: getReturnEligiblePOsByRequisitionId
    *     description: Get return eligible PO'S by RequisitionId
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: returnNote_Id
    *         description: Get return eligible PO'S by RequisitionId
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Get return eligible PO'S by RequisitionId
    *         in: body
    *         required: true
    *         schema: 
    *           properties:
    *             requisitionId:
    *               type: string
    *           required: [requisitionId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getReturnEligiblePOsByRequisitionId: {
        pre: null,
        process: "returnnote.getReturnEligiblePOsByRequisitionId",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/eproc/returnnotes/updateReturnNoteDetails:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Update Return Note details
    *     operationId: updateReturnNoteDetails
    *     description: Update Return Note details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: returnNote_Id
    *         description: Update Return Note details
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Update Return Note details
    *         in: body
    *         required: true
    *         schema: 
    *           properties:
    *             returnNoteItems:
    *               type: array
    *               items:
    *                 type: none
    *           required: [returnNoteItems]
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateReturnNoteDetails: {
        pre: null,
        process: "returnnote.updateReturnNoteDetails",
        post: null,
        method: 'POST'
    }

}