"use strict";
module.exports = {   
    /**
     * @swagger
     * /a/eproc/guidedForms/list:
     *   post:
     *     tags:
     *       - Eproc API
     *     summary: Get Guided Forms
     *     operationId: getGuidedForms
     *     description: Fetch all Guided Forms List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Find name or Provide page no to get records.
     *         in: body
     *         schema:
     *           $ref: '#/definitions/findRecord'
     *     responses:
     *       200:
     *         description: successful operation
     */ 
    getList: {
        pre: null,
        process: "guidedform.getList",
        post: null,
        method: 'POST'
    }  
};