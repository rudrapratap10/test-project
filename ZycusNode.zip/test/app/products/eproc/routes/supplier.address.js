"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/suppliers/{supplier_Id}/addresses:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get Supplier Address Details
    *     operationId: getSupplierAddressDetails
    *     description: Fetch a Supplier Address Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: supplier_Id
    *         description: Provide a Supplier ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
   getRecords: {
        pre: null,
        process: "supplierAddress.getRecords",
        post: null,
        method: 'GET'
    }
}