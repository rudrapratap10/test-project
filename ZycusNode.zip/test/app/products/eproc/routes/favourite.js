"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/favourites/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Favourites Items List
    *     operationId: favouritesItemList
    *     description: Get favourite items List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the favourite items(based on those options filter, sorting & pagination)..
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */    
    getList: {
        pre: null,
        process: "favourite.getList",
        post: null,
        method: 'POST'
    } ,

    /**
    * @swagger
    * /a/eproc/favourites:
    *   delete:
    *     tags:
    *       - Eproc API
    *     summary: Delete the favourite items
    *     operationId: deleteFavouriteItems
    *     description: Delete the favourite items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the item ID(s) to delete. supported entityType's [BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM]
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               entityIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               entityType:
    *                   type: string
    *                   enum: [BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM]
    *     required: [entityIds,entityType] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy : {  
        pre: null,
        process : "favourite.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
    * @swagger
    * /a/eproc/favourites:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add Items to Favourite list
    *     operationId: AddFavouriteItems
    *     description: Add Items to Favourite list 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add Items to Favourite list supported entityType's [BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM]
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               entityIds:
    *                 type: array
    *                 items:
    *                   type: string
    *               entityType:
    *                   type: string
    *                   enum: [BASKET, CATALOG, PUNCHOUT, CATEGORY_EFORM, CATALOG_ITEM, FREE_TEXT_ITEM]
    *     required: [entityIds,entityType] 
    *     responses:
    *       200:
    *         description: successful operation
    */

    create:{
        pre: null,
        process: "favourite.create",
        post: null,
        method: 'POST'
    }

};