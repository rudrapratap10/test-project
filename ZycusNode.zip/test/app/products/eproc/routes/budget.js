"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/budgets/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the budget list
    *     operationId: getbudgetList
    *     description: Get the budget list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the budget list ( Based on those options filter & sorting ).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "budget.getList",
        post: null,
        method: 'POST'
    },

   /**
   * @swagger
   * /a/eproc/budgets/{budget_Id}:
   *   get:
   *     tags:
   *       - Eproc API
   *     summary: Fetch/Get a Budget Details
   *     operationId: getBudgetDetails
   *     description: Fetch/Get a Budget Details
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: budget_Id
   *         description: Provide a budget ID.
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

   getDetails:{
     pre: null,
     process: "budget.getDetails",
     post: null,
     method: 'GET'
   },
    /**
    * @swagger
    * /a/eproc/budgets/getOptimumBudgetLine:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get the optimum budget line
    *     operationId: getOptimumBudgetLine
    *     description: Get the optimum budget line
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the optimum budget line ( Based on criteria & pagination filters).
    *         in: body
    *         required: true
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getOptimumBudgetLine: {
        pre: null,
        process: "budget.getOptimumBudgetLine",
        post: null,
        method: 'POST'
    },
};