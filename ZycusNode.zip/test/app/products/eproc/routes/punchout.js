"use strict";

module.exports = { 
    /**
    * @swagger
    * /a/eproc/punchouts/list:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Punchout Items
    *     operationId: getPunchoutItems
    *     description: Get Punchout Items
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the punchout items(based on those options filter, sorting & pagination).
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */   
    getList: {
        pre: null,
        process: "punchout.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/punchouts/addToCart:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add a Punchout Items to cart
    *     operationId: addPunchoutItemsToCart
    *     description: Add a Punchout Items to cart
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide a Punchout ID and Item(s) details.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               punchoutId:
    *                 type: string
    *               cartItems:
    *                 type: array
    *                 items:
    *                  type: object
    *                  properties:
    *                     item:
    *                       type: object
    *                       properties:
    *                          itemId:
    *                            type: string
    *                          price:
    *                            type: number
    *                            format: double
    *                       required: [itemId]
    *                     quantity:
    *                       type: number
    *                       format: double
    *                     assetNumberRequired:
    *                       type: boolean
    *                       format: double
    *                     itemTaxes:
    *                       type: array
    *                       items:
    *                         - $ref: '#/definitions/itemTax'
    *                     internalComment:
    *                       type: string
    *                     supplierComment:
    *                       type: string
    *                     requiredByDate:
    *                       type: string
    *                     attachmentIds:
    *                       type: array
    *                       items:
    *                        type: string
    *             required: [punchoutId,cartItems]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    addToCart: {
        pre: null,
        process: "punchout.addToCart",
        post: null,
        method: 'POST'
    },
    
    /**
    * @swagger
    * /a/eproc/punchouts/setupRequest:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Setup Punchout Request
    *     operationId: setupPunchOutRequest
    *     description: Setup Punchout Request
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create a punchout request
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               punchoutId:
    *                 type: string
    *               updatePunchoutStatus:
    *                 type: boolean
    *               mode:
    *                 type: string
    *               returnURL:
    *                 type: string
    *               itemIds:
    *                 type: array
    *                 items:
    *                  type: string
    *               quantity:
    *                 type: array
    *                 items:
    *                  type: string
    *               emailAddress:
    *                 type: string
    *             required: [punchoutId,updatePunchoutStatus,mode,returnURL]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    setupRequest: {
        pre: null,
        process: "punchout.setupRequest",
        post: null,
        method: 'POST'
    } ,

    /**
    * @swagger
    * /a/eproc/punchouts/validateItems:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Validate Punchout Item(s)
    *     operationId: validatePunchOutItems
    *     description: Validate Punchout Item(s)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Validate Punchout Item(s)
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               punchoutId:
    *                 type: string
    *               itemIds:
    *                 type: array
    *                 items:
    *                  type: string
    *               categoryCodes:
    *                 type: array
    *                 items:
    *                  type: string
    *             required: [punchoutId,itemIds,categoryCodes]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    validateItems: {
        pre: null,
        process: "punchout.validateItems",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/punchouts/addItems:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Add Punchout Item(s)
    *     operationId: addPunchOutItems
    *     description: Add Punchout Item(s)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Add Punchout Item(s)
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               punchoutId:
    *                 type: string
    *               testPunchout:
    *                 type: boolean
    *               params:
    *                 type: object
    *             required: [punchoutId,params]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    addItems: {
        pre: null,
        process: "punchout.addItems",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/punchouts/{punchout_Id}/updateItemClassification:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update Item Classification
    *     operationId: UpdateItemClassification
    *     description: Update Item Classification
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: punchout_Id
    *         description: Provide a punchout ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update Item Classification
    *         in: body
    *         required: true
    *         schema:
    *          properties:
    *           itemId:
    *            type: string
    *           catCode:
    *            type: string
    *          required: [itemId,catCode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateItemClassification: {
        pre: null,
        process: "punchout.updateItemClassification",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/punchouts/{punchout_Id}/returnFromPunchout:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Return from punchout
    *     operationId: returnfrompunchout
    *     description: returnfrompunchout
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: punchout_Id
    *         description: Provide a punchout ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: returnfrompunchout
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               testPunchout:
    *                 type: boolean
    *               params:
    *                 type: object
    *             required: [punchoutId,params]
    *     responses:
    *       200:
    *         description: successful operation
    */   
    returnFromPunchout: {
        pre: null,
        process: "punchout.returnFromPunchout",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/punchouts/{punchout_Id}/getItems:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get/Fetch the punchout Details
    *     operationId: getPunchoutDetails
    *     description: Get/Fetch the punchout Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: punchout_Id
    *         description: Provide a punchout ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getItems: {
        pre: null,
        process: "punchout.getItems",
        post: null,
        method: 'GET'
    },
};