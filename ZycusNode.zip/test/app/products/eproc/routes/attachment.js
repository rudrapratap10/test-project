"use strict";

module.exports = {
    /**
    * @swagger
    * /a/eproc/attachments/fileDownload/{filePath}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Download Attachment File
    *     operationId: downloadAttachmentFile
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    /*getDetails: {
        pre: null,
        process: null,
        post: null
    }*/

    /**
    * @swagger
    * /a/eproc/attachments/{filePath}/download:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Download an Attachment File
    *     operationId: downloadAnAttachmentFile
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the encoded file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    download: {
        pre: null,
        process: "attachment.download",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/attachments/{attachment_Id}/downloadFile:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get details by Id and Download Attachment 
    *     operationId: downloadFile
    *     description: Get details by Id and Download Attachment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: attachment_Id
    *         description: Provide an Attachment ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    downloadFile: {
        pre: null,
        process: "attachment.downloadFile",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/attachments:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Attach & Upload the files
    *     operationId: attachFiles
    *     consumes:
    *       - multipart/form-data
    *     parameters:
    *         - in: formData
    *           name: file
    *           type: file
    *           description: Attach & Upload the files to the SFTP server
    *           required: true
    *         - in: header
    *           name: modulename
    *           type: string
    *           required: true
    *     responses:
    *       200:
    *         description: successful operation
    */

    create: {
        pre: null,
        process: "attachment.create",
        post: null,
        method: 'POST'
    },


    /**
    * @swagger
    * /a/eproc/attachments:
    *   put:
    *     tags:
    *       - Eproc API
    *     summary: Update Attachment
    *     operationId: updateAttachment
    *     description: This method to update more than one attachment details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update the attachment details based on those inputs
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               attachmentId:
    *                   type: string
    *               visibility:
    *                   type: string
    *               comments:
    *                   type: string
    *             required: [attachmentId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "attachment.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/eproc/attachments/{attachment_Id}:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get an Attachment Details
    *     operationId: getAttachmentDetails
    *     description: Get an Attachment Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: attachment_Id
    *         description: Provide an Attachment ID.
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */

    getDetails: {
        pre: null,
        process: "attachment.getDetails",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/eproc/attachments/copy:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Copy Attachments
    *     operationId: CopyAttachment
    *     description: Copy the attachment(s)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: This api is use to copy the attachment(s)
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *           required: [ids]
    *     responses:
    *       200:
    *         description: successful operation
    */
    copy: {
        pre: null,
        process: "attachment.copy",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/attachments/getByIds:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Get Attachments
    *     operationId: getAttachments
    *     description: Get the multiple attachments details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the multiple Attachments Details
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *           required: [ids]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getByIds: {
        pre: null,
        process: "attachment.getByIds",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/eproc/attachments/webLink:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Attach the web link
    *     operationId: attachWebLink
    *     description: Attach the web link
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Provide the attachment web link and module
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             module:
    *               type: string
    *             path:
    *               type: string
    *           required: [module,path]
    *     responses:
    *       200:
    *         description: successful operation
    */
    webLink: {
        pre: null,
        process: "attachment.webLink",
        post: null,
        method: 'POST'
    },


    /**
    * @swagger
    * /a/eproc/attachments/image:
    *   post:
    *     tags:
    *       - Eproc API
    *     summary: Attach & Upload the image files
    *     operationId: attachImageFiles
    *     consumes:
    *       - multipart/form-data
    *     parameters:
    *         - in: formData
    *           name: file
    *           type: file
    *           description: Attach & Upload the image files to the SFTP server
    *           required: true
    *         - in: header
    *           name: modulename
    *           type: string
    *           required: true
    *     responses:
    *       200:
    *         description: successful operation
    */

    image: {
        pre: null,
        process: "attachment.image",
        post: null,
        method: 'POST'
    },

};