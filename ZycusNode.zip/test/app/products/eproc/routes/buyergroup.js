"use strict";

module.exports = {

    /**
    * @swagger
    * /a/eproc/buyerGroups/{group_Id}/getUsers:
    *   get:
    *     tags:
    *       - Eproc API
    *     summary: Get the assign buyer groups users
    *     operationId: GetAssignBuyerGroupsUsers
    *     description: Get the assign buyer groups users
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: group_Id
    *         description: Provide the group Id.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getUsers: {
        pre: null,
        process: "buyergroup.getUsers",
        post: null,
        method: 'GET'
    },

}