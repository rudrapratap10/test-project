"use strict";
module.exports = (parentClass)=> {
  class ReturnNote extends parentClass {     
      getReturnNoteDetails(request, input, callback) {
          try {
            const validationUtility = super.utils.validationUtility(request);   
            const schema = {
                "returNote_Id" : "joi.string().label('eproc-lable-14__')"
            };                      
            validationUtility.addInternalSchema(schema);              
            const result = validationUtility.validate({"returNote_Id": request.params.returnnote_Id});       
            if (false) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 8);
                    callback(errorMsg, null);
            } else {
                const http =  new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];
                const url = eProcURL+'/returnNotes/getReturnNoteDetails';
                
                http.post(url, 'getReturnNoteDetails', request.body, (error, result) => {           
                  if (error) {
                    return callback(error, null);
                  } else if (result) {
                    return callback(null, request, result);
                  }
                });
            }
          } catch (error) {
            callback(error, null);
          }
      };

      getReturnNoteViewDetails(request, input, callback) {
        try {
          const validationUtility = super.utils.validationUtility(request),
            schema = {
                "returNote_Id" : "joi.string().label('eproc-lable-14__')",
                "referrerModule": "joi.string().allow('', null).label('eproc-lable-398__')",
                "requisitionId": "joi.string().allow('', null).label('eproc-lable-6__')",
                "version": "joi.number().allow('', null).label('eproc-lable-72__')",
            };
          validationUtility.addInternalSchema(schema);
          const result = validationUtility.validate({
              "returNote_Id" : request.params.returnnote_Id,
              "referrerModule": request.body.referrerModule,
              "requisitionId": request.body.requisitionId,
              "version": request.body.version,
          });       
          if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 8);
                  callback(errorMsg, null);
          } else {
              const http =  new (super.httpService)(request);
              const eProcURL = request.productsURL.eProc["soa"];
              const url = eProcURL+'/returnNotes/getReturnNoteViewDetails/' + request.params.returnnote_Id;
              http.post(url, 'returnNoteDetails', request.body, (error, result) => {
                  if(error){
                      return callback(error, null);
                  }else if(result){
                      return callback(null, request, result);
                  }
              });
          }
        } catch (error) {
          callback(error, null);
        }
    };
    /**
    * @Name : destroy
    * @Description : This method is used to delete a returnnote
    * @return : object
    */
    destroy(request, input, callback) {
        try {
            let validationUtility = super.utils.validationUtility(request); 
            let schema = {
                  "returnnote_Id": "joi.string().required().label('eproc-lable-430__')"
            };
            validationUtility.addInternalSchema(schema);    
            let result = validationUtility.validate({"returnnote_Id": request.params.returnnote_Id});   
            if (result) {
              const errorMsg = new (super.customError)(result, 'ValidationError', 3);
              return callback(errorMsg, null);
            }else{
                const http = new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];   
                const url = eProcURL +'/returnNotes/'+ request.params.returnnote_Id +'/deleteReturnNote';
                http.delete(url, 'deleteReturnNote', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const message = {description: "eproc-msg-29"};
                        if(!super.lodash.isEmpty(result.data.id)){
                            result.message = [message];              
                        }
                        let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"}}};
                        const output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());       
                    }
                });
            }                
        } catch (error) {
          return callback(error, null);
        }
      };

       /**
    * Function to get getReturnNoteAttachment
    * @param {*} request 
    * @param {*} input 
    * @param {*} callback 
    */
    getReturnNoteAttachment(request, input, callback) {
        try {
          const validationUtility = super.utils.validationUtility(request),
            schema = {            
              "returnNoteId": "joi.string().required().label('eproc-lable-430__')",
              "requisitionId": "joi.string().allow('', null).label('eproc-lable-6__')"
            };
          validationUtility.addInternalSchema(schema);
          const result = validationUtility.validate(request.body);
          if (result) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
          } else {
            const http = new (super.httpService)(request),
              eProcURL = request.productsURL.eProc["soa"],
              url = eProcURL + '/returnNotes/returnNoteAttachmentPDF';
            http.post(url, 'getReturnNoteAttachment', request.body, (error, result) => {           
              if (error) {
                return callback(error, null);
              } else if (result) {
                  const responseSchema = {"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"attachmentId":{"type":"string"},"referenceAttachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"},"type":{"type":"number"},"visibility":{"type":"none"},"comments":{"type":"string"}}};
                  const output = (new (super.responseHandler)(request, result, responseSchema));
                  return callback(null, request, output.execute());
              }
            });
          }
        } catch (error) {
          return callback(error, null);
        }
      };

      /**
       * 
       * @param {*} request 
       * @param {*} input 
       * @param {*} callback 
       */
      getReturnEligiblePOsByRequisitionId(request, input, callback) {
        try {
          const validationUtility = super.utils.validationUtility(request),
            schema = {            
              "requisitionId": "joi.string().label('eproc-lable-6__')"
            };
          validationUtility.addInternalSchema(schema);
          const result = validationUtility.validate(request.body);
          if (result) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
          } else {
            const http = new (super.httpService)(request),
              eProcURL = request.productsURL.eProc["soa"],
              url = eProcURL + '/returnNotes/getReturnEligiblePOsByRequisitionId';
            http.post(url, 'getReturnEligiblePOsByRequisitionId', request.body, (error, result) => {           
              if (error) {
                return callback(error, null);
              } else if (result) {
                  return callback(null, request, result);
              }
            });
          }
        } catch (error) {
          return callback(error, null);
        }
      };
      /**
       * 
       * @param {*} request 
       * @param {*} input 
       * @param {*} callback 
       */
      updateReturnNoteDetails(request, input, callback) {
        try {
          const validationUtility = super.utils.validationUtility(request),
          //TODO will add schema later.
            schema = { "returnNoteItems": "joi.array().items(joi.object())" };
          validationUtility.addInternalSchema(schema);
          const result = validationUtility.validate(request.body);
          if (false) {
            const errorMsg = new (super.customError)(result, 'ValidationError', 3);
            return callback(errorMsg, null);
          } else {
            const http = new (super.httpService)(request),
              eProcURL = request.productsURL.eProc["soa"],
              url = eProcURL + '/returnNotes/updateReturnNoteDetails';
            http.post(url, 'updateReturnNoteDetails', request.body, (error, result) => {           
              if (error) {
                return callback(error, null);
              } else if (result) {
                  return callback(null, request, result);
              }
            });
          }
        } catch (error) {
          return callback(error, null);
        }
      }


    }

  return ReturnNote;
};

