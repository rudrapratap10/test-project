/**
 * Cart Controller
 *
 * @description :: Provides cart related curd operations
 */

module.exports = (parentClass) => {

    class Cart extends parentClass {

        getItemList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/cart/items';
                    http.post(url, 'cartList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            if (super.lodash.isArray(result.records)) {
                                result.records.forEach((item, key) => {
                                    item = super.utils.formatResponse(item);
                                });
                            } else {
                                result = super.utils.formatResponse(result);
                            }
                            callback(null, request, { "data": result });
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
         * Fetch the cart items
        */
        getRecords(request, input, callback) {
            try {
                let http = new (super.httpService)(request, null, super.appConstant.resHandler.entityList);
                const eProcURL = request.productsURL.eProc["soa"];
                const url = eProcURL + '/cart/items';
                http.get(url, 'cartList', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else if (result) {
                        let responseSchema = {"type":"array","properties":{"item.name":{"type":"string","key":"name"},"item.supplierName":{"type":"string","key":"supplierName"},"item.description":{"type":"string","key":"description"},"item.price":{"type":"number","key":"price"},"item['price']":{"type":"currency","key":"priceFormat"},"item.imageURL":{"type":"string","key":"imageURL"},"item.createdOn":{"type":"none","key":"createdOn"},"item.modifiedOn":{"type":"none","key":"modifiedOn"},"quantity":{"type":"number"},"item.currency":{"type":"string","key":"currency"},"item.totalAmount":{"type":"number","key":"totalAmount"},"item['totalAmount']":{"type":"currency","key":"totalAmountFormat"},"item.taxAmount":{"type":"number","key":"taxAmount"},"item['taxAmount']":{"type":"currency","key":"taxAmountFormat"},"item.itemId":{"type":"string","key":"itemId"},"item.uom":{"type":"string","key":"uom"},"item.scopeId":{"type":"string","key":"scopeId"},"item.catalogId":{"type":"string","key":"catalogId"},"item.catalogVersion":{"type":"string","key":"catalogVersion"},"item.catalogItemId":{"type":"string","key":"catalogItemId"},"item.supplierId":{"type":"string","key":"supplierId"},"item.supplierPartId":{"type":"string","key":"supplierPartId"},"item.supplierAuxPartId":{"type":"string","key":"supplierAuxPartId"},"item.supplierAddressId":{"type":"string","key":"supplierAddressId"},"item.supplierAddress":{"type":"string","key":"supplierAddress"},"item.supplierContact":{"type":"string","key":"supplierContact"},"item.supplierEmail":{"type":"string","key":"supplierEmail"},"item.supplierContactType":{"type":"number","key":"supplierContactType"},"item.supplierPhone":{"type":"string","key":"supplierPhone"},"item.supplierOtherDetails":{"type":"string","key":"supplierOtherDetails"},"item.manufacturerPartId":{"type":"string","key":"manufacturerPartId"},"item.manufacturerName":{"type":"string","key":"manufacturerName"},"item.marketPrice":{"type":"number","key":"marketPrice"},"item['marketPrice']":{"type":"currency","key":"marketPriceFormat"},"item.leadTime":{"type":"number","key":"leadTime"},"item.categoryCode":{"type":"string","key":"categoryCode"},"item.categoryName":{"type":"string","key":"categoryName"},"item.unsspscCode":{"type":"string","key":"unsspscCode"},"item.unsspscName":{"type":"string","key":"unsspscName"},"item.supplierProductURL":{"type":"string","key":"supplierProductURL"},"item.manufacturerProductURL":{"type":"string","key":"manufacturerProductURL"},"item.thumbnailURL":{"type":"string","key":"thumbnailURL"},"item.sourceRefNo":{"type":"string","key":"sourceRefNo"},"item.contractNo":{"type":"string","key":"contractNo"},"item.contractId":{"type":"string","key":"contractId"},"item.sourceType":{"type":"number","key":"sourceType"},"item.itemType":{"type":"number","key":"itemType"},"item.receiptType":{"type":"number","key":"receiptType"},"item.contractType":{"type":"number","key":"contractType"},"item.error":{"type":"boolean","key":"error"},"item.warning":{"type":"boolean","key":"warning"},"item.active":{"type":"boolean","key":"active"},"item.hidden":{"type":"boolean","key":"hidden"},"item.activity":{"type":"number","key":"activity"},"item.greenItem":{"type":"boolean","key":"greenItem"},"item.preferredItem":{"type":"boolean","key":"preferredItem"},"item.validFrom":{"type":"string","key":"validFrom"},"item.validTo":{"type":"string","key":"validTo"},"item.publishedOn":{"type":"none","key":"publishedOn"},"item.attachments":{"type":"none","key":"attachments"},"item.outOfStock":{"type":"boolean","key":"outOfStock"},"item.systemAttributes":{"type":"none","key":"systemAttributes"},"item.itemAttributes":{"type":"none","key":"itemAttributes"},"item.itemErrors":{"type":"string","key":"itemErrors"},"item.sourcingStatus":{"type":"number","key":"sourcingStatus"},"item.externalId":{"type":"string","key":"externalId"},"item.origin":{"type":"number","key":"origin"},"item.contracted":{"type":"boolean","key":"contracted"},"item.parentItemId":{"type":"string","key":"parentItemId"},"item.updated":{"type":"boolean","key":"updated"},"item.assetNumberRequired":{"type":"boolean","key":"assetNumberRequired"},"item.itemTaxes":{"type":"number","key":"itemTaxes"},"item.warehouseCode":{"type":"string","key":"warehouseCode"},"item.parentCatalogItemId":{"type":"string","key":"parentCatalogItemId"},"item.supplierCurrency":{"type":"string","key":"supplierCurrency"},"item.supplierLeadTime":{"type":"number","key":"supplierLeadTime"},"item.supplierStatus":{"type":"string","key":"supplierStatus"},"item.supplierCount":{"type":"string","key":"supplierCount"},"item.priceValidFrom":{"type":"string","key":"priceValidFrom"},"item.priceValidTo":{"type":"string","key":"priceValidTo"},"item.attachmentsStr":{"type":"string","key":"attachmentsStr"},"item.itemAttributesStr":{"type":"string","key":"itemAttributesStr"},"item.systemAttributesStr":{"type":"string","key":"systemAttributesStr"}}};
                        let output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                        return callback(null, request, output);
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

        addItemToCart(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.validObj = false;
                const schema = {
                    "price": "joi.number().label('eproc-lable-138__')",
                    "quantity": "joi.number().min(1).required().label('eproc-lable-1__')",
                    "itemId": "joi.string().min(1).required().label('eproc-lable-2__')",
                    "sourceType": "joi.number().integer().required().label('eproc-lable-151__')",
                    "updateCartItem": "joi.boolean().label('eproc-lable-211__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    inputData.forEach((value) => {
                        value.item = {
                            itemId: value.itemId,
                            sourceType: value.sourceType
                        };
                        value.price = value.price
                        value.quantity = value.quantity || 1;
                        value.updateCartItem  = (super.lodash.isBoolean(value.updateCartItem))?value.updateCartItem:true;
                        delete value.itemId;
                        delete value.sourceType;
                    }, this);
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/cart/items/update';
                    http.post(url, 'addItemToCart', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const resType = (super.lodash.isArray(result.data)) ? "array" : "object";
                            const responseSchema = { "type": resType, "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } };                            
                            if(!super.lodash.isEmpty(result.data)){
                                const message = { description: "eproc-msg-4" };
                                result.message = [message];
                                if (resType === "array") {
                                    for (let i = 1; i < result.data.length; i++) {
                                        result.message[i] = message;
                                    }
                                };                                
                            }                            
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        updateCartItem(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.validObj = false;
                let schema = {
                    "price": "joi.number().label('eproc-lable-138__')",
                    "quantity": "joi.number().min(1).required().label('eproc-lable-1__')",
                    "itemId": "joi.string().min(1).required().label('eproc-lable-2__')",
                    "sourceType": "joi.number().integer().required().label('eproc-lable-151__')",
                    "updateCartItem": "joi.boolean().label('eproc-lable-211__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    inputData.forEach((value) => {
                        value.item = {
                            itemId: value.itemId,
                            sourceType: value.sourceType
                        };
                        value.quantity = value.quantity || 1;
                        value.updateCartItem  = (super.lodash.isBoolean(value.updateCartItem))?value.updateCartItem:true;
                        delete value.itemId;
                        delete value.sourceType;
                    }, this);
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/cart/items/update';
                    http.post(url, 'updateItemInCart', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            const resType = (super.lodash.isArray(result.data)) ? "array" : "object";
                            const responseSchema = { "type": resType, "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } };                            
                            if(!super.lodash.isEmpty(result.data)){
                                const message = { description: "eproc-msg-4" };
                                result.message = [message];
                                if (resType === "array") {
                                    for (let i = 1; i < result.data.length; i++) {
                                        result.message[i] = message;
                                    }
                                };                                
                            }                            
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        removeItems(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-15__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/cart/items/delete';
                    http.post(url, 'removeCartItems', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } };
                            result.message = [{ "description": "eproc-msg-6" }];
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        clearCartItem(request, input, callback) {
            try {
                const http = new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];
                const url = eProcURL + '/cart/clear';
                http.delete(url, 'clearCartDelete', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } };
                        result.message = [{ "description": "eproc-msg-7" }];
                        const output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };

        /**
         * Description : This method will fetch the latest items available inside cart 
         */
        getLatestItems(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.entityList),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/catalog/getLatestCartItems';
                    http.post(url, 'getLatestItems', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "scopeId": { "type": "string" }, "catalogId": { "type": "string" }, "catalogVersion": { "type": "number" }, "catalogItemId": { "type": "number" }, "itemId": { "type": "string" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "supplierPartId": { "type": "string" }, "supplierAuxPartId": { "type": "string" }, "supplierAddressId": { "type": "string" }, "supplierAddress": { "type": "string" }, "supplierContact": { "type": "string" }, "supplierEmail": { "type": "string" }, "supplierContactType": { "type": "number" }, "supplierPhone": { "type": "string" }, "supplierOtherDetails": { "type": "string" }, "manufacturerPartId": { "type": "string" }, "manufacturerName": { "type": "string" }, "name": { "type": "string" }, "description": { "type": "string" }, "uom": { "type": "string" }, "currency": { "type": "string" }, "price": { "type": "number" }, "['price']": { "type": "currency","key":"priceFormat" },"marketPrice": { "type": "number" }, "['marketPrice']": { "type": "currency","key":"marketPriceFormat" }, "leadTime": { "type": "number" }, "categoryCode": { "type": "string" }, "categoryName": { "type": "string" }, "unsspscCode": { "type": "string" }, "unsspscName": { "type": "string" }, "supplierProductURL": { "type": "string" }, "manufacturerProductURL": { "type": "string" }, "imageURL": { "type": "string" }, "thumbnailURL": { "type": "string" }, "sourceRefNo": { "type": "string" }, "contractNo": { "type": "string" }, "contractId": { "type": "string" }, "sourceType": { "type": "number" }, "itemType": { "type": "number" }, "receiptType": { "type": "number" }, "contractType": { "type": "number" }, "error": { "type": "boolean" }, "warning": { "type": "boolean" }, "active": { "type": "boolean" }, "hidden": { "type": "boolean" }, "activity": { "type": "number" }, "greenItem": { "type": "boolean" }, "preferredItem": { "type": "boolean" }, "validFrom": { "type": "string" }, "validTo": { "type": "string" }, "publishedOn": { "type": "date" }, "attachments": { "type": "none" }, "outOfStock": { "type": "boolean" }, "systemAttributes": { "type": "object", "properties": { "icontractCurrency": { "type": "string" }, "icontractUom": { "type": "string" }, "icontractCategory": { "type": "string" }, "icontractCategoryName": { "type": "string" }, "icontractLineItemNo": { "type": "string" }, "isPulledFromIcontract": { "type": "boolean" } } }, "itemAttributes": { "type": "none" }, "itemErrors": { "type": "string" }, "sourcingStatus": { "type": "number" }, "externalId": { "type": "string" }, "origin": { "type": "number" }, "contracted": { "type": "boolean" }, "parentItemId": { "type": "string" }, "updated": { "type": "boolean" }, "assetNumberRequired": { "type": "boolean" }, "itemTaxes": { "type": "string" }, "taxAmount": { "type": "number" },"['taxAmount']": { "type": "currency","key":"taxAmountFormat" }, "totalAmount": { "type": "number" },"['totalAmount']": { "type": "currency","key":"totalAmountFormat" }, "warehouseCode": { "type": "string" }, "parentCatalogItemId": { "type": "string" }, "supplierCurrency": { "type": "string" }, "supplierLeadTime": { "type": "number" }, "supplierStatus": { "type": "string" }, "supplierCount": { "type": "number" }, "priceValidFrom": { "type": "date" }, "priceValidTo": { "type": "date" }, "createdOn": { "type": "date" }, "modifiedOn": { "type": "date" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * Description : This method will validate the items present inside cart whether the item info got updated (called before checkout)
         */
        validateItems(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 6);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/cart/validateCartItems';
                    http.post(url, 'validateItems', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            result.message = (result.data.info2 === "false") ? "eproc-msg-19" : "eproc-msg-20";
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" }, "info2": { "type": "boolean", "key": "isItemUpdated" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * Description : This method will add "virtual catalog item/item master item" into Cart
         */
        addDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "attachments": "joi.array().items(joi.string().label('eproc-lable-59__')).unique().label('eproc-lable-165__')",
                    "currency": "joi.string().required().label('eproc-lable-75__')",
                    "supplierName": "joi.string().allow('', null).label('eproc-lable-124__')",
                    "supplierId": "joi.number().integer().allow('', null).label('eproc-lable-123__')",
                    "description": "joi.string().allow('', null).label('eproc-lable-136__')",
                    "imageURL": "joi.string().allow('', null).label('eproc-lable-146__')",
                    "isGreen": "joi.boolean().label('eproc-lable-427__')",
                    "isPreferred": "joi.boolean().label('eproc-lable-428__')",
                    "itemId": "joi.string().required().label('eproc-lable-2__')",
                    "itemType": "joi.number().integer().required().label('eproc-lable-152__')",
                    "leadTime": "joi.number().integer().required().label('eproc-lable-140__')",
                    "name": "joi.string().required().label('eproc-lable-4__')",
                    "parametricData": "joi.array().items(joi.string().label('eproc-lable-202__')).unique().label('eproc-lable-202__')",
                    "sourcingStatus": "joi.number().integer().required().label('eproc-lable-170__')",
                    "parametricName": "joi.array().items(joi.string().label('eproc-lable-203__')).unique().label('eproc-lable-203__')",
                    "price": "joi.number().label('eproc-lable-138__')",
                    "receiptType": "joi.number().integer().required().label('eproc-lable-153__')",
                    "scopeId": "joi.string().allow('', null).label('eproc-lable-193__')",
                    "sourceRefNo": "joi.string().allow('', null).label('eproc-lable-148__')",
                    "manufacturerName": "joi.string().allow('', null).label('eproc-lable-135__')",
                    "manufacturerProductURL": "joi.string().allow('', null).label('eproc-lable-145__')",
                    "manufacturerPartId": "joi.string().allow('', null).label('eproc-lable-135__')",
                    "supplierPartId": "joi.string().allow('', null).label('eproc-lable-125__')",
                    "supplierProductURL": "joi.string().allow('', null).label('eproc-lable-144__')",
                    "marketPrice": "joi.number().integer().label('eproc-lable-139__')",
                    "uom": "joi.string().allow('', null).label('eproc-lable-137__')",
                    "quantity": "joi.number().allow('', null).label('eproc-lable-1__')",
                    "supplierContact": "joi.string().allow('', null).label('eproc-lable-129__')",
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/cart/items/addDetails/addToCart';
                    http.post(url, 'addToCart', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const message = { description: "eproc-msg-21" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        addItems(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {};
                validationUtility.addInternalSchema(schema);
                //const result = validationUtility.validate(request.body);            
                const result = false;
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const reqData = request.body;
                    if(reqData && super.lodash.isArray(reqData.guidedRequisitionItems)){
                        reqData.guidedRequisitionItems.forEach(item => {
                            if(item.guidedItem && !super.lodash.isEmpty(item.guidedItem)){
                                item.guidedItem.active = true;
                                item.guidedItem.hidden = false;
                            }                          
                        });
                    }
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/guidedRequisition/addToCart';
                    http.post(url, 'addItems', reqData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            result.message = "eproc-msg-4";
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "date" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }            
     }
    }

    return Cart;

};