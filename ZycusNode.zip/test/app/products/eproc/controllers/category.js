/**
 * Category Controller
 *
 * @description :: Provides Category related operations
 */

"use strict";

module.exports = (parentClass) => {
    class Category extends parentClass {
        /**
        * @Method Name : getRelated
        *
        * @Description : Display the related category lists
        * @return object / Throw Error
        */
        getRelated(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "description": "joi.string().allow('').required().label('eproc-lable-222__')",
                        "topCount": "joi.number().integer().required().label('eproc-lable-223__')",
                        "useMaster": "joi.boolean().required().label('eproc-lable-224__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                        http =  new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.entityList),
                        url = eProcURL + '/category/autoclass/iMaster';
                    http.post(url, 'getRelated', request.body, (error, response) => {
                        if (error) {
                            callback(error, null);
                        } else if (response) {
                            const responseSchema = {"type":"array","properties":{"name":{"type":"string"},"categoryCode":{"type":"string"},"categoryType":{"type":"string"},"parentCategoryCode":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"active":{"type":"boolean"},"archive":{"type":"boolean"}}},
                             output = (new (super.responseHandler)(request, response, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eProcURL = request.productsURL.eProc["soa"],
                     http  =  new  (super.httpService)(request,  super.appConstant.reqHandler.filter,  super.appConstant.resHandler.filter),
                     url = eProcURL + '/category/filter';
                    http.post(url, 'getCategoryList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {   
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"name":{"type":"string"},"favourite":{"type":"boolean"},"tenantId":{"type":"string"},"categoryCode":{"type":"string"},"categoryType":{"type":"string"},"parentCategoryCode":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"active":{"type":"boolean"},"archive":{"type":"boolean"}}}}},
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    
    }
    return Category;
};