/**
 * Audit Controller
 *
 * @description :: Provides audit related CRUD operation.
 */

module.exports = (parentClass) => {

    class Audit extends parentClass {

        /**
        * @Method Name : getList
        * @Description : Fetch/Get an Audit Details
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityType": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "entityId": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "entityVersion": "joi.string().allow(-1).label('eproc-lable-394__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request,
                        super.appConstant.reqHandler.businessEntity,
                        super.appConstant.resHandler.entityList),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/auditTrail/Details';
                    http.post(url, 'getAuditsList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const utils = super.utils,
                                lodash = super.lodash;
                            let userIds = [],
                                recordsWithTo = [],
                                userIdsTo = [];

                            if (lodash.isArray(result['data'])) {
                                // Get the unique user ID(S)
                                result['data'] = result['data'].map((ele) => {
                                    if (ele.auditVariables.TO) {
                                        // Get user ids from auditVariables
                                        ele.auditVariables.TO = JSON.parse(ele.auditVariables.TO);
                                        recordsWithTo.push(ele.auditVariables.TO)
                                    }
                                    userIds.push(ele.createdBy);
                                    return ele;
                                });
                                userIdsTo = lodash.flatten(recordsWithTo);
                                userIds = lodash.union(userIds, userIdsTo).filter((elem, index, self) => index == self.indexOf(elem) && elem);
                            }

                            const tasks = [
                                // Pass the userIds and Collect the user datas
                                (methodCallback) => {
                                    if (!lodash.isEmpty(userIds)) {
                                        const tms = new (super.tmsHook({request: request}))();
                                        tms.getUsers(request, userIds, methodCallback);
                                    } else {
                                        return methodCallback(null, request, []);
                                    }
                                },
                                // Merge the user datas and Product results
                                (request, input, methodCallback) => {
                                    if (!lodash.isEmpty(input)) {
                                        const extractProps = utils.extractObjPropsFromArray(input, ["firstName", "lastName", "displayName", "userId", "emailId"]);
                                        let utilsMerge = utils.mergeArray(result['data'], extractProps, ['createdBy', 'userId']);
                                        utilsMerge = utilsMerge.map(el => {
                                            el.auditVariables.TO = el.auditVariables.TO ? el.auditVariables.TO.map((item) => {
                                                item = lodash.find(extractProps, ["userId", item]);
                                                return item;
                                            }) : el.auditVariables.TO;
                                            return el;
                                        });
                                        result['data'] = utilsMerge;
                                    }
                                    return methodCallback(null, request, result);
                                }
                            ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    let removeReplies = [];
                                    result.data = result.data.map((element, index, self) => {
                                        // Pushing Replies of an activity in 'replies' key. Mapped using parentAuditTrailId
                                        element.replies = element.replies ? element.replies : [];
                                        if (element.parentAuditTrailId) {
                                            let commentIndex = result.data.findIndex((ele, i, arr) => element.parentAuditTrailId === ele.auditTrailId);
                                            if (commentIndex > 0) {
                                                removeReplies.push(index);
                                                if (!result.data[commentIndex].replies) {
                                                    result.data[commentIndex].replies = [];
                                                }
                                                result.data[commentIndex].replies.unshift(element);
                                            }
                                        }
                                        return element;
                                    });
                                    result.data = result.data.filter((element, index, self) => !removeReplies.includes(index));

                                    const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "object", "properties": { 'firstName': { "type": "string" }, 'lastName': { "type": "string" }, 'displayName': { "type": "string" }, 'userId': { "type": "string" } } }, "autoId": { "type": "number" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId": { "type": "string" }, "entityType": { "type": "string" }, "entityId": { "type": "string" }, "version": { "type": "number" }, "event": { "type": "string" }, "comments": { "type": "string" }, "role": { "type": "string" }, "auditVariables": { "type": "none" }, "attachments": { "type": "array", "properties": {} }, "attachmentIds": { "type": "none" }, "createdOn": { "type": "none" } } };

                                    responseSchema.properties.replies = JSON.parse(JSON.stringify(responseSchema));

                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                        output.addCommonSchema("attachments", output.responseSchema.properties.attachments.properties);
                                        output.addCommonSchema("attachments", output.responseSchema.properties.replies.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            })
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : createComment
        * @Description : Create new conversation
        * @return object / Throw Error
        */
        createComment(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityType": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "entityId": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "version": "joi.number().required().label('eproc-lable-72__')",
                        "comments": "joi.string().required().allow('').label('eproc-lable-405__')",
                        "role": "joi.string().required().label('eproc-lable-367__')",
                        "attachmentIds": "joi.array().items(joi.string().allow('').optional()).unique().label('eproc-lable-165__')",
                        "toUserId": "joi.array().items(joi.string().allow('').optional()).unique().label('eproc-lable-391__')",
                        "visibleTo": "joi.array().items(joi.string().allow('').optional()).unique().label('eproc-lable-392__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body,
                        http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/auditTrail/addOrReplyAuditComments';
                    inputData.parentAuditTrailId = null;
                    inputData.event = 'APPROVAL_CONVERSATION_NEW';
                    http.post(url, 'createNewConversation', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Method Name : createReply
        * @Description : Reply to conversations
        * @return object / Throw Error
        */
        createReply(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entityType": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "entityId": "joi.string().required().label('eproc-lable-356__').label('eproc-lable-357__')",
                        "parentAuditTrailId": "joi.string().required().label('eproc-lable-389__')",
                        "version": "joi.number().required().label('eproc-lable-72__')",
                        "comments": "joi.string().required().allow('').label('eproc-lable-405__')",
                        "role": "joi.string().required().label('eproc-lable-367__')",
                        "attachmentIds": "joi.array().items(joi.string().allow('').optional()).unique().label('eproc-lable-165__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body,
                        http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/auditTrail/addOrReplyAuditComments';
                    inputData.event = 'APPROVAL_CONVERSATION_REPLY'
                    http.post(url, 'createConversationReply', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else if (result) {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }

    return Audit;
};