/**
   * exchangerates Controller
   * Provides this controller to get the exchangerates lists and details.
*/

module.exports = (parentClass)=> {
  
  class Exchangerate extends parentClass {   

    /**
    * @Method Name : getRecords
    *
    * @Description : Get the currency exchange rates list
    * @return object / Throw Error
    */
    getRecords(request, input, callback) {
      try {
        const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
              tmsURL = request.productsURL.eProc["web"],
              url = tmsURL +
                '?responseType=json' +
                '&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                '&scopeName=eProcjQuery' +
                '&userId=' + super.utils.encodeURI(request.user.userId) +
                '&userName=' + super.utils.encodeURI(request.user.displayName) +
                '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                '&emailAddress=' + super.utils.encodeURI(request.user.emailId) +
                '&method=master.components.currency.searchCurrencyExchangeRates' +
                '&column1=SEARCH_BY_ARCHIVE&value1=0&column2=SEARCH_BY_ACTIVE&value2=1' +
                '&startIndex=0&noOfRecords=0&mode=2';
            http.get(url, 'currencyExchangeRates', (error, result) => {
                if (error) {
                    return callback(error, null);
                } else {
                    let currencyList = [];
                    let responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"fromCurrency":{"type":"string"},"toCurrency":{"type":"string"},"rate":{"type":"number"},"inverseRate":{"type":"number"},"erpId":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"code":{"type":"string"},"name":{"type":"string"},"active":{"type":"boolean"},"archive":{"type":"boolean"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"}}}}};
                    let output = (new (super.responseHandler)(request, result, responseSchema)),
                    response = output.execute(); 
                    if (!super.lodash.isEmpty(response.data) && super.lodash.isObject(response.data)) {
                        response.data.records.forEach((item,index) => {
                            let currencyMaps = {};
                            let map = item.fromCurrency + ':' + item.toCurrency;
                            currencyMaps[map] = item;
                            currencyList.push(currencyMaps);
                        });
                        response.data.totalRecords = result.data.totalCount;
                        response.data.records = currencyList;
                    }
                    return callback(null, request, response); 
                }
            });
      } catch (error) {
        return callback(error, null);
      }
    }
    
  }
  return Exchangerate;
}