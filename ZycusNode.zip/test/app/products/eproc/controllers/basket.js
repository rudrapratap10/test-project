/**
* Basket Controller
*
* @description :: Provides basket related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Basket extends parentClass {

    /**
    * @Method Name : getDetails
    *
    * @Description : Fetch/Get a Basket Details
    * @return object / Throw Error
    */
      getDetails(request, input, callback) {
          try {
              let validationUtility = super.utils.validationUtility(request);                    
              let schema = {
                    "basketId": "joi.required().label('eproc-lable-27__')"
              };
              validationUtility.addInternalSchema(schema);    
              let result = validationUtility.validate({"basketId": request.params.basket_Id});   
              if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
              } else {
                  const http =  new (super.httpService)(request);
                  const eProcURL = request.productsURL.eProc["soa"];
                  const url = eProcURL+'/basket/' + request.params.basket_Id;
                  http.get(url, 'basketDetails', (error, result) => {
                    if(error){
                        return callback(error, null);
                    }else{                          
                        let responseSchema = {"type":"object","properties":{"basket":{"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"basketId":{"type":"string"},"name":{"type":"string"},"totalItems":{"type":"number"},"totalPrice":{"type":"currency"},"isShared":{"type":"boolean"},"currency":{"type":"string"}}},"basketItemDetails":{"type":"array","properties":{"tenantId":{"type":"string"},"basketId":{"type":"string"},"itemId":{"type":"string"},"itemQuantity":{"type":"number"},"favorite":{"type":"boolean","key":"favourite"},"basketItem":{"type":"none"}}}}};
                        let output =  (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());        
                    }
                  });
              }
          } catch (error) {
            callback(error, null);
          }
      };

        /**
        * @Name : create
        * @Description : It is used to create a new basket
        * @return : object
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "basket": "joi.object({name: joi.string().required().label('eproc-lable-23__')}).required().label('eproc-lable-21__')",
                    "basketItems": "joi.array().items({itemId: joi.string().min(3).required().label('eproc-lable-25__'), itemQuantity:  joi.number().min(1).required().label('eproc-lable-26__')}).unique().min(1)"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    inputData.basket.currency = request.user.userSettings.currency;
                    inputData.modified = false;
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/basket/create';
                    http.post(url, 'createBasket', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } };                            
                            if(super.lodash.isEmpty(result.errors)){
                                result.message = "eproc-msg-8";
                            }
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : update
        * @Description : It is used to update an existing basket
        * @return : object
        */
        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "basket": "joi.object({name: joi.string().required().label('eproc-lable-23__'),basketId: joi.string().required().label('eproc-lable-27__')}).required().label('eproc-lable-21__')",
                    "basketItems": "joi.array().items({itemId: joi.string().min(3).required().label('eproc-lable-25__'),itemQuantity:  joi.number().integer().min(1).required().label('eproc-lable-26__')}).unique()"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const inputData = request.body;
                    inputData.modified = true;
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/basket/update';
                    http.post(url, 'updateBasket', inputData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } };                            
                            if(super.lodash.isEmpty(result.errors)){
                                result.message = "eproc-msg-9";
                            }
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : destroy
        * @Description : This method is used to delete an individual basket
        * @return : object
        */
        destroy(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request); 
                let schema = {
                      "basket_Id": "joi.string().required().label('eproc-lable-22__')"
                };
                validationUtility.addInternalSchema(schema);    
                let result = validationUtility.validate({"basket_Id": request.params.basket_Id});   
                if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                  return callback(errorMsg, null);
                }else{
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];   
                    const url = eProcURL + '/basket/'+request.params.basket_Id+'/delete';
                    http.delete(url, 'deleteBasket', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const message = {description: "eproc-msg-10"};
                            if(!super.lodash.isEmpty(result.data.id)){
                                result.message = [message];              
                            }
                            let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());       
                        }
                    });
                }                
            } catch (error) {
              return callback(error, null);
            }
        }

        /**
        * @Name : shareBasket
        * @Description : This method is used to share an individual basket
        * @return : object
        */
        share(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request); 
                let schema = {
                      "basketId": "joi.string().required().label('eproc-lable-27__')",
                      "scopeType" : "joi.number().integer().min(1).max(6).required().label('eproc-lable-34__')",
                      "companyCodes" : "joi.array().items(joi.string().label('eproc-lable-28__')).label('eproc-lable-28__')", 
                      "businessUnitCodes" : "joi.array().items(joi.string().label('eproc-lable-29__')).label('eproc-lable-29__')", 
                      "locationCodes" : "joi.array().items(joi.string().label('eproc-lable-30__')).label('eproc-lable-30__')", 
                      "regionCodes" : "joi.array().items(joi.string().label('eproc-lable-31__')).label('eproc-lable-31__')", 
                      "ouType" : "joi.array().items(joi.string().label('eproc-lable-32__')).label('eproc-lable-32__')", 
                      "deptCodes" : "joi.array().items(joi.string().label('eproc-lable-33__')).label('eproc-lable-33__')",
                      "shared" : "joi.boolean().label('eproc-lable-35__')"
                };
                validationUtility.addInternalSchema(schema);    
                let result = validationUtility.validate(request.body);   
                if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                  callback(errorMsg, null);
                }else{
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];   
                    const url = eProcURL + '/basket/share';
                    const requestData = {
                        basketId: request.body.basketId,
                        scopeType: request.body.scopeType,
                        companyCodes: request.body.companyCodes||[],
                        businessUnitCodes: request.body.businessUnitCodes||[],
                        locationCodes: request.body.locationCodes||[],
                        regionCodes: request.body.regionCodes||[],
                        ouType: request.body.ouType||[],
                        deptCodes: request.body.deptCodes||[],
                        shared: request.body.shared
                      };
                    http.post(url, 'shareBasket', requestData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = {description: "eproc-msg-11"};
                            if(!super.lodash.isEmpty(result.data.id)){
                                result.message = [message];              
                            }
                            let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"info1":{"type":"string"}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());       
                        }
                    });
                } 
            } catch (error) {
                return callback(error, null);
              }
        };
            
        /**
        * @Name : getList
        * @Description : It is used to get the basket list
        * @return : object
        */    
        getList(request, input, callback) {
            try {                
                let validationUtility = super.utils.validationUtility(request); 
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    let http =  new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL+'/basket/filter';

                    http.post(url, 'getBasketList', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result) {
                            let utils = super.utils,
                            lodash = super.lodash,
                            userIds = [];
                            
                            if(lodash.isArray(result['data'].records)) {
                                // Get the unique user ID(S)
                                userIds = result['data'].records.map((user)=> { return user.createdBy;}).filter((elem, index, self)=> {
                                    return index == self.indexOf(elem);
                                });
                            }

                            const tasks = [
                                // Pass the userIds and Collect the user datas
                                (methodCallback) => {
                                    if(!lodash.isEmpty(userIds)) {
                                        const tms = new (super.tmsHook({request: request}))();
                                        tms.getUsers(request, userIds, methodCallback);
                                    }else{
                                        return methodCallback(null, request, []);
                                    }
                                },
                                // Merge the user datas and Product results
                                (request, input, methodCallback) => {                                   
                                   if(!lodash.isEmpty(input)) {
                                        let extractProps = utils.extractObjPropsFromArray(input, ["firstName","lastName","displayName","userId"]);
                                        let utilsMerge = utils.mergeArray(result['data'].records, extractProps, ['createdBy','userId']);
                                        result['data'].records = utilsMerge; 
                                   }
                                   return methodCallback(null, request, result);
                                }
                            ];
                            
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"createdOn":{"type":"none"},"modifiedOn":{"type":"none"},"tenantId":{"type":"string"},"createdBy":{"type":"object","properties":{'firstName': {"type":"string"}, 'lastName': {"type":"string"}, 'displayName': {"type":"string"},'userId': {"type":"string"}}},"basketId":{"type":"string"},"favourite":{"type":"boolean"},"name":{"type":"string"},"totalItems":{"type":"number"},"totalPrice":{"type":"number"},"leadTime":{"type":"number"},"isShared":{"type":"boolean"},"scopeType":{"type":"number"},"scopeValue":{"type":"string"},"currency":{"type":"string"}}}}};
                                    let output =  (new (super.responseHandler)(request, result, responseSchema)); 
                                    output.addCommonSchema('pagination', output.responseSchema.properties);                          
                                    return callback(null, request, output.execute());    
                                }        
                            });           
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getOrganizationScope
        *
        * @Description : Fetch/Get a basket Organization Scope
        * @return object / Throw Error
        */
        getOrganizationScope(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);                    
                const schema = {
                        "basketId": "joi.string().required().label('eproc-lable-27__')",
                        "shareType": "joi.number().integer().required().label('eproc-lable-39__')"
                };
                validationUtility.addInternalSchema(schema);    
                const result = validationUtility.validate(request.body);   
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http =  new (super.httpService)(request, null, super.appConstant.resHandler.entityList);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL+'/basket/organizationScope';
                    http.post(url, 'getOrganizationScope', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else{ 
                            const output = { data:{}};
                            output.data.records = result.data;
                            if(super.lodash.isEmpty(result.data)){
                                output.errors = new (super.customError)('eproc-error-10', "AppError");   
                            }                         
                            return callback(null, request, output);        
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : addBasketToCart
        * @Description : This method is used to add a basket(items) to cart
        * @return : object
        */
        addToCart(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request); 
                let schema = {
                    "basket_Id": "joi.string().required().label('eproc-lable-22__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({"basket_Id": request.params.basket_Id});
                if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                  return callback(errorMsg, null);
                }else{
                    const http = new (super.httpService)(request);
                    const requestData = super.lodash.merge(request.body, {"basketId": request.params.basket_Id});
                    const eProcURL = request.productsURL.eProc["soa"];   
                    const url = eProcURL + '/basket/addtocart';
                    http.post(url, 'addBasketTocart', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const resType = (super.lodash.isArray(result.data)) ? "array": "object";
                            let responseSchema = {"type":resType,"properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"info1":{"type":"string"},"info2":{"type":"string"}}};
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());       
                        }
                    });
                }                
            } catch (error) {
              return callback(error, null);
            }
        }

        /**
        * Add virtual item to basket
        */
        addDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request); 
                let schema = {
                      "item": "joi.object({attachments:joi.array().items(joi.string().label('eproc-lable-59__')).unique().label('eproc-lable-165__'),currency:joi.string().required().label('eproc-lable-75__'),supplierName:joi.string().allow('', null).label('eproc-lable-124__'),supplierId:joi.number().integer().allow('', null).label('eproc-lable-123__'),description:joi.string().allow('', null).label('eproc-lable-136__'),imageURL:joi.string().allow('', null).label('eproc-lable-146__'),itemId:joi.string().required().label('eproc-lable-2__'),itemType:joi.number().integer().required().label('eproc-lable-152__'),leadTime:joi.number().integer().required().label('eproc-lable-140__'),name:joi.string().required().label('eproc-lable-4__'),parametricData:joi.array().items(joi.string().label('eproc-lable-202__')).unique().label('eproc-lable-202__'),sourcingStatus:joi.number().integer().required().label('eproc-lable-170__'),parametricName:joi.array().items(joi.string().label('eproc-lable-203__')).unique().label('eproc-lable-203__'),price:joi.number().integer().allow('', null).label('eproc-lable-138__'),receiptType:joi.number().integer().required().label('eproc-lable-153__'),scopeId:joi.string().allow('', null).label('eproc-lable-193__'),sourceRefNo:joi.string().allow('', null).label('eproc-lable-148__'),manufacturerName:joi.string().allow('', null).label('eproc-lable-135__'),manufacturerProductURL:joi.string().allow('', null).label('eproc-lable-145__'),manufacturerPartId:joi.string().allow('', null).label('eproc-lable-135__'),supplierPartId:joi.string().allow('', null).label('eproc-lable-125__'),supplierProductURL:joi.string().allow('', null).label('eproc-lable-144__'),marketPrice:joi.number().integer().required().label('eproc-lable-139__'),uom:joi.string().allow('', null).label('eproc-lable-137__'),quantity: joi.number().integer().allow('', null).label('eproc-lable-1__'),supplierContact: joi.string().allow('', null).label('eproc-lable-129__')}).required().label('eproc-lable-208__')", 
                      "basket": "joi.object({basketId: joi.string().allow('', null).label('eproc-lable-27__'),name: joi.string().required().label('eproc-lable-4__'),currency: joi.string().required().label('eproc-lable-75__')}).required().label('eproc-lable-209__')",
                      "basketItems": "joi.array().items({basketId : joi.string().allow('', null).label('eproc-lable-27__'),itemId : joi.string().required().label('eproc-lable-2__'),itemQuantity : joi.number().integer().required().label('eproc-lable-26__')}).required().min(1).unique().label('eproc-lable-210__')",
                      "modified":"joi.boolean().required().label('eproc-lable-449__')"
                };
                validationUtility.addInternalSchema(schema);    
                const result = validationUtility.validate(request.body);  
                if (result) {
                  const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                  return callback(errorMsg, null);
                }else{
                    let basketDetails = {
                        basket:request.body.basket,
                        basketItems:request.body.basketItems,
                        modified:request.body.modified
                    };      

                    request.body.basketDetails = basketDetails;
                    delete request.body.basket;
                    delete request.body.basketItems;
                    delete request.body.modified;

                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/basket/items/AddDetails/addToBasket';
                    http.post(url, 'addToBasket', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const message = {description: "eproc-msg-22"};
                            if(!super.lodash.isEmpty(result.data.id)){
                                result.message = [message];              
                            }
                            const responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"info1":{"type":"string"}}},
                                    output = (new (super.responseHandler)(request, result, responseSchema)).execute();
                            return callback(null, request, output);
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        }        
    
        getItemsList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort'); 
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/basket/items/filter';
                    http.post(url, 'getBasketItemsList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{}}}},
                            output =  (new (super.responseHandler)(request, result, responseSchema)); 
                           // using fav-item schema as previously used and filter items API's have same schema
                            output.addCommonSchema('favourite-item', output.responseSchema.properties.records.properties);
                            output.addCommonSchema('pagination', output.responseSchema.properties);                               
                            const schemaRes = output.execute(); 
                            if (schemaRes.data) {
                                schemaRes.data.facetResult = result.data.facetResult;
                                schemaRes.data.statResult = result.data.statResult;
                            }
                            return callback(null, request, schemaRes);
                        }
                    })
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : addGuidedItemToBasket
        * @Description : This method is used to add guided items to a exixting basket
        * @return : object
        */
        addGuidedItemToBasket(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "basket_Id": "joi.string().required().label('eproc-lable-22__')"
                    };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "basket_Id": request.params.basket_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                          requestData = super.lodash.merge(request.body, { "basketId": request.params.basket_Id }),
                          eProcURL = request.productsURL.eProc["soa"],
                          url = eProcURL + '/guidedRequisition/addToBasket';
                    http.post(url, 'addGuidedItemToBasket', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {                            
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "date" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
   
    };
      return Basket;
};
