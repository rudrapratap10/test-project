"use strict";
module.exports = (parentClass)=> {
    class Supplier extends parentClass {     
        /*getWebsitesList(request, input, callback){
            try {
            let validationUtility = super.utils.validationUtility(request);                    
            validationUtility.addCommonSchema('pagination'); 
            let schema = {
                    "name" : "joi.string().alphanum().min(3).max(30).label('eproc-lable-4__')"
            };
            validationUtility.addInternalSchema(schema);    
            let result = validationUtility.validate(request.body);   
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {  
                let http =  new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];
                let url = eProcURL+'/supplier/websitesList';
                const requestData = {
                    maxRows: request.body.perPageRecords,  
                    pageNumber: request.body.pageNo,
                    name: request.body.name
                };
                http.post(url, 'websitesList', requestData, (error, result) => {
                    if(error){
                        callback(error, null);
                    }else if(result){
                        callback(null, request, result.websites);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }*/

        /**
        * @Method Name : addUpdateSuggestedSupplier
        * @Description : Add or Update Suggested Supplier
        * @return object / Throw Error
        */
        addUpdateSuggestedSupplier(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "suggestedSupplierId": "joi.string().required().allow('').label('eproc-lable-359__')",
                    "name": "joi.string().required().label('eproc-lable-4__')"
                };
                validationUtility.addInternalSchema(schema);    
                const result = validationUtility.validate(request.body); 
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/supplier/addUpdateSuggestedSupplier';

                    http.post(url, 'addUpdateSuggestedSupplier', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"info1":{"type":"string"},"info2":{"type":"string"}}},
                                output =  (new (super.responseHandler)(request, result, responseSchema));                    
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

         /**
        * @Method Name : getList
        * @Description : Search for supplier list
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                          eProcURL = request.productsURL.eProc["soa"],
                          url = eProcURL + '/supplier/filter';

                    http.post(url, 'searchsupplier', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"supplierId":{"type":"number"},"globalSupplierId":{"type":"string"},"name":{"type":"string"},"contracted":{"type":"boolean"},"preffered":{"type":"boolean"},"taxIdFormat":{"type":"string"},"taxId":{"type":"string"},"status":{"type":"number"},"mapAddressERPId":{"type":"none"},"erpId":{"type":"string"},"supplierAddress":{"type":"array","properties":{"tenantId":{"type":"string"},"addressId":{"type":"string"},"street1":{"type":"string"},"street2":{"type":"string"},"street3":{"type":"string"},"city":{"type":"string"},"state":{"type":"string"},"country":{"type":"string"},"zip":{"type":"number"},"phone":{"type":"number"}}}}}}},
                                  output =  (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);                     
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }


        /**
       * @Method Name : updatedSuppliers
       * @Description : Get List of Updated Suppliers
       * @return object / Throw Error
       */
        updatedSuppliers(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-451__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/supplier/updatedSuppliers';
                    http.post(url, 'updatedSuppliers', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "supplierId": { "type": "string" }, "globalSupplierId": { "type": "string" }, "name": { "type": "string" }, "contracted": { "type": "boolean" }, "preffered": { "type": "boolean" }, "taxIdFormat": { "type": "string" }, "taxId": { "type": "string" }, "status": { "type": "number" }, "ERPId": { "type": "string" }, "mapAddressERPId": { "type": "none" }, "supplierContactMap": { "type": "none" }, "supplierAddress": { "type": "array", "properties": { "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" }, "tenantId": { "type": "string" } } }, "tenantId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
       * @Method Name : doValidateSupplierPaymentTerm
       * @Description : Get List of Updated Suppliers
       * @return object / Throw Error
       */
        doValidateSupplierPaymentTerm(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "supplierIds": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-451__')",
                        "ouCodes": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-464__')",
                        "isCustomArray": "joi.array().items(joi.boolean()).unique().required().label('eproc-lable-465__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/supplier/doValidateSupplierPaymentTerm';
                    http.post(url, 'updatedSuppliers', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "supplierName": { "type": "string" }, "supplierId": { "type": "string" }, "errorType": { "type": "string" }, "ouCode": { "type": "string" }, "facilityLevel": { "type": "string" }, "ouName": { "type": "string" }} },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request,  output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    }

    return Supplier;
};       
