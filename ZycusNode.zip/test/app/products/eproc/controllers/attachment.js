/**
 * Attachment Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload');

module.exports = (parentClass) => {

    class Attachment extends parentClass {

        /*
        * addEntry Method
        * This method to make an entry into the attachment table by Product API call.
        */
        addEntry(request, result, callback) {
            try {
                const output = { errors: result.errors, files: result.files },
                    input = [],
                    moduleName = request.headers.modulename;
                if (super.lodash.isEmpty(result.files) === false) {
                    result.files.forEach((file) => {
                        if (file.status === true) {
                            input.push({ "module": moduleName.toUpperCase(), "type": "0", "encoding": "UTF-8", "name": file.name, "fileSize": file.size });
                        }
                    });
                    if (super.lodash.isEmpty(input) === false) {
                        const eproc = new (super.eprocHook({ request: request }))();
                        eproc.addAttachment(request, input, (error, request, response) => {
                            if (error) {
                                return callback(error, output);
                            } else if (response) {
                                if (super.lodash.isEmpty(response.data) === false) {
                                    result.files.map((item) => {
                                        const fileDetails = (super.lodash.isArray(response.data)) ? super.lodash.find(response.data, { "info2": item.name }) : ((item.name === response.data.info2) ? response.data : {});
                                        if (super.lodash.isEmpty(fileDetails) === false) {
                                            super.lodash.merge(item, fileDetails);
                                        } else {
                                            super.lodash.merge(item, { status: false });
                                        }
                                    });
                                }
                                if (super.lodash.isEmpty(response.errors) === false) {
                                    response.errors.forEach((error) => {
                                        output.errors.push({ "description": error });
                                    });
                                }
                                return callback(null, output);
                            }
                        });
                    } else {
                        return callback(null, output);
                    }
                } else {
                    return callback(null, output);
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /*
        * fileUploadToSFTP Method
        * This method to upload file from tmp folder to sftp server.
        */
        fileUploadToSFTP(request, input, callback) {
            try {
                const result = input.result,
                    uploadService = input.uploadService,
                    output = { records: [], errors: result.errors, message: [], files: result.files };
                if (super.lodash.isEmpty(result.files) === false) {
                    super.async.eachSeries(result.files, (file, callback1) => {
                        if (file.status === true) {
                            let data = {
                                remoteFilePath: file.info1,
                                localFilePath: file.path,
                            };
                            //Upload file to the sftp server
                            uploadService.save(data, (error, response) => {
                                if (error) {
                                    output.errors.push({ "description": error });
                                } else if (response) {
                                    const filePath = file.info1 + '~' + file.name,
                                        filePathEncode = super.utils.encrypt(filePath, request.tokenId, true),
                                        replaceSlash = filePathEncode.replace(/\//g, "@"),
                                        record = {
                                            "id": file.id,
                                            "name": file.name,
                                            "path": replaceSlash,
                                            "size": file.size,
                                            "type": file.type,
                                            "modifiedBy": file.modifiedBy,
                                            "modifiedOn": file.modifiedOn
                                        };
                                    output.records.push(record);
                                    output.message.push({ description: super.utils.translate(request, "dd-msg-3", { fileName: file.name }) });
                                }
                                callback1();
                            });
                        } else {
                            callback1();
                        }
                    }, () => {
                        return callback(null, output);
                    });
                } else {
                    return callback(null, output);
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /*
        * finalOutput Method
        * This method to provide/perpare the final attachment outputs.
        */
        finalOutput(request, input, callback) {
            try {
                const results = input.results,
                    error = input.error,
                    uploadService = input.uploadService;

                //Delete file from tmp folder
                if (super.lodash.isEmpty(results.files) === false) {
                    results.files.forEach((file) => {
                        uploadService.unlink(file.path, () => { });
                    });
                }

                if (error) {
                    return callback(error, null);
                }

                if (results.errors.length && results.records.length == 0) {
                    return callback(results.errors, null);
                }

                let output = {
                    data: {
                        records: (results.records.length) ? results.records : undefined
                    },
                    message: (results.message.length) ? results.message : undefined,
                    errors: (results.errors.length) ? results.errors : undefined
                };

                return callback(null, request, output);
            } catch (error) {
                callback(error, null);
            }
        }

        /*
         * Create Method
         * Add attachment files.
         */
        create(request, input, callback) {
            try {
                const productSetting = super.productSetting(request),
                    modules = Object.keys(productSetting['modules']),
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "modulename": "joi.any().required().valid(" + JSON.stringify(modules) + ").label('eproc-lable-37__')"
                    },
                    moduleName = request.headers.modulename;
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "modulename": moduleName });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting['modules'][moduleName]['attachment'],
                        options = { productName: request.productName },
                        uploadService = new (upload)(super.lodash.merge(moduleOptions, options));
                    super.async.waterfall([
                        (callback) => {
                            uploadService.fileUploadToServer(request, callback);
                        },
                        (result, callback) => {
                            uploadService.validateZipFile(request, result, callback);
                        },
                        (result, callback) => {
                            this.addEntry(request, result, callback);
                        },
                        (result, callback) => {
                            this.fileUploadToSFTP(request, { result: result, uploadService: uploadService }, callback)
                        }
                    ],
                        (error, results) => { //final method to provides the output details here.
                            return this.finalOutput(request, { error: error, results: results, uploadService: uploadService }, callback);
                        });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /*
         * Image Method
         * Add image files.
         */
        image(request, input, callback) {
            try {
                const productSetting = super.productSetting(request),
                    modules = Object.keys(productSetting.modules),
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "modulename": "joi.any().required().valid(" + JSON.stringify(modules) + ").label('eproc-lable-37__')"
                    },
                    moduleName = request.headers.modulename;
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "modulename": moduleName });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting.modules[moduleName].imageAttachment,
                        options = { productName: request.productName },
                        uploadService = new (upload)(super.lodash.merge(moduleOptions, options));
                    super.async.waterfall([
                        (callback) => {
                            uploadService.fileUploadToServer(request, callback);
                        },
                        (result, callback) => {
                            result.imageAttachment = moduleOptions;
                            uploadService.validateImageFile(request, result, callback);
                        },
                        (result, callback) => {
                            this.addEntry(request, result, callback);
                        },
                        (result, callback) => {
                            this.fileUploadToSFTP(request, { result: result, uploadService: uploadService }, callback)
                        }
                    ],
                        (error, results) => { //final method to provides the output details here.
                            return this.finalOutput(request, { error: error, results: results, uploadService: uploadService }, callback);
                        });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /*
        * Update Method
        * This method to update more than one attachment details.
        */

        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.validObj = false;
                const schema = {
                    "attachmentId": "joi.string().min(1).required().label('eproc-lable-194__')",
                    "visibility": "joi.string().allow('').label('eproc-lable-195__')",
                    "comments": "joi.string().allow('').label('eproc-lable-196__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/attachment/update';
                    http.post(url, 'updateAttachment', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const resType = (super.lodash.isArray(result.data)) ? "array" : "object",
                                responseSchema = { "type": resType, "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "date" } } },
                                message = { description: "eproc-msg-18" };
                            result.message = [message];
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : getDetails
        * @Description : Fetch/Get an Attachment Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "attachmentId": "joi.required().label('eproc-lable-194__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "attachmentId": request.params.attachment_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/attachment/' + request.params.attachment_Id;
                    http.get(url, 'attachmentDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "date" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "attachmentId": { "type": "string" }, "referenceAttachmentId": { "type": "string" }, "name": { "type": "string" }, "encoding": { "type": "string" }, "fileSize": { "type": "number" }, "path": { "type": "filePathEncode" }, "type": { "type": "number" }, "visibility": { "type": "string" }, "comments": { "type": "string" }, "errorReasonsStr": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : copy
        * @Description : Copy the Attachment(s)
        * @return object / Throw Error
        */
        copy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-15__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/attachment/copyAttachments';
                    http.post(url, 'copyAttachments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": {} },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('attachments', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getByIds
        * @Description : Get the multiple Attachment
        * @return object / Throw Error
        */
        getByIds(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('eproc-lable-3__')).unique().required().label('eproc-lable-15__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/attachment/getAttachments';
                    http.post(url, 'getAttachments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": {} },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('attachments', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : webLinks
        * @Description : attach the web links
        * @return object / Throw Error
        */
        webLink(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().required().label('eproc-lable-37__')",
                        "path": "joi.string().required().label('eproc-lable-442__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eproc = new (super.eprocHook({ request: request }))(),
                        requestData = {
                            "module": request.body.module,
                            "type": "1",
                            "path": request.body.path
                        };
                    eproc.addAttachment(request, requestData, (error, request, response) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, response, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        download(request, input, callback) {
            try {
                const ddHook = new (super.ddHook({ request: request }))();
                ddHook.getFileStream(request, input, (error, response) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, { data: response });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : downloadFile
        * @Description : Get details by Id and Download Attachment
        * @return object / Throw Error
        */
        downloadFile(request, input, callback) {
            try {
                const eprocHook = new (super.eprocHook({ request: request }))(),
                    ddHook = new (super.ddHook({ request: request }))();
                eprocHook.getAttachmentDetails(request, input, (error, request, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const filePath = result.data.path;
                        request.params.attachment_Id = filePath;
                        ddHook.getFileStream(request, input, (error, response) => {
                            if (error) {
                                return callback(error, null);
                            } else {
                                return callback(null, request, { data: response });
                            }
                        });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return Attachment;
};