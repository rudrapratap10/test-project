/**
* Receipt Controller
*
* @description :: Provides receipt related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Receipt extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the receipt list
        * @return : object
        */
        getList(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/receipts/filter';
                    http.post(url, 'getReceiptList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            let responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "enitity.createdOn": { "type": "none", "key": "createdOn" }, "enitity.modifiedOn": { "type": "none", "key": "modifiedOn" }, "enitity.tenantId": { "type": "string", "key": "tenantId" }, "enitity.createdBy": { "type": "string", "key": "createdBy" }, "enitity.modifiedBy": { "type": "string", "key": "modifiedBy" }, "enitity.submittedOn": { "type": "none", "key": "submittedOn" }, "enitity.receivedOn": { "type": "none", "key": "receivedOn" }, "enitity.status": { "type": "number", "key": "status" }, "enitity.statusText": { "type": "string", "key": "statusText" }, "enitity.statusComments": { "type": "string", "key": "statusComments" }, "enitity.archive": { "type": "boolean", "key": "archive" }, "enitity.version": { "type": "number", "key": "version" }, "enitity.receiptDocType": { "type": "number", "key": "receiptDocType" }, "enitity.receiptId": { "type": "string", "key": "receiptId" }, "enitity.externalId": { "type": "string", "key": "externalId" }, "enitity.referenceType": { "type": "number", "key": "referenceType" }, "enitity.referenceValue": { "type": "string", "key": "referenceValue" }, "enitity.attachmentIds": { "type": "array", "key": "attachmentIds" }, "enitity.erpId": { "type": "string", "key": "erpId" }, "enitity.notifySupplier": { "type": "boolean", "key": "notifySupplier" }, "enitity.external": { "type": "boolean", "key": "external" }, "enitity.receiptNo": { "type": "string", "key": "receiptNo" }, "enitity.consignmentNo": { "type": "string", "key": "consignmentNo" }, "enitity.shipInfo": { "type": "string", "key": "shipInfo" }, "enitity.airwayBillNo": { "type": "string", "key": "airwayBillNo" }, "enitity.lastReceipt": { "type": "boolean", "key": "lastReceipt" }, "enitity.allowInvoice": { "type": "boolean", "key": "allowInvoice" }, "enitity.totalItems": { "type": "number", "key": "totalItems" }, "enitity.assetCodeSetting": { "type": "boolean", "key": "assetCodeSetting" }, "enitity.comments": { "type": "string", "key": "comments" }, "enitity.workflowId": { "type": "string", "key": "workflowId" }, "enitity.workflowInstanceId": { "type": "string", "key": "workflowInstanceId" }, "enitity.approvalIntegrationStatus": { "type": "number", "key": "approvalIntegrationStatus" }, "enitity.parameterStr": { "type": "array", "key": "parameterStr" }, "attachment": { "type": "array" } } } } };
                            let output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * @Method Name : getDetails
        *
        * @Description : Fetch/Get a Receipt Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "receiptId":  "joi.required().label('eproc-lable-395__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "receiptId": request.params.receipt_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/receipts/receiptDetails/' + request.params.receipt_Id;
                    http.get(url, 'receiptDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "receipt": { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "version": { "type": "number" }, "receiptDocType": { "type": "number" }, "receiptId": { "type": "string" }, "externalId": { "type": "string" }, "submittedOn": { "type": "none" }, "receivedOn": { "type": "none" }, "referenceType": { "type": "number" }, "referenceValue": { "type": "string" }, "attachmentIds": { "type": "array" }, "erpId": { "type": "string" }, "notifySupplier": { "type": "boolean" }, "external": { "type": "boolean" }, "receiptNo": { "type": "string" }, "consignmentNo": { "type": "string" }, "shipInfo": { "type": "string" }, "airwayBillNo": { "type": "string" }, "lastReceipt": { "type": "boolean" }, "allowInvoice": { "type": "boolean" }, "totalItems": { "type": "number" }, "assetCodeSetting": { "type": "boolean" }, "comments": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "approvalIntegrationStatus": { "type": "number" }, "parameterStr": { "type": "array" } } }, "receiptItems": { "type": "array", "properties": { "tenantId": { "type": "string" }, "lineItemId": { "type": "string" }, "receiptId": { "type": "string" }, "itemId": { "type": "string" }, "receivedQuantity": { "type": "number" }, "approvedQuantity": { "type": "number" }, "invoicedQuantity": { "type": "number" }, "receivedRating": { "type": "number" }, "itemComment": { "type": "string" }, "requisitionId": { "type": "string" }, "purchaseOrderId": { "type": "string" }, "lineNo": { "type": "string" }, "itemQuantity": { "type": "number" }, "assetCode": { "type": "string" }, "assetCodeType": { "type": "number" }, "attachmentIds": { "type": "array" }, "supplierComment": { "type": "string" }, "parameterStr": { "type": "array" } } }, "supportObjects": { "type": "object", "properties": { "returnNoteDetailsList": { "type": "array" } } } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };


        /**
        * @Name : create/update
        * @Description : It is used to create/update receipt
        * @return : object
        */

        create(request, input, callback) {
            try {
                /*let validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "submit": "joi.boolean().label('eproc-lable-396__')",
                    "doProceed": "joi.boolean().label('eproc-lable-397__')",
                    "referrerModule": "joi.string().allow('').label('eproc-lable-398__')",
                    "receipt": "joi.object().keys({receiptId: joi.string().allow('').label('eproc-lable-395__'),airwayBillNo: joi.string().allow('').label('eproc-lable-399__'),consignmentNo: joi.string().allow('').label('eproc-lable-400__'),status: joi.number().label('eproc-lable-76__'),shipInfo: joi.string().allow('').label('eproc-lable-401__'),receivedOn: joi.number().label('eproc-lable-258__'),referenceType: joi.number().label('eproc-lable-403__'),referenceValue: joi.string().allow('').label('eproc-lable-93__'),comments: joi.string().allow('').label('eproc-lable-196__'),lastReceipt: joi.boolean().label('eproc-lable-406__'),allowInvoice: joi.boolean().label('eproc-lable-407__'),totalItems: joi.number().label('eproc-lable-204__'),workflowId: joi.string().allow('').label('eproc-lable-266__'),assetCodeSetting: joi.boolean().label('eproc-lable-312__'),attachmentIds: joi.array().items(joi.string()).unique().label('eproc-lable-194__')})", 
                    "receiptItems": "joi.array().items(joi.object().keys({itemId: joi.string().allow('').label('eproc-lable-2__'),lineItemId: joi.string().allow('').label('eproc-lable-417__'),requisitionId: joi.string().allow('').label('eproc-lable-6__'),purchaseOrderId: joi.string().allow('').label('eproc-lable-70__'),receivedQuantity: joi.number().label('eproc-lable-226__'),approvedQuantity: joi.number().label('eproc-lable-339__'),itemComment: joi.string().allow('').label('eproc-lable-418__'),receivedRating: joi.number().label('eproc-lable-419__'),assetCode: joi.string().allow('').label('eproc-lable-346__'),assetCodeType: joi.number().label('eproc-lable-347__'),supplierComment: joi.string().allow('').label('eproc-lable-420__'),attachmentIds: joi.array().items(joi.string()).unique().label('eproc-lable-194__')})).unique().label('eproc-lable-416__')",
                    "returnNoteDetails": "joi.object().keys({returnNoteItems: joi.array().items(joi.object().keys({lineItemId: joi.string().allow('').label('eproc-lable-417__'),itemId: joi.string().allow('').label('eproc-lable-2__'),returnedQuantity: joi.number().label('eproc-lable-422__'),reasonForReturn: joi.string().allow('').label('eproc-lable-423__'),returnMethod: joi.string().allow('').label('eproc-lable-424__'),requisitionId: joi.string().allow('').label('eproc-lable-6__'),attachmentIds:joi.array().items(joi.string()).unique().label('eproc-lable-194__'),purchaseOrderId: joi.string().allow('').label('eproc-lable-70__')})).unique().label('eproc-lable-421__'),returnNote: joi.object().keys({rmaNumber: joi.string().allow('').label('eproc-lable-425__'),attachmentIds: joi.array().items(joi.string()).unique().label('eproc-lable-194__'),referenceNumber: joi.string().allow('').label('eproc-lable-426__')})}).allow(null)", 
   
                    "supportObjects": "joi.object({}).label('eproc-lable-221__')",
                    "attachmentsDetails": "joi.array().items(joi.object().keys({attachmentId: joi.string().allow('').allow(null).label('eproc-lable-194__'),comments: joi.string().allow('').allow(null).label('eproc-lable-196__'),visibility: joi.string().allow('').allow(null).label('eproc-lable-195__')})).unique().label('eproc-lable-412__')", 
                    "rmaPoDetails": "joi.array().items(joi.object().keys({rmaPoId: joi.string().allow('').label('eproc-lable-414__'),rmaPoNumber: joi.string().allow('').label('eproc-lable-415__')})).unique().label('eproc-lable-413__')" 
                };
                
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {*/
                const eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/receipts/receiptDetails/update',
                    http = new (super.httpService)(request);
                http.post(url, 'createReceipt', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else if (result) {
                        const responseSchema = { "type": "object", "properties": { "warningList": { "type": "array", "properties": { "field": { "type": "string" }, "type": { "type": "number" }, "value": { "type": "none" }, "lineItemId": { "type": "string" } } }, "errorList": { "type": "array", "properties": { "field": { "type": "string" }, "type": { "type": "number" }, "value": { "type": "none" }, "lineItemId": { "type": "string" } } }, "validReceiptCreationDate": { "type": "boolean" }, "receiptId": { "type": "string" }, "externalId": { "type": "string" } } };
                        const output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
                //  }
            }
            catch (error) {
                callback(error, null);
            }
        };

        /**
    * @Name : destroy
    * @Description : This method is used to delete a receipt
    * @return : object
    */
        destroy(request, input, callback) {
            try {
                let validationUtility = super.utils.validationUtility(request);
                let schema = {
                    "receipt_Id":  "joi.string().required().label('eproc-lable-395__')"
                };
                validationUtility.addInternalSchema(schema);
                let result = validationUtility.validate({ "receipt_Id": request.params.receipt_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    const url = eProcURL + '/receipts/' + request.params.receipt_Id + '/deleteReceipt';
                    http.delete(url, 'deleteReceipt', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const message = { description: "eproc-msg-28" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            let responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" } } };
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * Function to cancel receipt
        * @param {*} request 
        * @param {*} input 
        * @param {*} callback 
        */
        cancel(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "receiptId": "joi.string().required().label('eproc-lable-395__')",
                        "roleType": "joi.string().required().label('eproc-lable-367__')",
                        "comments": "joi.string().required().allow('', null).label('eproc-lable-196__')",
                        "referrerModule": "joi.boolean().allow('', null).label('eproc-lable-429__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/receipts/receiptCancel';
                    http.post(url, 'receiptCancel', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const  responseSchema  =  {  "type":  "object",  "properties": {  "id": {  "type":  "string"  },  "modifiedBy": {  "type":  "string"  },  "modifiedOn": {  "type":  "date"  } } };
                            if (super.lodash.isEmpty(result.errors)) {
                                result.message = "eproc-msg-30";
                            }
                            const output  =  (new  (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : receiptDetails
        *
        * @Description : Get Receipt Details to Render UI
        * @return object / Throw Error
        */
        receiptDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requisitionId":  "joi.string().required().label('eproc-lable-6__')",
                        "receiptId":  "joi.string().label('eproc-lable-395__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/receipts/details';
                    http.post(url, 'receiptDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "receiptWithAdditionalDetails": { "type": "object", "key": "receipt", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "version": { "type": "number" }, "receiptDocType": { "type": "number" }, "receiptId": { "type": "string" }, "externalId": { "type": "string" }, "submittedOn": { "type": "none" }, "receivedOn": { "type": "none" }, "referenceType": { "type": "number" }, "referenceValue": { "type": "string" }, "attachmentIds": { "type": "none" }, "erpId": { "type": "string" }, "notifySupplier": { "type": "boolean" }, "external": { "type": "boolean" }, "receiptNo": { "type": "string" }, "consignmentNo": { "type": "string" }, "shipInfo": { "type": "string" }, "airwayBillNo": { "type": "string" }, "lastReceipt": { "type": "boolean" }, "allowInvoice": { "type": "boolean" }, "totalItems": { "type": "number" }, "assetCodeSetting": { "type": "boolean" }, "comments": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "approvalIntegrationStatus": { "type": "number" }, "attachments": { "type": "array", "properties": {} }, "parameterStr": { "type": "array" }, "companyCode": { "type": "string" }, "currency": { "type": "string" }, "retrospectivePurchase": { "type": "boolean" }, "requisitionSubmittedOn": { "type": "string" } } }, "receiptItems": { "type": "array", "properties": { "tenantId": { "type": "string" }, "lineItemId": { "type": "string" }, "receiptId": { "type": "string" }, "itemId": { "type": "string" }, "receivedQuantity": { "type": "number" }, "approvedQuantity": { "type": "number" }, "invoicedQuantity": { "type": "number" }, "receivedRating": { "type": "number" }, "itemComment": { "type": "string" }, "requisitionId": { "type": "string" }, "purchaseOrderId": { "type": "string" }, "lineNo": { "type": "string" }, "itemQuantity": { "type": "number" }, "assetCode": { "type": "string" }, "assetCodeType": { "type": "number" }, "attachmentIds": { "type": "none" }, "supplierComment": { "type": "string" }, "attachments": { "type": "array", "properties": {} }, "parameterStr": { "type": "array" } } }, "supportObjects": { "type": "object", "properties": { "assetCodes": { "type": "none" }, "itemWithDeliveryAndPODetails": { "type": "none" }, "returnNoteDetailsList": { "type": "none" }, "items": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('attachments', output.responseSchema.properties.receiptWithAdditionalDetails.properties.attachments.properties);
                            output.addCommonSchema('attachments', output.responseSchema.properties.receiptItems.properties.attachments.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : receiptView
        *
        * @Description : Get Receipt View to Render UI
        * @return object / Throw Error
        */
        receiptView(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "requisitionId":  "joi.string().label('eproc-lable-6__')",
                        "purchaseOrderId": "joi.string().label('eproc-lable-70__')",
                        "receiptId":  "joi.string().label('eproc-lable-395__')",
                        "referrer": "joi.number().label('eproc-lable-398__')",
                        "version":  "joi.number().label('eproc-lable-72__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    let receiptViewUrl = '';
                    if (request.body.purchaseOrderId) {
                        receiptViewUrl = '/receipts/recieptAndPurchaseOrderDetails';
                    } 
                    if (request.body.requisitionId) {
                        receiptViewUrl = '/receipts/receiptAndRequisitionDetails';
                    }
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + receiptViewUrl;
                    http.post(url, 'receiptView', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            if(request.body.purchaseOrderId) {
                               return callback(null, request, result);
                            }

                            if(request.body.requisitionId) {
                                let data = {}
                                data.requisition = result.data.deliveryObjects.requisition;
                                data.requisitionItems = result.data.deliveryObjects.requisitionItems;
                                data.requisitionObjectsItems = result.data.deliveryObjects.requisitionObjectsItems;
                                data.returnNoteDetailsList = result.data.deliveryObjects.returnNoteDetailsList;
                                data.assetCodes = result.data.deliveryObjects.assetCodes;

                                const utils = super.utils;
                                let selectReceiptObjectsItems = utils.extractObjPropsFromArray(result.data.deliveryObjects.receiptObjectsItems, ["itemId", "name", "supplierName", "supplierAddress", "currency", "uom", "supplierPartId", "price"]),
                                    receiptItems = utils.mergeArray(result.data.deliveryObjects.receiptItems, selectReceiptObjectsItems, ["itemId", "itemId"], true),
                                    itemWithDeliveryAndPODetails = utils.extractObjPropsFromArray(result.data.deliveryObjects.itemWithDeliveryAndPODetails, ["requisitionDeliveries"]);
                                itemWithDeliveryAndPODetails.forEach((val, i) => {
                                    let selectRequisitionDeliveries = utils.extractObjPropsFromArray(val.requisitionDeliveries, ["lineItemId", "locationName", "itemQuantity", "orderedQuantity"]),
                                        selectRequisitionDeliveriesPO = utils.extractObjPropsFromArray(val.requisitionDeliveries, ["purchaseOrderNumber", "purchaseOrderId"]);
                                    selectRequisitionDeliveries.forEach((val, i) => {
                                        val.quantity = val.itemQuantity;
                                        delete val.itemQuantity;
                                    });
                                    receiptItems = super.lodash.merge(receiptItems, utils.mergeArray(result.data.deliveryObjects.receiptItems, selectRequisitionDeliveries, ["lineItemId", "lineItemId"], true))
                                    data.returnNoteDetailsList.forEach((val, i) => {
                                        let selectReturnNoteItemsPO = utils.extractObjPropsFromArray(val.returnNoteItems, ["purchaseOrderId"])
                                        selectRequisitionDeliveriesPO.forEach((ele, i) => {
                                            if (ele.purchaseOrderId === selectReturnNoteItemsPO[0].purchaseOrderId) {
                                                val.returnNote["purchaseOrderNumber"] = ele.purchaseOrderNumber
                                            }
                                        });
                                    });
                                });

                                data.receiptItems = receiptItems;
                                let selectRequisition = super.lodash.pick(result.data.deliveryObjects.requisition, ["requisitionId", "requisitionNo", "name", "totalAmount", "grossTotalAmount"])
                                data.receipt = super.lodash.merge(selectRequisition, result.data.deliveryObjects.receipt);
                                result.data = data;

                                const responseSchema = {"type":"object","properties":{"receiptItems":{"type":"array","properties":{"name":{"type":"string"},"supplierName":{"type":"string"},"supplierAddress":{"type":"string"},"currency":{"type":"string"},"uom":{"type":"string"},"supplierPartId":{"type":"string"},"price":{"type":"number"},"locationName":{"type":"string"},"quantity":{"type":"number"},"orderedQuantity":{"type":"number"},"tenantId":{"type":"string"},"lineItemId":{"type":"string"},"receiptId":{"type":"string"},"itemId":{"type":"string"},"receivedQuantity":{"type":"number"},"approvedQuantity":{"type":"number"},"invoicedQuantity":{"type":"number"},"receivedRating":{"type":"number"},"itemComment":{"type":"string"},"requisitionId":{"type":"string"},"purchaseOrderId":{"type":"string"},"lineNo":{"type":"string"},"itemQuantity":{"type":"number"},"assetCode":{"type":"string"},"assetCodeType":{"type":"number"},"attachmentIds":{"type":"none"},"supplierComment":{"type":"string"},"attachments":{"type":"array","properties":{}},"parameterStr":{"type":"array"}}},"assetCodes":{"type":"none"},"receipt":{"type":"object","properties":{"attachments":{"type":"array","properties":{}},"attachmentIds":{"type":"none"},"receiptNo":{"type":"string"},"status":{"type":"number"},"consignmentNo":{"type":"string"},"shipInfo":{"type":"string"},"airwayBillNo":{"type":"string"},"lastReceipt":{"type":"boolean"},"allowInvoice":{"type":"boolean"},"totalItems":{"type":"number"},"assetCodeSetting":{"type":"boolean"},"comments":{"type":"string"},"workflowId":{"type":"string"},"workflowInstanceId":{"type":"string"},"approvalIntegrationStatus":{"type":"number"},"receiptDocType":{"type":"number"},"receiptId":{"type":"string"},"externalId":{"type":"string"},"submittedOn":{"type":"none"},"receivedOn":{"type":"none"},"referenceType":{"type":"number"},"referenceValue":{"type":"string"},"erpId":{"type":"string"},"notifySupplier":{"type":"boolean"},"external":{"type":"string"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"object"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"tenantId":{"type":"string"},"receiptStatus":{"type":"number"},"requisitionId":{"type":"string"},"requisitionNo":{"type":"string"},"name":{"type":"string"},"totalAmount":{"type":"number"},"grossTotalAmount":{"type":"number"}}},"requisition":{"type":"none"},"requisitionItems":{"type":"none"},"returnNoteDetailsList":{"type":"array","properties":{"returnNote":{"type":"object","properties":{"rmaNumber":{"type":"string"},"purchaseOrderNumber":{"type":"string"}}},"returnNoteItems":{"type":"none"}}},"requisitionObjectsItems":{"type":"none"}}},
                                    output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('attachments', output.responseSchema.properties.receiptItems.properties.attachments.properties);
                                output.addCommonSchema('attachments', output.responseSchema.properties.receipt.properties.attachments.properties);

                                return callback(null, request, output.execute());
                            }
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : receiptPOView
        *
        * @Description : Get PO Receipt View
        * @return object / Throw Error
        */
        receiptPOView(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId":  "joi.string().required().label('eproc-lable-70__')",
                        "receiptId":  "joi.string().optional().label('eproc-lable-395__')",
                        "referrerModule":  "joi.string().required().label('eproc-lable-398__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        eProcURL = request.productsURL.eProc["soa"],
                        url = eProcURL + '/receipts/receiptPOView';
                    http.post(url, 'receiptPOView', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            // TODO Response Schema
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }
    return Receipt;
};