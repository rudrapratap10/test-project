"use strict";
module.exports = (parentClass)=> {
  
  class RequisitionComment extends parentClass { 
      createComment(request, input, callback) {
          try {      
            let validationUtility = super.utils.validationUtility(request);   
            let schema = {
                "requisition_Id" : "joi.number().integer().min(1).label('eproc-lable-6__')",
                "comment" : "joi.string().required().label('eproc-lable-7__')"
            };                      
            validationUtility.addInternalSchema(schema);             
            let result = validationUtility.validate(super.lodash.merge(request.body, {"requisition_Id": request.params.requisition_Id}));       
            if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                  }else{                  
                    let http =  new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL+'/requisitions/createComment';
                    const requestData = {
                      requisition_Id: request.params.requisition_Id,
                      comment: request.body.comment
                    };
                    http.post(url, 'requisitionCommentDetails', requestData, (error, result) => {
                      if(error){
                        callback(error, null);
                      }else{                       
                        callback(null, request, super.utils.formatResponse(result));
                      }
                    });
                  }
          } catch (error) {
            callback(error, null);
          }
      }

      fetchComments(request, input, callback) {
          try {                
            let validationUtility = super.utils.validationUtility(request);   
            let schema = {
                "requisition_Id" : "joi.number().integer().min(1).label('eproc-lable-6__')"
            };                      
            validationUtility.addInternalSchema(schema);              
            let result = validationUtility.validate({"requisition_Id": request.params.requisition_Id});       
            if (result) {
                    let errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                  }else{
                    let http =  new (super.httpService)(request);
                    const eProcURL = request.productsURL.eProc["soa"];
                    let url = eProcURL+'/requisitions/'+request.params.requisition_Id+'/fetchComments';                 
                    http.get(url, 'requisitionCommentList', (error, result) => {
                      if(error){
                        callback(error, null);
                      }else {
                        if (super.lodash.isArray(result)) {
                          result.forEach((item, key) => {
                            item = super.utils.formatResponse(item);
                          });
                        }else {
                          result = super.utils.formatResponse(result);
                        }
                        callback(null, request, {records: result});
                      }
                    });
                  }          
          } catch (error) {
            callback(error, null);
          }
      }    

  }

  return RequisitionComment;
}