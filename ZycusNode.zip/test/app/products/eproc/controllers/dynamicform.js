"use strict";
/**
 * Dynamic Form Controller
 *
 * @description :: Provides Dynamic Form related operations
 */

module.exports = (parentClass)=> {
  class DynamicForm extends parentClass {

      update(request, input, callback) {
        try {
            let validationUtility = super.utils.validationUtility(request);
            const schema = {
              "dynamicFormId": "joi.string().required().label('eproc-lable-79__')",
              "processCode": "joi.string().required().label('eproc-lable-80__')",
              "type": "joi.number().integer().required().label('eproc-lable-81__')",
              "formInstance": "joi.object().keys({formInstanceId:joi.string().required().label('eproc-lable-85__'),formDefinitionId:joi.string().required().label('eproc-lable-86__'),sectionInstances:joi.array().items(joi.object().keys({sectionInstanceId:joi.string().label('eproc-lable-88__'),sectionDefinitionId:joi.string().label('eproc-lable-89__'),fieldInstances:joi.array().items(joi.object().keys({fieldInstanceId:joi.string().label('eproc-lable-91__'),fieldDefinitionId:joi.string().label('eproc-lable-92__'),value:joi.array().label('eproc-lable-19__'),referenceValue:joi.array().label('eproc-lable-93__')})).label('eproc-lable-90__')})).required().label('eproc-lable-87__')}).required().label('eproc-lable-82__')",
              "extraParams": "joi.object().required().label('eproc-lable-83__')",
              "dynamicInstanceId": "joi.string().allow('').required().label('eproc-lable-84__')"
            };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, {"dynamicFormId": request.params.dynamicform_Id}));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
              const eProcURL = request.productsURL.eProc["soa"],
              url = eProcURL + '/dynamicForm/dynamicInstance/update',
              http =  new (super.httpService)(request),
              requestData = super.lodash.merge(request.body, {"dynamicFormId": request.params.dynamicform_Id});
              
              http.post(url, 'updateDynamicForm', requestData, (error, result) => {
                  if(error){
                      return callback(error, null);
                  }else if(result){
                    const message = {description: "eproc-msg-17"};
                    if(!super.lodash.isEmpty(result.data.id)){
                        result.message = [message];              
                    }
                    let responseSchema = {"type":"object","properties":{"id":{"type":"string"},"modifiedOn":{"type":"none"},"modifiedBy":{"type":"string"},"info1":{"type":"string"},"info2":{"type":"string"}}};
                    const output = (new (super.responseHandler)(request, result, responseSchema));
                    return callback(null, request, output.execute());                    
                  }
              });
            }
        }
        catch (error) {
          callback(error, null);
        }
      };

        /**
        * @Name : getForm
        * @Description : It is used to get the Dynamicform Instance
        * @return : object / Throw Error
        */    
        getForm(request, input, callback) {
            try {                
                const validationUtility = super.utils.validationUtility(request), 
                schema = {
                    "dynamicFormId": "joi.string().required().label('eproc-lable-51__')",
                    "dynamicInstanceId": "joi.string().allow('').label('eproc-lable-52__')"
                };
                validationUtility.addInternalSchema(schema); 
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const http =  new (super.httpService)(request),
                          eProcURL = request.productsURL.eProc["soa"],
                          url = eProcURL+'/dynamicForm/instance';
                    http.post(url, 'getDynamicForm', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else{                        
                            const responseSchema = {"type":"object","properties":{"dynamicInstance":{"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"dynamicInstanceId":{"type":"string"},"dynamicFormId":{"type":"string"},"formInstance":{"type":"object","properties":{"formInstanceId":{"type":"string"},"formDefinitionId":{"type":"string"},"sectionInstances":{"type":"array","properties":{"sectionInstanceId":{"type":"string"},"sectionDefinitionId":{"type":"string"},"fieldInstances":{"type":"array","properties":{"fieldInstanceId":{"type":"string"},"fieldDefinitionId":{"type":"string"},"value":{"type":"array"},"referenceValue":{"type":"array"}}}}}}}}},"dynamicForm":{"type":"object","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"string"},"createdOn":{"type":"none"},"dynamicFormId":{"type":"string"},"name":{"type":"string"},"processCode":{"type":"string"},"formDefinition":{"type":"object","properties":{"formDefinitionId":{"type":"string"},"sectionDefinitions":{"type":"array","properties":{"sectionDefinitionId":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"display":{"type":"boolean"},"tableLayout":{"type":"object","properties":{"columnCount":{"type":"number"},"tableRows":{"type":"array","properties":{"colSpan":{"type":"number"},"tableCells":{"type":"array","properties":{"fieldDefinitionId":{"type":"string"}}}}}}},"fieldDefinitions":{"type":"array","properties":{"fieldDefinitionId":{"type":"string"},"fieldKey":{"type":"string"},"fieldType":{"type":"string"},"name":{"type":"string"},"info":{"type":"string"},"required":{"type":"boolean"},"display":{"type":"boolean"},"defaults":{"type":"array"},"options":{"type":"object"},"fieldProperties":{"type":"object","properties":{"MAX_CHAR":{"type":"number"},"SPACE_ALLOWED":{"type":"boolean"},"SPECIAL_CHAR_ALLOWED":{"type":"boolean"}}},"uiProperties":{"type":"object","properties":{"SPAN_ACROSS":{"type":"boolean"}}}}}}}}}}}}},
                                  output =  (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                           
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };     
  }

  return DynamicForm;
};