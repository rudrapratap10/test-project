/**
 * Buyer Controller
 *
 * @description :: Provides user and userGroup related search operation.
 */

module.exports = (parentClass)=> {
    
        class Buyer extends parentClass {          
    
            assignBuyers(request, input, callback) {
                try {
                    const validationUtility = super.utils.validationUtility(request);
                    const schema = {
                        "name": "joi.string().label('eproc-lable-4__')"
                    };
                    validationUtility.addInternalSchema(schema);
                    validationUtility.addCommonSchema('pagination');
                    const result = validationUtility.validate(request.body);
                    if (result) {
                        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                        return callback(errorMsg, null);
                    } else {
                        const displayName = request.user.displayName;
                        const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
                            paginate = super.utils.formPaginateRequest(request.body),
                            tmsURL = request.productsURL.eProc["web"];
                
                        const url = tmsURL + 
                        '?responseType=json&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                        '&scopeName=eProcjQuery' +
                        '&userId=' + super.utils.encodeURI(request.user.userId) + 
                        '&userName=' + super.utils.encodeURI(displayName) +		 
                        '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                        '&emailAddress='+ super.utils.encodeURI(request.user.emailId) + 
                        '&method=master.authority.user.searchUsers' +
                        '&sortColumn=SORT_BY_DISPLAY_NAME' +
                        '&ascending=1' +
                        '&column1=SEARCH_BY_NAME_OR_EMAIL' +
                        '&value1='+ (super.utils.encodeURI(request.body.name || '')) +
                        '&column2=SEARCH_BY_ACTIVE' +
                        '&value2=true' +
                        '&column3=SEARCH_IN_TMS' +
                        '&value3=false' +
                        '&column4=REQUIRE_PREFERENCES' +
                        '&value4=false' +
                        '&column5=SEARCH_IN_ACTIVITIES' +
                        '&value5=Show+%26+reassign+all+requests+in+scope' +
                        '&value5=Show+all+requests+in+scope' +
                        '&value5=Access+Buyers+Desk' +
                        '&column6=SEARCH_BY_LOCATION_CONFIGURED' +
                        '&value6=true' +
                        '&startIndex=' + (super.utils.encodeURI(paginate.pageNo -1)) +
                        '&noOfRecords=' + super.utils.encodeURI(paginate.perPageRecords) +
                        '&mode=2' +
                        '&requireUserDefault=1'; 
                        http.get(url, 'searchUsers', (error, response) => {
                            if(error){
                                callback(error, null);
                            }else if(response){
                                let responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"userId":{"type":"string"},"emailId":{"type":"string"},"displayName":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"active":{"type":"boolean"},"tenantId":{"type":"string"}}}}};
                                const output = (new (super.responseHandler)(request, response, responseSchema));
                                output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());                 
                            }
                        });
                    }
                } catch (error) {
                callback(error, null);
                }
            };

            assignBuyerGroups(request, input, callback) {
                try {
                    const validationUtility = super.utils.validationUtility(request);
                    const schema = {
                        "name": "joi.string().label('eproc-lable-4__')"
                    };
                    validationUtility.addInternalSchema(schema);
                    validationUtility.addCommonSchema('pagination');
                    const result = validationUtility.validate(request.body);
                    if (result) {
                        const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                        return callback(errorMsg, null);
                    } else {
                        const displayName = request.user.displayName;
                        const http = new (super.httpTmsService)(request, null, super.appConstant.resHandler.tmsSearch),
                            paginate = super.utils.formPaginateRequest(request.body),
                            tmsURL = request.productsURL.eProc["web"];
                
                        const url = tmsURL + 
                        '?responseType=json&tenantId=' + super.utils.encodeURI(request.user.tenantId) +
                        '&scopeName=eProcjQuery' +
                        '&userId=' + super.utils.encodeURI(request.user.userId) + 
                        '&userName=' + super.utils.encodeURI(displayName) +		 
                        '&tokenId=' + super.utils.encodeURI(request.tokenId) +
                        '&emailAddress='+ super.utils.encodeURI(request.user.emailId) + 
                        '&method=master.authority.user.searchUserGroups' +
                        '&sortColumn=SORT_BY_DISPLAY_NAME' +
                        '&ascending=1' +
                        '&column1=SEARCH_BY_NAME_OR_EMAIL' +
                        '&value1='+ (super.utils.encodeURI(request.body.name || '')) +
                        '&column2=SEARCH_BY_ACTIVE' +
                        '&value2=true' +
                        '&column3=SEARCH_IN_TMS' +
                        '&value3=false' +
                        '&column4=REQUIRE_PREFERENCES' +
                        '&value4=false' +
                        '&startIndex=' + (super.utils.encodeURI(paginate.pageNo -1)) +
                        '&noOfRecords=' + super.utils.encodeURI(paginate.perPageRecords) +
                        '&mode=2' +
                        '&requireUserDefault=1'; 
                        http.get(url, 'searchUserGroups', (error, response) => {
                            if(error){
                                callback(error, null);
                            }else{
                                const responseSchema = {"type":"object","properties":{"result":{"type":"array","key":"records","properties":{"id":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"active":{"type":"boolean"},"users":{"type":"array","properties":{"userId":{"type":"string"},"emailId":{"type":"string"},"displayName":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"tenantId":{"type":"string"}}},"count":{"type":"number"},"creationDate":{"type":"none"}}}}};
                                const output = (new (super.responseHandler)(request, response, responseSchema));
                                output.addCommonSchema('cmd-pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());                    
                            }
                        });
                    }
                } catch (error) {
                callback(error, null);
                }
            };
        }

    return Buyer;    
};
    