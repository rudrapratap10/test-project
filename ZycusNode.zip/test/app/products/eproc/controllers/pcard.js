"use strict";
module.exports = (parentClass) => {
    class Pcard extends parentClass {
        /*getCardTypes(request, input, callback) {
            try {
                const http =  new (super.httpService)(request);
                const eProcURL = request.productsURL.eProc["soa"];
                let url = eProcURL+'/pcard/getCardTypes';
                http.get(url, 'getCardTypes', (error, result) => {
                    if(error){
                        callback(error, null);
                    }else if(result){
                        callback(null, request, { "data": super.utils.formatResponse(result)});
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }*/

        /**
        * @Method Name : getpCards
        *
        * @Description : Get pCard List
        * @return object / Throw Error
        */
        getpCards(request, input, callback) {
            try {
                const eprocHook = new (super.eprocHook({request: request}))();
                eprocHook.getUserScope(request, input, (error, request, response) => { // Calling method from hook tms to get UserScope data
                    if (error) {
                        return callback(error, null);
                    } else if (response) {
                        const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.filter);
                        const eProcURL = request.productsURL.eProc["soa"];
                        const requestData = {
                            "requestUserId": request.user.userId,
                            "companyCode": response.data.companyCode,
                            "businessUnitCode": response.data.businessUnitCode,
                            "locationCode": response.data.locationCode
                        };
                        const url = eProcURL + '/pCard/allowedPCards';
                        http.post(url, 'getpCards', requestData, (error, result) => {
                            if (error) {
                                callback(error, null);
                            } else if (result) {
                                const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "bankAccountNumber": { "type": "string" }, "modifiedOn": { "type": "none" }, "pCardId": { "type": "string" }, "type": { "type": "string" }, "cardNumber": { "type": "string" }, "bankName": { "type": "string" }, "currency": { "type": "string" }, "expiryDate": { "type": "none" },"totalSpendAmount": { "type": "number" },"transactionsPerCycle": { "type": "number" },"transactionsPerDay": { "type": "number" } } } } };
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }
                        });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : pCardStats
        *
        * @Description : Validate the Pcard balance
        * @return object / Throw Error
        */

        pCardStats(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "requestUserId": "joi.string().required().label('eproc-lable-365__')",
                    "pcardId": "joi.string().required().label('eproc-lable-366__')",
                    "roleType": "joi.string().required().label('eproc-lable-367__')",
                    "currency": "joi.string().required().label('eproc-lable-48__')",
                    "amount": "joi.number().label('eproc-lable-370__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                    eProcURL = request.productsURL.eProc["soa"],
                    url = eProcURL + '/pCard/pCardStats';
                    http.post(url, 'validatePCard', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"pCardStats":{"type":"object","properties":{"validationErrors":{"type":"object","properties":{"errors":{ "type": "none" },"error":{ "type": "boolean" }}},"cycleStat":{ "type": "object","properties":{"noOfTransactions":{"type":"number"},"totalAmount":{"type":"number"}} }}}}},
                            output =  (new (super.responseHandler)(request, result, responseSchema));                              
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Method Name : allowedList
        *
        * @Description : Search allowed pCards List
        * @return object / Throw Error
        */
        allowedList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "requestUserId": "joi.string().required().label('eproc-lable-365__')",
                    "companyCode": "joi.string().required().label('eproc-lable-56__')",
                    "businessUnitCode": "joi.string().required().label('eproc-lable-29__')",
                    "locationCode": "joi.string().required().label('eproc-lable-58__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const eprocHook = new (super.eprocHook({request: request}))();
                    eprocHook.getUserScope(request, input, (error, request, response) => { // get the UserScope data form TMS
                        if (error) {
                            return callback(error, null);
                        } else {
                            const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.filter),
                            eProcURL = request.productsURL.eProc["soa"],
                            url = eProcURL + '/pCard/allowedPCards';
                            http.post(url, 'getpCards', request.body, (error, result) => {
                                if (error) {
                                    callback(error, null);
                                } else {
                                    const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "bankAccountNumber": { "type": "string" }, "modifiedOn": { "type": "none" }, "pCardId": { "type": "string" }, "type": { "type": "string" }, "cardNumber": { "type": "string" }, "bankName": { "type": "string" }, "currency": { "type": "string" }, "expiryDate": { "type": "none" },"totalSpendAmount": { "type": "number" },"transactionsPerCycle": { "type": "number" },"transactionsPerDay": { "type": "number" } } } } };
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        }
    };

    return Pcard;

};