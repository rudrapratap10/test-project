/**
* contact Controller
*
* @description :: Provides Contact related crud operations
*/

"use strict";
module.exports = (parentClass) => {
    class Contact extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the procurementTeam list
        * @return : object
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                          iRequestURL = request.productsURL.iRequest,
                          url = iRequestURL + '/procurementTeam/filter';

                    http.post(url, 'procurementTeamList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"emailAddress":{"type":"string"},"userRoles":{"type":"string"},"actorType":{"type":"string"}}},"createdOn":{"type":"none"},"teamName":{"type":"string"},"modifiedBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"emailAddress":{"type":"string"},"userRoles":{"type":"string"},"actorType":{"type":"string"}}},"modifiedOn":{"type":"none"},"status":{"type":"number"},"contactId":{"type":"string"},"contactImage":{"type":"object","properties":{"tenantId":{"type":"string"},"createdDate":{"type":"none"},"createdById":{"type":"string"},"updatedDate":{"type":"none"},"attachmentId":{"type":"string"},"name":{"type":"string"},"path":{"type":"filePathEncode"}},"key":"image"},"contactNumber":{"type":"string"},"emailId":{"type":"string"},"extension":{"type":"string"},"firstName":{"type":"string"},"deleted":{"type":"boolean"},"lastName":{"type":"string"},"tenantId":{"type":"string"},"title":{"type":"string"},"statusText":{"type":"i18n"}}}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    };
        
    return Contact;
}
