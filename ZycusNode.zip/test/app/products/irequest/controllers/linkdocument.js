/**
 * Linkdocument Controller
 *
 * @description :: Provides to get the linked document
 */

module.exports = (parentClass) => {

    class LinkDocument extends parentClass {

        /**
        * @Name : getDetails
        * @Description : It is used to get the linked document
        * @return : object
        */    
        getDetails(request, input, callback) {
            try {         
                const validationUtility = super.utils.validationUtility(request),
                      schema = {
                        "requestId": "joi.string().allow('').label('irequest-lable-20__')",
                        "activity": "joi.string().allow('').label('irequest-lable-55__')",
                     };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const http =  new (super.httpService)(request),
                          iRequestURL = request.productsURL.iRequest,
                          url = iRequestURL + '/request/linkedDocument';
                    http.post(url, 'getlinkedDocList', request.body, (error, result) => {
                        if(error) {
                            return callback(error, null);
                        }else if(result) {
                             const responseSchema = { "type": "object", "properties": { "dynamicForm": { "type": "string" }, "dynamicInstance": { "type": "string" } } },
                                   output =  (new (super.responseHandler)(request, result, responseSchema));                       
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return LinkDocument;
};