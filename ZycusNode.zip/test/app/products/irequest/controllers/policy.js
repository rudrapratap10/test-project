/**
* Policy Controller
*
* @description :: Provides Policy related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Policy extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the Policy requests list
        * @return : object
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                         iRequestURL = request.productsURL.iRequest,
                         url = iRequestURL + '/policy/filter';
                    http.post(url, 'getPoliciesList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"},"emailAddress":{"type":"string"}}},"createdOn":{"type":"none"},"modifiedBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"},"emailAddress":{"type":"string"}}},"modifiedOn":{"type":"none"},"status":{"type":"number"},"description":{"type":"string"},"policyType":{"type":"object","properties":{"deleted":{"type":"boolean"},"name":{"type":"string"},"policytypeId":{"type":"string"},"createdBy":{"type":"string"}}},"attachments":{"type":"array","properties":{"attachmentId":{"type":"string"},"createdBy":{"type":"string"},"createdById":{"type":"string"},"createdDate":{"type":"none"},"name":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"},"updatedDate":{"type":"none"}}},"name":{"type":"string"},"policyId":{"type":"string"},"deleted":{"type":"boolean"},"statusText":{"type":"i18n"}}}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name : getTypes
        * @Description : It is used to get the Policy Type list
        * @return : object
        */
        getTypes(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                         iRequestURL = request.productsURL.iRequest,
                         url = iRequestURL + '/policy/type/filter';
                    http.post(url, 'getPolicyTypeList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"name":{"type":"string"},"policyTypeId":{"type":"string"},"deleted":{"type":"boolean"},"tenantId":{"type":"string"},"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"actorType":{"type":"string"},"userRoles":{"type":"none"},"emailAddress":{"type":"string"}}}}}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

         /**
        * @Name : getPolicyWithTypes
        * @Description : It is used to get the policy list with policyTypes
        * @return : array
        */
        getPolicyWithTypes(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                         iRequestURL = request.productsURL.iRequest,
                         url = iRequestURL + '/policy/policytypewithpolicy/filter';
                    http.post(url, 'getPoliciesList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result) {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"deleted":{"type":"string"},"name":{"type":"string"},"policyTypeId":{"type":"string"},"tenantId":{"type":"string"},"createdBy":{"type":"none"},"createdOn":{"type":"none"},"userId":{"type":"string"},"policies":{"type":"array","properties":{"createdOn":{"type":"none"},"modifiedBy":{"type":"string"},"modifiedOn":{"type":"none"},"createdById":{"type":"string"},"status":{"type":"number"},"userId":{"type":"string"},"createdBy":{"type":"string"},"description":{"type":"string"},"policyType":{"type":"none"},"deleted":{"type":"boolean"},"name":{"type":"string"},"policyId":{"type":"string"},"tenantId":{"type":"string"},"attachments":{"type":"array","properties":{}},"statusText":{"type":"i18n"}}}}}}},
                                  output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
							output.addCommonSchema('attachments', output.responseSchema.properties.records.properties.policies.properties.attachments.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    };

    return Policy;
};
