/**
 * Banner Controller
 *
 * @description :: Provides Banner related curd operations
 */

module.exports = (parentClass) => {

    class Banner extends parentClass {

        /**
        * @Name : getList
        * @Description : It is used to get the Banner list
        * @return : array
        */    
        getList(request, input, callback) {
            try {                
                const validationUtility = super.utils.validationUtility(request); 
                validationUtility.addCommonSchema('pagination'); 
                validationUtility.addCommonSchema('sort');              
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{
                    const http =  new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    iRequestURL = request.productsURL.iRequest,
                    url = iRequestURL + '/banner/filter';
                    http.post(url, 'getBannerList', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else if(result) {
                            let responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"createdBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"emailAddress":{"type":"string"},"userRoles":{"type":"string"},"actorType":{"type":"string"}}},"createdOn":{"type":"none"},"modifiedBy":{"type":"object","properties":{"tenantId":{"type":"string"},"userId":{"type":"string"},"userDisplayName":{"type":"string"},"active":{"type":"boolean"},"emailAddress":{"type":"string"},"userRoles":{"type":"string"},"actorType":{"type":"string"}}},"modifiedOn":{"type":"none"},"status":{"type":"number"},"bannerId":{"type":"string"},"image":{"type":"object","properties":{"tenantId":{"type":"string"},"createdDate":{"type":"none"},"createdById":{"type":"string"},"updatedDate":{"type":"none"},"createdBy":{"type":"string"},"attachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"}}},"deleted":{"type":"boolean"},"link":{"type":"string"},"mobileImage":{"type":"object","properties":{"tenantId":{"type":"string"},"createdDate":{"type":"none"},"createdById":{"type":"string"},"updatedDate":{"type":"none"},"createdBy":{"type":"string"},"attachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"}}},"tenantId":{"type":"string"},"title":{"type":"string"},"statusText":{"type":"i18n"}}}}};
                            let output =  (new (super.responseHandler)(request, result, responseSchema)); 
                            output.addCommonSchema('pagination', output.responseSchema.properties);                          
                            return callback(null, request, output.execute());                            
                        }
                    });
                }                
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return Banner;
};