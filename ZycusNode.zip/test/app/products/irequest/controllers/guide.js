/**
* Guide Controller
*
* @description :: Provides Guide Me related curd operations
*/

"use strict";
module.exports = (parentClass) => {
    class Guide extends parentClass {

        /**
        * @Name : getGuideDetails
        * @Description : It is used to get the Guide Me details
        * @return : object
        */
       getGuideDetails(request, input, callback) {
            try {                
                const http = new (super.httpService)(request),
                    iRequestURL = request.productsURL.iRequest,
                    url = iRequestURL + '/guideMe';
                http.get(url, 'getGuideDetails', (error, result) => {
                    if (error) {
                        callback(error, null);
                    } else {
                        return callback(null, request, result);
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        }


        /**
        * @Name : getGuideNext
        * @Description : It is used to get the Guide Me Next Question details and submit current answer
        * @return : object
        */
        getGuideNext(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                const schema = {
                    "optionCode" : "joi.string().required().label('irequest-lable-61__')",
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if(result){
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }else{     
                    const http = new (super.httpService)(request),
                        iRequestURL = request.productsURL.iRequest,
                        url = iRequestURL + '/guideMe';
                    http.post(url, 'getGuideNext', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            let responseSchema = {"type":"object","properties":{"scoreId":{"type":"string"},"formId":{"type":"string"}}};
                            let output =  (new (super.responseHandler)(request, result, responseSchema));    
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }
		
    };
    return Guide;
};