/**
 * Report Controller
 *
 * @description :: Provides Report related curd operations
 */

module.exports = (parentClass) => {

    class Report extends parentClass {

         /**
        * @Name : createIssue
        * @Description : It is used to report an issue
        * @return : object
        */
        createIssue(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                    "module": "joi.string().required().label('irequest-lable-28__')",
                    "subject": "joi.string().max(100).required().label('irequest-lable-29__')",
                    "messageType": "joi.string().required().label('irequest-lable-30__')",
                    "priority": "joi.string().required().label('irequest-lable-31__')",
                    "message": "joi.string().max(5000).required().label('irequest-lable-32__')",
                    "browser": "joi.object({ currentUrl: joi.string().required().label('irequest-lable-33__'),name: joi.string().required().label('irequest-lable-35') , version: joi.string().required().label('irequest-lable-36__'),agent: joi.string().required().label('irequest-lable-37__') , screenResolution: joi.string().required().label('irequest-lable-38__'), flashVersion: joi.string().allow('').label('irequest-lable-39__') }).required().label('irequest-lable-40__')",
                    "attachments": "joi.array().items({id: joi.string().label('irequest-lable-41__'), name: joi.string().required().label('irequest-lable-42__'), path: joi.string().required().label('irequest-lable-43__'), size: joi.number().label('irequest-lable-44__'), type: joi.string().label('irequest-lable-45__')}).min(1).unique().label('irequest-lable-46__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const irequestHook = new (super.iRequestHook({request: request}))(),
                          attachments = request.body.attachments;
                    super.async.waterfall
                    (
                        [
                            (callback) => {
                                //Step 1: Get Email Settings                             
                                irequestHook.getEmailConfig(request, null, (error, request, result) => {
                                    if (error) {
                                        return callback(error, null);
                                    }
                                    else {
                                        const address = result.data,
                                            templateLabel = {
                                                "hi": super.utils.translate(request, "irequest-email-label-1"),
                                                "irequestModule": super.utils.translate(request, "irequest-email-label-2"),
                                                "hasIssue": super.utils.translate(request, "irequest-email-label-3"),
                                                "issueDescription": super.utils.translate(request, "irequest-email-label-4"),
                                                "userSysInfo": super.utils.translate(request, "irequest-email-label-5"),
                                                "pageUrl": super.utils.translate(request, "irequest-email-label-6"),
                                                "browser": super.utils.translate(request, "irequest-email-label-7"),
                                                "screenResolution": super.utils.translate(request, "irequest-email-label-8"),
                                                "flashPlayer": super.utils.translate(request, "irequest-email-label-9"),
                                                "sysGenratedMail": super.utils.translate(request, "irequest-email-label-10")
                                            },
                                            options = {
                                                from: address.from,
                                                to: address.to,
                                                cc: (address.ccUser ? address.ccUser.split(',') : []),
                                                subject: request.productName + ' - ' + request.body.messageType + ' - ' + request.body.subject + ' -  ' + request.body.priority + ' ' +  super.utils.translate(request, "irequest-email-label-11"),
                                                //https://nodemailer.com/message/attachments/
                                                attachments: [],
                                                context: {
                                                    templateLabel: templateLabel,
                                                    module: request.body.module,
                                                    message: request.body.message,
                                                    browser: request.body.browser || {}
                                                },
                                                body: "ticket_notification"
                                            };
                                        return callback(null, request, options);
                                    }
                                });
                            },
                            (request, input, callback) => {
                                //Step 2 : If attachments available download it                               
                                if (!super.lodash.isEmpty(attachments)) {
                                    let count = 0;
                                    const errors = [],
                                        output = [],
                                        sftp = new(require('@provider/sftp'))(request.productName);
                                    //Download each attachments as file stream                                          
                                    attachments.forEach((item) => {
                                        const path = super.utils.getFilePath(request, item.path);
                                        sftp.get(path, (error, fileStream) => {
                                            count++;
                                            error ? errors.push(error) : output.push({
                                                filename: item.name,
                                                content: super.utils.createBufferData(fileStream)
                                            });

                                            if (count === attachments.length) {
                                                input.attachments = output;
                                                return (errors.length > 0) ? callback(errors, null): callback(null, request, input);
                                            }
                                        });
                                    });
                                }
                                else{
                                    callback(null, request, input);
                                }
                            }                         
                        ],
                        (error, request, response) => { 
                            if (error) {
                                return callback(error, null);
                            }
                            //Step 3 : Make Email Service call to send email
                            const emailService = new (super.emailService)({ productName: request.productName, type: "template" });                         
                            emailService.sendMail(response, (err, result) => {
                                //Setp 4 : Send resposne back to client
                                if (err) {
                                    return callback(err, null);
                                }
                                else {       
                                    //Step 5: In background(async), remove all the attachments
                                    if(!super.lodash.isEmpty(attachments)){
                                        attachments.forEach((item)=> {
                                            irequestHook.deleteAttachment(request, {"attachmentId" : item.id}, ()=>{});
                                        });          
                                    }                                         
                                    return callback(null, request, { data: result, message: "irequest-msg-4" });
                                }
                            });
                        }
                    );
                }
            } catch (error) {
                callback(error, null);
            }
        };        

    };
    return Report;
};