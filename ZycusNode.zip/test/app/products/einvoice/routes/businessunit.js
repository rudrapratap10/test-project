"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/businessUnits/allowedList:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the filtered business unit list
    *     operationId: businessUnitList
    *     description: Get the filtered business unit list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the business unit list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   allowedList: {
        pre: null,
        process: "businessunit.allowedList",
        post: null,
        method: 'POST'
    }

}