"use strict";

module.exports = {
    
    /**
    * @swagger
    * /a/einvoice/reports/generateAPReport:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Generate AP Report Details
    *     operationId: generateAPReport
    *     description:  Generate AP Report Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Generate AP Report Details
    *         type: string
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             criteriaBasedOn:
    *               type: string
    *             fromDate:
    *               type: string
    *             toDate:
    *               type: string
    *             lastMonths:
    *               type: string
    *             lastYears:
    *               type: string
    *           required: [criteriaBasedOn, fromDate, toDate, lastMonths, lastYears]
    *     responses:
    *       200:
    *         description: successful operation
    */
    generateAPReport: {
        pre: null,
        process: "report.generateAPReport",
        post: null,
        method: 'POST'
    },

        /**
    * @swagger
    * /a/einvoice/reports/{noOfEntries}/getDetails:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get Report Details based on No. of Entries
    *     operationId: getReportDetails
    *     description:  Get Report Details based on No. of Entries
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: noOfEntries
    *         description: Fetch Report Details based on No. of Entries.
    *         in: path
    *         required: true
    *         type: number
    *     responses:
    *       200:
    *         description: successful operation
    */
   getDetails: {
    pre: null,
    process: "report.getDetails",
    post: null,
    method: 'GET'
}
}