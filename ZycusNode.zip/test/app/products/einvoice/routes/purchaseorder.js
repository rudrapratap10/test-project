module.exports = {
  /**
    * @swagger
    * /a/einvoice/purchaseOrders/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the purchaseOrder list
    *     operationId: purchaseorderList
    *     description: Get the purchaseOrder list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the purchaseOrder list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
   getList: {
    pre: null,
    process: "purchaseorder.getList",
    post: null,
    method: 'POST'
},
   /**
   * @swagger
   * /a/einvoice/purchaseOrders/{purchaseOrder_Id}:
   *   get:
   *     tags:
   *       - eInvoice API
   *     summary: Get details of purchase order
   *     operationId: getPurchaseOrderDetails
   *     description:  Get details of purchase order
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: purchaseOrder_Id
   *         description: Get details of purchase order
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */
  getDetails:{
    pre: null,
    process: "purchaseorder.getDetails",
    post: null,
    method: 'GET'
  },
     /**
   * @swagger
   * /a/einvoice/purchaseOrders/{purchaseOrder_Id}/allAttachments:
   *   get:
   *     tags:
   *       - eInvoice API
   *     summary: Get getAllAttachments details by purchase order id
   *     operationId: getAllAttachmentsbyPOId
   *     description:  Get getAllAttachments details by purchase order id
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: purchaseOrder_Id
   *         description: Get getAllAttachments details by purchase order id
   *         in: path
   *         required: true
   *         type: string
   *     responses:
   *       200:
   *         description: successful operation
   */
  allAttachments:{
    pre: null,
    process: "purchaseorder.allAttachments",
    post: null,
    method: 'GET'
  }
}