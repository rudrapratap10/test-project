"use strict";
module.exports = {
  /**
 * @swagger
 * definitions:
 *   eInvoiceUserRole:
 *     properties:
 *       userRole:
 *         type: string
 *     required: [userRole]
 */

  /**
    * @swagger
    * /a/einvoice/users/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the buyer/requestor list
    *     operationId: buyer/requestorList
    *     description: Get the buyer/requestor list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the buyer/requestor list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/eInvoiceUserRole'
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
  getList: {
    pre: null,
    process: "user.getList",
    post: null,
    method: 'POST'
  },

  /**
    * @swagger
    * /a/einvoice/users/scopeList:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get User Scopes list
    *     operationId: UserScopesList
    *     description: Get User Scopes list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the User Scope list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    scopeList: {
      pre: null,
      process: "user.scopeList",
      post: null,
      method: 'POST'
    },
    /**
    * @swagger
    * /a/einvoice/users/updateConfig:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update User Config Details
    *     operationId: UpdateUserConfigDetails
    *     description: Update User Config Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch/Update the User Config Details.
    *         in: body
    *         schema:
    *           type: object
    *           properties:
    *             EPROC_APPROVAL_DELEGATION:
    *               type: object
    *               properties:
    *                 FROM_DATE: 
    *                     type: string
    *                 TO_DATE:
    *                     type: string
    *                 USER_ID:
    *                     type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateConfig: {
      pre: null,
      process: "user.updateConfig",
      post: null,
      method: 'PUT'
    },

    /**
    * @swagger
    * /a/einvoice/users/getConfig:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get User Config Details
    *     operationId: UserConfigDetails
    *     description: Get User Config Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the User Config Details based on keys.
    *         in: body
    *         schema:
    *             properties:
    *               configkeys:
    *                 type: array
    *                 items:
    *                     type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
   getConfig: {
    pre: null,
    process: "user.getConfig",
    post: null,
    method: 'POST'
  }

}