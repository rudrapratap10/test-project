module.exports = {    
    /**
    * @swagger
    * /a/einvoice/contracts/{contract_Id}:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get Contract Details
    *     operationId: getContractDetails
    *     description:  Get Contract Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Get Contract Details
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails:{
        pre: null,
        process: "contract.getDetails",
        post: null,
        method: 'GET'
    }
}