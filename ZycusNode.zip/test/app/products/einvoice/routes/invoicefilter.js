"use strict";

module.exports = {

    /**
     * @swagger
     * definitions:
     *   invoicefilter:
     *     properties:
     *       pageName:
     *         type: string
     *       filterName:
     *          type: string
     *       isDefault:
     *         type: boolean
     *       advancedFilters:
     *          type: string
     *       filters:
     *         type: string
     *       sortColumn:
     *          type: number
     *       sortType:
     *         type: string
     *       displayRecords:
     *          type: number
     *     required: [pageName, filterName]
    */

    /**
   * @swagger
   * /a/einvoice/invoiceFilters:
   *   post:
   *     tags:
   *       - eInvoice API
   *     summary: Create the invoice filter view
   *     operationId: createInvoiceFilterView
   *     description: Create the invoice filter view
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: body
   *         description: Create the invoice filter view
   *         type: string
   *         in: body
   *         schema: 
   *           $ref: '#/definitions/invoicefilter'
   *     responses:
   *       200:
   *         description: successful operation
   */
    create: {
        pre: null,
        process: "invoicefilter.create",
        post: null,
        method: 'POST'
    },

    /**
  * @swagger
  * /a/einvoice/invoiceFilters/{invoiceFilter_Id}:
  *   put:
  *     tags:
  *       - eInvoice API
  *     summary: Update the invoice filter view
  *     operationId: updateInvoiceFilterView
  *     description: Update the invoice filter view
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoiceFilter_Id
  *         description: Update the invoice filter view
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         type: string
  *         in: body
  *         schema: 
  *           $ref: '#/definitions/invoicefilter'
  *     responses:
  *       200:
  *         description: successful operation
  */
    update: {
        pre: null,
        process: "invoicefilter.update",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/einvoice/invoiceFilters/{invoiceFilter_Id}:
    *   delete:
    *     tags:
    *       - eInvoice API
    *     summary: Delete the invoice filter view
    *     operationId: deleteInvoiceFilterView
    *     description: Delete the invoice filter view
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: invoiceFilter_Id
    *         description: Delete the invoice filter view
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "invoicefilter.destroy",
        post: null,
        method: 'DELETE'
    },

    /**
   * @swagger
   * /a/einvoice/invoiceFilters/getList:
   *   post:
   *     tags:
   *       - eInvoice API
   *     summary: Get all the invoice filter view
   *     operationId: invoiceList
   *     description: Get all the invoice filter view
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *         description: successful operation
   *     parameters:
   *       - name: body
   *         description: Create the invoice filter view
   *         type: string
   *         in: body
   *         schema: 
   *             properties:
   *               pageName:
   *                 type: string
   *             required: [pageName]
   */
    getList: {
        pre: null,
        process: "invoicefilter.getList",
        post: null,
        method: 'POST'
    },

   /**
   * @swagger
   * /a/einvoice/invoiceFilters/{invoiceFilter_Id}:
   *   get:
   *     tags:
   *       - eInvoice API
   *     summary: Get details of invoice filter view
   *     operationId: getInvoiceFilterViewDetails
   *     description:  Get details of invoice filter view
   *     produces:
   *       - application/json
   *     parameters:
   *       - name: invoiceFilter_Id
   *         description: Get details of invoice filter view
   *         in: path
   *         required: true
   *         type: integer
   *     responses:
   *       200:
   *         description: successful operation
   */

  getDetails:{
    pre: null,
    process: "invoicefilter.getDetails",
    post: null,
    method: 'GET'
  }
}