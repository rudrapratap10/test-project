"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/categories/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the categories list
    *     operationId: categoriesList
    *     description: Get the categories list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the categories (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "category.getList",
        post: null,
        method: 'POST'
    }
}