"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/suppliers/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the filtered supplier list
    *     operationId: supplierList
    *     description: Get the filtered supplier list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the suppliers list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "supplier.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/suppliers/paymentTerm:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get Supplier PaymentTerm Details
    *     operationId: Get Supplier PaymentTerm Details
    *     description: Get Supplier PaymentTerm Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: View Supplier Payment Term Details.
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               supplierId:
    *                 type: string
    *               locationCode:
    *                 type: string
    *             required: [supplierId, locationCode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    paymentTerm: {
        pre: null,
        process: "supplier.getPaymentTermDetails",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/suppliers/{supplier_Id}/addressDetails:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get Supplier Address Details
    *     operationId: getSupplierAddressDetails
    *     description:  Get Supplier Address Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: supplier_Id
    *         description: Get Supplier Address Details
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
    addressDetails: {
        pre: null,
        process: "supplier.getDetails",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/einvoice/suppliers/{supplier_Id}/getContactDetails:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Fetch/Get Supplier Contact Details
    *     operationId: getSupplierContact Details
    *     description: Fetch/Get Supplier Contact Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: supplier_Id
    *         description: Get Supplier Contact Details
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: View Supplier Contact Details
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               addressId:
    *                 type: string
    *               referConfig:
    *                 type: boolean
    *             required: [addressId, referConfig]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContactDetails: {
        pre: null,
        process: "supplier.getContactDetails",
        post: null,
        method: 'POST'
    },

    /**
   * @swagger
   * /a/einvoice/suppliers/accountGroups:
   *   get:
   *     tags:
   *       - eInvoice API
   *     summary: Get Supplier Account Groups
   *     operationId: get Supplier Account Groups
   *     description: Fetch all the Supplier Account Groups
   *     produces:
   *       - application/json
   *     responses:
   *       200:
   *         description: successful operation
   */
   accountGroups: {
        pre: null,
        process: "supplier.accountGroups",
        post: null,
        method: 'GET'
    },

        /**
    * @swagger
    * /a/einvoice/suppliers/{supplier_Id}/bankingDetails:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Get Supplier Banking Details
    *     operationId: getSupplierBankingDetails
    *     description:  get Supplier Banking Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: supplier_Id
    *         description: get Supplier Banking Details
    *         in: path
    *         required: true
    *         type: integer
    *     responses:
    *       200:
    *         description: successful operation
    */
   bankingDetails: {
    pre: null,
    process: "supplier.bankingDetails",
    post: null,
    method: 'GET'
}
    
}