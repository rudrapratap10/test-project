"use strict";

module.exports = {
    /**
    * @swagger
    * /a/einvoice/attachments/fileDownload/{filePath}:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Download Attachment File
    *     operationId: Download Attachment File
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    /**
    * @swagger
    * /a/einvoice/attachments/{filePath}/download:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: Download an Attachment File
    *     operationId: downloadAnAttachmentFile
    *     description: Download Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: filePath
    *         description: Provide the encoded file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

    download: {
        pre: null,
        process: "attachment.download",
        post: null,
        method: 'GET'
    },

     /**
    * @swagger
    * /a/einvoice/attachments:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Attach & Upload the files
    *     operationId: attachFiles
    *     consumes:
    *       - multipart/form-data
    *     parameters:
    *         - in: formData
    *           name: file
    *           type: file
    *           description: Attach & Upload the files to the SFTP server
    *           required: true
    *         - in: header
    *           name: modulename
    *           type: string
    *           required: true
    *     responses:
    *       200:
    *         description: successful operation
    */  

   create: {
    pre: null,
    process: "attachment.create",
    post: null,
    method: 'POST'
},


    /**
    * @swagger
    * /a/einvoice/attachments/{attachment_Id}:
    *   delete:
    *     tags:
    *       - eInvoice API
    *     summary: Delete Attachment File
    *     operationId: Delete Attachment File
    *     description: Delete Attachment File
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: attachment_Id
    *         description: Provide the file path.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */

   destroy: {
    pre: null,
    process: "attachment.destroy",
    post: null,
    method: 'DELETE'
},

    /**
    * @swagger
    * /a/einvoice/attachments/{attachment_Id}:
    *   get:
    *     tags:
    *       - eInvoice API
    *     summary: get Attachment Details based on attachment_Id
    *     operationId: Get Attachment Details
    *     description: Get Attachment Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: attachment_Id
    *         description: Provide the attachment ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "attachment.getDetails",
        post: null,
        method: 'GET'
    },

    /**
    * @swagger
    * /a/einvoice/attachments/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get attachment list
    *     operationId: attachmentList
    *     description: Get attachment list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Attachment (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "attachment.getList",
        post: null,
        method: 'POST'
    },

    /**
    * @swagger
    * /a/einvoice/attachments/{attachment_Id}:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update Attachment
    *     operationId: Update Attachment
    *     description: Update Attachment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: attachment_Id
    *         description: Provide the attachment ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update the attachment details based on below inputs
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             name:
    *               type: string
    *             displayName:
    *               type: string
    *             encoding:
    *               type: string
    *             fileSize:
    *               type: number
    *             type:
    *               type: number
    *             origin:
    *               type: number
    *             moduleName:
    *               type: string
    *             supplierId:
    *               type: string
    *             supplierName:
    *               type: string
    *           required: [attachmentId, displayName, moduleName]
    *     responses:
    *       200:
    *         description: successful operation
    */    
    update: {
        pre: null,
        process: "attachment.update",
        post: null,
        method: 'PUT'
    }
};