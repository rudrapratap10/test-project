"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/invoiceTemplate/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the invoice templates list
    *     operationId: invoiceTemplateList
    *     description: Get the invoice templates list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the invoice templates (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "invoicetemplate.getList",
        post: null,
        method: 'POST'
    },

    /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoicetemplate_Id}/callAction:
  *   put:
  *     tags:
  *       - eInvoice API
  *     summary: Update the Invoice template based on actionName
  *     operationId: updateInvoiceTemplateBasedOnAction
  *     description: Update the Invoice template based on actionName
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoicetemplate_Id
  *         description: Provide a Invoice template Id
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: Update the invoice Template based on actionName (deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate') with comments.
  *         type: string
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               actionName:
  *                 type: string
  *               comments:
  *                 type: string
  *               approvedAmount:
  *                 type: string
  *             required: [actionName ]
  *     responses:
  *       200:
  *         description: successful operation
  */
  callAction: {
      pre: null,
      process: "invoicetemplate.updateAction",
      post: null,
      method: 'PUT'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoicetemplate_Id}/getDetails:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Template Details
  *     operationId: getInvoiceTemplateDetails
  *     description: Fetch/Get a Invoice Template Details
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoicetemplate_Id
  *         description: Provide a invoice Template ID.
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: View Invoice Template Details.
  *         in: body
  *         schema: 
  *             properties:
  *               version:
  *                 type: integer
  *             required: [version]
  *     responses:
  *       200:
  *         description: successful operation
  */
  getDetails: {
      pre: null,
      process: "invoicetemplate.getInvoiceTemplateDetails",
      post: null,
      method: 'POST'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{invoicetemplate_Id}/getReleaseDetails:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Details
  *     operationId: getInvoiceTemplateReleaseDetails
  *     description: Fetch/Get a Invoice Details
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: invoicetemplate_Id
  *         description: Provide a invoice ID.
  *         in: path
  *         required: true
  *         type: integer
  *       - name: body
  *         description: View Invoice Template Release Details.
  *         in: body
  *         schema: 
  *             properties:
  *               version:
  *                 type: integer
  *             required: [version]
  *     responses:
  *       200:
  *         description: successful operation
  */
 getReleaseDetails: {
    pre: null,
    process: "invoicetemplate.getInvoiceTemplateReleaseDetails",
    post: null,
    method: 'POST'
},

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/isExistsInvoiceTemplateNumber:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get a Invoice Details if Invoice Number Exists
  *     operationId: getInvoiceDetails if Invoice Number Exists
  *     description: Fetch/Get a Invoice Details if Invoice Number Exists
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: body
  *         description: View Invoice Details if Invoice Number Exists
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               invoiceNumber:
  *                 type: string
  *               supplierId:
  *                 type: string
  *               invoiceId:
  *                 type: string
  *             required: [invoiceNumber,supplierId]
  *     responses:
  *       200:
  *         description: successful operation
  */
  isExistsInvoiceTemplateNumber: {
      pre: null,
      process: "invoicetemplate.isExistsInvoiceTemplateNumber",
      post: null,
      method: 'POST'
  },

  /**
  * @swagger
  * /a/einvoice/invoiceTemplate/{id}/auditTrail:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Fetch/Get Audit Trail Details by Id and Type
  *     operationId: getAuditTrailDetails
  *     description: Fetch/Get Audit Trail Details by Id and Type
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: id
  *         description: Provide invoice template id
  *         in: path
  *         required: true
  *         type: string
  *       - name: body
  *         description: Get Audit Trail Details(pass the entityType as INVOICE_TEMPLATE with respetive Id).
  *         in: body
  *         required: true
  *         schema: 
  *             properties:
  *               entityType:
  *                 type: string
  *             required: [entityType ]
  *     responses:
  *       200:
  *         description: successful operation
  */
  auditTrail: {
      pre: null,
      process: "invoicetemplate.auditTrail",
      post: null,
      method: 'POST'
  },
   /**
    * @swagger
    * /a/einvoice/invoiceTemplate:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Create a invoiceTemplate
    *     operationId: Create invoiceTemplate
    *     description: Create invoiceTemplate
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create invoiceTemplate.
    *         in: body
    *         schema:
    *             properties:
    *               actionName:
    *                 type: string 
    *               recurringContract:
    *                 type: object
    *                 properties:  
    *                   statusComments:
    *                       type: string
    *                   status:
    *                       type: string
    *                   templateOwner:
    *                       type: string
    *                   templateName:
    *                       type: string
    *                   autoInvoiceNo:
    *                       type: string
    *                   sequence:
    *                       type: number
    *                   visibilityRuleStatus:
    *                       type: boolean
    *                   notes:
    *                       type: string
    *                   releaseScheduleId:
    *                       type: string
    *                   lastExecutionTime:
    *                       type: number
    *                   nextExecutionTime:
    *                       type: number
    *                   suppAddress:
    *                       type: string
    *                   suppAddressRemit:
    *                       type: string
    *                   invoicedAmount:
    *                       type: number
    *                   suppPaymentTermId:
    *                       type: string
    *                   neverExpire:
    *                       type: boolean
    *                   suppBankingDetails:
    *                       type: string
    *                   grossContractTotalAmount:
    *                       type: string
    *                   createdBy:
    *                       type: string
    *                   createdOn:
    *                       type: number
    *                   tenantId:
    *                       type: string
    *                   templateId:
    *                       type: string
    *                   externalId:
    *                       type: string
    *                   templateUniqueId:
    *                       type: string
    *                   comments:
    *                       type: string
    *                   templateDate:
    *                       type: number
    *                   contractOwner:
    *                       type: string
    *                   contractName:
    *                       type: string
    *                   description:
    *                       type: string
    *                   purchaseOrderNumber:
    *                       type: number
    *                   buyer:
    *                       type: string
    *                   supplierId:
    *                       type: string
    *                   supplierName:
    *                       type: string
    *                   supplierAddressId:
    *                       type: string
    *                   supplierAddressIdRemit:
    *                       type: string
    *                   supplierCurrency:
    *                       type: string
    *                   supplierContact:
    *                       type: string
    *                   discountLevel:
    *                       type: number
    *                   discounttype: 
    *                       type: number
    *                   discountValue:
    *                       type: number
    *                   extraCharges:
    *                       type: number
    *                   freightCharges:
    *                       type: number
    *                   insuranceCharges:
    *                       type: number
    *                   exciseDuties:
    *                       type: number
    *                   submittedOn:
    *                       type: number
    *                   baseCurrency:
    *                       type: string
    *                   baseExchangeRate:
    *                       type: number
    *                   baseTotal:
    *                       type: number
    *                   shouldSubmit:
    *                       type: boolean
    *                   purchasetype: 
    *                       type: string
    *                   companyCode:
    *                       type: string
    *                   referenceValue:
    *                       type: string
    *                   recurringSchedule:
    *                     type: object
    *                     properties:
    *                       schedulerId:
    *                           type: string
    *                       templateId:
    *                           type: string
    *                       frequencyBy:
    *                           type: string
    *                       recurrancesOn:
    *                           type: number
    *                       interval:
    *                           type: number
    *                       startFrom:
    *                           type: number
    *                       endTo:
    *                           type: number
    *                       neverExpire :
    *                           type: boolean
    *                       previousFireTime:
    *                           type: number
    *                       nextFireTime:
    *                           type: number
    *                       finalFireTime:
    *                           type: number
    *                       recurranceMonthForYear:
    *                           type: number
    *                       activeFrom:
    *                           type: number
    *                       activeTill:
    *                           type: number
    *                   attachmentIds:
    *                     type: array
    *                     items:
    *                         type:  string
    *                   splitCostingLevel:
    *                       type: number
    *                   splitCostingtype: 
    *                       type: number
    *                   referencetype: 
    *                       type: number
    *                   origin:
    *                       type: number
    *                   supplierErpId:
    *                       type: string
    *                   supplierAddressERPId:
    *                       type: string
    *                   erpId:
    *                       type: string
    *                   workflowId:
    *                       type: string
    *                   workflowInstanceId:
    *                       type: string
    *                   processEformId:
    *                       type: string
    *                   dynamicFormId:
    *                       type: string
    *                   dynamicInstanceId:
    *                       type: string
    *                   paymentTermId:
    *                       type: string
    *                   businessUnitCode:
    *                       type: string
    *                   locationCode:
    *                       type: string
    *                   billToCode:
    *                       type: string
    *                   invoiceToCode:
    *                       type: string
    *                   supplierRemitAddressERPId:
    *                       type: string
    *                   shipToCodetype: 
    *                       type: number
    *                   shipToCode:
    *                       type: string
    *                   shipToLocation:
    *                       type: string
    *                   newGrossTotalAmount:
    *                       type: number
    *                   newTotalTaxAmount:
    *                       type: number
    *                   supplierBankingDetailsId:
    *                       type: string
    *                   visibilityRule:
    *                       type: string
    *                   epDiscDueDate:
    *                       type: number
    *                   coaFlexiFormId:
    *                       type: string
    *                   coaFlexiFormInstanceId:
    *                       type: string
    *                   coaFlexiFormInstanceVersion:
    *                       type: number
    *                   customerReferenceId:
    *                       type: string
    *                   entitySetting:
    *                       type: string
    *                   dueDate:
    *                     type: number
    *                   matchStatus:
    *                     type: number
    *                   matchedOn:
    *                     type: number
    *                   sendToReadyForApproval:
    *                     type: boolean
    *                   deliverTo:
    *                     type: string
    *                   submitForCodingUserId:
    *                     type: string
    *                   requester:
    *                     type: string
    *                   originId:
    *                     type: string
    *                   originType:
    *                     type: string
    *               items:
    *                 type: array
    *                 items:
    *                     type: object
    *                     properties:  
    *                       lineItemId:
    *                           type: string
    *                       lineNo:
    *                           type: string
    *                       poLineNo:
    *                           type: string
    *                       itemQuantity:
    *                           type: number
    *                       marketPrice:
    *                           type: number
    *                       discounttype: 
    *                           type: number
    *                       discountValue:
    *                           type: number
    *                       itemPrice:
    *                           type: number
    *                       itemTaxPrice:
    *                           type: number
    *                       applyNoTaxes:
    *                           type: boolean
    *                       itemTotalPrice:
    *                           type: number
    *                       splitCostingtype: 
    *                           type: number
    *                       itemComment:
    *                           type: string
    *                       purchaseOrderId:
    *                           type: string
    *                       attachmentIds:
    *                         type: array
    *                         items:
    *                             type:  string
    *                       contractNo:
    *                           type: string
    *                       contractId:
    *                           type: string
    *                       contracttype: 
    *                           type: number
    *                       assetCode:
    *                           type: string
    *                       assetCodetype: 
    *                           type: number
    *                       shipToCodetype: 
    *                           type: number
    *                       shipToCode:
    *                           type: string
    *                       shipToLocation:
    *                           type: string
    *                       processEformId:
    *                           type: string
    *                       dynamicFormId:
    *                           type: string
    *                       dynamicInstanceId:
    *                           type: string
    *                       dynamicInstanceVersion:
    *                           type: number
    *                       selfAssessedTaxAmt:
    *                           type: number
    *                       catalogItem:
    *                         type: object
    *                         properties:
    *                           catalogId:
    *                               type: string
    *                           itemId:
    *                               type: string
    *                           supplierPartId:
    *                               type: string
    *                           manufacturerPartId:
    *                               type: string
    *                           manufacturerName:
    *                               type: string
    *                           name:
    *                               type: string
    *                           description:
    *                               type: string
    *                           uom:
    *                               type: string
    *                           leadTime:
    *                               type: number
    *                           categoryCode:
    *                               type: string
    *                           categoryName:
    *                               type: string
    *                           unsspscCode:
    *                               type: string
    *                           unsspscName:
    *                               type: string
    *                           supplierProductURL:
    *                               type: string
    *                           manufacturerProductURL:
    *                               type: string
    *                           imageURL:
    *                               type: string
    *                           thumbnailURL:
    *                               type: string
    *                           sourceRefNo:
    *                               type: string
    *                           contractNo:
    *                               type: string
    *                           contractId:
    *                               type: string
    *                           sourcetype: 
    *                               type: number
    *                           itemtype: 
    *                               type: number
    *                           receipttype: 
    *                               type: number
    *                           contracttype: 
    *                               type: number
    *                           active:
    *                               type: boolean
    *                           hidden:
    *                               type: boolean
    *                           activity:
    *                               type: number
    *                           greenItem:
    *                               type: boolean 
    *                           preferredItem:
    *                               type: boolean
    *                           validFrom:
    *                               type: string
    *                           validTo:
    *                               type: string
    *                           publishedOn:
    *                               type: string
    *                           attachments:
    *                             type: array
    *                             items:
    *                                 type: string 
    *                           outOfStock:
    *                               type: boolean
    *                           sourcingStatus:
    *                               type: number
    *                       coaFlexiFormId:
    *                          type: string
    *                       coaFlexiFormInstanceId:
    *                           type: string
    *                       coaFlexiFormInstanceVersion:
    *                           type: number
    *                       apportionalableAmt:
    *                           type: number
    *                       apportionedAmt:
    *                           type: number
    *                       creditedAmt:
    *                           type: number
    *                       itemTaxes:
    *                         type: array
    *                         items:
    *                             type: object
    *                             properties:
    *                               type: 
    *                                   type: string
    *                               name:
    *                                   type: string
    *                               rate:
    *                                   type: number
    *                               taxAmount:
    *                                   type: number
    *                               useTax:
    *                                   type: boolean
    *                               taxableAmount:
    *                                   type: boolean
    *                               borneByBuyerCheck:
    *                                   type: boolean
    *               costings:
    *                 type: array
    *                 items:
    *                     type: object
    *                     properties:
    *                       lineItemId:
    *                           type: string
    *                       businessUnitCode:
    *                           type: string
    *                       costCenterCode:
    *                           type:  string
    *                       projectCode:
    *                           type:  string
    *                       value:
    *                           type:  number
    *                       splitValue:
    *                           type:  number 
    *               headerTaxes:
    *                 type: array
    *                 items:
    *                     type: object
    *                     properties:
    *                       type: 
    *                           type: string
    *                       name:
    *                           type:  string
    *                       rate:
    *                           type:  number
    *                       taxAmount:
    *                           type:  number
    *                       useTax:
    *                           type:  boolean
    *                       compound:
    *                           type:  boolean
    *                       taxableAmount:
    *                           type:  number
    *                       applicableFor:
    *                           type:  number
    *                       borneByBuyerCheck:
    *                           type:  boolean
    *               accountings:
    *                 type: array
    *                 items:
    *                     type: object
    *                     properties:
    *                       accountTypeCode:
    *                           type: string
    *                       generalLedgerCode:
    *                           type: string
    *                       value:
    *                           type: number
    *                       purchasetype: 
    *                           type: string
    *                       purchaseTypeCode:
    *                           type: string
    *                       visibilityRule:
    *                           type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
   create: {
    pre: null,
    process: "invoicetemplate.create",
    post: null,
    method: 'POST'
    },
}