"use strict";

module.exports = {
  
    /**
    * @swagger
    * /a/einvoice/creditMemos/list:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Get the Credit Memo list
    *     operationId: creditMemoList
    *     description: Get the Credit Memo list
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the Credit Memo list (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "creditmemo.getList",
        post: null,
        method: 'POST'
    },

      /**
    * @swagger
    * /a/einvoice/creditMemos/{creditMemo_Id}/callAction:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update the Credit Memo based on actionName
    *     operationId: updateCreditMemoBasedOnAction
    *     description: Update the Credit Memo based on actionName
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: creditMemo_Id
    *         description: Provide a Credit Memo Id
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: Update the Credit Memo based on actionName (voidCreditMemo, returnCreditMemo, removeCreditMemo) with comments.
    *         type: string
    *         in: body
    *         required: true
    *         schema: 
    *             properties:
    *               actionName:
    *                 type: string
    *               comments:
    *                 type: string
    *               doVoid:
    *                 type: boolean
    *               cmStatus:
    *                 type: string
    *             required: [actionName]
    *     responses:
    *       200:
    *         description: successful operation
    */
    callAction: {
        pre: null,
        process: "creditmemo.updateAction",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/einvoice/creditMemos/{creditMemo_Id}/getDetails:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Fetch/Get a CreditMemo Details
    *     operationId: get Credit Memo Details
    *     description: Fetch/Get Credit Memo Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: creditMemo_Id
    *         description: Provide a Credit Memo ID.
    *         in: path
    *         required: true
    *         type: integer
    *       - name: body
    *         description: View Credit Memo Details.
    *         in: body
    *         schema: 
    *             properties:
    *               version:
    *                 type: integer
    *             required: [version]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "creditmemo.getCreditMemoDetails",
        post: null,
        method: 'POST'
    }

}