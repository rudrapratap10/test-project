"use strict";

module.exports = {

      /**
	* @swagger
	* /a/einvoice/configs/getInvoiceConfig:
	*   post:
	*     tags:
	*       - eInvoice API
	*     summary: Get configuration details
	*     operationId: getDetailsByLevel
	*     description: Fetch configuration details
	*     produces:
	*       - application/json
    *     parameters:
    *       - name: body
    *         description: Get configuration details
	*         in: body
    *         required: true
    *         schema:
    *             properties:
    *               configKeys:
    *                 type: array
    *                 items:
    *                   type: string
    *             required: [configKeys]
	*     responses:
	*       200:
	*         description: successful operation
    */
   getInvoiceConfig: {
        pre: null,
        process: "config.getInvoiceConfig",
        post: null,
        method: 'POST'
    },

          /**
	* @swagger
	* /a/einvoice/configs/getSystemConfig:
	*   post:
	*     tags:
	*       - eInvoice API
	*     summary: Get System configuration details
	*     operationId: getSystemConfig
	*     description: Fetch system configuration details
	*     produces:
	*       - application/json
    *     parameters:
    *       - name: body
    *         description: Get system configuration details
	*         in: body
    *         required: true
    *         schema:
    *             properties:
    *               configKeys:
    *                 type: array
    *                 items:
    *                   type: string
    *             required: [configKeys]
	*     responses:
	*       200:
	*         description: successful operation
    */
   getSystemConfig: {
    pre: null,
    process: "config.getSystemConfig",
    post: null,
    method: 'POST'
}

}