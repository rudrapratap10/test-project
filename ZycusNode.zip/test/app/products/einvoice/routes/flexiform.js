"use strict";

module.exports = {

    /**
    * @swagger
    * /a/einvoice/flexiForms/{dynamicForm_Id}/dynamicInstanceCOA:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update Dynamic Instance COA
    *     operationId: updateDynamicInstanceCOA
    *     description: Update Dynamic Instance COA
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: dynamicForm_Id
    *         description: Provide a Form ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a dynamic Instance COA
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             dynamicFormInstanceId:
    *                 type: string
    *             formInstance:
    *               type: object
    *               properties:
    *                 formDefinitionId:
    *                     type: string
    *                 formInstanceId:
    *                     type: string
    *                 sectionInstances:
    *                   type: array
    *                   items:
    *                     type: object
    *                     properties:
    *                       sectionInstanceId:
    *                           type: string
    *                       sectionDefinitionId:
    *                           type: string
    *                       fieldInstances:
    *                         type: array
    *                         items:
    *                           type: object
    *                           properties:
    *                             fieldInstanceId:
    *                                 type: string
    *                             fieldDefinitionId:
    *                                 type: string
    *                             value:
    *                               type: array
    *                               items:
    *                                 type: none
    *                             fieldRevisionId:
    *                                 type: number
    *                             fieldLibraryId:
    *                                 type: string
    *                             floatingPrecisionValue:
    *                                 type: number
    *                       tableInstances:
    *                         type: array
    *                         items:
    *                           type: object
    *                           properties:
    *                             tableInstanceId:
    *                                 type: string
    *                             tableDefinitionId:
    *                                 type: string
    *                             type:
    *                                 type: string
    *                             tableRowInstances:
    *                               type: array
    *                               items:
    *                                 type: object
    *                                 properties:
    *                                   tableRowInstanceId:
    *                                       type: string
    *                                   rowInstanceChanged:
    *                                       type: string
    *                                   fieldInstances:
    *                                     type: array
    *                                     items:
    *                                       type: object
    *                                       properties:
    *                                         fieldInstanceId:
    *                                             type: string
    *                                         fieldDefinitionId:
    *                                             type: string
    *                                         fieldLibraryId:
    *                                             type: string
    *                                         fieldKey:
    *                                             type: string
    *                                         value:
    *                                           type: array
    *                                           items:
    *                                             type: none
    *                                         valueHtml:
    *                                           type: array
    *                                           items:
    *                                             type: string
    *                                         fieldRevisionId:
    *                                             type: number
    *                                         isMandatory:
    *                                             type: boolean
    *                                         isEditable:
    *                                             type: boolean
    *                                         floatingPrecisionValue:
    *                                             type: number
    *                             tableInstanceModified:
    *                                 type: string
    *             skipValidation:
    *                 type: boolean
    *             extraParams:
    *               type: object
    *               properties:
    *                 quantity:
    *                     type: number
    *                 totalAmount:
    *                     type: number
    *                 purchaseType:
    *                     type: string
    *                 company:
    *                     type: string
    *                 businessUnit:
    *                     type: string
    *                 location:
    *                     type: string 
    *                 category:
    *                     type: string 
    *                 userId:
    *                     type: string 
    *                 scopeType:
    *                     type: string 
    *                 scopeId:
    *                     type: string 
    *                 skipMandatory:
    *                     type: boolean
    *                 isEmptyTableAllowed:
    *                     type: boolean
    *             decimalPrecisionMap:
    *                 type: object
    *           required: [dynamicForm_Id, formInstance, extraParams]    
    *     responses:
    *       200:
    *         description: successful operation
    */
    dynamicInstanceCOA: {
        pre: null,
        process: "flexiform.dynamicInstanceCOA",
        post: null,
        method: 'PUT'
    },

    /**
    * @swagger
    * /a/einvoice/flexiForms/{dynamicForm_Id}/dynamicInstance:
    *   put:
    *     tags:
    *       - eInvoice API
    *     summary: Update Dynamic Instance
    *     operationId: updateDynamicInstance
    *     description: Update Dynamic Instance
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: dynamicForm_Id
    *         description: Provide a Form ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Update a dynamic Instance
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             dynamicFormInstanceId:
    *                 type: string
    *             formInstance:
    *               type: object
    *               properties:
    *                 formDefinitionId:
    *                     type: string
    *                 formInstanceId:
    *                     type: string
    *                 sectionInstances:
    *                   type: array
    *                   items:
    *                     type: object
    *                     properties:
    *                       sectionInstanceId:
    *                           type: string
    *                       sectionDefinitionId:
    *                           type: string
    *                       fieldInstances:
    *                         type: array
    *                         items:
    *                           type: object
    *                           properties:
    *                             fieldInstanceId:
    *                                 type: string
    *                             fieldDefinitionId:
    *                                 type: string
    *                             value:
    *                               type: array
    *                               items:
    *                                 type: none
    *           required: [formInstance]
    *     responses:
    *       200:
    *         description: successful operation
    */
    dynamicInstance: {
        pre: null,
        process: "flexiform.dynamicInstance",
        post: null,
        method: 'PUT'
    }
}