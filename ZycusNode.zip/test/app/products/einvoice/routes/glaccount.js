"use strict";
module.exports = {


    /**
  * @swagger
  * /a/einvoice/glAccounts/allowedList:
  *   post:
  *     tags:
  *       - eInvoice API
  *     summary: Filter the list of GL account's based on the criterai passed
  *     operationId: allowedList
  *     description: Filter the list of GL account's based on the criterai passed
  *     produces:
  *       - application/json
  *     parameters:
  *       - name: body
  *         description: Fetch GL account's list (based on filter, sorting & pagination options).
  *         type: string
  *         in: body
  *         schema: 
  *           allOf:
  *             - $ref: '#/definitions/pagination'
  *             - $ref: '#/definitions/criteriaGroup'
  *             - $ref: '#/definitions/sort'
  *     responses:
  *       200:
  *         description: successful operation
  */

    allowedList: {
        pre: null,
        process: "glaccount.allowedList",
        post: null,
        method: 'POST'
    }

}
