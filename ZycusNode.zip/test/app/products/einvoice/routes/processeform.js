"use strict";

module.exports = {
    
    /**
    * @swagger
    * /a/einvoice/processeForm/evaluate:
    *   post:
    *     tags:
    *       - eInvoice API
    *     summary: Create Process eForm Details
    *     operationId: createProcessEform
    *     description:  Create Process eForm Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create Process eForm Details
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           properties:
    *             processCode:
    *               type: string
    *             regions:
    *               type: array
    *               items:
    *                 type: string
    *             purchaseType:
    *               type: string
    *             companyBUList:
    *               type: array
    *               items:
    *                 type: object
    *                 properties:
    *                   company:
    *                     type: string
    *                   businessUnits:
    *                     type: array
    *                     items:
    *                       type: string
    *           required: [processCode, regions, companyBUList]
    *     responses:
    *       200:
    *         description: successful operation
    */
    evaluate: {
        pre: null,
        process: "processeform.evaluate",
        post: null,
        method: 'POST'
    }
}