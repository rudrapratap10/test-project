/**
* Purchase Order Controller
*
* @description :: Provides purchase order related CRUD operation.
*/

module.exports = (parentClass) => {

    class PurchaseOrder extends parentClass {
        /**
        * @name :: getList
        *
        * @description :: It gives the purchaseOrder List based on  (based on filter, sorting & pagination options).
        *
        * @param1 :: input perPageRecords
        * @param2 :: input pageNo
        * @param3 :: input logicalOperator
        * @return/callback purchaseOrder List details
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/purchaseOrder/filter/purchaseOrder';
                    http.post(url, 'purchaseOrderList', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "description": { "type": "string" }, "purchaseType": { "type": "string" }, "purchaseOrderNumber": { "type": "string" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "suppCurrency": { "type": "string" }, "totalAmount": { "type": "number" }, "amount": { "type": "number" }, "grossTotalAmount": { "type": "none" }, "docType": { "type": "number" }, "docTypeDesc": { "type": "string" }, "paymentTermId": { "type": "string" }, "newGrossTotalAmount": { "type": "number" }, "paymentStatus": { "type": "number" }, "name": { "type": "string" }, "releasedOn": { "type": "none" }, "items": { "type": "number" }, "type": { "type": "number" }, "purchaseOrderId": { "type": "string" }, "companyCode": { "type": "none", "key": "company" }, "businessUnitCode": { "type": "none", "key": "businessUnit" }, "checkoutBuyer": { "type": "none", "key": "buyerInfo" }, "locationCode": { "type": "none", "key": "location" }, "shipToCode": { "type": "none", "key": "address" }, "requester": { "type": "string" }, "allowInvoice": { "type": "boolean" }, "orderAuthorizationType": { "type": "string" }, "invoiceStatus": { "type": "number" }, "supplierERPId": { "type": "none" } } } } };
                            let buyerDetails = [],
                                companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [],
                                shipToCodes = [];
                            if (!lodash.isEmpty(records) && lodash.isArray(records)) {
                                records.forEach(item => {
                                    if (item.checkoutBuyer) buyerDetails.push(item.checkoutBuyer);
                                    if (item.companyCode) companyCodes.push(item.companyCode);
                                    if (item.businessUnitCode) businessUnitCodes.push(item.businessUnitCode);
                                    if (item.locationCode) locationCodes.push(item.locationCode);
                                    if (item.shipToCode) shipToCodes.push(item.shipToCode);
                                });
                                buyerDetails = lodash.uniq(buyerDetails);
                                companyCodes = lodash.uniq(companyCodes);
                                businessUnitCodes = lodash.uniq(businessUnitCodes);
                                locationCodes = lodash.uniq(locationCodes);
                                shipToCodes = lodash.uniq(shipToCodes);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                                return callback(null, request, output.execute());
                            }
                            const cmd = new (super.cmdHook({ request: request }))(),
                                tasks = [

                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) return methodCallback(request, {});
                                        //Step 1 : Fetch Company details 
                                        const reqData = { "codes": companyCodes, "pageNo": 1, "perPageRecords": companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) return methodCallback(request, {});
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes, "pageNo": 1, "perPageRecords": businessUnitCodes.length };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) return methodCallback(request, {});
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo": 1, "perPageRecords": locationCodes.length };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];
                                        if (lodash.isEmpty(shipToCodes)) return methodCallback(request, {});
                                        //Step 4 : Fetch shipToAddress details 
                                        const reqData = { "codes": shipToCodes, "pageNo": 1, "perPageRecords": shipToCodes.length };
                                        cmd.getAddress(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        const tms = new (super.tmsHook({ request: request }))();
                                        output.shipToAddressDetails = input.data.result || [];
                                        if (lodash.isEmpty(buyerDetails)) return methodCallback(request, {});
                                        //step 5 : get the buyer details
                                        const reqData = { "ids": buyerDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {

                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 5 : Merge all details to the response                                      
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                        if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //d) shipTo Address
                                        if (!lodash.isEmpty(output.shipToAddressDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.shipToAddressDetails, ["name", "code", "line1", "line2", "city", "county", "state.name", "state.code", "state.isoCode", "zip", "country.name", "country.code", "country.isoCode"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["shipToCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //e) Buyer Details
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]),
                                                utilsMerge = utils.mergeArray(output.records, extractProps, ["checkoutBuyer", "id"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, output);
                                    },
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, { "data": result }, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getPurchaseOrderDetails
        *
        * @Description :: Fetch/Get Purchase Order Details by passing purchaseorder_Id
        * 
        * @return/object/Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required().label('einvoice-lable-21__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "purchaseOrderId": request.params.purchaseorder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/purchaseOrder/' + request.params.purchaseorder_Id;
                    http.get(url, 'getPurchaseOrderDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                                responseSchema = { "type": "array", "properties": { "purchaseOrder": { "type": "object", "properties": { "orderAuthorizationType": { "type": "string" }, "paymentStatus": { "type": "number" }, "shipToCodeType": { "type": "number" }, "shipToCode": { "type": "string" }, "type": { "type": "number" }, "amendStatus": { "type": "number" }, "paymentMethod": { "type": "number" }, "invoiceStatus": { "type": "number" }, "allowInvoice": { "type": "boolean" }, "name": { "type": "string" }, "deliveryTo": { "type": "none" }, "deliverOn": { "type": "number" }, "checkoutBuyer": { "type": "none", "key": "buyerInfo" }, "erpId": { "type": "string" }, "attachmentIds": { "type": "none" }, "locationCode": { "type": "string" }, "discountValue": { "type": "number" }, "processEformId": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "billToCode": { "type": "string" }, "invoiceToCode": { "type": "string" }, "freightCharges": { "type": "number" }, "splitCostingLevel": { "type": "number" }, "splitCostingType": { "type": "number" }, "assignProject": { "type": "boolean" }, "supplierId": { "type": "string" }, "baseCurrency": { "type": "string" }, "baseExchangeRate": { "type": "number" }, "supplierERPId": { "type": "string" }, "workflowId": { "type": "string" }, "workflowInstanceId": { "type": "string" }, "paymentTermId": { "type": "string" }, "deliveryTermCode": { "type": "string" }, "contractNumber": { "type": "string" }, "parentPurchaseOrderId": { "type": "string" }, "purchaseOrderNumber": { "type": "string", "key": "PurchaseOrderNo" }, "statusComments": { "type": "string" }, "purchaseType": { "type": "string" }, "supplierName": { "type": "string" }, "suppAddress": { "type": "object", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } }, "quotationNo": { "type": "string" }, "retrospectivePurchase": { "type": "boolean" }, "suppPOContactEmail": { "type": "string" }, "suppPOContact": { "type": "string" }, "suppCurrency": { "type": "string" }, "totalAmount": { "type": "number" }, "grossTotalAmount": { "type": "number" }, "discountLevel": { "type": "number" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "requester": { "type": "none" }, "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "version": { "type": "number" } } }, "purchaseOrderItems": { "type": "array", "properties": { "shipToCodeType": { "type": "string" }, "contractId": { "type": "none" }, "internalComment": { "type": "none" }, "supplierComment": { "type": "none" }, "shipToCode": { "type": "string" }, "requesterId": { "type": "none", "key": "requesterIdInfo" }, "deliverTo": { "type": "none", "key": "deliverToInfo" }, "requesterName": { "type": "string" }, "marketPrice": { "type": "number" }, "itemQuantity": { "type": "number" }, "itemTotalPrice": { "type": "number" }, "invoicedQuantity": { "type": "number" }, "orderedQuantity": { "type": "number" }, "adjustedQuantity": { "type": "number" }, "creditedQuantity": { "type": "number" }, "receivedQuantity": { "type": "number" }, "netAcceptedQuantity": { "type": "number" }, "lineItemId": { "type": "string" }, "purchaseOrderId": { "type": "string" }, "itemId": { "type": "string" }, "attachmentIds": { "type": "none" }, "lineNo": { "type": "string" }, "itemTaxes": { "type": "none" }, "splitCostingType": { "type": "number" }, "assetCodeType": { "type": "number" }, "assetCode": { "type": "string" }, "contractNo": { "type": "string" }, "contractType": { "type": "number" }, "discountType": { "type": "number" }, "discountValue": { "type": "number" }, "dynamicFlexiForm": { "type": "string" }, "dynamicFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "dynamicInstanceVersion": { "type": "number" }, "coaflexiFormId": { "type": "string" }, "coaflexiFormInstanceId": { "type": "string" }, "coaflexiFormInstanceVersion": { "type": "number" } } }, "purchaseOrderTaxes": { "type": "none" }, "purchaseOrderCostings": { "type": "array", "properties": { "lineItemId": { "type": "string" }, "businessUnitCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "value": { "type": "number" }, "budgetBaseValue": { "type": "number" }, "splitValue": { "type": "number" }, "budgetId": { "type": "string" }, "budgetLineId": { "type": "string" }, "budgetLineTransactionId": { "type": "string" }, "projectCode": { "type": "string" }, "purchaseOrderId": { "type": "string" } } }, "purchaseOrderAccountings": { "type": "array", "properties": { "lineItemId": { "type": "string" }, "tenantId": { "type": "string" }, "accountTypeCode": { "type": "string" }, "visibilityRule": { "type": "none" }, "purchaseOrderId": { "type": "string" }, "purchaseType": { "type": "string" }, "generalLedgerCode": { "type": "string" }, "value": { "type": "number" }, "purchaseTypeCode": { "type": "string" } } }, "supportObjects": { "type": "object", "properties": { "attachments": { "type": "array", "properties": {} }, "items": { "type": "none" }, "supplier": { "type": "none" }, "costCenters": { "type": "none" }, "locations": { "type": "none" }, "accountTypes": { "type": "none" }, "companies": { "type": "none" }, "supplierAddresses": { "type": "none" }, "generalLedgers": { "type": "none" }, "businessUnits": { "type": "none" }, "supplierPaymentTerm": { "type": "none" }, "addresses": { "type": "none" } } } } };
                            let userDetails = [];
                            if (!lodash.isEmpty(records)) {
                                if (records.purchaseOrder) {
                                    if (records.purchaseOrder.checkoutBuyer) userDetails.push(records.purchaseOrder.checkoutBuyer);
                                    if (records.purchaseOrder.deliveryTo) userDetails.push(records.purchaseOrder.deliveryTo);
                                }
                                if(records.purchaseOrderItems){ 
                                    records.purchaseOrderItems.forEach(item => {
                                        if(item.deliverTo) userDetails.push(item.deliverTo);
                                        if(item.requesterId) userDetails.push(item.requesterId);
                                    });                                                                
                                }
                                if (records.supportObjects && records.supportObjects.attachments) {
                                    records.supportObjects.attachments.forEach(item => {
                                        userDetails.push(item.createdBy);
                                    });
                                }
                                userDetails = lodash.uniq(userDetails);
                            } else {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }
                            if (lodash.isEmpty(userDetails)) {
                                const output = (new (super.responseHandler)(request, { "data": [records] }, responseSchema));
                                return callback(null, request, output.execute());
                            }
                            const tms = new (super.tmsHook({ request: request }))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                        const reqData = { "ids": userDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records.purchaseOrder, extractProps, ["checkoutBuyer", "id"]);
                                            utils.mergeObject(records.purchaseOrder, extractProps, ["deliveryTo", "id"]);
                                            utils.mergeArray(records.supportObjects.attachments, extractProps, ["createdBy", "id"]);
                                            utils.mergeArray(records.purchaseOrderItems, extractProps, ["deliverTo", "id"]);
                                            utils.mergeArray(records.purchaseOrderItems, extractProps, ["requesterId", "id"]);                                            
                                            data.push(records);
                                        }
                                        return methodCallback(null, request, { data });
                                    },
                                ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('attachments', output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
                /**
        * @Name :: allAttachments
        *
        * @Description :: Get allAttachments Details by passing purchaseorder_Id
        * 
        * @return/object/Throw Error
        */

        allAttachments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "purchaseOrderId": "joi.string().required().label('einvoice-lable-21__')"
                         };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({purchaseOrderId:request.params.purchaseorder_Id});
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                          url = `${request.productsURL.eInvoice}/invoice/getAllDocumentAttachments/${request.params.purchaseorder_Id}`;
                   
                    http.get(url, 'allAttachments', (error, result) => {
                         if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"array","properties":{"documentType":{"type":"string"},"documentNumber":{"type":"string"},"documentDate":{"type":"number"},"lineNo":{"type":"string"},"attachments":{"type":"array","properties":{"displayName":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"consumerId":{"type":"string"},"origin":{"type":"number"},"alreadyInvoiced":{"type":"boolean"},"ocrParsedContent":{"type":"string"},"ocrDocumentJson":{"type":"string"},"ocrExtractedFieldsJson":{"type":"string"},"documentMappings":{"type":"array","properties":{"type":"none"}},"statusDetails":{"type":"number"},"checksum":{"type":"string"},"data":{"type":"string"},"version":{"type":"string"},"additionalInfo":{"type":"string"},"productid":{"type":"string"},"refId":{"type":"string"},"serviceCode":{"type":"string"},"serviceProviderCode":{"type":"string"},"callBackEndPoints":{"type":"string"},"tpiDoc":{"type":"string"},"tpiStatusComments":{"type":"string"},"serviceRequestTrackingId":{"type":"string"},"requestAccepted":{"type":"boolean"},"tpiResponse":{"type":"string"},"isExtract":{"type":"string"},"kofaxResponse":{"type":"string"},"attachmentErpId":{"type":"string"}}}}},
                                output = (new(super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('attachments', output.responseSchema.properties.attachments.properties);
                            return callback(null, request, output.execute());
                            }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }
    return PurchaseOrder;
}