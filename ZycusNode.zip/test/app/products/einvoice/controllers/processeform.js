/**
 * ProcesseForm Controller
 *
 * @description :: Provides ProcesseForm related CRUD operation.
 */

module.exports = (parentClass) => {

    class Processform extends parentClass {

        /**
        * @Name :: evaluate
        *
        * @Description :: Create Process eForm Details
        * 
        * @return/object/Throw Error
        */
        evaluate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "processCode": "joi.string().required().label('einvoice-lable-30__')",
                        "regions": "joi.array().items(joi.string()).min(1).unique().required().label('einvoice-lable-289__')",
                        "purchaseType": "joi.string().label('einvoice-lable-49__')",
                        "companyBUList": `joi.array().items(
                            joi.object().keys({
                                company: joi.string().label('einvoice-lable-259__'),
                                businessUnits: joi.array().items(joi.string()).min(1).unique().label('einvoice-lable-260__')
                            })
                        ).required().label('einvoice-lable-290')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/processEForm/evaluate`;
                    http.post(url, 'evaluateProcesseForm', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "version": { "type": "number" }, "processEformId": { "type": "string" }, "name": { "type": "string" }, "description": { "type": "string" }, "processCode": { "type": "string" }, "dynamicFormId": { "type": "none" }, "type": { "type": "number" }, "updated": { "type": "boolean" }, "parentProcessEformId": { "type": "string" }, "errorReasonsStr": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return Processform;
};