/**
 * Supplier Controller
 *
 * @description :: Provides Supplier related CRUD operation.
 */

module.exports = (parentClass) => {

    class Supplier extends parentClass {

        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/supplier/filter';
                    http.post(url, 'SupplierFilterList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "name": { "type": "string" }, "supplierId": { "type": "string" }, "erpId": { "type": "string" }, "customObjects":{"type":"object", "properties": {"TAXEXAMPT":{"type":"string"},"ABNNUMBER":{"type":"string"}}} } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }

                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getPaymentTermDetails
        *
        * @Description :: Fetch/Get Supplier PaymentTerm Details
        * 
        * @return/object/Throw Error
        */
        getPaymentTermDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "locationCode": "joi.string().required().label('einvoice-lable-20__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        supplierId = request.body.supplierId,
                        locationCode = request.body.locationCode,
                        url = einvoiceURL + '/supplier/' + supplierId + '/' + locationCode + '/' + 'paymentTerm';
                    http.get(url, 'paymentTermDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "paymentTerm": { "type": "string" }, "paymentType": { "type": "none" }, "poSubmission": { "type": "none" }, "poRevision": { "type": "string" }, "poTransmission": { "type": "string" }, "currency": { "type": "string" }, "customerId": { "type": "none" }, "incoTerm": { "type": "string" }, "code": { "type": "string" }, "name": { "type": "string" }, "createdOn": { "type": "number" }, "active": { "type": "boolean" }, "creditDays": { "type": "number" }, "daysAvailDiscount": { "type": "number" }, "rate": { "type": "number" }, "erpId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getSupplierAddressDetails
        *
        * @Description :: Fetch/Get Supplier Address Details
        * 
        * @return/object/Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "supplierId": "joi.number().required().label('einvoice-lable-19__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "supplierId": request.params.supplier_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/supplier/' + request.params.supplier_Id + '/' + 'addresses';
                    http.get(url, 'getSupplierAddressDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "addressId": { "type": "string" }, "street1": { "type": "string" }, "street2": { "type": "string" }, "street3": { "type": "string" }, "city": { "type": "string" }, "state": { "type": "string" }, "country": { "type": "string" }, "zip": { "type": "string" }, "poBox": { "type": "string" }, "phone": { "type": "string" }, "fax": { "type": "string" }, "headQuarter": { "type": "boolean" }, "order": { "type": "boolean" }, "remitt": { "type": "boolean" }, "addressAccountGroupId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: getSupplierContactDetails
        *
        * @Description :: Fetch/Get Supplier Contact Details
        * 
        * @return/object/Throw Error
        */
       getContactDetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "supplierId": "joi.number().required().label('einvoice-lable-19__')",
                    "addressId": "joi.string().required().label('einvoice-lable-24__')",
                    "referConfig": "joi.boolean().required().label('einvoice-lable-25__')"
                };
            validationUtility.addInternalSchema(schema);                
            const result = validationUtility.validate(super.lodash.merge(request.body, { "supplierId": request.params.supplier_Id }));
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    url = einvoiceURL + '/supplier/' + 'supplierContact';
                http.post(url, 'getSupplierContactDetails', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "supplierContactId": { "type": "string" }, "supplierId": { "type": "string" }, "addressId": { "type": "string" }, "contactType": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "title": { "type": "string" }, "email": { "type": "string" }, "phone": { "type": "string" }, "cell": { "type": "string" }, "fax": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };

        /**
        * @Name :: getSupplier Account Group Details
        *
        * @Description :: Fetch/Get Supplier Account Group Details
        * 
        * @return/object/Throw Error
        */
        accountGroups(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    url = einvoiceURL + '/supplier/supplierAccountGroups';
                http.get(url, 'getAccountsList', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "OART": { "type": "string" }, "OA": { "type": "string" }, "RT": { "type": "string" }, "OTHERS": { "type": "string" }, "HQ": { "type": "string" }, "HQOA": { "type": "string" }, "HQRT": { "type": "string" }, "HQOART": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
* @Name :: getSupplierBankingDetails
*
* @Description :: Fetch/get Supplier Banking Details
* 
* @return/object/Throw Error
*/
        bankingDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "supplierId": "joi.number().required().label('einvoice-lable-19__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "supplierId": request.params.supplier_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/supplier/' + request.params.supplier_Id + '/' + 'bankingDetails';
                    http.get(url, 'getSupplierBankingDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "bankingDetailsID": { "type": "string" }, "bankRecordLabel": { "type": "string" }, "bankRecordERPId": { "type": "string" }, "bankCountry": { "type": "string" }, "bankName": { "type": "string" }, "branchName": { "type": "string" }, "bankId": { "type": "string" }, "bankBeneficiaryName": { "type": "string" }, "bankAccountType": { "type": "string" }, "bankAccountNo": { "type": "string" }, "bankIdQualifier": { "type": "string" }, "bankSwiftQualifierCode": { "type": "boolean" }, "bankIBANNo": { "type": "boolean" }, "bankSwiftCode": { "type": "boolean" }, "bankSortCode": { "type": "string" }, "bankRoutingNo": { "type": "string" }, "bankBranchId": { "type": "string" }, "bankAccountSeqNumber": { "type": "string" }, "bankDescription": { "type": "string" }, "isDefault": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

    }

    return Supplier;
}