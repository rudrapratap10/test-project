/**
 * Flexiform Controller
 *
 * @description :: Provides Flexiform related CRUD operation.
 */

module.exports = (parentClass) => {

    class Flexiform extends parentClass {

        /**
        * @Name : updateDynamicInstanceCOA
        * @Description : It is used to update the Dynamic Instances COA
        * @return : object / Throw Error
        */
        dynamicInstanceCOA(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "dynamicFormId": "joi.string().required().label('einvoice-lable-108__')",
                    "dynamicFormInstanceId":"joi.string().allow('').label('einvoice-lable-244__')",
                    "formInstance": `joi.object().keys({
                        formDefinitionId: joi.string().label('einvoice-lable-246__'),
                        formInstanceId: joi.string().allow('').label('einvoice-lable-247__'),
                        sectionInstances: joi.array().items(
                            joi.object().keys({
                                sectionInstanceId: joi.string().label('einvoice-lable-249__'),
                                sectionDefinitionId: joi.string().label('einvoice-lable-250__'),
                                fieldInstances: joi.array().items(
                                    joi.object().keys({
                                        fieldInstanceId: joi.string().label('einvoice-lable-252__'),
                                        fieldDefinitionId: joi.string().label('einvoice-lable-253__'),
                                        value: joi.array().items(joi.any().allow('').label('einvoice-lable-205__')).unique().label('einvoice-lable-205__'),
                                        fieldRevisionId: joi.number().label('einvoice-lable-254__'),
                                        fieldLibraryId: joi.string().label('einvoice-lable-255__'),
                                        floatingPrecisionValue: joi.number().label('einvoice-lable-256__') 
                                    })
                                ).label('einvoice-lable-251__'),
                                tableInstances: joi.array().items(
                                    joi.object().keys({
                                        tableInstanceId: joi.string().label('einvoice-lable-271__'),
                                        tableDefinitionId: joi.string().label('einvoice-lable-272__'),
                                        type: joi.string().label('einvoice-lable-193'),
                                        tableRowInstances: joi.array().items(
                                            joi.object().keys({
                                                tableRowInstanceId: joi.string().label('einvoice-lable-274__'),
                                                rowInstanceChanged: joi.string().label('einvoice-lable-275__'),
                                                fieldInstances: joi.array().items(
                                                    joi.object().keys({
                                                        fieldInstanceId: joi.string().label('einvoice-lable-252__'),
                                                        fieldDefinitionId: joi.string().label('einvoice-lable-253__'),
                                                        fieldLibraryId: joi.string().label('einvoice-lable-255__'),
                                                        fieldKey: joi.string().label('einvoice-lable-276__'),
                                                        value: joi.array().items(joi.any().allow('').label('einvoice-lable-205__')).unique().label('einvoice-lable-205__'),
                                                        valueHtml: joi.array().items(joi.string().allow('').label('einvoice-lable-277__')).unique().label('einvoice-lable-277__'),
                                                        fieldRevisionId: joi.number().label('einvoice-lable-254__'),
                                                        isMandatory: joi.boolean().label('einvoice-lable-278__'),
                                                        isEditable: joi.boolean().label('einvoice-lable-279__'),
                                                        floatingPrecisionValue: joi.number().label('einvoice-lable-256__')
                                                    })                                                    
                                                ).label('einvoice-lable-251')
                                            })
                                        ).label('einvoice-lable-273__'),
                                        tableInstanceModified: joi.string().label('einvoice-lable-280__')
                                    })
                                ).label('einvoice-lable-270__')
                            })
                        ).required().label('einvoice-lable-248__')
                    }).required().label('einvoice-lable-245__')`,
                    "skipValidation": "joi.boolean().label('einvoice-lable-257__')",
                    "extraParams": `joi.object().keys({
                        quantity: joi.number().label('einvoice-lable-258__'),                        
                        totalAmount: joi.number().label('einvoice-lable-48__'),
                        purchaseType: joi.string().label('einvoice-lable-49__'),
                        company: joi.string().label('einvoice-lable-259__'),
                        businessUnit: joi.string().label('einvoice-lable-260__'),
                        location: joi.string().label('einvoice-lable-261__'),
                        category: joi.string().label('einvoice-lable-262__'),
                        userId: joi.string().label('einvoice-lable-263__'),
                        scopeType: joi.string().label('einvoice-lable-264__'),
                        scopeId: joi.string().label('einvoice-lable-265__'),
                        skipMandatory: joi.boolean().label('einvoice-lable-266__'),
                        isEmptyTableAllowed: joi.boolean().label('einvoice-lable-267__')
                    }).required().label('einvoice-lable-269__')`,
                    "decimalPrecisionMap":"joi.object().allow('').label('einvoice-lable-268__')"             
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "dynamicFormId": request.params.flexiform_Id }));                
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http =  new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/flexiForm/updateDynamicInstanceCOA`;
                    http.post(url, 'updateDynamicInstanceCOA', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else {
                            const responseSchema = {"type":"object","properties":{"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"string"}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                    
                        }
                    });
                }
            }
            catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : updateDynamicInstance
        * @Description : It is used to update the Dynamic Instances
        * @return : object / Throw Error
        */
        dynamicInstance(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "dynamicFormId": "joi.string().required().label('einvoice-lable-108__')",
                    "dynamicFormInstanceId":"joi.string().allow('').label('einvoice-lable-244__')",
                    "formInstance": `joi.object().keys({
                        formDefinitionId: joi.string().label('einvoice-lable-246__'),
                        formInstanceId: joi.string().allow('').label('einvoice-lable-247__'),
                        sectionInstances: joi.array().items(
                            joi.object().keys({
                                sectionInstanceId: joi.string().label('einvoice-lable-249__'),
                                sectionDefinitionId: joi.string().label('einvoice-lable-250__'),
                                fieldInstances: joi.array().items(
                                    joi.object().keys({
                                        fieldInstanceId: joi.string().label('einvoice-lable-252__'),
                                        fieldDefinitionId: joi.string().label('einvoice-lable-253__'),
                                        value: joi.array().items(joi.any().allow('').label('einvoice-lable-205__')).unique().label('einvoice-lable-205__')
                                    })
                                ).label('einvoice-lable-251__')
                            })
                        ).required().label('einvoice-lable-248__')
                    }).required().label('einvoice-lable-245__')`         
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "dynamicFormId": request.params.flexiform_Id }));                
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http =  new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/flexiForm/updateDynamicInstance`;
                    http.post(url, 'updateDynamicInstance', request.body, (error, result) => {
                        if(error){
                            return callback(error, null);
                        }else {
                            const responseSchema = {"type":"object","properties":{"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"string"}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());                    
                        }
                    });
                }
            }
            catch (error) {
                callback(error, null);
            }
        };

    }
    return Flexiform;
};