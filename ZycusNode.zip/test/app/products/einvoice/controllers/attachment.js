/**
 * Attachment Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload'),
      rm = require('@service/require.module')();

module.exports = (parentClass) => {

    class Attachment extends parentClass {
        /*
       * addEntry Method
       * This method to make an entry into the attachment table by Product API call.
       */
        addEntry(request, result, callback) {
            try {
                const output = { errors: result.errors, files: result.files },
                    input = [];

                    let displayName;
                if (super.lodash.isEmpty(result.files) === false) {
                    result.files.forEach((file) => {
                        if (file.status === true) {
                             displayName = file.name.split(".")[0];
                            input.push({ "type": "0", "encoding": "UTF-8", "name": file.name, "fileSize": file.size , "displayName": displayName,"origin": "0"});
                        }
                    });
                    if (super.lodash.isEmpty(input) === false) {
                        const einvoice = new (super.einvoceHook({ request: request }))();
                        einvoice.addAttachment(request, input, (error, request, response) => {
                            if (error) {
                                return callback(error, output);
                            } else if (response) {
                                if (super.lodash.isEmpty(response.data) === false) {
                                    result.files.map((item) => {
                                        const fileDetails = (super.lodash.isArray(response.data)) ? super.lodash.find(response.data, { "info2": item.name }) : ( response.data);
                                        if (super.lodash.isEmpty(fileDetails) === false) {
                                            super.lodash.merge(item, fileDetails);
                                        } else {
                                            super.lodash.merge(item, { status: false });
                                        }
                                    });
                                }
                                if (super.lodash.isEmpty(response.errors) === false) {
                                    response.errors.forEach((error) => {
                                        output.errors.push({ "description": error });
                                    });
                                }
                                return callback(null, output);
                            }
                        });
                    } else {
                        return callback(null, output);
                    }
                } else {
                    return callback(null, output);
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    /*
    * fileUploadToSFTP Method
    * This method to upload file from tmp folder to sftp server.
    */
        fileUploadToSFTP(request, input, callback) {
            try {
                const result = input.result,
                    uploadService = input.uploadService,
                    output = { records: [], errors: result.errors, message: [], files: result.files };
                if (super.lodash.isEmpty(result.files) === false) {
                    super.async.eachSeries(result.files, (file, callback1) => {
                        if (file.status === true) {
                            let data = {
                                remoteFilePath: file.info1,
                                localFilePath: file.path,
                            };
                            //Upload file to the sftp server
                            uploadService.save(data, (error, response) => {
                                if (error) {
                                    output.errors.push({ "description": error });
                                } else if (response) {
                                    const filePath = file.info1 + '~' + file.name,
                                        filePathEncode = super.utils.encrypt(filePath, request.tokenId, true),
                                        replaceSlash = filePathEncode.replace(/\//g, "@"),
                                        record = {
                                            "id": file.id,
                                            "name": file.name,
                                            "path": replaceSlash,
                                            "size": file.size,
                                            "type": file.type,
                                            "modifiedBy": file.modifiedBy,
                                            "modifiedOn": file.modifiedOn
                                        };
                                    output.records.push(record);
                                    output.message.push({ description: super.utils.translate(request, "dd-msg-3", { fileName: file.name }) });
                                }
                                callback1();
                            });
                        } else {
                            callback1();
                        }
                    }, () => {
                        return callback(null, output);
                    });
                } else {
                    return callback(null, output);
                }
            } catch (error) {
                return callback(error, null);
            }
        }

    /*
    * finalOutput Method
    * This method to provide/perpare the final attachment outputs.
    */
        finalOutput(request, input, callback) {
            try {
                const results = input.results,
                    error = input.error,
                    uploadService = input.uploadService;

                //Delete file from tmp folder
                if (super.lodash.isEmpty(results.files) === false) {
                    results.files.forEach((file) => {
                        uploadService.unlink(file.path, () => { });
                    });
                }

                if (error) {
                    return callback(error, null);
                }

                if (results.errors.length && results.records.length == 0) {
                    return callback(results.errors, null);
                }

                let output = {
                    data: {
                        records: (results.records.length) ? results.records : undefined
                    },
                    message: (results.message.length) ? results.message : undefined,
                    errors: (results.errors.length) ? results.errors : undefined
                };

                return callback(null, request, output);
            } catch (error) {
                callback(error, null);
            }
        }

        /*
         * Create Method
         * Add attachment files.
         */
        create(request, input, callback) {
            try {
                const productSetting = super.productSetting(request),
                    modules = Object.keys(productSetting['modules']),
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "modulename": "joi.any().required().valid(" + JSON.stringify(modules) + ").label('einvoice-lable-26__')"
                    },
                    moduleName = request.headers.modulename;
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "modulename": moduleName });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting['modules'][moduleName]['attachment'],
                        options = { productName: request.productName },
                        uploadService = new (upload)(super.lodash.merge(moduleOptions, options));
                    super.async.waterfall([
                        (callback) => {
                            uploadService.fileUploadToServer(request, callback);
                        },
                        (result, callback) => {
                            uploadService.validateZipFile(request, result, callback);
                        },
                        (result, callback) => {
                            this.addEntry(request, result, callback);
                        },
                        (result, callback) => {
                            this.fileUploadToSFTP(request, { result: result, uploadService: uploadService }, callback)
                        }
                    ],
                        (error, results) => { //final method to provides the output details here.
                            return this.finalOutput(request, { error: error, results: results, uploadService: uploadService }, callback);
                        });
                }
            } catch (error) {
                return callback(error, null);
            }
        };


        /**
        * Delete method to delete the files
        */
        destroy(request, input, callback) {
            try {

                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "attachment_Id": "joi.string().required().label('einvoice-lable-27')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "attachment_Id": request.params.attachment_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const filePath = request.params.attachment_Id,
                        decodedPath = rm.utils.decrypt(filePath.replace(/@/g, "/"), request.tokenId, true);
                    if (decodedPath) {
                        const filePathSplit = decodedPath.split("~"),
                            path = filePathSplit[0],
                            options = { productName: request.productName },
                            deleteService = new (upload)(options);
                        deleteService.delete(path, (error, result) => {
                            if (error) {
                                if (error.code === 2) {
                                    const errorOutput = { message: "File not Found" }
                                    return callback(errorOutput, null);
                                }
                                return callback(error, null);
                            } else {
                                const output = { data: "File Deleted Successfully" };
                                return callback(null, request, output);
                            }
                        });
                    } else {
                        const errorMsg = new (super.customError)([{"message": "INVOICE-60042"}], 'ValidationError', 3);
                        return callback(errorMsg, null);
                    }
                }
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getDetails
        * @Description : Fetch/Get an Attachment Details
        * @return object / Throw Error
        */

        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "attachmentId": "joi.string().required().label('einvoice-lable-27__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "attachmentId": request.params.attachment_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/attachment/' + request.params.attachment_Id;
                    http.get(url, 'attachmentDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "attachmentId": { "type": "string" }, "referenceAttachmentId": { "type": "string" }, "name": { "type": "string" }, "encoding": { "type": "string" }, "fileSize": { "type": "number" }, "path": { "type": "filePathEncode" }, "type": { "type": "number" }, "visibility": { "type": "string" }, "comments": { "type": "string" }, "errorReasonsStr": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        download(request, input, callback) {
            try {
                const ddHook = new (super.ddHook({ request: request }))();
                ddHook.getFileStream(request, input, (error, response) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        return callback(null, request, { data: response });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        }

        /**
        * @Method Name : getList
        * @Description : Fetch/Get Attachment List Details
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                    validationUtility.addCommonSchema('pagination');
                    validationUtility.addCommonSchema('sort');
                    validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.eInvoice}/attachment/filter`;
                    http.post(url, 'attachmentList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records" : { "type":"array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "status": { "type": "number" }, "statusComments": { "type": "string" }, "archive": { "type": "boolean" }, "error": { "type": "boolean" }, "errorReasons": { "type": "none" }, "attachmentId": { "type": "string" }, "referenceAttachmentId": { "type": "string" }, "name": { "type": "string" }, "encoding": { "type": "string" }, "fileSize": { "type": "number" }, "path": { "type": "filePathEncode" }, "type": { "type": "number" }, "visibility": { "type": "string" }, "comments": { "type": "string" }, "displayName": { "type": "string" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "consumerId": { "type": "string" }, "origin": { "type": "number" }, "alreadyInvoiced": { "type": "boolean" }, "ocrParsedContent": { "type": "none" }, "ocrDocumentJson": { "type": "none" }, "ocrExtractedFieldsJson": { "type": "none" }, "documentMappings": { "type": "none" }, "statusDetails": { "type": "number" }, "checksum": { "type": "none" }, "data": { "type": "none" }, "version": { "type": "none" }, "additionalInfo": { "type": "none" }, "productid": { "type": "none" }, "refId": { "type": "none" }, "serviceCode": { "type": "none" }, "serviceProviderCode": { "type": "none" }, "callBackEndPoints": { "type": "none" }, "tpiDoc": { "type": "none" }, "tpiStatusComments": { "type": "none" }, "serviceRequestTrackingId": { "type": "none" }, "requestAccepted": { "type": "boolean" }, "tpiResponse": { "type": "none" }, "isExtract": { "type": "none" }, "kofaxResponse": { "type": "none" }, "attachmentErpId": { "type": "none" }, "errorReasonsStr": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                                output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Method Name : update
        * @Description : Update Attachment Details
        * @return object / Throw Error
        */
        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "moduleName": "joi.string().required().label('einvoice-lable-26__')",
                        "attachmentId": "joi.string().required().label('einvoice-lable-27__')",
                        "name": "joi.string().label('einvoice-lable-159__')",
                        "displayName": "joi.string().required().label('einvoice-lable-241__')",
                        "encoding": "joi.string().label('einvoice-lable-242__')",
                        "fileSize": "joi.number().label('einvoice-lable-243__')",
                        "type": "joi.number().label('einvoice-lable-193__')",
                        "origin": "joi.number().label('einvoice-lable-103__')",
                        "supplierId":"joi.string().label('einvoice-lable-19__')",
                        "supplierName":"joi.string().label('einvoice-lable-236__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "attachmentId": request.params.attachment_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/attachment/${request.body.moduleName.toUpperCase()}/update`;
                        delete request.body.moduleName;
                    http.post(url, 'updateAttachment', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return Attachment;
}