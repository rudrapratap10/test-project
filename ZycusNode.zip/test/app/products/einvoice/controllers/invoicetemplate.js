/**
 * Invoice Template Controller
 *
 * @description :: Provides invoice template related CRUD operation.
 */

module.exports = (parentClass) => 
{
    class InvoiceTemplate extends parentClass 
    {
        getList(request, input, callback) 
        {
            try 
            {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);

                if (result) 
                {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }
                else 
                {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                    einvoiceURL = request.productsURL.eInvoice,
                    url = einvoiceURL + '/invoiceTemplate/filter';
                    http.post(url, 'invoiceTemplateFilterList', request.body, (error, result) => 
                    {
                        if (error) 
                        {
                            callback(error, null);
                        }
                        else 
                        {
                                const utils = super.utils,
                                lodash = super.lodash,
                                output = {},
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'].records : [],
                                pagination = (!super.lodash.isEmpty(result['data'])) ? result['data'].pagination : {},
                                
                                // TODO : We need to change this.
                                responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"tenantId":{"type":"string"},"templateId":{"type":"string"},"requester":{"type":"string"},"autoInvoiceNo":{"type":"string"},"description":{"type":"string"},"lastExecutionTime":{"type":"none"},"nextExecutionTime":{"type":"none"},"supplierName":{"type":"string"},"supplierId":{"type":"string"},"docType":{"type":"none"},"referenceValue":{"type":"string"},"origin":{"type":"none"},"templateName":{"type":"string"},"status":{"type":"none"},"invoicedAmount":{"type":"number"},"countractNumber":{"type":"string"},"version":{"type":"none"},"requesterEmail":{"type":"string"},"designation":{"type":"string"},"suppCurrency":{"type":"string"},"supplieName":{"type":"string"},"comments":{"type":"string"},"grossTotalAmount":{"type":"number"},"postedOn":{"type":"none"},"approvedOn":{"type":"none"},"companyCode":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"createdOn":{"type":"none"},"createdBy":{"type":"string"},"neverExpire":{"type":"boolean"}}}}};
                                let companyCodes = [],
                                businessUnitCodes = [],
                                locationCodes = [];
                                if(!lodash.isEmpty(records) && lodash.isArray(records)) 
                                {  
                                    records.forEach(item => 
                                    {
                                        if(item.companyCode) companyCodes.push(item.companyCode);
                                        if(item.businessUnitCode) businessUnitCodes.push( item.businessUnitCode);
                                        if(item.locationCode) locationCodes.push( item.locationCode);
                                    });
                                    companyCodes = lodash.uniq(companyCodes);
                                    businessUnitCodes = lodash.uniq(businessUnitCodes);
                                    locationCodes = lodash.uniq(locationCodes);
                                }
                                else 
                                {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }
                                
                                const cmd = new (super.cmdHook({request: request}))(),
                                tasks = [
                                    (methodCallback) => {
                                        if (lodash.isEmpty(companyCodes)) 
                                        {
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 1 : Fetch company details 
                                        const reqData = { "codes": companyCodes, "pageNo":1 , "perPageRecords":companyCodes.length };
                                        cmd.getCompany(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.companyDetails = input.data.result || [];
                                        if (lodash.isEmpty(businessUnitCodes)) 
                                        {
                                            
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 2 : Fetch BusinessUnit details 
                                        const reqData = { "codes": businessUnitCodes,"pageNo":1 , "perPageRecords":businessUnitCodes.length  };
                                        cmd.getBusinessUnit(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        output.businessUnitDetails = input.data.result || [];
                                        if (lodash.isEmpty(locationCodes)) 
                                        {
                                            const output = (new (super.responseHandler)(request, result, responseSchema));
                                            output.addCommonSchema('pagination', output.responseSchema.properties);
                                            return callback(null, request, output.execute());
                                            //return methodCallback(request, {});
                                        }
                                        //Step 3 : Fetch Location details 
                                        const reqData = { "codes": locationCodes, "pageNo":1 , "perPageRecords":locationCodes.length  };
                                        cmd.getLocation(request, reqData, methodCallback);
                                    },                                    
                                    (request, input, methodCallback) => {
                                        output.locationDetails = input.data.result || [];    
                                        output.records = [];
                                        output.pagination = pagination;
                                        //Step 4 : Merge OU details to the response       
                                        //a) Company
                                        if (!lodash.isEmpty(output.companyDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.companyDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(records, extractProps, ["companyCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //b) Business Unit
                                         if (!lodash.isEmpty(output.businessUnitDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.businessUnitDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["businessUnitCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        //c) Location
                                        if (!lodash.isEmpty(output.locationDetails)) {
                                            const extractProps = utils.extractObjPropsFromArray(output.locationDetails, ["name", "code"]),
                                                  utilsMerge = utils.mergeArray(output.records, extractProps, ["locationCode", "code"]);
                                            output.records = utilsMerge;
                                        }
                                        return methodCallback(null, request, {"data": output});
                                    }, 
                                ];

                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {                                  
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    output.addCommonSchema('pagination', output.responseSchema.properties);
                                    return callback(null, request, output.execute());
                                }        
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

       /**
        * @name :: updateAction
        *
        * @description :: It Updates the Invoice based on actionName with Comments
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback response details
        */
        updateAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "actionName": "joi.string().required().valid('deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate').label('einvoice-lable-12__')",
                        "comments": "joi.string().when('actionName', { is: joi.string().valid('deleteInvoiceTemplate','activateInvoiceTemplate','deActivateInvoiceTemplate','recallInvoiceTemplate'), then: joi.required(), otherwise : joi.optional()}).label('einvoice-lable-13__')",
                        "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoicetemplate_Id}));
                
                if (result) 
                {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }
                else 
                {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        actionName = request.body.actionName,
                        url = einvoiceURL + '/invoiceTemplate/' +  request.params.invoicetemplate_Id + '/action/' + actionName,
                        requestBody = {comments: request.body.comments};                     
                    http.post(url, 'invoiceTemplateAction', requestBody, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        


        /**
        * @Name :: getInvoiceTemplateReleaseDetails
        *
        * @Description :: Fetch/Get a Invoice Release Details of a recurring template
        * 
        * @return/object/Throw Error
        */
       getInvoiceTemplateReleaseDetails(request, input, callback){
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {                        
                    "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                    "version": "joi.number().integer().label('einvoice-lable-18__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoicetemplate_Id}));              
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),                   
                    einvoiceURL = request.productsURL.eInvoice,
                    version = request.body.version,
                    url = einvoiceURL + '/invoiceTemplate/' + request.params.invoicetemplate_Id + '/' + version + '/releaseDetails';

                http.get(url, 'invoiceTemplateReleaseDetails', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const utils = super.utils,
                            lodash = super.lodash,
                            records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                            // TODO : We need to change the Schema
                            responseSchema = {"type":"array","properties":{"tenantId":{"type":"string"},"invoiceNo":{"type":"string"},"status":{"type":"number"},"invoiceAmount":{"type":"number"},"paidAmount":{"type":"number"},"issuedOn":{"type":"none"},"currancy":{"type":"string"}}}
                        let userDetails = [];
                        if (!lodash.isEmpty(records)) 
                        {
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        } 
                        else 
                        {
                            const output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    }
                });
            }
        } catch (error) {
            return callback(error, null);
        }
    };
    

        /**
        * @Name :: getInvoiceTemplateDetails
        *
        * @Description :: Fetch/Get a Invoice Details
        * 
        * @return/object/Throw Error
        */
        getInvoiceTemplateDetails(request, input, callback){
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {                        
                        "invoiceTemplateId": "joi.string().required().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                        "version": "joi.number().integer().label('einvoice-lable-18__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "invoiceTemplateId": request.params.invoicetemplate_Id}));              
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),                   
                        einvoiceURL = request.productsURL.eInvoice,
                        version = request.body.version,
                        url = einvoiceURL + '/invoiceTemplate/' + request.params.invoicetemplate_Id + '/' + version;

                    http.get(url, 'invoiceTemplateDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [],
                                
                                responseSchema = {"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"none"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"modifiedBy":{"type":"none"},"modifiedOn":{"type":"none"},"version":{"type":"number"},"templateId":{"type":"string"},"templateUniqueId":{"type":"string"},"templateOwner":{"type":"none"},"templateName":{"type":"string"},"buyer":{"type":"none"},"requester":{"type":"none"},"autoInvoiceNo":{"type":"string"},"sequence":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"},"description":{"type":"string"},"notes":{"type":"string"},"releaseScheduleId":{"type":"string"},"lastExecutionTime":{"type":"none"},"nextExecutionTime":{"type":"none"},"templateDate":{"type":"none"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"suppAddressId":{"type":"string"},"suppRemitToAddressId":{"type":"string"},"suppCurrency":{"type":"string"},"suppContact":{"type":"string"},"suppAddress":{"type":"string"},"supplierAddress":{"type":"none"},"supplierAddressRemit":{"type":"none"},"suppAddressRemit":{"type":"string"},"customerReferenceId":{"type":"string"},"extraCharges":{"type":"number"},"freightCharges":{"type":"number"},"insuranceCharges":{"type":"number"},"exciseDuties":{"type":"number"},"totalAmount":{"type":"number"},"grossTotalAmount":{"type":"number"},"taxAmount":{"type":"number"},"invoicedAmount":{"type":"number"},"submittedOn":{"type":"none"},"approvedOn":{"type":"none"},"closedOn":{"type":"none"},"baseCurrency":{"type":"string"},"baseExchangeRate":{"type":"number"},"baseTotal":{"type":"number"},"docType":{"type":"number"},"companyCode":{"type":"string"},"referenceValue":{"type":"string"},"referenceType":{"type":"number"},"splitCostingLevel":{"type":"number"},"splitCostingType":{"type":"number"},"origin":{"type":"number"},"suppErpid":{"type":"string"},"suppAddrErpid":{"type":"string"},"workflowId":{"type":"string"},"externalId":{"type":"string"},"erpId":{"type":"string"},"workflowInstanceId":{"type":"string"},"projectSettingStatus":{"type":"string"},"contractId":{"type":"string"},"contractNumber":{"type":"string"},"contractType":{"type":"number"},"suppPaymentTermId":{"type":"string"},"businessUnitCode":{"type":"string"},"locationCode":{"type":"string"},"billToCode":{"type":"string"},"invoiceToCode":{"type":"string"},"supplierRemitAddErpId":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"shipToLocation":{"type":"string"},"purchaseTypeSetting":{"type":"boolean"},"ptGLAccountSetting":{"type":"boolean"},"assignProject":{"type":"boolean"},"supplierTaxExempt":{"type":"string"},"discountLevel":{"type":"number"},"discountType":{"type":"number"},"discountValue":{"type":"number"},"applyNoTaxes":{"type":"boolean"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"attachments":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"none"},"createdOn":{"type":"none"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"attachmentId":{"type":"string"},"referenceAttachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"},"type":{"type":"number"},"visibility":{"type":"string"},"comments":{"type":"string"},"displayName":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"consumerId":{"type":"string"},"origin":{"type":"number"},"alreadyInvoiced":{"type":"boolean"},"ocrParsedContent":{"type":"string"},"ocrDocumentJson":{"type":"string"},"ocrExtractedFieldsJson":{"type":"string"},"statusDetails":{"type":"number"},"checksum":{"type":"string"},"data":{"type":"string"},"version":{"type":"string"},"additionalInfo":{"type":"string"},"productid":{"type":"string"},"refId":{"type":"string"},"serviceCode":{"type":"string"},"serviceProviderCode":{"type":"string"},"callBackEndPoints":{"type":"string"},"tpiDoc":{"type":"string"},"tpiStatusComments":{"type":"string"},"serviceRequestTrackingId":{"type":"string"},"requestAccepted":{"type":"boolean"},"tpiResponse":{"type":"string"},"isExtract":{"type":"string"},"kofaxResponse":{"type":"string"},"attachmentErpId":{"type":"string"},"errorReasonsStr":{"type":"string"}}},"taxes":{"type":"array","properties":{"templateId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"taxType":{"type":"string"},"taxName":{"type":"string"},"taxRate":{"type":"number"},"compound":{"type":"boolean"},"applicableFor":{"type":"number"},"taxableAmount":{"type":"number"},"taxAmount":{"type":"number"},"useTax":{"type":"boolean"},"borneByBuyerTaxAmount":{"type":"number"}}},"costings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"items":{"type":"array","properties":{"lineItemId":{"type":"string"},"templateId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"lineNo":{"type":"string"},"splitCostingType":{"type":"number"},"itemId":{"type":"string"},"invoicedQuantity":{"type":"number"},"marketPrice":{"type":"number"},"discountType":{"type":"number"},"discountValue":{"type":"number"},"discountedPrice":{"type":"number"},"discountAmount":{"type":"number"},"applyNoTaxes":{"type":"boolean"},"itemPrice":{"type":"number"},"itemTaxPrice":{"type":"number"},"itemTotalPrice":{"type":"number"},"attachments":{"type":"array","properties":{"tenantId":{"type":"string"},"createdBy":{"type":"none"},"createdOn":{"type":"string"},"status":{"type":"number"},"statusComments":{"type":"string"},"archive":{"type":"boolean"},"error":{"type":"boolean"},"errorReasons":{"type":"none"},"attachmentId":{"type":"string"},"referenceAttachmentId":{"type":"string"},"name":{"type":"string"},"encoding":{"type":"string"},"fileSize":{"type":"number"},"path":{"type":"filePathEncode"},"type":{"type":"number"},"visibility":{"type":"string"},"comments":{"type":"string"},"displayName":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"consumerId":{"type":"string"},"origin":{"type":"number"},"alreadyInvoiced":{"type":"boolean"},"ocrParsedContent":{"type":"string"},"ocrDocumentJson":{"type":"string"},"ocrExtractedFieldsJson":{"type":"string"},"documentMappings":{"type":"array","properties":{"tenantId":{"type":"string"},"attachmentId":{"type":"string"},"documentId":{"type":"string"},"docType":{"type":"number"},"status":{"type":"string"}}},"statusDetails":{"type":"number"},"checksum":{"type":"string"},"data":{"type":"string"},"version":{"type":"string"},"additionalInfo":{"type":"string"},"productid":{"type":"string"},"refId":{"type":"string"},"serviceCode":{"type":"string"},"serviceProviderCode":{"type":"string"},"callBackEndPoints":{"type":"string"},"tpiDoc":{"type":"string"},"tpiStatusComments":{"type":"string"},"serviceRequestTrackingId":{"type":"string"},"requestAccepted":{"type":"boolean"},"tpiResponse":{"type":"string"},"isExtract":{"type":"string"},"kofaxResponse":{"type":"string"},"attachmentErpId":{"type":"string"},"errorReasonsStr":{"type":"string"}}},"comments":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"contractType":{"type":"number"},"chargedLineAmount":{"type":"number"},"chargedLineTaxAmount":{"type":"number"},"chargedQuantity":{"type":"number"},"assetCode":{"type":"string"},"adjustedQuantity":{"type":"number"},"assetCodeType":{"type":"number"},"requesterId":{"type":"string"},"requesterName":{"type":"string"},"shipToCodeType":{"type":"number"},"shipToCode":{"type":"string"},"shipToLocation":{"type":"string"},"deliverToType":{"type":"number"},"deliverTo":{"type":"string"},"deliveryUpto":{"type":"string"},"deliveryOn":{"type":"string"},"catlogItem":{"type":"object","properties":{"scopeId":{"type":"string"},"catalogId":{"type":"string"},"catalogItemId":{"type":"number"},"catalogVersion":{"type":"number"},"itemId":{"type":"string"},"supplierId":{"type":"string"},"supplierName":{"type":"string"},"supplierPartId":{"type":"string"},"supplierAuxPartId":{"type":"string"},"supplierAddressId":{"type":"string"},"supplierAddress":{"type":"string"},"manufacturerPartId":{"type":"string"},"manufacturerName":{"type":"string"},"name":{"type":"string"},"description":{"type":"string"},"uom":{"type":"string"},"currency":{"type":"string"},"price":{"type":"number"},"marketPrice":{"type":"number"},"leadTime":{"type":"number"},"categoryCode":{"type":"string"},"categoryName":{"type":"string"},"unsspscCode":{"type":"string"},"unsspscName":{"type":"string"},"supplierProductURL":{"type":"string"},"manufacturerProductURL":{"type":"string"},"imageURL":{"type":"string"},"thumbnailURL":{"type":"string"},"sourceRefNo":{"type":"string"},"contractNo":{"type":"string"},"contractId":{"type":"string"},"sourceType":{"type":"number"},"itemType":{"type":"number"},"receiptType":{"type":"number"},"contractType":{"type":"number"},"error":{"type":"boolean"},"active":{"type":"boolean"},"hidden":{"type":"boolean"},"activity":{"type":"number"},"greenItem":{"type":"boolean"},"preferredItem":{"type":"boolean"},"validFrom":{"type":"string"},"validTo":{"type":"string"},"publishedOn":{"type":"string"},"attachments":{"type":"array","items":{"type":"string"}},"outOfStock":{"type":"boolean"},"systemAttributes":{"type":"none"},"itemAttributes":{"type":"none"},"itemErrors":{"type":"none"},"sourcingStatus":{"type":"number"},"externalId":{"type":"string"},"origin":{"type":"number"}}},"taxes":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"taxType":{"type":"string"},"taxName":{"type":"string"},"taxRate":{"type":"number"},"compound":{"type":"boolean"},"taxableAmount":{"type":"number"},"taxAmount":{"type":"number"},"useTax":{"type":"boolean"}}},"accountings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"accountingValue":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"purchaseTypeTemp":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"}}},"costings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"numebr"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"numebr"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"attachmentIds":{"type":"array"},"itemQuantity":{"type":"number"},"processEformId":{"type":"string"},"dynamicFormId":{"type":"string"},"dynamicInstanceId":{"type":"string"},"dynamicInstanceVersion":{"type":"numebr"},"coaflexiFormId":{"type":"string"},"coaflexiFormInstanceVersion":{"type":"number"},"coaflexiFormInstanceId":{"type":"string"},"attachmentsStr":{"type":"string"}}},"recurringSchedule":{"type":"object","properties":{"schedulerId":{"type":"string"},"templateId":{"type":"string"},"frequencyBy":{"type":"string"},"recurrancesOn":{"type":"none"},"interval":{"type":"none"},"startFrom":{"type":"none"},"endTo":{"type":"none"},"neverExpire":{"type":"boolean"},"previousFireTime":{"type":"none"},"nextFireTime":{"type":"none"},"finalFireTime":{"type":"none"},"recurranceMonthForYear":{"type":"none"},"activeFrom":{"type":"none"},"activeTill":{"type":"none"}}},"attachmentIds":{"type":"array"},"neverExpire":{"type":"boolean"},"selfAssessedAmt":{"type":"number"},"useTaxApplicable":{"type":"boolean"},"supplierBankId":{"type":"string"},"suppBankingDetails":{"type":"string"},"supplierBankingDetails":{"type":"none"},"newGrossTotalAmount":{"type":"number"},"applyTaxOnGrossTotal":{"type":"boolean"},"newTotalTaxAmount":{"type":"number"},"entitySettings":{"type":"none"},"grossContractTotalAmount":{"type":"number"},"result":{"properties":{"errorList":{"type":"array","properties":{"fieldName":{"type":"string"},"errorCode":{"type":"string"},"errorMessage":{"type":"string"},"errorParameters":{"type":"array"}}},"warningList":{"type":"array","properties":{"fieldName":{"type":"string"},"errorCode":{"type":"string"},"errorMessage":{"type":"string"},"errorParameters":{"type":"array"}}}}},"invoiceAccountings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"accountTypeCode":{"type":"string"},"generalLedgerCode":{"type":"string"},"accountingValue":{"type":"number"},"purchaseType":{"type":"string"},"purchaseTypeCode":{"type":"string"},"purchaseTypeTemp":{"type":"string"},"visibilityRule":{"type":"string"},"visibilityRuleStatus":{"type":"boolean"}}},"allTemplateCostings":{"type":"array","properties":{"templateId":{"type":"string"},"lineItemId":{"type":"string"},"position":{"type":"number"},"tenantId":{"type":"string"},"budgetId":{"type":"string"},"budgetLineId":{"type":"string"},"budgetLineTransactionId":{"type":"string"},"budgetBaseValue":{"type":"number"},"businessUnitCode":{"type":"string"},"costCenterCode":{"type":"string"},"costingValue":{"type":"number"},"projectCode":{"type":"string"},"splitValue":{"type":"number"},"unique":{"type":"string"}}},"validationResults":{"type":"string"},"attachmentsStr":{"type":"string"},"errorReasonsStr":{"type":"string"}}};
                            let userDetails = [];
                            if (!lodash.isEmpty(records)) 
                            {
                                if(records.buyer) userDetails.push(records.buyer);
                                if(records.requester) userDetails.push(records.requester);
                                if(records.createdBy) userDetails.push(records.createdBy);
                                if(records.templateOwner) userDetails.push(records.templateOwner);
                                if(records.modifiedBy) userDetails.push(records.modifiedBy);
                                                            
                                if(records.attachments && records.attachments)
                                {
                                    records.attachments.forEach(item =>{
                                        userDetails.push(item.createdBy);
                                    });
                                }
                                
                                // Add the createdBy ids of the users from the line level attachments
                                records.items.forEach(item => {
                                    if(!lodash.isEmpty(item.attachments))
                                    {
                                        item.attachments.forEach(item =>{
                                            userDetails.push(item.createdBy);
                                        });
                                    }
                                });
                              
                                
                                userDetails = lodash.uniq(userDetails);
                            } 
                            else 
                            {
                                const output = (new (super.responseHandler)(request, result, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            if (lodash.isEmpty(userDetails)) 
                            {
                                let output1 = [];
                                output1.push(records);
                                const output = (new (super.responseHandler)(request, { "data": output1 }, responseSchema));
                                return callback(null, request, output.execute());
                            }

                            const tms = new (super.tmsHook({ request: request }))(),
                                tasks = [                                                                       
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userDetails)) return methodCallback(request, {});
                                        const reqData = { "ids": userDetails };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            utils.mergeObject(records, extractProps, ["buyer", "id"]);
                                            utils.mergeObject(records, extractProps, ["requester", "id"]);
                                            utils.mergeObject(records, extractProps, ["templateOwner", "id"]);
                                            utils.mergeObject(records, extractProps, ["createdBy", "id"]);
                                            utils.mergeArray(records.attachments, extractProps, ["createdBy", "id"]);
                                          
                                            records.items.forEach(item => 
                                            {
                                                utils.mergeArray(item.attachments, extractProps, ["createdBy", "id"]);
                                            })                                           

                                            data.push(records);                                            
                                        }
                                        return methodCallback(null, request, { data });
                                    }
                                ];
                            super.async.waterfall(tasks, (error, request, result) => {
                                if (error) {
                                    return callback(error, null);
                                } else {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    // TODO : (HARSHAL) Are we populating the support object here ?
                                    //output.addCommonSchema('attachments', //output.responseSchema.properties.supportObjects.properties.attachments.properties);
                                    return callback(null, request, output.execute());
                                }
                            });
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: check if Invoice template Number Exists
        *
        * @Description :: Check if Invoice template Number Exists
        * 
        * @return/object/Throw Error
        */
        isExistsInvoiceTemplateNumber(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "recurringTemplateName": "joi.string().required().label('EINVOICE_BFF_TEMPLATE_NAME__')",
                        "supplierId": "joi.string().required().label('einvoice-lable-19__')",
                        "templateId": "joi.string().label('EINVOICE_BFF_INVOICE_TEMPLATE_ID__')",
                        "autoInvoiceNumber": "joi.string().label('einvoice-lable-14__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoiceTemplate/' + 'isExistsInvoiceTemplateNumber';
                    http.post(url, 'isInvoiceTemplateNumberExists', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "info1": { "type": "boolean" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Audit Trail By Id and Type
        *
        * @Description :: Audit Trail By Id and Type
        * 
        * @return/object/Throw Error
        */
        auditTrail(request, input, callback) 
        {
            try 
            {
                const validationUtility = super.utils.validationUtility(request),
                schema = {
                        "Id": "joi.string().required().label('einvoice-lable-66__')",
                        "entityType": "joi.string().required().label('einvoice-lable-67__')"
                    };
                
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "Id": request.params.invoicetemplate_Id }));
                
                if (result) 
                {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                }
                else 
                {
                    let userIds =[];
                    const http = new (super.httpService)(request),
                    einvoiceURL = request.productsURL.eInvoice,
                    entityType = request.body.entityType,
                    url = einvoiceURL + '/invoiceTemplate/' + request.params.invoicetemplate_Id + '/auditTrail/' + entityType;
                    http.get(url, 'auditTrail', (error, result) => 
                    {
                        const lodash = super.lodash;

                        if (error) 
                        {
                            return callback(error, null);
                        }
                        else 
                        {
                            const responseSchema = { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "autoId": { "type": "number" }, "auditTrailId": { "type": "string" }, "parentAuditTrailId":{"type":"string"}, "entityType":{"type":"string"}, "entityId":{"type":"string"}, "version":{"type":"number"}, "event":{"type":"string"}, "comments":{"type":"string"}, "attachmentIds":{"type":"none"}, "role":{"type":"string"}, "auditVariables":{"type":"none"}, "auditVariablesStr":{"type":"string"}, "attachmentsStr":{"type":"string"} } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                            
                            records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [];
                            
                            
                            if(!lodash.isEmpty(records) && lodash.isArray(records)) 
                            {
                                records.forEach(auditVar => 
                                {
                                    if(auditVar.createdBy) userIds.push(auditVar.createdBy);
                                });

                                userIds = lodash.uniq(userIds);
                            }
                            //return callback(null, request, output.execute());
                        }

                        const tms = new (super.tmsHook({ request: request }))(),
                        tasks = [                                                                       
                                    (methodCallback) => {
                                        if (lodash.isEmpty(userIds)) 
                                            return methodCallback(request, {});
                                        
                                        const reqData = { "ids": userIds };
                                        tms.getUsersDetails(request, reqData, methodCallback);
                                    },
                                    (request, input, methodCallback) => {
                                        let data = [];
                                        if (!lodash.isEmpty(input)) {
                                            const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                            records.forEach(auditVar => 
                                            {
                                                utils.mergeObject(auditVar, extractProps, ["createdBy", "id"]);
                                            })

                                            data.push(records);                                            
                                        }
                                        return methodCallback(null, request, { data });
                                    }
                                ];
                            super.async.waterfall(tasks, (error, request, result) => 
                            {
                                if (error) 
                                {
                                    return callback(error, null);
                                }
                                
                                else 
                                {
                                    const output = (new (super.responseHandler)(request, result, responseSchema));
                                    return callback(null, request, output.execute());
                                }
                            });
                    });
                }
            } 
            catch (error) 
            {
                return callback(error, null);
            }
        };

        /**
        * @Name :: Create
        *
        * @Description :: Create invoiceTemplate
        * 
        * @return/object/Throw Error
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request); 
                const schema = {
                    "actionName": "joi.string().valid('draft','submit').required().label('einvoice-lable-12__')",                
                    "recurringContract": `joi.object().keys({
                        purchaseOrderNumber: joi.string().label('einvoice-lable-234__'),
                        referenceValue: joi.string().label('einvoice-lable-99__'),
                        createdBy: joi.string().required().label('einvoice-lable-227__'),
                        createdOn: joi.number().required().label('einvoice-lable-228__'),
                        status: joi.number().label('einvoice-lable-291__'),
                        templateOwner: joi.string().label('einvoice-lable-292__'),
                        templateName: joi.string().label('einvoice-lable-293__'),
                        autoInvoiceNo: joi.string().label('einvoice-lable-295__'),
                        sequence: joi.number().label('einvoice-lable-296__'),
                        visibilityRuleStatus: joi.boolean().label('einvoice-lable-297__'),
                        notes: joi.string().allow('').label('einvoice-lable-298__'),
                        releaseScheduleId: joi.string().label('einvoice-lable-299__'),
                        lastExecutionTime: joi.number().label('einvoice-lable-300__'),
                        nextExecutionTime: joi.number().label('einvoice-lable-301__'),
                        suppAddress: joi.string().label('einvoice-lable-303__'),
                        suppAddressRemit: joi.string().label('einvoice-lable-304__'),
                        invoicedAmount: joi.number().label('einvoice-lable-305__'),
                        suppPaymentTermId: joi.string().label('einvoice-lable-306__'),
                        recurringSchedule: joi.string().label('einvoice-lable-307__'),
                        neverExpire: joi.boolean().label('einvoice-lable-64__'),
                        suppBankingDetails: joi.string().label('einvoice-lable-308__'),
                        grossContractTotalAmount: joi.string().label('einvoice-lable-309__'),
                        tenantId: joi.string().required().label('einvoice-lable-229__'),
                        templateId: joi.string().label('einvoice-lable-61__'),
                        externalId: joi.string().label('einvoice-lable-230__'),
                        templateUniqueId: joi.string().label('einvoice-lable-294__'),
                        templateDate: joi.number().label('einvoice-lable-302__'),
                        supplierId: joi.string().required().label('einvoice-lable-19__'),
                        supplierName: joi.string().required().label('einvoice-lable-236__'),
                        supplierAddressId: joi.string().required().label('einvoice-lable-237__'),
                        supplierAddressIdRemit: joi.string().required().label('einvoice-lable-238__'),
                        suppCurrency: joi.string().required().label('einvoice-lable-239__'),
                        discountLevel: joi.number().required().label('einvoice-lable-87__'),
                        discountType: joi.number().required().label('einvoice-lable-88__'),
                        baseCurrency: joi.string().required().label('einvoice-lable-95__'),
                        baseExchangeRate: joi.number().required().label('einvoice-lable-96__'),
                        baseTotal: joi.number().required().label('einvoice-lable-97__'),
                        companyCode: joi.string().required().label('einvoice-lable-34__'),
                        splitCostingLevel: joi.number().required().label('einvoice-lable-101__'),
                        splitCostingType: joi.number().required().label('einvoice-lable-102__'),
                        referenceType: joi.number().required().label('einvoice-lable-51__'),
                        origin: joi.number().required().label('einvoice-lable-103__'),
                        businessUnitCode: joi.string().required().label('einvoice-lable-35__'),
                        locationCode: joi.string().required().label('einvoice-lable-20__'),
                        billToCode: joi.string().required().label('einvoice-lable-135__'),
                        invoiceToCode: joi.string().required().label('einvoice-lable-112__'),
                        newGrossTotalAmount: joi.number().required().label('einvoice-lable-118__'),
                        newTotalTaxAmount: joi.number().required().label('einvoice-lable-119__'),
                        purchaseType: joi.string().label('einvoice-lable-49__'),
                        paymentTermId: joi.string().label('einvoice-lable-110__'),
                        epDiscDueDate: joi.number().label('einvoice-lable-122__'),
                        coaFlexiFormId: joi.string().label('einvoice-lable-44__'),
                        coaFlexiFormInstanceId: joi.string().label('einvoice-lable-43__'),
                        entitySetting: joi.string().label('einvoice-lable-125__'),
                        coaFlexiFormInstanceVersion: joi.number().label('einvoice-lable-123__'),
                        shouldSubmit: joi.boolean().label('einvoice-lable-98__'),
                        statusComments: joi.string().label('einvoice-lable-226__'),
                        comments: joi.string().label('einvoice-lable-13__'),
                        description: joi.string().allow('').label('einvoice-lable-233__'),
                        buyer: joi.string().label('einvoice-lable-235__'),
                        contractOwner: joi.string().label('einvoice-lable-62__'),
                        contractName: joi.string().required().label('einvoice-lable-311__'),
                        suppContact: joi.string().label('einvoice-lable-240__'),
                        discountValue: joi.number().label('einvoice-lable-89__'),
                        extraCharges: joi.number().label('einvoice-lable-90__'),
                        freightCharges: joi.number().label('einvoice-lable-91__'),
                        insuranceCharges: joi.number().label('einvoice-lable-92__'),
                        exciseDuties: joi.number().label('einvoice-lable-93__'),
                        submittedOn: joi.number().label('einvoice-lable-94__'),
                        suppErpid: joi.string().label('einvoice-lable-104__'),
                        suppAddrErpid: joi.string().label('einvoice-lable-105__'),
                        erpId: joi.string().label('einvoice-lable-106__'),
                        workflowId: joi.string().label('einvoice-lable-28__'),
                        workflowInstanceId: joi.string().label('einvoice-lable-29__'),
                        processEformId: joi.string().label('einvoice-lable-107__'),
                        dynamicFormId: joi.string().label('einvoice-lable-108__'),
                        dynamicInstanceId: joi.string().label('einvoice-lable-109__'),
                        supplierRemitAddressERPId: joi.string().label('einvoice-lable-114__'),
                        shipToCodeType: joi.number().label('einvoice-lable-115__'),
                        shipToCode: joi.string().label('einvoice-lable-116__'),
                        shipToLocation: joi.string().label('einvoice-lable-117__'),
                        supplierBankingDetailsId: joi.string().allow('').label('einvoice-lable-120__'),
                        visibilityRule: joi.string().allow('').label('einvoice-lable-121__'),
                        customerReferenceId: joi.string().allow('').label('einvoice-lable-124__'),
                        requester: joi.string().label('einvoice-lable-132__'),
                        dueDate: joi.number().label('einvoice-lable-126__'),
                        matchStatus: joi.number().label('einvoice-lable-127__'),
                        matchedOn: joi.number().label('einvoice-lable-128__'),
                        sendToReadyForApproval: joi.boolean().label('einvoice-lable-129__'),
                        deliverTo: joi.string().label('einvoice-lable-130__'),
                        submitForCodingUserId: joi.string().label('einvoice-lable-131__'),
                        originId: joi.string().label('einvoice-lable-133__'),
                        originType: joi.string().label('einvoice-lable-134__'),
                        recurringSchedule: joi.object().keys({ 
                            schedulerId: joi.string().label('einvoice-lable-312__'),
                            templateId: joi.string().label('einvoice-lable-61__'),
                            frequencyBy: joi.string().required().label('einvoice-lable-313__'),
                            recurrancesOn: joi.number().required().label('einvoice-lable-314__'),
                            interval: joi.number().required().label('einvoice-lable-315__'),
                            startFrom: joi.number().required().label('einvoice-lable-316__'),
                            endTo: joi.number().label('einvoice-lable-317__'),
                            neverExpire : joi.boolean().required().label('einvoice-lable-64__'),
                            previousFireTime: joi.number().required().label('einvoice-lable-318__'),
                            nextFireTime: joi.number().required().label('einvoice-lable-319__'),
                            finalFireTime: joi.number().required().label('einvoice-lable-320__'),
                            recurranceMonthForYear: joi.number().required().label('einvoice-lable-321__'),
                            activeFrom: joi.number().required().label('einvoice-lable-35__'),
                            activeTill: joi.number().required().label('einvoice-lable-35__'),
                        }).label('einvoice-lable-201__'),
                        attachmentIds: joi.array().items(
                            joi.string().label('einvoice-lable-27__')
                        ).label('einvoice-lable-113__'),
                    }).label('einvoice-lable-225__')`,             
                    "costings": `joi.array().items(
                        joi.object().keys({
                            lineItemId: joi.string().label('einvoice-lable-35__'),
                            businessUnitCode: joi.string().label('einvoice-lable-35__'),
                            costCenterCode: joi.string().label('einvoice-lable-203__'),
                            projectCode: joi.string().label('einvoice-lable-204__'),
                            value: joi.number().label('einvoice-lable-205__'),
                            splitValue: joi.number().label('einvoice-lable-206__'),
                        }).label('einvoice-lable-201__')
                    ).label('einvoice-lable-201__')`,             
                    "headerTaxes": `joi.array().items(
                        joi.object().keys({
                            type: joi.string().required().label('einvoice-lable-193__'),
                            compound: joi.boolean().required().label('einvoice-lable-209__'), 
                            useTax: joi.boolean().label('einvoice-lable-196__'),
                            name: joi.string().required().label('einvoice-lable-159__'),
                            rate: joi.number().required().label('einvoice-lable-194__'),
                            taxAmount: joi.number().required().label('einvoice-lable-195__'),                     
                            taxableAmount: joi.number().required().label('einvoice-lable-197__'),
                            applicableFor: joi.number().required().label('einvoice-lable-210__'),                                            
                            borneByBuyerCheck: joi.boolean().label('einvoice-lable-310__'),                                            
                        }).label('einvoice-lable-207__')
                    ).label('einvoice-lable-207__')`,          
                    "accountings": `joi.array().items(
                        joi.object().keys({    
                            accountTypeCode: joi.string().required().label('einvoice-lable-47__'),
                            generalLedgerCode: joi.string().required().label('einvoice-lable-214__'),
                            value: joi.number().label('einvoice-lable-205__'),
                            purchaseType: joi.string().label('einvoice-lable-49__'),
                            purchaseTypeCode: joi.string().label('einvoice-lable-215__'),
                            visibilityRule: joi.string().allow('').label('einvoice-lable-121__'),
                        }).label('einvoice-lable-211__')
                    ).label('einvoice-lable-211__')`,           
                    "items": `joi.array().items(
                        joi.object().keys({     
                            purchaseOrderId: joi.string().label('einvoice-lable-21__'),
                            poLineNo: joi.string().allow('').label('einvoice-lable-140__'),
                            coaFlexiFormId: joi.string().label('einvoice-lable-44__'),
                            coaFlexiFormInstanceId: joi.string().label('einvoice-lable-43__'),                   
                            coaFlexiFormInstanceVersion: joi.number().label('einvoice-lable-123__'),
                            lineItemId: joi.string().label('einvoice-lable-138__'),
                            requisitionId: joi.string().label('einvoice-lable-50__'),
                            deliveryOn: joi.number().label('einvoice-lable-184__'),
                            deliveryUpto: joi.number().label('einvoice-lable-185__'),
                            chargedLineAmount: joi.number().label('einvoice-lable-186__'),
                            chargedLineTaxAmount: joi.number().label('einvoice-lable-187__'),
                            chargedQuantity: joi.number().label('einvoice-lable-188__'),
                            adjustedQuantity: joi.number().label('einvoice-lable-189__'),
                            requesterId: joi.string().label('einvoice-lable-54__'),
                            deliverToType: joi.number().label('einvoice-lable-190__'),
                            lineNo: joi.string().required().label('einvoice-lable-139__'),                            
                            itemQuantity: joi.number().required().label('einvoice-lable-141__'),                            
                            marketPrice: joi.number().required().label('einvoice-lable-142__'),                            
                            discountType: joi.number().required().label('einvoice-lable-88__'),                            
                            discountValue: joi.number().label('einvoice-lable-89__'),                            
                            itemPrice: joi.number().required().label('einvoice-lable-143__'),                            
                            itemTaxPrice: joi.number().required().label('einvoice-lable-144__'),                            
                            applyNoTaxes: joi.boolean().label('einvoice-lable-145__'),                            
                            itemTotalPrice: joi.number().required().label('einvoice-lable-198__'),                            
                            splitCostingType: joi.number().required().label('einvoice-lable-102__'),                             
                            itemComment: joi.string().label('einvoice-lable-146__'),                            
                            attachmentIds: joi.array().items(
                                joi.string().label('einvoice-lable-185__')
                            ).label('einvoice-lable-100__'),                            
                            contractNo: joi.string().label('einvoice-lable-147__'), 
                            contractId: joi.string().label('einvoice-lable-22__'), 
                            contractType: joi.number().label('einvoice-lable-148__'), 
                            assetCode: joi.string().label('einvoice-lable-149__'), 
                            assetCodeType: joi.number().label('einvoice-lable-150__'), 
                            shipToCodeType: joi.number().label('einvoice-lable-115__'), 
                            shipToCode: joi.string().label('einvoice-lable-116__'), 
                            shipToLocation: joi.string().label('einvoice-lable-117__'), 
                            processEformId: joi.string().label('einvoice-lable-107__'), 
                            dynamicFormId: joi.string().label('einvoice-lable-108__'), 
                            dynamicInstanceId: joi.string().label('einvoice-lable-109__'), 
                            dynamicInstanceVersion: joi.number().label('einvoice-lable-151__'), 
                            selfAssessedTaxAmt: joi.number().required().label('einvoice-lable-152__'),  
                            catalogItem: joi.object().keys({
                                itemId: joi.string().label('einvoice-lable-155__'),
                                name: joi.string().required().label('einvoice-lable-159__'),
                                uom: joi.string().required().label('einvoice-lable-160__'),
                                categoryCode: joi.string().required().label('einvoice-lable-161__'),
                                unsspscCode: joi.string().required().label('einvoice-lable-163__'),
                                sourceType: joi.number().required().label('einvoice-lable-171__'),
                                receiptType: joi.number().required().label('einvoice-lable-173__'),
                                catalogId: joi.string().label('einvoice-lable-154__'),
                                supplierPartId: joi.string().allow('').label('einvoice-lable-156__'),
                                manufacturerPartId: joi.string().allow('').label('einvoice-lable-157__'),
                                manufacturerName: joi.string().allow('').label('einvoice-lable-158__'),
                                description: joi.string().allow('').label('einvoice-lable-233__'),
                                leadTime: joi.number().label('einvoice-lable-167__'),
                                categoryName: joi.string().label('einvoice-lable-162__'),
                                unsspscName: joi.string().label('einvoice-lable-164__'),
                                supplierProductURL: joi.string().label('einvoice-lable-165__'),
                                manufacturerProductURL: joi.string().allow('').label('einvoice-lable-166__'),
                                imageURL: joi.string().label('einvoice-lable-168__'),
                                thumbnailURL: joi.string().label('einvoice-lable-169__'),
                                sourceRefNo: joi.string().allow('').label('einvoice-lable-170__'),
                                contractNo: joi.string().label('einvoice-lable-147__'),
                                contractId: joi.string().label('einvoice-lable-22__'),
                                itemType: joi.number().label('einvoice-lable-172__'),
                                contractType: joi.number().label('einvoice-lable-164__'),
                                active: joi.boolean().label('einvoice-lable-174__'),
                                hidden: joi.boolean().label('einvoice-lable-175__'),
                                activity: joi.number().label('einvoice-lable-176__'),
                                greenItem: joi.boolean().label('einvoice-lable-177__'),
                                preferredItem: joi.boolean().label('einvoice-lable-178__'),
                                validFrom: joi.number().label('einvoice-lable-179__'),
                                validTo: joi.number().label('einvoice-lable-180__'),
                                publishedOn: joi.number().label('einvoice-lable-181__'),
                                attachments: joi.array().items(
                                    joi.string().label('einvoice-lable-174__')
                                ).label('einvoice-lable-199__'),
                                outOfStock: joi.boolean().label('einvoice-lable-182__'),
                                sourcingStatus: joi.number().label('einvoice-lable-183__'),                            
                            }),                       
                            itemTaxes: joi.array().items(
                                joi.object().keys({
                                    type: joi.string().required().label('einvoice-lable-193__'),
                                    name: joi.string().required().label('einvoice-lable-159__'),
                                    rate: joi.number().required().label('einvoice-lable-194__'),
                                    taxAmount: joi.number().required().label('einvoice-lable-195__'),
                                    useTax: joi.boolean().label('einvoice-lable-196__'),
                                    taxableAmount: joi.number().required().label('einvoice-lable-197__'),
                                    borneByBuyerCheck: joi.boolean().label('einvoice-lable-310__')
                                })
                            ).label('einvoice-lable-191__'),
                        })).label('einvoice-lable-136__')`
                    
                };    
                validationUtility.addInternalSchema(schema);               
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/invoiceTemplate/create/${request.body.actionName}`;
                        delete request.body.actionName;
                        http.post(url, 'createInvoiceTemplate', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "number" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute())
                           
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return InvoiceTemplate;
};