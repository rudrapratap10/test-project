/**
 * Mailbox Controller
 *
 * @description :: Provides mailbox related CRUD operation.
 */

module.exports = (parentClass) => {

    class Mailbox extends parentClass {

        /**
        * @name :: getList
        *
        * @description :: provides the mailbox list
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback mailbox list details
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/invoice/mailbox/filter';
                    http.post(url, 'eMailboxListing', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "none" }, "status": { "type": "number" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "none" }, "invoiceId": { "type": "string" }, "invoiceUniqueId": { "type": "string" }, "invoiceNumber": { "type": "string" }, "invoiceDate": { "type": "none" }, "description": { "type": "string" }, "purchaseOrderNumber": { "type": "string" }, "supplierId": { "type": "string" }, "supplierName": { "type": "string" }, "supplierCurrency": { "type": "string" }, "totalAmount": { "type":"none" }, "grossTotalAmount": { "type": "none" }, "baseCurrency": { "type": "string" }, "baseTotal": { "type": "number" }, "docType": { "type": "number" }, "docTypeDesc": { "type": "string" }, "origin": { "type": "number" }, "paymentTermId": { "type": "string" }, "requestEdit": { "type": "boolean" }, "epDiscountDueDate": { "type": "none" }, "epDiscountedAmount": { "type": "none" }, "newGrossTotalAmount": { "type": "none" }, "dueDate": { "type": "none" }, "paymentStatus": { "type": "number" }, "invoiceType": { "type": "number" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return Mailbox;
}