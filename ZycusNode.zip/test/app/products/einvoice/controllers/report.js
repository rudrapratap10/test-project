/**
 * Report Controller
 *
 * @description :: Provides Report related CRUD operation.
 */

module.exports = (parentClass) => {

    class Report extends parentClass {

        /**
        * @Name : generateAPReport
        * @Description : It is used to generate AP Report Details
        * @return : object / Throw Error
        */
        generateAPReport(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "criteriaBasedOn": "joi.string().required().allow('').label('einvoice-lable-285__')",
                        "fromDate": "joi.string().required().allow('').label('einvoice-lable-282__')",
                        "toDate": "joi.string().required().allow('').label('einvoice-lable-283__')",
                        "lastMonths": "joi.string().required().allow('').label('einvoice-lable-286__')",
                        "lastYears": "joi.string().required().allow('').label('einvoice-lable-287__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/report/generateAPReport`;
                    http.post(url, 'getReportDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            }
            catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : getDetails
        * @Description : It is used to Get Report Details by passing No of entries
        * @return : object / Throw Error
        */
       getDetails(request, input, callback) {
        try {
            const validationUtility = super.utils.validationUtility(request),
                schema = {
                    "noOfEntries": "joi.number().required().label('einvoice-lable-288__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate({noOfEntries:request.params.report_Id});
            if (result) {
                const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                callback(errorMsg, null);
            } else {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.eInvoice}/report/getAPReportDetails/${request.params.report_Id}`;
                http.get(url, 'getReportDetails', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = {"type":"array","properties":{"reportId":{"type":"string"},"tenantId":{"type":"string"},"userId":{"type":"string"},"criteriaBasedOn":{"type":"string"},"status":{"type":"string"},"reportCriteria":{"type":"string"},"createdOn":{"type":"number"},"updatedOn":{"type":"number"},"filePath":{"type":"string"},"fileName":{"type":"string"}}},
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            }
        }
        catch (error) {
            callback(error, null);
        }
    };

    }
    return Report;
};