/**
 * User Controller
 *
 * @description :: Provides user related CRUD operation.
 */

module.exports = (parentClass) => {

    class User extends parentClass {

        /**
        * @name :: getList
        *
        * @description :: based on user role(buyer/requester) provides the user list
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback buyer/requester details
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "userRole": "joi.string().valid('requestor','buyer').required().label('einvoice-lable-11__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/user/filter/' + request.body.userRole;
                    delete request.body.userRole;
                    http.post(url, 'BuyerorRequesterList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = {"type":"object","properties":{"records":{"type":"array","properties":{"userId":{"type":"string","key":"Id"},"emailId":{"type":"string"},"displayName":{"type":"string"},"firstName":{"type":"string"},"lastName":{"type":"string"},"designation":{"type":"string"},"department":{"type":"string"},"active":{"type":"boolean"},"tenantId":{"type":"string"},"erpId":{"type":"string"}}}}},
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @name :: getUserScopesList
        *
        * @description :: based on user Scope(Company_Code/BusinessUnit_Code/Location_Code) provides the user list
        *
        * @param1 :: request object
        * @param2 :: input object
        * @return/callback Users Scopes List details
        */
        scopeList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        einvoiceURL = request.productsURL.eInvoice,
                        url = einvoiceURL + '/user/scopes/filter/';
                    http.post(url, 'UserScopesList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "tenantId": { "type": "string" }, "createdBy": { "type": "string" }, "createdOn": { "type": "number" }, "requestUserId": { "type": "string" }, "emailAddress": { "type": "string" }, "salutation": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "displayName": { "type": "string" }, "name": { "type": "string" }, "controlCurrency": { "type": "string" }, "spendLimit": { "type": "number" }, "approvalLimit": { "type": "number" }, "invoiceApprovalLimit": { "type": "number" }, "companyCode": { "type": "string" }, "businessUnitCode": { "type": "string" }, "locationCode": { "type": "string" }, "costCenterCode": { "type": "string" }, "purchasingScopeCode": { "type": "string" }, "reportingManagerId": { "type": "string" }, "designation": { "type": "string" }, "department": { "type": "string" }, "deliveryScope": { "type": "string" }, "behalfScope": { "type": "string" }, "active": { "type": "boolean" }, "erpId": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Name : updateConfig
        * @Description : It is used to Update User Config Details
        * @return : object / Throw Error
        */
        updateConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = { 
                        "EPROC_APPROVAL_DELEGATION": `joi.object().keys({
                            FROM_DATE: joi.string().label('einvoice-lable-282__'),
                            TO_DATE: joi.string().label('einvoice-lable-283__'),
                            USER_ID: joi.string().label('einvoice-lable-284__')
                        }).allow('').label('einvoice-lable-281__')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/user/updateUserConfig`;
                    http.post(url, 'updateUserConfig', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            }
            catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Name : getConfig
        * @Description : It is used to Get User Config Details
        * @return : object / Throw Error
        */
        getConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = { "configkeys": "joi.array().items(joi.string()).unique().label('einvoice-lable-1__')" };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.eInvoice}/user/gateUserConfig`;
                    http.post(url, 'getUserConfig', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const utils = super.utils,
                                lodash = super.lodash,
                                records = (!super.lodash.isEmpty(result['data'])) ? result['data'] : [];
                            if (!lodash.isEmpty(records)) {
                                const record = JSON.parse(records.EPROC_APPROVAL_DELEGATION);
                                let userDetails = [];
                                if (record.USER_ID) userDetails.push(record.USER_ID);
                                userDetails = lodash.uniq(userDetails);
                                if (lodash.isEmpty(userDetails)) {
                                    return callback(null, request, { "data": record });
                                }

                                const tms = new (super.tmsHook({ request: request }))(),
                                    tasks = [
                                        (methodCallback) => {
                                            tms.getUsersDetails(request, { "ids": userDetails }, methodCallback);
                                        },
                                        (request, input, methodCallback) => {
                                            let data = [];
                                            if (!lodash.isEmpty(input)) {
                                                const extractProps = utils.extractObjPropsFromArray(input, ["id", "firstName", "lastName"]);
                                                utils.mergeObject(record, extractProps, ["USER_ID", "id"]);
                                                data.push(record);
                                            }
                                            return methodCallback(null, request, data);
                                        }
                                    ];

                                super.async.waterfall(tasks, (error, request, result) => {
                                    if (error) {
                                        return callback(error, null);
                                    } else {
                                        return callback(null, request, { "data": result });
                                    }
                                });
                            }
                            else {
                                return callback(null, request, result);
                            }
                        }
                    });
                }
            }
            catch (error) {
                callback(error, null);
            }
        };
    }

    return User;
}