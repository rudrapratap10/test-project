"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/screenlabels/getLabels:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get UI Labels
    *     operationId: getLabels
    *     description: Get UI Labels (from UI Config Sheet) for Authoring Contract Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the Labels ( Based on Label ID ).
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               labelId:
    *                   type: string
    *           required: [labelId]
    *     responses:
    *       200:
    *         description: successful operation
    */    
   getLabels: {
    pre: null,
    process: "screenlabel.getLabels",
    post: null,
    method: 'POST'
    }
};