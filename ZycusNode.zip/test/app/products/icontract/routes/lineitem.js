"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/lineItems/downloadReferenceSheet:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: download Reference Sheet
    *     operationId: ReferenceSheet
    *     description: download Reference Sheet
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadReferenceSheet: {
        pre: null,
        process: "lineitem.downloadReferenceSheet",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/lineItems/{searchKey}/searchKey:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Line Item Categories Auto Suggest
    *     operationId: searchKey
    *     description: Get Line Item Categories Auto Suggest
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: searchKey
    *         description: Provide a Search Key.
    *         in: path
    *         required: true
    *         type: number
    *     responses:
    *       200:
    *         description: successful operation
    */
    searchKey: {
        pre: null,
        process: "lineitem.searchKey",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/lineItems/bulkUploadStatus:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get status of the 'bulk upload for line item'
    *     operationId: bulkUploadStatus
    *     description: Get status of the 'bulk upload for line item'
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get status of the 'bulk upload for line item'
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               contentType:
    *                 type: string
    *               fileName:
    *                 type: string
    *               content:
    *                 type: string
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               failureCount:
    *                 type: number
    *               mode:
    *                 type: string
    *               module:
    *                 type: string               
    *           required: [fileName]
    *     responses:
    *       200:
    *         description: successful operation
    */
    bulkUploadStatus: {
        pre: null,
        process: "lineitem.bulkUploadStatus",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/lineItems/getFields:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: get line items Fields
    *     operationId: getFields
    *     description: getFields
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get status of the 'bulk upload for line item'
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               isAuthoring:
    *                 type: boolean
    *               contractId:
    *                 type: string              
    *               lineItemId:
    *                 type: string              
    *           required: [isAuthoring,contractId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getFields: {
        pre: null,
        process: "lineitem.getFields",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/lineItems:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete Lineitem
    *     operationId: delete
    *     description: Delete Lineitem
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delete Lineitem
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               lineItemIds:
    *                 type: array                          
    *                 items:
    *                   type: string
    *               lineItemId:
    *                 type: string                          
    *               isAuthoring:
    *                 type: boolean                          
    *               contractId:
    *                 type: string              
    *           required: [isAuthoring,contractId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "lineitem.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/lineItems:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Create Lineitem
    *     operationId: Create
    *     description: Create Lineitem
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create Lineitem
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               isAuthoring:
    *                 type: string                          
    *               lineItem:
    *                 type: object              
    *                 properties:
    *                   lineItemNumber:
    *                     type: string
    *                   id:
    *                     type: string
    *                   description:
    *                     type: string
    *                   pricingType:
    *                     type: object                 
    *                     properties:
    *                       id:
    *                         type: string
    *                       pricingType:
    *                         type: string
    *                   uom:
    *                     type: object                 
    *                     properties:
    *                       id:
    *                         type: string
    *                       unitOfMeasurement:
    *                         type: string
    *                       status:
    *                         type: number
    *                       sequence:
    *                         type: number
    *                   quantity:
    *                     type: number                                     
    *                   category:
    *                     type: string                                     
    *                   currency:
    *                     type: object                                                                        
    *                     properties:
    *                       id:
    *                         type: string
    *                       currency:
    *                         type: string
    *                       status:
    *                         type: boolean
    *                   priceType:
    *                     type: string                                                                        
    *                   cost:
    *                     type: number                                                                        
    *                   field_1:
    *                     type: string                                                                        
    *                   field_2:
    *                     type: string                                                                        
    *                   field_3:
    *                     type: string                                                                        
    *                   field_4:
    *                     type: string                                                                        
    *                   field_5:
    *                     type: string                                                                        
    *                   field_6:
    *                     type: string                                                                        
    *                   field_7:
    *                     type: string                                                                        
    *                   field_8:
    *                     type: string                                                                        
    *                   field_9:
    *                     type: string                                                                        
    *                   field_10:
    *                     type: string                                                                        
    *                   status:
    *                     type: boolean                                                                        
    *               lineItemId:
    *                 type: string
    *               lineItemPricingTypeDTO:
    *                 type: object
    *                 properties:
    *                   pricingType:
    *                     type: string
    *                   lineItemPricingType:
    *                     type: object
    *                     properties:
    *                       volumeBasedDiscountPricingDetails:
    *                         type: array
    *                         items:
    *                           type: object
    *                           properties:
    *                             slabLowerLimit:
    *                               type: string
    *                             slabUpperLimit:
    *                               type: string
    *                             basePrice:
    *                               type: string
    *                             discount:
    *                               type: string
    *               lineItemPricingTypeId:
    *                 type: string
    *               contractId:
    *                 type: string
    *               edit:
    *                 type: boolean
    *           required: [isAuthoring,lineItem,lineItemId,contractId,edit]
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "lineitem.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/lineItems/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get line item Paginated List API
    *     operationId: linitem List
    *     description: Get line item Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get line item Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - type: object
    *               properties:
    *                 contractId:
    *                   type: string
    *               required: [contractId]
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroupWithArray'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "lineitem.getList",
        post: null,
        method: 'POST'
    }
};