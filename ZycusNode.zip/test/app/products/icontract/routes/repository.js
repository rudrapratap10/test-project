"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/repositories/getLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get UI labels for repository contract
    *     operationId: getLabels
    *     description: Get UI Labels for Repository Contract
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLabels: {
        pre: null,
        process: "repository.getLabels",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/repositories/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get the list of contracts from repository module
    *     operationId: repositoryList
    *     description: Get the list of contracts from repository module
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Fetch the list of contracts from repository module (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroupWithArray'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "repository.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/{contract_Id}/getContractHierarchy:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Fetch/Get a Contract Hierarchy Details
    *     operationId: getContractDetails
    *     description: Fetch/Get a Contract Hierarchy Details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContractHierarchy: {
        pre: null,
        process: "repository.getContractHierarchy",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/repositories/downloadLineItem:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download line items
    *     operationId: downloadLineItem
    *     description: Download line items [Mode should be single or bulk]
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Download line items
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadLineItem: {
        pre: null,
        process: "repository.downloadLineItem",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/downloadDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download All Documents 
    *     operationId: downloadDocuments
    *     description: Download All Documents 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the multiple Documents
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadDocuments: {
        pre: null,
        process: "repository.downloadDocuments",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/canDelete:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Check whether the contract is deletable or not
    *     operationId: canDelete
    *     description: Check whether the contract is deletable or not. Allowed Value for mode (Single,Bulk)
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Check whether the contract is deletable or not.Allowed Value for mode (Single,Bulk)
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *             comment:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    canDelete: {
        pre: null,
        process: "repository.canDelete",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/deleteContract:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               comment:
    *                   type: string                       
    *               mode:
    *                   type: string                       
    *     required: [ids,mode] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    deleteContract: {
        pre: null,
        process: "repository.deleteContract",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/repositories/getAllowedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get allowed action for contract ID
    *     operationId: getAllowedActionByContract
    *     description: Get get allowed action for contract ID
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get get allowed action for contract ID
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAllowedAction: {
        pre: null,
        process: "repository.getAllowedAction",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/delegateAmendment:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                   type: string  
    *               delegateUsersEmailIds:
    *                 type: array
    *                 items:
    *                   type: string                     
    *     required: [contractId,delegateUsersEmailIds] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    delegateAmendment: {
        pre: null,
        process: "repository.delegateAmendment",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/suggestedAction:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get suggested action
    *     operationId: suggestedaction
    *     description: Get the suggestedaction details for contract ID's
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the suggestedaction details for contract ID's
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    suggestedAction: {
        pre: null,
        process: "repository.suggestedAction",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/foldersByConfidentiality:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Folder Confidentiality
    *     operationId: foldersByConfidentiality
    *     description: Get Folder Confidentiality
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Folder Confidentiality
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractTypeId:
    *                   type: string                       
    *               contractCategoryId:
    *                   type: string                       
    *               contractOwner:
    *                   type: string                       
    *               searchable:
    *                   type: boolean                       
    *               confidential:
    *                   type: boolean                       
    *     required: [contractTypeId,contractCategoryId,contractOwner,searchable,confidential] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    foldersByConfidentiality: {
        pre: null,
        process: "repository.foldersByConfidentiality",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/getContratLinkingLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: get Contrat Linking Labels
    *     operationId: getContratLinkingLabels
    *     description: get Contrat Linking Labels
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContratLinkingLabels: {
        pre: null,
        process: "repository.getContratLinkingLabels",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/repositories/userGroupList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Groups with access to contract folder
    *     operationId: userGroupList
    *     description: Get Groups with access to contract folder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Groups with access to contract folder (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - type: object
    *               properties:
    *                 mode:
    *                   type: string
    *               required: [mode]
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    userGroupList: {
        pre: null,
        process: "repository.userGroupList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/userList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Users with access to the contract folder
    *     operationId: userList
    *     description: Get Users with access to the contract folder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Users with access to the contract folder (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - type: object
    *               properties:
    *                 mode:
    *                   type: string
    *               required: [mode]
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    userList: {
        pre: null,
        process: "repository.userList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/usersForSelectedGroup:
    *   post:
    *     tags:
    *       - IContract API
    *     summary:  Get list of users for a given user group
    *     operationId: usersForSelectedGroup
    *     description:  Get list of users for a given user group
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description:  Get list of users for a given user group (based on filter, sorting & pagination options).
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    usersForSelectedGroup: {
        pre: null,
        process: "repository.usersForSelectedGroup",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/giveAccess:
    *   post:
    *     tags: 
    *       - IContract API
    *     summary: Save users/groups who have access to the contract
    *     operationId: giveAccess
    *     description: Save users/groups who have access to the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save users/groups who have access to the contract
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             contractId:
    *               type: string
    *             folderId:
    *               type: string
    *             groupIds:
    *               type: array
    *               items:
    *                 type: string
    *             users:
    *               type: array
    *               items:
    *                 type: object
    *                 properties:
    *                   userId:
    *                     type: string
    *                   groupIds:
    *                     type: array
    *                     items:
    *                       type: string
    *           required: [contractId,folderId,groupIds,users]
    *     responses:
    *       200:
    *         description: successful operation
    */
    giveAccess: {
        pre: null,
        process: "repository.giveAccess",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/revokeAccess:
    *   post:
    *     tags: 
    *       - IContract API
    *     summary: Delete access to a User / Group
    *     operationId: revokeAccess
    *     description: Delete access to a User / Group
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delete access to a User / Group
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             mode:
    *               type: string
    *             contractId:
    *               type: string
    *             folderId:
    *               type: string
    *             groupIds:
    *               type: array
    *               items:
    *                 type: string
    *             users:
    *               type: array
    *               items:
    *                 type: object
    *                 properties:
    *                   userId:
    *                     type: string
    *                   groupIds:
    *                     type: array
    *                     items:
    *                       type: string
    *           required: [contractId,folderId,users,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    revokeAccess: {
        pre: null,
        process: "repository.revokeAccess",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/repositories/publishContract:
    *   post:
    *     tags: 
    *       - IContract API
    *     summary: Publish Contract
    *     operationId: publishContract
    *     description: Publish Contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Publish Contract
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             contractId:
    *               type: string
    *             revisionComment:
    *               type: string
    *             sendmail:
    *               type: boolean
    *             companyName:
    *               type: string
    *             companyId:
    *               type: string
    *             mailTemplateDetailsDTO:
    *               type: object
    *               properties:
    *                 actionType:
    *                   type: string
    *                 fileIds:
    *                   type: array
    *                   items:
    *                     type: string
    *                 fileName:
    *                   type: string
    *                 sendTo:
    *                   type: string
    *                 sendCc:
    *                   type: string
    *                 sendBcc:
    *                   type: string
    *                 emailSubject:
    *                   type: string
    *                 emailContents:
    *                   type: string
    *           required: [contractId,sendmail,companyName,companyId]
    *     responses:
    *       200:
    *         description: successful operation
    */
    publishContract: {
        pre: null,
        process: "repository.publishContract",
        post: null,
        method: 'POST'
    }
};