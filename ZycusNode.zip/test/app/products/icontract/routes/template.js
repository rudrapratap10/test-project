"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/templates/getLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get UI labels 
    *     operationId: getLabels
    *     description: Get UI Labels 
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLabels: {
        pre: null,
        process: "template.getLabels",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/templates/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get template Paginated List API
    *     operationId: template List
    *     description: Get template Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get template Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroupWithArray'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "template.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/templates/updateStatus:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Change the status of contracts
    *     operationId: changeStatus
    *     description: Change the status of contracts
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Change the status of contracts - Allowed Value for status ('Active','Inactive','Delete')
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             status:
    *               type: string
    *           required: [ids,status]
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateStatus: {
        pre: null,
        process: "template.updateStatus",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/templates/downloadDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Download All Documents 
    *     operationId: downloadDocuments
    *     description: Download All Documents 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the multiple Documents . Allowed value for mode (single,bulk)
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             mode:
    *               type: string
    *           required: [ids,mode]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadDocuments: {
        pre: null,
        process: "template.downloadDocuments",
        post: null,
        method: 'POST'
    }
};