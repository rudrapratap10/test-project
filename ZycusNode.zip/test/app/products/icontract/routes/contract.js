"use strict";
module.exports = {
    /**
     * @swagger
     * /a/icontract/contracts/list:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get the list of contracts from authoring module
     *     operationId: Contract List
     *     description: Get the list of contracts from authoring module
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Fetch the list of contracts from authoring module (based on filter, sorting & pagination options).
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroupWithArray'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getList: {
        pre: null,
        process: "contract.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the contract
    *     operationId: deleteContract
    *     description: Delete the contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to delete. Allowed value for mode (Single,Bulk)
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               comment:
    *                   type: string                       
    *               mode:
    *                   type: string                       
    *     required: [ids,mode] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "contract.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/contracts/cloningContract:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Template Version For Cloning Contract
    *     operationId: cloningContract
    *     description: Get Template Version For Cloning Contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide the contract ID(s) to Cloning the Contract.
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string
    *               amendment:
    *                   type: boolean                       
    *     required: [ids,amendment] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    cloningContract: {
        pre: null,
        process: "contract.cloningContract",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contract/checkLineItemsPermissions:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Permission to bulk download of Line Items (for multiple contracts) API
    *     operationId: checkLineItemsPermissions
    *     description: Permission to bulk download of Line Items (for multiple contracts) API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Permission to bulk download of Line Items (for multiple contracts) API
    *         in: body
    *         required: true
    *         schema:
    *           $ref: '#/definitions/idArray'
    *     responses:
    *       200:
    *         description: successful operation
    */
    checkLineItemsPermissions: {
        pre: null,
        process: "contract.checkLineItemsPermissions",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/checkDocumentPermissions:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Bulk Contract documents permission API 
    *     operationId: checkDocumentPermission
    *     description: Bulk Contract documents permission API [Allowed Value for module (Authoring,Repository) ]
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Bulk Contract documents permission API 
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             ids:
    *               type: array
    *               items:
    *                 type: string
    *             module:
    *               type: string
    *           required: [ids,module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    checkDocumentPermissions: {
        pre: null,
        process: "contract.checkDocumentPermissions",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getContractList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get the list of contracts
    *     operationId: getContractList
    *     description: Get the list of contracts
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get the list of contracts
    *         in: body
    *         schema:
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - type: object
    *               properties:
    *                 vendorId:
    *                   type: string
    *                 type:
    *                   type: string
    *                 subType:
    *                   type: string
    *                 categoryDesc:
    *                   type: string
    *                 BUDesc:
    *                   type: string 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContractList: {
        pre: null,
        process: "contract.getContractList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getFilterData:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get All Filter Parameters with Values for given module
    *     operationId: getFilterData
    *     description: Get All Filter Parameters with Values for given module
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get All Filter Parameters with Values for given module
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             module:
    *                 type: string
    *           required: [module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getFilterData: {
        pre: null,
        process: "contract.getFilterData",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/getCustomMasters:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get enumeration values for a given custom master field
     *     operationId: Custom Master List
     *     description: Get enumeration values for a given custom master field
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get enumeration values for a given custom master field
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    getCustomMasters: {
        pre: null,
        process: "contract.getCustomMasters",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getTypes:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get all contract types and sub types
    *     operationId: getTypeSubType
    *     description: Get all contract types and sub types
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTypes: {
        pre: null,
        process: "contract.getTypes",
        post: null,
        method: 'GET'
    },
    /**
     * @swagger
     * /a/icontract/contracts/getConfiguration:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get Product Configuration for Contract Outline Document 
     *     operationId: getConfiguration
     *     description: Get Product Configuration for Contract Outline Document 
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get Product Configuration for Contract Outline Document 
     *         in: body
     *         required: true
     *         schema:
     *           properties:
     *             subtypeId:
     *                 type: string
     *             module:
     *                 type: string
     *           required: [subtypeId,module]
     *     responses:
     *       200:
     *         description: successful operation
     */
    getConfiguration: {
        pre: null,
        process: "contract.getConfiguration",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/{subTypeId}/{module}/getAuthoringConfiguration:
    *   get:
    *     tags:
    *       - IContract API
    *     summary:  Get get Authoring Configuration 
    *     operationId: getAuthoringConfiguration
    *     description:  Get get Authoring Configuration 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: subTypeId
    *         description: Provide a sub tye ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: module
    *         description: Provide a Module Name
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAuthoringConfiguration: {
        pre: null,
        process: "contract.getAuthoringConfiguration",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getTitle:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get 'auto-title' base on "type and subtype ", contract Category or region
    *     operationId: getContractAutoTitle
    *     description: Get 'auto-title' base on "type and subtype ", contract Category or region
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get 'auto-title' base on "type and subtype ", contract Category or region
    *         in: body
    *         schema:
    *             properties:
    *               type:
    *                 type: string
    *               subType:
    *                   type: string                       
    *               contractCategory:
    *                   type: string                       
    *               region:
    *                   type: string                       
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTitle: {
        pre: null,
        process: "contract.getTitle",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getBUList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get list of business units
    *     operationId: Bu List
    *     description: Get list of business units
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get list of business units
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getBUList: {
        pre: null,
        process: "contract.getBUList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getMetaData:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Filtered MetaData By BaseType 
    *     operationId: getMetaData
    *     description: Get Filtered MetaData By BaseType 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Filtered MetaData By BaseType 
    *         in: body
    *         schema:
    *           properties:
    *             subtypeId:
    *                 type: string
    *             contractId:
    *                 type: string
    *             commonContractId:
    *                 type: string
    *             contractModule:
    *                 type: string
    *             contractCloning:
    *                 type: boolean
    *             metaDataClone:
    *                 type: boolean
    *     responses:
    *       200:
    *         description: successful operation
    */
    getMetaData: {
        pre: null,
        process: "contract.getMetaData",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/{contract_Id}/getFlexiFormDetails:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get Flexi Form Details for given contract id
    *     operationId: getFlexiFormDetails
    *     description: Get get Flexi Form Details for given contract id
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a contract ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: Get get Flexi Form Details for given contract id
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             eFormId:
    *                 type: string
    *             iseFormClone:
    *                 type: string
    *           required: [iseFormClone]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getFlexiFormDetails: {
        pre: null,
        process: "contract.getFlexiFormDetails",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getContractEnumFilterData:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get get Contract EnumFilter Data for given module name
    *     operationId: getContractEnumFilterData
    *     description: Get get Contract EnumFilter Data for given module name
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get get Contract EnumFilter Data for given module name
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *             module:
    *                 type: string
    *           required: [module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    getContractEnumFilterData: {
        pre: null,
        process: "contract.getContractEnumFilterData",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/categoriesList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract Categories list
     *     operationId: categoriesList
     *     description: Get All Contract Categories
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract Categories List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    categoriesList: {
        pre: null,
        process: "contract.categoriesList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/foldersList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract folders List
     *     operationId: foldersList
     *     description: Get All Contract folders List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract folders List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    foldersList: {
        pre: null,
        process: "contract.foldersList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/regionsList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract regions List
     *     operationId: regionsList
     *     description: Get All Contract regions List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract regions List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    regionsList: {
        pre: null,
        process: "contract.regionsList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/signersList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract signers List
     *     operationId: signersList
     *     description: Get All Contract signers List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract signers List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    signersList: {
        pre: null,
        process: "contract.signersList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/ownersList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract owner List
     *     operationId: ownersList
     *     description: Get All Contract owner List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract owner List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    ownersList: {
        pre: null,
        process: "contract.ownersList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/vendorsList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract vendors List
     *     operationId: vendorsList
     *     description: Get All Contract vendors List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Contract vendors List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    vendorsList: {
        pre: null,
        process: "contract.vendorsList",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/contracts/hierarchyStatusList:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Get All Contract hierarchy Status List
     *     operationId: hierarchyStatusList
     *     description: Get All Contract hierarchy Status List
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: body
     *         description: Get All Contract hierarchy Status List
     *         type: string
     *         in: body
     *         schema: 
     *           allOf:
     *             - $ref: '#/definitions/pagination'
     *             - $ref: '#/definitions/criteriaGroup'
     *             - $ref: '#/definitions/sort'
     *     responses:
     *       200:
     *         description: successful operation
     */
    hierarchyStatusList: {
        pre: null,
        process: "contract.hierarchyStatusList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getDateNumeric:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get all date and numeric value
    *     operationId: getDateNumeric
    *     description: Get all date and numeric value
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDateNumeric: {
        pre: null,
        process: "contract.getDateNumeric",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/contracts/downloadTemplate:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: download Template For Bulk Upload
    *     operationId: downloadTemplate
    *     description: download Template For Bulk Upload
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: provide entity value to get template
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               entity:
    *                 type: string                      
    *     required: [entity] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadTemplate: {
        pre: null,
        process: "contract.downloadTemplate",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Create contract
    *     operationId: create
    *     description: Create contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create contract
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               module:
    *                 type: string                      
    *               authoringFieldsRequestDTO:
    *                 type: object                                           
    *                 properties:
    *                   bypassAuthoringWorkflow:
    *                     type: number
    *                   bypassNegotiateStage:
    *                     type: boolean
    *                   repoAmendment:
    *                     type: boolean
    *                   shouldDocumentsClone:
    *                     type: boolean
    *                   shouldLineItemsClone:
    *                     type: boolean
    *                   shouldMetaDataClone:
    *                     type: boolean
    *                   useCloneContractTemplate:
    *                     type: string
    *               subtypeId:
    *                 type: string                      
    *               cloneContractId:
    *                 type: string                      
    *               cloneContractCommonId:
    *                 type: string                      
    *               oldHierarchyStatusId:
    *                 type: string                      
    *               contractTitleConfigId:
    *                 type: string                      
    *               draft:
    *                 type: boolean                      
    *               autotitle:
    *                 type: boolean                      
    *               confidentialityFeatureInUse:
    *                 type: boolean                      
    *               clone:
    *                 type: boolean                      
    *               flexiFormInstanceDTO:
    *                 type: object                      
    *                 properties:
    *                   formInstance:
    *                     type: string
    *                   dynamicInstanceId:
    *                     type: string
    *                   dynamicFormId:
    *                     type: string
    *                   version:
    *                     type: number
    *               templateManager:
    *                 type: object                      
    *                 properties:
    *                   id:
    *                     type: string
    *                   sections:
    *                     type: array
    *                     items:
    *                       type: object
    *                   templateCreatedFrom:
    *                     type: number
    *                   templateDocId:
    *                     type: string
    *                   docHtml:
    *                     type: string
    *               fieldDTOs:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     fieldName:
    *                       type: string
    *                     fieldType:
    *                       type: string
    *                     fieldDisplayValue:
    *                       type: string
    *                     fieldDataBaseValue:
    *                       type: string
    *               manyToManySubEntity:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     subEntityKey:
    *                       type: string
    *                     subEntityValue:
    *                       type: array
    *                       items:
    *                         type: string
    *               oneToManySubEntity:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     subEntityKey:
    *                       type: string
    *                     subEntityValue:
    *                       type: array
    *                       items:
    *                         type: object
    *                         properties:
    *                           id:
    *                             type: string
    *                           fieldName:
    *                             type: string
    *                           fieldType:
    *                             type: string
    *                           maxLength:
    *                             type: number
    *                           isMandatory:
    *                             type: boolean
    *                           isVisible:
    *                             type: boolean
    *                           isEditable:
    *                             type: boolean
    *                           isVisibleInAuthoring:
    *                             type: boolean
    *                           headerName:
    *                             type: string
    *                           headerSequence:
    *                             type: number
    *                           subHeaderName:
    *                             type: string
    *                           subHeaderSequence:
    *                             type: number
    *                           values:
    *                             type: array
    *                             items:
    *                               type: object
    *                               properties:
    *                                 value:
    *                                   type: object
    *                                 id:
    *                                   type: string
    *                                 resourceKey:
    *                                   type: string
    *                                 isSelected:
    *                                   type: boolean
    *                           subFields:
    *                             type: array
    *                             items:
    *                               type: object
    *                           selectedValues:
    *                             type: array
    *                             items:
    *                               type: object
    *                               properties:
    *                                 id:
    *                                   type: string
    *                                 isSelected:
    *                                   type: boolean
    *                                 resourceKey:
    *                                   type: string
    *                                 value:
    *                                   type: object
    *                           subEntityScreenLbl:
    *                             type: string
    *                           toolTip:
    *                             type: string
    *                           isSubEntityMandatory:
    *                             type: boolean
    *                           fieldDisplayName:
    *                             type: string
    *     required: [module] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "contract.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Update contract
    *     operationId: update
    *     description: Update contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update contract
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               module:
    *                 type: string                      
    *               revisionComment:
    *                 type: string                      
    *               contractCommonId:
    *                 type: string                      
    *               oldFolderId:
    *                 type: string                      
    *               oldOwnerEmailId:
    *                 type: string                      
    *               oldContractDocId:
    *                 type: string                      
    *               oldFieldIdDataDTOs:
    *                 type: array                      
    *                 items:
    *                   type: object                                            
    *                   properties:
    *                     fieldName:
    *                       type: string
    *                     fileId:
    *                       type: string
    *               authoringFieldsRequestDTO:
    *                 type: object                      
    *                 properties:
    *                   bypassAuthoringWorkflow:
    *                     type: number
    *                   bypassNegotiateStage:
    *                     type: boolean
    *                   repoAmendment:
    *                     type: boolean
    *                   shouldDocumentsClone:
    *                     type: boolean
    *                   shouldLineItemsClone:
    *                     type: boolean
    *                   shouldMetaDataClone:
    *                     type: boolean
    *                   useCloneContractTemplate:
    *                     type: string
    *               subtypeId:
    *                 type: string                                                                 
    *               oldHierarchyStatusId:
    *                 type: string                      
    *               contractTitleConfigId:
    *                 type: string                      
    *               draft:
    *                 type: boolean                      
    *               autotitle:
    *                 type: boolean                      
    *               confidentialityFeatureInUse:
    *                 type: boolean                      
    *               clone:
    *                 type: boolean                      
    *               flexiFormInstanceDTO:
    *                 type: object                      
    *                 properties:
    *                   formInstance:
    *                     type: string
    *                   dynamicInstanceId:
    *                     type: string
    *                   dynamicFormId:
    *                     type: string
    *                   version:
    *                     type: number
    *               templateManager:
    *                 type: object                      
    *                 properties:
    *                   id:
    *                     type: string
    *                   sections:
    *                     type: array
    *                     items:
    *                       type: object
    *                   templateCreatedFrom:
    *                     type: number
    *                   templateDocId:
    *                     type: string
    *                   docHtml:
    *                     type: string
    *               fieldDTOs:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     fieldName:
    *                       type: string
    *                     fieldType:
    *                       type: string
    *                     fieldDisplayValue:
    *                       type: string
    *                     fieldDataBaseValue:
    *                       type: string
    *               manyToManySubEntity:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     subEntityKey:
    *                       type: string
    *                     subEntityValue:
    *                       type: array
    *                       items:
    *                         type: string
    *               oneToManySubEntity:
    *                 type: array                      
    *                 items:
    *                   type: object
    *                   properties:
    *                     subEntityKey:
    *                       type: string
    *                     subEntityValue:
    *                       type: array
    *                       items:
    *                         type: object
    *                         properties:
    *                           id:
    *                             type: string
    *                           fieldName:
    *                             type: string
    *                           fieldType:
    *                             type: string
    *                           maxLength:
    *                             type: number
    *                           isMandatory:
    *                             type: boolean
    *                           isVisible:
    *                             type: boolean
    *                           isEditable:
    *                             type: boolean
    *                           isVisibleInAuthoring:
    *                             type: boolean
    *                           headerName:
    *                             type: string
    *                           headerSequence:
    *                             type: number
    *                           subHeaderName:
    *                             type: string
    *                           subHeaderSequence:
    *                             type: number
    *                           values:
    *                             type: array
    *                             items:
    *                               type: object
    *                               properties:
    *                                 value:
    *                                   type: object
    *                                 id:
    *                                   type: string
    *                                 resourceKey:
    *                                   type: string
    *                                 isSelected:
    *                                   type: boolean
    *                           subFields:
    *                             type: array
    *                             items:
    *                               type: object
    *                           selectedValues:
    *                             type: array
    *                             items:
    *                               type: object
    *                               properties:
    *                                 id:
    *                                   type: string
    *                                 isSelected:
    *                                   type: boolean
    *                                 resourceKey:
    *                                   type: string
    *                                 value:
    *                                   type: object
    *                           subEntityScreenLbl:
    *                             type: string
    *                           toolTip:
    *                             type: string
    *                           isSubEntityMandatory:
    *                             type: boolean
    *                           fieldDisplayName:
    *                             type: string
    *     required: [module,subtypeId,contractCommonId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "contract.update",
        post: null,
        method: 'PUT'
    },
    /**
    * @swagger
    * /a/icontract/contracts/downloadMainDocument:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: download attachment
    *     operationId: download
    *     description: download attachment
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: download attachment
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               contentType:
    *                 type: string
    *               fileName:
    *                 type: string
    *               content:
    *                 type: string
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               failureCount:
    *                 type: number
    *               mode:
    *                 type: string
    *               module:
    *                 type: string
    *           required: [fileName,module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    downloadMainDocument: {
        pre: null,
        process: "contract.downloadMainDocument",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/deleteDocument:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the line items documents
    *     operationId: documentsDelte
    *     description: Delete the line items documents
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delete the line items documents
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               contentType:
    *                 type: string
    *               fileName:
    *                 type: string
    *               content:
    *                 type: string
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               failureCount:
    *                 type: number
    *               mode:
    *                 type: string
    *               module:
    *                 type: string
    *           required: [fileName,module]
    *     responses:
    *       200:
    *         description: successful operation
    */
    deleteDocument: {
        pre: null,
        process: "contract.deleteDocument",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/contracts/bulkUpload:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Line Document with contract 
    *     operationId: bulkUpload
    *     description: Line Document with contract 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Line Document with contract 
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               contentType:
    *                 type: string
    *               fileName:
    *                 type: string
    *               content:
    *                 type: string
    *               ids:
    *                 type: array
    *                 items:
    *                   type: string
    *               failureCount:
    *                 type: number
    *               mode:
    *                 type: string
    *               module:
    *                 type: string
    *               entity:
    *                 type: string
    *           required: [fileName,module,mode,entity]
    *     responses:
    *       200:
    *         description: successful operation
    */
    bulkUpload: {
        pre: null,
        process: "contract.bulkUpload",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/saveManyToManyFields:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Save many to many fields for a contract
    *     operationId: saveManyToManyFields
    *     description: Save many to many fields for a contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save many to many fields for a contract
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               subTypeId:
    *                 type: string
    *               manyToManyFieldName:
    *                 type: string
    *               contractId:
    *                 type: string
    *               mandatoryFlag:
    *                 type: boolean
    *               manyToManyIds:
    *                 type: array
    *                 items:
    *                   type: string
    *           required: [subTypeId,manyToManyFieldName,contractId,manyToManyIds]
    *     responses:
    *       200:
    *         description: successful operation
    */
    saveManyToManyFields: {
        pre: null,
        process: "contract.saveManyToManyFields",
        post: null,
        method: 'PUT'
    },
    /**
    * @swagger
    * /a/icontract/contracts/deleteManyToManyFields:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete many to many fields for a contract
    *     operationId: deleteManyToManyFields
    *     description: Delete many to many fields for a contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Delete many to many fields for a contract
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               subTypeId:
    *                 type: string
    *               manyToManyFieldName:
    *                 type: string
    *               contractId:
    *                 type: string
    *               mandatoryFlag:
    *                 type: boolean
    *               manyToManyIds:
    *                 type: array
    *                 items:
    *                   type: string
    *           required: [subTypeId,manyToManyFieldName,contractId,manyToManyIds]
    *     responses:
    *       200:
    *         description: successful operation
    */
    deleteManyToManyFields: {
        pre: null,
        process: "contract.deleteManyToManyFields",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/contracts/contractOutline:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Save Contract Outline
    *     operationId: contractOutline
    *     description: Save Contract Outline
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save Contract Outline
    *         in: body
    *         required: true
    *         schema:
    *           properties:
    *               contractId:
    *                 type: string
    *               fileName:
    *                 type: string
    *               fileID:
    *                 type: string
    *               comments:
    *                 type: string
    *           required: [contractId,fileName,fileID]
    *     responses:
    *       200:
    *         description: successful operation
    */
    contractOutline: {
        pre: null,
        process: "contract.contractOutline",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contracts/{contractId}/{mailActionId}/getMailTemplate:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Mail Details 
    *     operationId: getMailTemplate
    *     description: Get Mail Details 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string                                        
    *       - name: mailActionId
    *         description: Provide a Mail Action Id.
    *         in: path
    *         required: true
    *         type: integer                                        
    *     responses:
    *       200:
    *         description: successful operation
    */
    getMailTemplate: {
        pre: null,
        process: "contract.getMailTemplate",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/contracts/getLanguages:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get List Of Language
    *     operationId: getLanguages
    *     description: Get List Of Language
    *     produces:
    *       - application/json                                      
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLanguages: {
        pre: null,
        process: "contract.getLanguages",
        post: null,
        method: 'GET'
    }
};