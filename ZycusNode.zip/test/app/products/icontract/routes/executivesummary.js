"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/executiveSummaries/{contractId}/getTags:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Tags to be used for Executive Summary
    *     operationId: getTags
    *     description: Get Tags to be used for Executive Summary
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getTags: {
        pre: null,
        process: "executivesummary.getTags",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/executiveSummaries/{contractId}/showSummary:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Show Executive Summary
    *     operationId: showSummary
    *     description: Show Executive Summary
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    showSummary: {
        pre: null,
        process: "executivesummary.showSummary",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/executiveSummaries:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Save Executive Summary
    *     operationId: create
    *     description: Save Executive Summary
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save Executive Summary
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                                                                     
    *               selectedSummaryType:
    *                 type: string                                                                                     
    *               contractSummaryText:
    *                 type: string                                                                                     
    *               isAuthoring:
    *                 type: boolean                                                                                     
    *               hasAuthoringLogs:
    *                 type: string                                                                                     
    *               sendInMail:
    *                 type: string                                                                                     
    *               hasNegotiateLogs:
    *                 type: string                                                                                     
    *               hasSignOffLogs:
    *                 type: string                                                                                     
    *               uploadedCustomFileName:
    *                 type: string                                                                                     
    *               uploadedCustomFileId:
    *                 type: string                                                                                         
    *             required: [contractId,selectedSummaryType,contractSummaryText,isAuthoring,hasAuthoringLogs,sendInMail,hasNegotiateLogs,hasSignOffLogs,uploadedCustomFileName,uploadedCustomFileId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "executivesummary.create",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/executiveSummaries/{contractId}/getDetails:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Show Executive Summary Details
     *     operationId: getexecutivesummarydetails
     *     description: Show Executive Summary Details
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: contractId
     *         description: Provide a Contract ID.
     *         in: path
     *         required: true
     *         type: string
     *       - name: body
     *         description: Get get Summary Details for given contract id
     *         in: body
     *         required: true
     *         schema:
     *           properties:
     *             showContractDetails:
     *                 type: boolean
     *             isAuthoring:
     *                 type: boolean
     *           required: [showContractDetails,isAuthoring]
     *     responses:
     *       200:
     *         description: successful operation
     */
    getDetails: {
        pre: null,
        process: "executivesummary.getDetails",
        post: null,
        method: 'POST'
    },
    /**
     * @swagger
     * /a/icontract/executiveSummaries/{contractId}/exportSummary:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Export Summary
     *     operationId: export
     *     description: Export Summary
     *     produces:
     *       - application/json
     *     parameters:
     *       - name: contractId
     *         description: Provide a Contract ID.
     *         in: path
     *         required: true
     *         type: string
     *       - name: body
     *         description: Export Summary
     *         in: body
     *         required: true
     *         schema:
     *           properties:
     *             summaryDownloadFormat:
     *                 type: string
     *             isAuthoring:
     *                 type: boolean
     *           required: [summaryDownloadFormat,isAuthoring]
     *     responses:
     *       200:
     *         description: successful operation
     */
    exportSummary: {
        pre: null,
        process: "executivesummary.exportSummary",
        post: null,
        method: 'POST'
    }
};