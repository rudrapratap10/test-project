"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/contractingParties/getLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get UI labels 
    *     operationId: getLabels
    *     description: Get UI Labels 
    *     produces:
    *       - application/json
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLabels: {
        pre: null,
        process: "contractingparty.getLabels",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * definitions:
    *   createContractParties:
    *     properties:
    *       contractId:
    *         type: string                                            
    *       contactId:
    *         type: string                                            
    *       vendorId:
    *         type: string                                            
    *       parentVendorId:
    *         type: string                                            
    *       replaceVendorId:
    *         type: string                                                                                      
    *       companyType:
    *         type: string                                            
    *       order:
    *         type: number                                            
    *       dbaId:
    *         type: string                                            
    *       dbaName:
    *         type: string                                            
    *       selectedCustomSiteIdKey:
    *         type: string                                            
    *       selectedCustomSiteIdValue:
    *         type: string                                            
    *       module:
    *         type: string                                            
    *       replace:
    *         type: boolean                                            
    */
    /**
    * @swagger
    * /a/icontract/contractingParties:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: create Contracting Parties
    *     operationId: create Contracting Parties
    *     description: create Contracting Parties
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: create Contracting Parties
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             $ref: '#/definitions/createContractParties' 
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "contractingparty.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contractingParties/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get paginated list of all contracting parties selected for a contract
    *     operationId: contractingParties List
    *     description: Get paginated list of all contracting parties selected for a contract
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get paginated list of all contracting parties selected for a contract
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "contractingparty.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contractingParties/getAllContractingPartiesList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get all contracting parties with pagination
    *     operationId: getAllContractingPartiesList
    *     description: Get all contracting parties with pagination
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get all contracting parties with pagination
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAllContractingPartiesList: {
        pre: null,
        process: "contractingparty.getAllContractingPartiesList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/contractingParties:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: delete Contracting Parties
    *     operationId: delete Contracting Parties
    *     description: delete Contracting Parties
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: delete Contracting Parties
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           properties:
    *             contractId:
    *               type: string
    *             vendorId:
    *               type: string
    *             contactId:
    *               type: string
    *             isPrimary:
    *               type: boolean
    *             sequence:
    *               type: number
    *           required: [contractId,vendorId,contactId,isPrimary,sequence]
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "contractingparty.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/contractingParties/makePrimary:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Set Contracting party (aka Vendor) as Primary 
    *     operationId: makePrimary
    *     description: Set Contracting party (aka Vendor) as Primary 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Set Contracting party (aka Vendor) as Primary 
    *         in: body
    *         required: true
    *         schema:
    *           type: object
    *           properties:
    *             contractId:
    *               type: string
    *             vendorId:
    *               type: string
    *             contactId:
    *               type: string
    *             sequence:
    *               type: number
    *           required: [contractId,vendorId,contactId,sequence]
    *     responses:
    *       200:
    *         description: successful operation
    */
    makePrimary: {
        pre: null,
        process: "contractingparty.makePrimary",
        post: null,
        method: 'POST'
    }

};