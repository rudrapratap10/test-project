"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/signs/{contract_Id}/getSignersCount:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Signers Count
    *     operationId: getSignersCount
    *     description: Get Signers Count
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a contract_Id
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getSignersCount: {
        pre: null,
        process: "sign.getSignersCount",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/signs/updateSigningStatus:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Update Signing Status
    *     operationId: updateSigningStatus
    *     description: update Signing Status
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: updateSigningStatus
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string
    *               esigneSelected:
    *                   type: boolean                                            
    *     required: [contractId,esigneSelected] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateSigningStatus: {
        pre: null,
        process: "sign.updateSigningStatus",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/getBlockConfig:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: get signature Block Config
    *     operationId: getBlockConfig
    *     description: get signature Block Config
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: getBlockConfig
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string
    *               isEsignatureSelected:
    *                   type: boolean                                            
    *               blockUsageType:
    *                   type: number                                            
    *     required: [contractId,isEsignatureSelected,blockUsageType] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getBlockConfig: {
        pre: null,
        process: "sign.getBlockConfig",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/getSignerConfig:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: get signature  Config
    *     operationId: getSignerConfig
    *     description: get signature  Config
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: getSignerConfig
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *     required: [contractId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getSignerConfig: {
        pre: null,
        process: "sign.getSignerConfig",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/saveBlockConfig:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: save block  Config
    *     operationId: saveBlockConfig
    *     description: save block  Config
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: save block  Config
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               deleteUITags:
    *                 type: boolean                                           
    *               contractSigningBlockElementList:
    *                 type: array                                           
    *                 items:
    *                   type: object
    *                   properties:
    *                     id:
    *                       type: string
    *                     signingTypeId:
    *                       type: string
    *                     blockMasterId:
    *                       type: number
    *                     elementLable:
    *                       type: string
    *                     isMandatory:
    *                       type: boolean
    *                     isCustome:
    *                       type: boolean
    *                     isVisible:
    *                       type: boolean
    *                     isPrefilled:
    *                       type: boolean
    *                     sequence:
    *                       type: number
    *     required: [contractId,deleteUITags,contractSigningBlockElementList] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    saveBlockConfig: {
        pre: null,
        process: "sign.saveBlockConfig",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/saveSequence:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: save sequence
    *     operationId: saveSequence
    *     description: save sequence
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: save sequence
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               signersSequence:
    *                 type: object                                           
    *     required: [contractId,signersSequence] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    saveSequence: {
        pre: null,
        process: "sign.saveSequence",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/getDetails:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get signer details
    *     operationId: getDetails
    *     description: Get signer details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get signer details
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               signerId:
    *                 type: string                                           
    *               type:
    *                 type: string                                           
    *     required: [contractId,type] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "sign.getDetails",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * definitions:
    *   createSign:
    *     properties:
    *       contractId:
    *         type: string                                                                                       
    *       signerId:
    *         type: string                                                                                       
    *       deleteUITags:
    *         type: boolean                                                                                       
    *       deleteSignerBlock:
    *         type: boolean                                                                                       
    *       contractSigner:
    *         type: object                                                                                       
    *         properties:
    *           contractSignerId:
    *             type: string
    *           firstName:
    *             type: string
    *           lastName:
    *             type: string
    *           emailId:
    *             type: string
    *           designation:
    *             type: string
    *           companyName:
    *             type: string
    *           party:
    *             type: string
    *           contractId:
    *             type: string
    *           createdBy:
    *             type: string
    *           createdDate:
    *             type: string
    *           modifiedBy:
    *             type: string
    *           modifiedDate:
    *             type: string
    *           signerDate:
    *             type: string
    *           signingStatus:
    *             type: string
    *           signingOrder:
    *             type: number
    *           signingPlace:
    *             type: string
    *           address:
    *             type: string
    *           customAttributeJson:
    *             type: string
    *           populateFromJson:
    *             type: string
    *           signerIdentity:
    *             type: number
    *           fullName:
    *             type: string
    */

    /**
    * @swagger
    * /a/icontract/signs:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Create signer details
    *     operationId: Create
    *     description: Create signer details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create signer details
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/createSign'                                           
    *             required: [contractId]                                          
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "sign.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Update signer details
    *     operationId: Update
    *     description: Update signer details
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update signer details
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/createSign'                                           
    *             required: [contractId]                                          
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "sign.update",
        post: null,
        method: 'PUT'
    },
    /**
    * @swagger
    * /a/icontract/signs/{contractId}/{tempFileId}/skipSigning:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Skip Signing 
    *     operationId: skipSigning
    *     description: Skip Signing 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         type: string
    *         required: true
    *       - name: tempFileId
    *         description: Provide a temp file  ID.
    *         in: path
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *         description: successful operation
    */
    skipSigning: {
        pre: null,
        process: "sign.skipSigning",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/signs/{contractId}/validateSigning:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Validate Signing 
    *     operationId: validateSigning
    *     description: Validate Signing 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *         description: successful operation
    */
    validateSigning: {
        pre: null,
        process: "sign.validateSigning",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/signs/{contractId}/loadDocument:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Load consolidated contract documents 
    *     operationId: loadDocument
    *     description: Load consolidated contract documents 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *         description: successful operation
    */
    loadDocument: {
        pre: null,
        process: "sign.loadDocument",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/signs/consolidatedDocuments:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Save Consolidated Documents
    *     operationId: consolidatedDocuments
    *     description: Save Consolidated Documents
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save Consolidated Documents
    *         in: body
    *         required: true
    *         schema:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               docId:
    *                 type: string
    *               contractId:
    *                   type: string                                            
    *               documentPageCount:
    *                   type: number                                            
    *               docOrder:
    *                   type: number                                            
    *               uploadedDocId:
    *                   type: string                                            
    *               skipSigning:
    *                   type: boolean                                                                                
    *     required: [docId,contractId,documentPageCount,docOrder,uploadedDocId,skipSigning] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    consolidatedDocuments: {
        pre: null,
        process: "sign.consolidatedDocuments",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/withdrawSigning:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Withdraw Signing
    *     operationId: withdrawSigning
    *     description: Withdraw Signing
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Withdraw Signing
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               contractModule:
    *                 type: string                                           
    *               contractDeclined:
    *                 type: boolean                                           
    *             required: [contractId,contractModule,contractDeclined] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    withdrawSigning: {
        pre: null,
        process: "sign.withdrawSigning",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/sendRemainder:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Send Reminder to a signer for signing document
    *     operationId: sendRemainder
    *     description: Send Reminder to a signer for signing document
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Send Reminder to a signer for signing document
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               signerEmailId:
    *                 type: string                                                                                    
    *             required: [contractId,signerEmailId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    sendRemainder: {
        pre: null,
        process: "sign.sendRemainder",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/signs/{contractId}/getEsign:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get ESignature UI Tags For Contract 
    *     operationId: getEsign
    *     description: Get ESignature UI Tags For Contract 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         type: string
    *         required: true
    *     responses:
    *       200:
    *         description: successful operation
    */
    getEsign: {
        pre: null,
        process: "sign.getEsign",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/signs/{signerId}:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete Signer
    *     operationId: destroy
    *     description: Delete Signer
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: signerId
    *         description: Delete Signer
    *         in: path
    *         type: string
    *         required: true
    *       - name: body
    *         description: Send Reminder to a signer for signing document
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               fromWithdrawSigner:
    *                 type: boolean                                                                                    
    *               deleteUITags:
    *                 type: boolean                                                                                    
    *               deleteSignerBlock:
    *                 type: boolean                                                                                    
    *             required: [contractId,fromWithdrawSigner,deleteUITags,deleteSignerBlock] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "sign.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/signs/saveUploadedSignedCopy:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Save Uploaded signed document details 
    *     operationId: saveUploadedSignedCopy
    *     description: Save Uploaded signed document details 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Save Uploaded signed document details 
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                           
    *               fileId:
    *                 type: string                                           
    *               comments:
    *                 type: string                                                                                                                                                                   
    *             required: [fileId,contractId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    saveUploadedSignedCopy: {
        pre: null,
        process: "sign.saveUploadedSignedCopy",
        post: null,
        method: 'POST'
    }
};