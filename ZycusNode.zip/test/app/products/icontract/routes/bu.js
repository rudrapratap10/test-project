"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/bu/{contractType_Id}/getLabels:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get UI Labels
    *     operationId: getLabels
    *     description: Get UI Labels (from UI Config Sheet) for BU List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractType_Id
    *         description: Provide a contract Type Id .
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getLabels: {
        pre: null,
        process: "bu.getLabels",
        post: null,
        method: 'GET'
    }
};