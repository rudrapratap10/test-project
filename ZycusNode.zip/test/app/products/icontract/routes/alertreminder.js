"use strict";
module.exports = {
    /**
    * @swagger
    * /a/icontract/alertReminders/list:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get alert Paginated List API
    *     operationId: alert List
    *     description: Get alert Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get alert Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    getList: {
        pre: null,
        process: "alertreminder.getList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{contract_Id}/getAlertDateCondition:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Alert Date Condition
    *     operationId: getAlertDateCondition
    *     description: Get Alert Date Condition
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contract_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAlertDateCondition: {
        pre: null,
        process: "alertreminder.getAlertDateCondition",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{alert_Id}:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the Alert
    *     operationId: deleteAlert
    *     description: Delete the Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: alert_Id
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string
    *       - name: body
    *         description: provide the contract ID and Alert ID to delete alert
    *         in: body
    *         required: true
    *         schema:
    *             properties:
    *               contractId:
    *                 type: string                                            
    *     required: [contractId] 
    *     responses:
    *       200:
    *         description: successful operation
    */
    destroy: {
        pre: null,
        process: "alertreminder.destroy",
        post: null,
        method: 'DELETE'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{alert_Id}/getAlertRecipients:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Alert Recipients by alert id 
    *     operationId: getAlertRecipients
    *     description: Get Alert Recipients by alert id 
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: alert_Id
    *         description: Provide a alert ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getAlertRecipients: {
        pre: null,
        process: "alertreminder.getAlertRecipients",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * definitions:
    *   saveAlert:
    *     properties:
    *       contractId:
    *         type: string                                            
    *       contractValue:
    *         type: string                                            
    *       alertId:
    *         type: string                                            
    *       title:
    *         type: string                                            
    *       description:
    *         type: string                                            
    *       priority:
    *         type: string                                            
    *       metadataScreenLabel:
    *         type: string                                            
    *       metaData:
    *         type: string                                            
    *       metadataDate:
    *         type: string                                            
    *       alertOn:
    *         type: boolean                                            
    *       selfAlert:
    *         type: boolean                                            
    *       alertType:
    *         type: number                                            
    *       alertBefore:
    *         type: number                                            
    *       alertOnDate:
    *         type: string                                            
    *       repeatDuration:
    *         type: number                                            
    *       quick:
    *         type: boolean                                            
    *       internalUsers:
    *         type: object                                            
    *       isOutLookEventSend:
    *         type: boolean                                            
    *       internalUserList:
    *         type: array                                            
    *         items:
    *             type: object
    *             properties:
    *               externalUserEmailId:
    *                   type: string
    *               externalUserName:
    *                   type: string
    *               userID:
    *                   type: number
    *               ownerID:
    *                   type: number
    *       externalUsers:
    *         type: array                                            
    *         items:
    *             type: object
    *             properties:
    *               externalUserEmailId:
    *                   type: string
    *               externalUserName:
    *                   type: string
    *               ownerID:
    *                   type: number
    *               userID:
    *                   type: number
    *       alertConditionDto:
    *         type: object                                            
    *         properties:
    *           alertConditionId:
    *               type: string
    *           numberOfRepetitions:
    *               type: number
    *           numberOfRepetitionFixed:
    *               type: number
    *           utilizationValue:
    *               type: number
    *           lastTriggeredUtilizedValue:
    *               type: number
    *           firstTriggeredUtilizedValue:
    *               type: number
    *           repeatByUtilization:
    *               type: number
    *           repeatByDays:
    *               type: number
    *           alertConditionType:
    *               type: string
    *           metadataName:
    *               type: string
    *           utilizationUnit:
    *               type: string
    *           dateCondition:
    *               type: string
    *           alertDate:
    *               type: string
    */
    /**
    * @swagger
    * /a/icontract/alertReminders:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: create Alert
    *     operationId: createAlert
    *     description: create Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: create Alert
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveAlert' 
    *     responses:
    *       200:
    *         description: successful operation
    */
    create: {
        pre: null,
        process: "alertreminder.create",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Update Alert
    *     operationId: UpdateAlert
    *     description: Update Alert
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update Alert
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveAlert' 
    *     responses:
    *       200:
    *         description: successful operation
    */
    update: {
        pre: null,
        process: "alertreminder.update",
        post: null,
        method: 'PUT'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/internalUserList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get Internal Users List
    *     operationId: getInternalUsers
    *     description: Get Internal Users List
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get Internal Users Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    internalUserList: {
        pre: null,
        process: "alertreminder.internalUserList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/reminderList:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Get reminder Paginated List API
    *     operationId: reminder List
    *     description: Get reminder Paginated List API
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Get reminder Paginated List API
    *         type: string
    *         in: body
    *         schema: 
    *           allOf:
    *             - $ref: '#/definitions/pagination'
    *             - $ref: '#/definitions/criteriaGroup'
    *             - $ref: '#/definitions/sort'
    *     responses:
    *       200:
    *         description: successful operation
    */
    reminderList: {
        pre: null,
        process: "alertreminder.reminderList",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{alert_Id}/getDetails:
    *   get:
    *     tags:
    *       - IContract API
    *     summary: Get Alert Deatils
    *     operationId: getDetails
    *     description: Alert Deatils
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: alert_Id
    *         description: Provide a alert ID.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "alertreminder.getDetails",
        post: null,
        method: 'GET'
    },
    /**
    * @swagger
    * definitions:
    *   saveRemainder:
    *     properties:
    *       eventId:
    *         type: number                                            
    *       title:
    *         type: string                                            
    *       description:
    *         type: string                                            
    *       createdBy:
    *         type: string                                            
    *       status:
    *         type: string                                            
    *       reminderDate:
    *         type: string                                            
    *       durationHour:
    *         type: string                                            
    *       durationMinute:
    *         type: number                                            
    *       durationFormat:
    *         type: string                                            
    *       contractNumber:
    *         type: string                                            
    *       contractTitle:
    *         type: string                                            
    *       outLookEventSend:
    *         type: boolean                                            
    */

    /**
    * @swagger
    * /a/icontract/alertReminders/createRemainder:
    *   post:
    *     tags:
    *       - IContract API
    *     summary: Create Remainder
    *     operationId: createRemainder
    *     description: Create Remainder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Create Remainder
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveRemainder'                                           
    *             required: [title,reminderDate,contractNumber,eventId]                                            
    *     responses:
    *       200:
    *         description: successful operation
    */
    createRemainder: {
        pre: null,
        process: "alertreminder.createRemainder",
        post: null,
        method: 'POST'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/updateRemainder:
    *   put:
    *     tags:
    *       - IContract API
    *     summary: Update Remainder
    *     operationId: updateRemainder
    *     description: Update Remainder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Update Remainder
    *         in: body
    *         required: true
    *         schema:
    *             allOf:
    *               - $ref: '#/definitions/saveRemainder'                                           
    *             required: [title,reminderDate,contractNumber,eventId]                                            
    *     responses:
    *       200:
    *         description: successful operation
    */
    updateRemainder: {
        pre: null,
        process: "alertreminder.updateRemainder",
        post: null,
        method: 'PUT'
    },
    /**
    * @swagger
    * /a/icontract/alertReminders/{contractId}/{reminderEventId}/deleteReminder:
    *   delete:
    *     tags:
    *       - IContract API
    *     summary: Delete the Remainder
    *     operationId: deleteReminder
    *     description: Delete the Remainder
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: contractId
    *         description: Provide a Contract ID.
    *         in: path
    *         required: true
    *         type: string                                        
    *       - name: reminderEventId
    *         description: Provide a Remainder Event ID.
    *         in: path
    *         required: true
    *         type: integer                                        
    *     responses:
    *       200:
    *         description: successful operation
    */
    deleteReminder: {
        pre: null,
        process: "alertreminder.deleteReminder",
        post: null,
        method: 'DELETE'
    }
};