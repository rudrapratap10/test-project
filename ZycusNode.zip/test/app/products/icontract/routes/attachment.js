"use strict";
module.exports = {
    /**
     * @swagger
     * /a/icontract/attachments:
     *   post:
     *     tags:
     *       - IContract API
     *     summary: Attach & Upload the files
     *     operationId: attachFiles
     *     consumes:
     *       - multipart/form-data
     *     parameters:
     *         - in: formData
     *           name: file
     *           type: file
     *           description: Attach & Upload the files 
     *           required: true
     *         - in: header
     *           name: module
     *           type: string
     *           required: true
     *         - in: header
     *           name: mode
     *           type: string
     *         - in: header
     *           name: id
     *           type: string
     *     responses:
     *       200:
     *         description: successful operation
     */
    create: {
        pre: null,
        process: "attachment.create",
        post: null,
        method: 'POST'
    }
};