/**
 * ScreenLabel Controller 
 * @description :: Provides Alert Remainder  Details.
 */
module.exports = (parentClass) => {
    class AlertReminder extends parentClass {
        /**
        * @Method Name : getAlertList
        * @Description : Get Alert List
        * @return object / Throw Error
        */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getAlertList`;
                    http.post(url, 'getAlertList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "alertId": { "type": "string" }, "title": { "type": "string" }, "alertType": { "type": "string" }, "createdFor": { "type": "string" }, "alertTriggeredCondition": { "type": "string" }, "createdBy": { "type": "string" }, "priority": { "type": "string" }, "alertOnDate": { "type": "number" }, "alertBefore": { "type": "number" }, "utilizationValue": { "type": "none" }, "utilizationUnit": { "type": "none" }, "utilizationDateCondition": { "type": "none" }, "utilizationAlertOnDate": { "type": "none" }, "repeatDateAlertDuration": { "type": "number" }, "repeatByUtilization": { "type": "number" }, "repeatByDaysInUtilization": { "type": "number" }, "numberOfRepetitionFixedInUtilization": { "type": "number" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getAlertDateCondition
        * @Description : Get Alert Date Condition
        * @return object / Throw Error
        */
        getAlertDateCondition(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.alertreminder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getAlertDateCondition/${request.params.alertreminder_Id}`;
                    http.get(url, 'getAlertList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "metadata": { "type": "string" }, "screenLevel": { "type": "string" }, "date": { "type": "none" }, "formatdate": { "type": "string" }, "remainDays": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : destroy
         *
         * @Description : Delete the alert
         * @return object / Throw Error
         */

        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "alertId": "joi.string().required().label('icontract-lable-23__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(super.lodash.merge(request.body, { "alertId": request.params.alertreminder_Id }));
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/deleteAlert/${request.body.contractId}/${request.params.alertreminder_Id}`;
                    http.get(url, 'deletAlert', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getAlertDateCondition
        * @Description : Get Alert Date Condition
        * @return object / Throw Error
        */
        getAlertRecipients(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "alertId": "joi.string().required().label('icontract-lable-23__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "alertId": request.params.alertreminder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getalertrecipients/${request.params.alertreminder_Id}`;
                    http.get(url, 'getAlertList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "recipientType": { "type": "number" }, "recipientName": { "type": "string" }, "recipientEmail": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : Create
        * @param1 labelId 
        * @Description : Create Alert
        * @return object / Throw Error
        */
        saveAndUpdateAlert(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "contractValue": "joi.string().label('icontract-lable-49__')",
                        "alertId": "joi.string().allow('').label('icontract-lable-23__')",
                        "title": "joi.string().required().label('icontract-lable-26__')",
                        "description": "joi.string().allow('').label('icontract-lable-27__')",
                        "priority": "joi.string().required().label('icontract-lable-28__')",
                        "metadataScreenLabel": "joi.string().when('alertId',{is:1,then:joi.required()}).label('icontract-lable-29__')",
                        "metaData": "joi.string().when('alertId',{is:1,then:joi.required()}).label('icontract-lable-30__')",
                        "metadataDate": "joi.string().when('alertId',{is:1,then:joi.required()}).label('icontract-lable-31__')",
                        "alertOn": "joi.boolean().when('alertId',{is:1,then:joi.required()}).label('icontract-lable-32__')",
                        "selfAlert": "joi.boolean().required().label('icontract-lable-33__')",
                        "alertType": "joi.number().required().label('icontract-lable-34__')",
                        "alertOnDate": "joi.string().when('alertOn',{is:true,then:joi.required(),otherwise:joi.allow('',null)}).label('icontract-lable-35__')",
                        "repeatDuration": "joi.number().label('icontract-lable-36__')",
                        "alertBefore": "joi.number().when('alertOn',{is:false,then:joi.required()}).label('icontract-lable-47__')",
                        "internalUsers": "joi.object().label('icontract-lable-48__')",
                        "internalUserList": `joi.array().items(
                            joi.object().keys({
                                externalUserEmailId: joi.string().email().label('icontract-lable-43__'),
                                externalUserName: joi.string().label('icontract-lable-44__'),
                                userID: joi.number().label('icontract-lable-39__'),
                                ownerID: joi.number().label('icontract-lable-40__')
                            }).label('icontract-lable-38__')
                        ).label('icontract-lable-37__')`,
                        "externalUsers": `joi.array().items(
                            joi.object().keys({
                                externalUserEmailId: joi.string().email().label('icontract-lable-43__'),
                                externalUserName: joi.string().label('icontract-lable-44__'),
                                userID: joi.number().label('icontract-lable-39__'),
                                ownerID: joi.number().label('icontract-lable-40__')
                            }).label('icontract-lable-42__')
                        ).label('icontract-lable-41__')`,
                        "quick": "joi.boolean().label('icontract-lable-45__')",
                        "isOutLookEventSend": "joi.boolean().when('alertId',{is:1,then:joi.required()}).label('icontract-lable-46__')",
                        "alertConditionDto": `joi.object().keys({
                            alertConditionId: joi.string().label('icontract-lable-51__'),
                            numberOfRepetitions: joi.number().label('icontract-lable-52__'),
                            numberOfRepetitionFixed: joi.number().label('icontract-lable-53__'),
                            utilizationValue: joi.number().label('icontract-lable-54__'),
                            lastTriggeredUtilizedValue: joi.number().label('icontract-lable-55__'),
                            firstTriggeredUtilizedValue: joi.number().label('icontract-lable-56__'),
                            repeatByUtilization: joi.number().label('icontract-lable-57__'),
                            repeatByDays: joi.number().label('icontract-lable-58__'),
                            alertConditionType: joi.string().label('icontract-lable-59__'),
                            metadataName: joi.string().label('icontract-lable-60__'),
                            utilizationUnit: joi.string().label('icontract-lable-61__'),
                            dateCondition: joi.string().label('icontract-lable-62__'),
                            alertDate: joi.string().label('icontract-lable-63__'),
                        }).label('icontract-lable-50__')`,
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/saveorupdatealert`;
                    http.post(url, 'saveOrUpdate', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        create(request, input, callback) {
            this.saveAndUpdateAlert(request, input, callback);
        };
        /**
        * @Method Name : update
        * @param1 labelId 
        * @Description : update Alert
        * @return object / Throw Error
        */
        update(request, input, callback) {
            this.saveAndUpdateAlert(request, input, callback);
        };
        /**
        * @Method Name : internalUserList
        * @Description : Get Internal Users list
        * @return object / Throw Error
        */
        internalUserList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getInternalUsers`;
                    http.post(url, 'getAlertList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "userId": { "type": "string" }, "userName": { "type": "string" }, "emailId": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : reminder List         
        * @Description : Get reminderList 
        * @return object / Throw Error
        */
        reminderList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');

                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getReminderList`;
                    http.post(url, 'reminderList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "eventId": { "type": "number" }, "title": { "type": "string" }, "description": { "type": "string" }, "createdBy": { "type": "string" }, "status": { "type": "string" }, "reminderDate": { "type": "none" }, "durationHour": { "type": "number" }, "durationMinute": { "type": "number" }, "durationFormat": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getDetails
        * @Description : Get Alert Details
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "alertId": "joi.string().required().label('icontract-lable-23__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "alertId": request.params.alertreminder_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/getAlertDetails/${request.params.alertreminder_Id}`;
                    http.get(url, 'getDetails', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "alertCondition": { "type": "null" }, "alertDetails": { "type": "object", "properties": { "alertId": { "type": "string" }, "description": { "type": "string" }, "priority": { "type": "string" }, "metadataScreenLabel": { "type": "string" }, "metaData": { "type": "string" }, "ownerId": { "type": "number" }, "metadataDate": { "type": "number" }, "quickAlert": { "type": "boolean" }, "active": { "type": "boolean" }, "alertOnDate": { "type": "none" }, "lastTrigerDate": { "type": "none" }, "firstTrigerDate": { "type": "none" }, "createdDate": { "type": "none" }, "modifiedDate": { "type": "none" }, "alertBefore": { "type": "number" }, "repeatAlertDuration": { "type": "number" }, "alertType": { "type": "number" }, "contractOwnerId": { "type": "number" }, "contractId": { "type": "string" }, "title": { "type": "string" }, "alertUsers": { "type": "array", "properties": { "uuid": { "type": "string" }, "internalUserId": { "type": "number" }, "externalUserEmailId": { "type": "string" }, "externalUserName": { "type": "string" }, "active": { "type": "boolean" }, "ownerId": { "type": "number" } } } } }, "outLookEventSend": { "type": "boolean" }, "selfAlert": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        saveAndUpdateRemainder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "eventId": "joi.number().required().label('icontract-lable-171__')",
                        "title": "joi.string().required().label('icontract-lable-26__')",
                        "description": "joi.string().label('icontract-lable-27__')",
                        "createdBy": "joi.string().label('icontract-lable-172__')",
                        "status": "joi.string().label('icontract-lable-6__')",
                        "reminderDate": "joi.string().required().label('icontract-lable-173__')",
                        "durationHour": "joi.string().label('icontract-lable-174__')",
                        "durationMinute": "joi.number().label('icontract-lable-175__')",
                        "durationFormat": "joi.string().label('icontract-lable-176__')",
                        "contractNumber": "joi.string().required().label('icontract-lable-177__')",
                        "contractTitle": "joi.string().label('icontract-lable-178__')",
                        "outLookEventSend": "joi.boolean().label('icontract-lable-46__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/saveorupdatereminder`;
                    http.post(url, 'createRemainder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : createRemainder
        * @Description : Create Remainder
        * @return object / Throw Error
        */
        createRemainder(request, input, callback) {
            this.saveAndUpdateRemainder(request, input, callback);
        };
        /**
        * @Method Name : updateRemainder
        * @Description : Update Remainder
        * @return object / Throw Error
        */
        updateRemainder(request, input, callback) {
            this.saveAndUpdateRemainder(request, input, callback);
        };
        /**
         * @Method Name : deleteReminder
         *
         * @Description : Delete the Reminder
         * @return object / Throw Error
         */

        deleteReminder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "reminderEventId": "joi.number().required().label('icontract-lable-234__')"
                    };
                validationUtility.addInternalSchema(schema);            
                const result = validationUtility.validate({ "contractId": request.params.contractId, "reminderEventId": request.params.reminderEventId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/alertReminder/deleteReminder/${request.params.contractId}/${request.params.reminderEventId}`;
                    http.get(url, 'deleteReminder', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

    }
    return AlertReminder;
};