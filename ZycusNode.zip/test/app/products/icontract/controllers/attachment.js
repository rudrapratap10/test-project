/**
 * Attachment Controller
 *
 * @description :: Provides attachment related operations
 */
const upload = require('@service/upload');

module.exports = (parentClass) => {
    class Attachment extends parentClass {
        /*
        * Create Method
        * Add attachment files.
        */
        create(request, input, callback) {
            try {
                const productSetting = super.productSetting(request),
                    modules = Object.keys(productSetting['modules']),
                    validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().valid(" + JSON.stringify(modules) + ").required().insensitive().label('icontract-lable-8__')",
                        "mode": "joi.string().valid('bulk','single','replace').when('module',{ is :'lineItem', then : joi.required()}).label('icontract-lable-7__')",
                        "id": "joi.string().label('icontract-lable-95__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "module": request.headers.module, "mode": request.headers.mode, "id": request.headers.id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const moduleOptions = productSetting['modules'][(request.headers.module).toLowerCase()]['attachment'],
                        options = { "productName": request.productName },
                        uploadService = new (upload)(super.lodash.merge(moduleOptions, options)),
                        ddHook = new (super.ddHook({ request: request }))();
                    super.async.waterfall([
                        (callback) => {
                            uploadService.fileUploadToServer(request, callback);
                        }, (result, callback) => {
                            if (super.lodash.isEmpty(result.errors)) {
                                ddHook.getFileInfo(result, (error, results) => {
                                    if (error) callback(error, null);
                                    else callback(null, results);
                                });
                            }
                            else {
                                callback(result.errors, null);
                            }
                        },
                        (result, callback) => {
                            this.sendRequest(request, result, callback);
                        }
                    ],
                        (error, request, results) => {
                            if (error) {
                                callback(error, null);
                            }
                            else {
                                callback(null, request, results)
                            }
                        });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /*
        * Sending File To BK API
        */
        sendRequest(request, result, callback) {
            try {
                request.body = super.lodash.merge(request.body, result, { "module": request.headers.module, "mode": request.headers.mode, "ids": [request.headers.id || ""] });
                const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                    url = `${request.productsURL.iContract["soa"]}/contract/uploaddocument`;
                http.post(url, 'uploadDocument', request.body, (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };
    }
    return Attachment;
};