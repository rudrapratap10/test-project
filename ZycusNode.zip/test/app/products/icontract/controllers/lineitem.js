/**
 * LineItem Controller
 * @description :: Provides LineItem related CRUD operation.
 */
module.exports = (parentClass) => {
    class LineItem extends parentClass {
        /**
        * @Method Name : downloadReferenceSheet
        * @Description : Get Template 
        * @return object / Throw Error
        */
        downloadReferenceSheet(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/lineItem/downloadReferenceSheetForLineItem`;
                http.get(url, 'downloadReferenceSheet', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : searchKey
        * @Description : Get Line Item Categories Auto Suggest
        * @return object / Throw Error
        */
        searchKey(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "searchKey": "joi.number().required().label('icontract-lable-128__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "searchKey": request.params.lineitem_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/getLineItemCategoriesAutoSuggest/searchKey/${request.params.lineitem_Id}`;
                    http.get(url, 'searchKey', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "unspscCode": { "type": "string" }, "segment": { "type": "string" }, "family": { "type": "string" }, "categoryClass": { "type": "string" }, "commodity": { "type": "string" }, "searchText": { "type": "string" }, "categoryCode": { "type": "string" }, "parentCategoryCode": { "type": "string" }, "categoryName": { "type": "string" }, "children": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Method Name : bulkUploadStatus
        * @Description : Get status of the 'bulk upload for line item'
        * @return object / Throw Error
        */
        bulkUploadStatus(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contentType": "joi.string().label('icontract-lable-131__')",
                        "fileName": "joi.string().required().label('icontract-lable-132__')",
                        "content": "joi.string().label('icontract-lable-133__')",
                        "ids": "joi.array().items(joi.string()).label('icontract-lable-95__')",
                        "failureCount": "joi.number().label('icontract-lable-134__')",
                        "mode": "joi.string().label('icontract-lable-7__')",
                        "module": "joi.string().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/downloadStatusOfBulkUploadLineItem`;
                    http.post(url, 'bulkUploadStatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getFields
        * @Description : Get get Fields 
        * @return object / Throw Error
        */
        getFields(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isAuthoring": "joi.boolean().required().label('icontract-lable-139__')",
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "lineItemId": "joi.string().label('icontract-lable-140__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/getLineItemFields`;
                    http.post(url, 'getFields', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : Delete Line Item
        * @Description : Delete 
        * @return object / Throw Error
        */
        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isAuthoring": "joi.boolean().required().label('icontract-lable-139__')",
                        "lineItemId": "joi.string().allow('',null).label('icontract-lable-140__')",
                        "lineItemIds": "joi.array().items(joi.string()).unique().label('icontract-lable-237__')",
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                request.body = super.lodash.merge(request.body);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/contract/lineItem/delete`;
                    http.post(url, 'Delete', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : Create Line Item
        * @Description : Create 
        * @return object / Throw Error
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "isAuthoring": "joi.string().required().label('icontract-lable-139__')",
                        "lineItem": `joi.object().keys({
                            lineItemNumber : joi.string().required().label('icontract-lable-151__'),
                            id : joi.string().allow('',null).label('icontract-lable-95__'),
                            description : joi.string().label('icontract-lable-27__'),
                            pricingType : joi.object().keys({
                                id : joi.string().label('icontract-lable-95__'),
                                pricingType : joi.string().label('icontract-lable-152__'),
                            }).allow(null).label('icontract-lable-152__'),
                            uom : joi.object().keys({
                                id : joi.string().label('icontract-lable-95__'),
                                unitOfMeasurement : joi.string().label('icontract-lable-154__'),
                                status : joi.number().label('icontract-lable-6__'),
                                sequence : joi.number().label('icontract-lable-136__'),                                
                            }).label('icontract-lable-153__'),
                            quantity : joi.number().label('icontract-lable-155__'),
                            category : joi.string().allow(null,'').label('icontract-lable-156__'),
                            currency : joi.object().keys({
                                id : joi.string().label('icontract-lable-95__'),
                                currency : joi.string().label('icontract-lable-157__'),
                                status : joi.boolean().label('icontract-lable-6__')                                                              
                            }).label('icontract-lable-157__'),
                            priceType : joi.string().label('icontract-lable-158__'),
                            cost : joi.number().label('icontract-lable-159__'),
                            field_1 : joi.any().allow('').label('icontract-lable-160__'),
                            field_2 : joi.any().allow('').label('icontract-lable-160__'),
                            field_3 : joi.any().allow('').label('icontract-lable-160__'),
                            field_4 : joi.any().allow('').label('icontract-lable-160__'),
                            field_5 : joi.any().allow('').label('icontract-lable-160__'),
                            field_6 : joi.any().allow('').label('icontract-lable-160__'),
                            field_7 : joi.any().allow('').label('icontract-lable-160__'),
                            field_8 : joi.any().allow('').label('icontract-lable-160__'),
                            field_9 : joi.any().allow('').label('icontract-lable-160__'),
                            field_10 : joi.any().allow('').label('icontract-lable-160__'),
                            status : joi.boolean().label('icontract-lable-6__')
                        }).required().label('icontract-lable-139__')`,
                        "lineItemId": "joi.string().when('edit',{ is : true, then : joi.required(), otherwise : joi.allow('',null) }).label('icontract-lable-140__')",
                        "lineItemPricingTypeDTO": `joi.object().keys({
                            pricingType : joi.string().label('icontract-lable-152__'),
                            lineItemPricingType : joi.object().keys({
                                volumeBasedDiscountPricingDetails : joi.array().items(
                                    joi.object().keys({
                                        slabLowerLimit: joi.string().label('icontract-lable-167__'),
                                        slabUpperLimit: joi.string().label('icontract-lable-168__'),
                                        basePrice: joi.string().label('icontract-lable-169__'),
                                        discount: joi.string().label('icontract-lable-170__'),
                                    }).label('icontract-lable-166__')
                                ).label('icontract-lable-165__')
                            }).label('icontract-lable-164__'),
                        }).label('icontract-lable-163__')`,
                        "lineItemPricingTypeId": "joi.string().allow('',null).label('icontract-lable-161__')",
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "edit": "joi.boolean().required().label('icontract-lable-162__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/contract/lineItem/save`;
                    http.post(url, 'Create', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of lineitem 
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addCommonSchema('criteriaGroupWithArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    if (typeof (request.body.criteriaGroup) != "undefined" && typeof (request.body.criteriaGroup.criteriaGroup) != "undefined" && !super.lodash.isEmpty(request.body.criteriaGroup.criteriaGroup)) {
                        request.body.criteriaGroup.logicalOperator = "AND";
                        request.body.criteriaGroup.criteria = request.body.criteriaGroup.criteria.concat(request.body.criteriaGroup.criteriaGroup[0].criteria);
                        delete request.body.criteriaGroup.criteriaGroup;
                    }
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/lineItem/getLineItemsForContract/${request.body.contractId}`;
                    delete request.body.contractId;
                    http.post(url, 'getList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "contractId": { "type": "string" }, "lineItemId": { "type": "string" }, "lineItemNumber": { "type": "string" }, "description": { "type": "string" }, "unitOfMeasurement": { "type": "string" }, "quantity": { "type": "string" }, "currency": { "type": "string" }, "cost": { "type": "string" }, "isValid": { "type": "boolean" }, "lineItemPricingTypeId": { "type": "string" }, "lineItemPricingTypeDTO": { "type": "object", "properties": { "pricingType": { "type": "string" }, "lineItemPricingType": { "type": "object", "properties": { "id": { "type": "string" }, "lineItem": { "type": "string" }, "fixedPrice": { "type": "number" }, "status": { "type": "boolean" } } } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return LineItem;
};
