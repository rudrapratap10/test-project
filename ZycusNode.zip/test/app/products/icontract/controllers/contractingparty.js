/**
 * Templatel Controller 
 * @description :: Provides Template  Details.
 */
module.exports = (parentClass) => {
    class ContractingParty extends parentClass {
        /**
        * @Method Name : getLabels
        * @Description : Get UI Labels 
        * @return object / Throw Error
        */
        getLabels(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/contractingparty/screenLabels`;
                http.get(url, 'contractingPartyGetLabels', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "array", "properties": { "key": { "type": "string" }, "displayLabel": { "type": "string" }, "mappingLabel": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.validObj = false;
                const schema = {
                    "contractId": "joi.string().required().label('icontract-lable-2__')",
                    "contactId": "joi.string().required().label('icontract-lable-70__')",
                    "vendorId": "joi.string().required().label('icontract-lable-9__')",
                    "parentVendorId": "joi.string().allow(null).label('icontract-lable-71__')",
                    "replaceVendorId": "joi.string().allow(null).label('icontract-lable-72__')",
                    "companyType": "joi.string().required().label('icontract-lable-73__')",
                    "order": "joi.number().when('module',{ is :'Repository', then : joi.required()}).label('icontract-lable-74__')",
                    "dbaId": "joi.string().allow(null).label('icontract-lable-75__')",
                    "dbaName": "joi.string().allow(null).label('icontract-lable-76__')",
                    "selectedCustomSiteIdKey": "joi.string().allow('').label('icontract-lable-77__')",
                    "selectedCustomSiteIdValue": "joi.string().allow('').label('icontract-lable-78__')",
                    "module": "joi.string().required().label('icontract-lable-8__')",
                    "replace": "joi.boolean().required().label('icontract-lable-79__')",
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contractingparty/upsertvendor`;
                    http.post(url, 'createContractParties', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of contracting parties  
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contractingparty/getContractingParty`;
                    http.post(url, 'getList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "id": { "type": "string" }, "vendorContact": { "type": "none" }, "sequence": { "type": "number" }, "vendorStatus": { "type": "number" }, "contactDetails": { "type": "none" }, "customVendorField": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getAllContractingPartiesList
         *
         * @Description : Get the list of contracting parties  
         * @return object / Throw Error
         */
        getAllContractingPartiesList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contractingparty/getAllContractingParties`;
                    http.post(url, 'getList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "dbaId": { "type": "number" }, "name": { "type": "string" }, "taxId": { "type": "string" }, "supplierType": { "type": "string" }, "companyType": { "type": "string" }, "customFeilds": { "type": "array", "properties": { "name": { "type": "string" }, "value": { "type": "string" } } }, "dbaListingDetails": { "type": "none" }, "customVendorFieldList": { "type": "none" }, "contactPersonDetails": { "type": "array", "properties": { "firstName": { "type": "string" }, "lastName": { "type": "string" }, "title": { "type": "string" }, "emailId": { "type": "string" }, "phoneNumber": { "type": "string" }, "cellNumber": { "type": "string" }, "fax": { "type": "string" }, "contactDetailId": { "type": "number" }, "dbaId": { "type": "number" }, "address": { "type": "string" }, "country": { "type": "string" }, "state": { "type": "string" }, "customVendorSiteId": { "type": "string" }, "name": { "type": "string" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : destroy
         *
         * @Description : Delete the contract parties
         * @return object / Throw Error
         */

        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "contactId": "joi.string().required().label('icontract-lable-70__')",
                        "vendorId": "joi.string().required().label('icontract-lable-9__')",
                        "isPrimary": "joi.boolean().required().label('icontract-lable-135__')",
                        "sequence": "joi.number().required().label('icontract-lable-136__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contractingparty/delete`;
                    http.post(url, 'DeleteContractParties', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : makePrimary
         *
         * @Description : Make contracting party primary
         * @return object / Throw Error
         */
        makePrimary(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "contactId": "joi.string().required().label('icontract-lable-70__')",
                        "vendorId": "joi.string().required().label('icontract-lable-9__')",
                        "sequence": "joi.number().required().label('icontract-lable-136__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contractingparty/makePrimary`;
                    http.post(url, 'DeleteContractParties', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return ContractingParty;
};