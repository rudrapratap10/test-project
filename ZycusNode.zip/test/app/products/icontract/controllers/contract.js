/**
 * Contract Filter Controller
 * @description :: Provides Contract related CRUD operation.
 */
module.exports = (parentClass) => {
    class Contract extends parentClass {
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of contract 
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addCommonSchema('criteriaGroupWithArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    if (typeof (request.body.criteriaGroup) != "undefined" && typeof (request.body.criteriaGroup.criteriaGroup) != "undefined" && !super.lodash.isEmpty(request.body.criteriaGroup.criteriaGroup)) {
                        request.body.criteriaGroup.logicalOperator = "AND";
                        request.body.criteriaGroup.criteria = request.body.criteriaGroup.criteria.concat(request.body.criteriaGroup.criteriaGroup[0].criteria);
                        delete request.body.criteriaGroup.criteriaGroup;
                    }
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/authoring/filter`;
                    http.post(url, 'getAuthoringContractList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "id": { "type": "string" }, "contractTitle": { "type": "string" }, "contractNumber": { "type": "string" }, "type": { "type": "string" }, "subtype": { "type": "string" }, "contractingParty": { "type": "string" }, "stage": { "type": "string" }, "status": { "type": "string" }, "stageCode": { "type": "number" }, "statusCode": { "type": "number" }, "contractValue": { "type": "string" }, "contractCategory": { "type": "string" }, "region": { "type": "string" }, "currency": { "type": "string" }, "contractCreationDate": { "type": "none" }, "contractModificationDate": { "type": "none" }, "contractStartDate": { "type": "none" }, "contractEndDate": { "type": "none" }, "contractSource": { "type": "string" }, "templateType": { "type": "string" }, "contractSignDate": { "type": "none" }, "owner": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getContractList
         *
         * @Description : Get the list of contract 
         * @return object / Throw Error
         */
        getContractList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "vendorId": "joi.string().allow(null).label('icontract-lable-9__')",
                        "type": "joi.string().allow(null).label('icontract-lable-10__')",
                        "subType": "joi.string().allow(null).label('icontract-lable-11__')",
                        "categoryDesc": "joi.string().allow(null).label('icontract-lable-12__')",
                        "BUDesc": "joi.string().allow(null).label('icontract-lable-13__')"
                    };
                validationUtility.addInternalSchema(schema);
                validationUtility.addCommonSchema('pagination');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, null, super.appConstant.resHandler.none),
                        tenantId = request.user.tenantId,
                        vendorId = request.body.vendorId || null,
                        type = request.body.type || null,
                        subType = request.body.subType || null,
                        categoryDesc = request.body.categoryDesc || null,
                        BUDesc = request.body.BUDesc || null,
                        startIndex = (request.body.pageNo && request.body.perPageRecords) ? ((request.body.pageNo - 1) * request.body.perPageRecords) + 1 : (request.body.pageNo) ? ((request.body.pageNo - 1) * 10) + 1 : 1,
                        endIndex = (request.body.perPageRecords && request.body.pageNo) ? request.body.pageNo * request.body.perPageRecords : (request.body.perPageRecords) ? request.body.perPageRecords : (startIndex + 10) - 1,
                        url = `${request.productsURL.iContract["web"]}/contract/getContracts/${tenantId}/${vendorId}/${type}/${subType}/${categoryDesc}/${BUDesc}/${startIndex}/${endIndex}`;
                    http.get(url, 'getContractList', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            result.data = JSON.parse(result.data);
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * @Method Name : destroy
         *
         * @Description : Delete the contract
         * @return object / Throw Error
         */

        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).unique().required().label('icontract-lable-2__')",
                        "comment": "joi.string().label('icontract-lable-3__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/deletecontract`;
                    http.post(url, 'DeleteContract', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const message = { description: "icontract-msg-1" };
                            if (!super.lodash.isEmpty(result.data.id)) {
                                result.message = [message];
                            }
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        }
        /**
        * @Method Name : cloningContract
        *
        * @Description : Cloning Contract
        * @return object / Throw Error
        */

        cloningContract(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().min(1).required().label('icontract-lable-2__')",
                        "amendment": "joi.boolean().required().label('icontract-lable-3__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/authoring/getTemplateVersionForCloningContract`;
                    http.post(url, 'getTemplateVersionForCloningContract', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "AUTHORING_ROUND": { "type": "boolean" }, "NEW_TEMPLATE": { "type": "boolean" }, "ORIGINAL_TEMPLATE": { "type": "boolean" }, "LATEST_TEMPLATE": { "type": "boolean" }, "NEGOTIATION_ROUND": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : checkLineItemsPermission
        * @Description : Permission to bulk download of Line Items (for multiple contracts) API
        * @return object / Throw Error
        */
        checkLineItemsPermissions(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/candownloadlineitem`;
                    http.post(url, 'checkLineItemsPermissions', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : checkDocumentPermission
        * @Description : Bulk Contract documents permission API
        * @return object / Throw Error
        */
        checkDocumentPermissions(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "module": "joi.string().required().valid('Authoring','Repository').insensitive().label('icontract-lable-8__')"

                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/contract/documents/permission`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getFilterData
        * @Description : Get All Filter Parameters with Values for given module
        * @return object / Throw Error
        */
        getFilterData(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().required().valid('Authoring','Repository','Clause','Template').insensitive().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getfilterwithvalues/${request.body.module}`;
                    http.get(url, 'downloadDocuments', (error, result) => {
                        if (error) return callback(error, null);
                        else return callback(null, request, result);
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getCustomMasters
         *
         * @Description : Get enumeration values for a given custom master field
         * @return object / Throw Error
         */
        getCustomMasters(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/custommaster/filter`;
                    http.post(url, 'getCustomMasters', request.body, (error, result) => {

                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "fieldName": { "type": "string" }, "fieldValues": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getTypeSubType
        * @Description : Get all contract types and sub types
        * @return object / Throw Error
        */
        getTypes(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/contract/gettypesubtype`;
                http.get(url, 'getTypes', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "array", "properties": { "typeName": { "type": "string" }, "typeDisplayName": { "type": "string" }, "subTypeList": { "type": "array", "properties": { "hierarchyId": { "type": "string" }, "typeName": { "type": "string" }, "typeDisplayName": { "type": "string" }, "subTypeName": { "type": "string" }, "subTypeDisplayName": { "type": "string" } } } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : getConfiguration
         * @Description : Get ProductConfiguration for Contract Outline Document 
         * @return object / Throw Error
         */
        getConfiguration(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "subtypeId": "joi.string().required().label('icontract-lable-15__')",
                        "module": "joi.string().required().valid('Authoring','Repository','Clause','Template').insensitive().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    callback(new (super.customError)(result, 'ValidationError', 3), null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getcontractconfigurationdetails`;
                    http.post(url, 'getConfiguration', request.body, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "fieldName": { "type": "string" }, "fieldType": { "type": "none" }, "maxLength": { "type": "number" }, "isMandatory": { "type": "boolean" }, "isVisible": { "type": "boolean" }, "isEditable": { "type": "boolean" }, "isVisibleInAuthoring": { "type": "boolean" }, "headerName": { "type": "string" }, "headerSequence": { "type": "number" }, "subHeaderName": { "type": "string" }, "subHeaderSequence": { "type": "number" }, "values": { "type": "none" }, "subFields": { "type": "none" }, "subEntityScreenLbl": { "type": "string" }, "toolTip": { "type": "String" }, "isSubEntityMandatory": { "type": "boolean" }, "fieldDisplayName": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : getAuthoringConfiguration
         * @Description : Get get Authoring Configuration 
         * @return object / Throw Error
         */
        getAuthoringConfiguration(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    requestData = {
                        "subtypeId": request.params.subTypeId,
                        "module": request.params.module
                    },
                    schema = {
                        "subtypeId": "joi.string().required().label('icontract-lable-15__')",
                        "module": "joi.string().required().valid('Authoring','Repository','Clause','Template').label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(requestData);
                if (result) {
                    callback(new (super.customError)(result, 'ValidationError', 3), null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getauthoringcontractconfigurationdetails`;
                    http.post(url, 'getAuthoringConfiguration', requestData, (error, result) => {
                        if (error) {
                            callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contractFields": { "type": "array", "properties": { "id": { "type": "string" }, "fieldName": { "type": "string" }, "fieldType": { "type": "none" }, "maxLength": { "type": "number" }, "isMandatory": { "type": "boolean" }, "isVisible": { "type": "boolean" }, "isEditable": { "type": "boolean" }, "isVisibleInAuthoring": { "type": "boolean" }, "headerName": { "type": "string" }, "headerSequence": { "type": "number" }, "subHeaderName": { "type": "string" }, "subHeaderSequence": { "type": "number" }, "values": { "type": "none" }, "subFields": { "type": "none" }, "subEntityScreenLbl": { "type": "string" }, "toolTip": { "type": "String" }, "isSubEntityMandatory": { "type": "boolean" }, "fieldDisplayName": { "type": "string" }, "selectedValues": { "type": "none" } } }, "showNegotiationWorkflow": { "type": "boolean" }, "showAuthorWorkflow": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : getContractAutoTitle
         *
         * @Description : Get 'auto-title' base on "type and subtype ", contract Category or region selection
         * @return object / Throw Error
         */
        getTitle(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    requestBody = { "body": request.body },
                    schema = {
                        "body": `joi.object().keys({
                            type: joi.string().allow('').label('icontract-lable-10__'),
                            subType: joi.string().allow('').label('icontract-lable-11__'),
                            contractCategory: joi.string().allow('').label('icontract-lable-16__'),
                            region: joi.string().allow('').label('icontract-lable-17__')
                        }).min(1).label('icontract-lable-18__')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(requestBody);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getContractAutoTitleFormat`;
                    http.post(url, 'getTitle', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "errorMsg": { "type": "string" }, "errorCode": { "type": "number" }, "error": { "type": "boolean" }, "autoTitleConfig": { "type": "object", "properties": { "configId": { "type": "string" }, "masterId": { "type": "object", "properties": { "masterId": { "type": "number" }, "masterField": { "type": "string" }, "masterDisplayName": { "type": "string" }, "active": { "type": "boolean" } } }, "fieldId": { "type": "string" }, "fieldName": { "type": "string" }, "titleStartNumber": { "type": "string" }, "titleCurrentSequence": { "type": "string" }, "createdAt": { "type": "none" }, "modifiedAt": { "type": "none" }, "createdBy": { "type": "string" }, "modifiedby": { "type": "string" }, "separator": { "type": "string" }, "preview": { "type": "string" }, "active": { "type": "string" }, "fields": { "type": "array", "properties": { "id": { "type": "string" }, "fieldName": { "type": "string" }, "fieldDisplayName": { "type": "string" }, "sequence": { "type": "number" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getBUList
        *
        * @Description : Get the list of Business unit 
        * @return object / Throw Error
        */
        getBUList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getAllBusinessUnits`;
                    http.post(url, 'getBUList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "none" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getMetaData
        * @Description : Get Filtered MetaData By BaseType 
        * @return object / Throw Error
        */
        getMetaData(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "subtypeId": "joi.string().label('icontract-lable-15__')",
                        "contractId": "joi.string().allow(null).required().label('icontract-lable-2__')",
                        "commonContractId": "joi.string().allow(null).required().label('icontract-lable-19__')",
                        "contractModule": "joi.string().required().label('icontract-lable-20__')",
                        "contractCloning": "joi.boolean().required().label('icontract-lable-21__')",
                        "metaDataClone": "joi.boolean().required().label('icontract-lable-22__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getcontractmetadata`;
                    http.post(url, 'getMetaData', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "structuredFieldMap": { "type": "none" }, "contractId": { "type": "string" }, "contractCommonId": { "type": "string" }, "contractModule": { "type": "string" }, "flexiForms": { "type": "none" }, "autoRenewEnabled": { "type": "boolean" }, "confidentialityFeatureInUse": { "type": "boolean" }, "contractCloning": { "type": "boolean" }, "flexiTabShow": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getFlexiFormDetails
        * @Description : Get get Flexi Form Details for given contract id
        * @return object / Throw Error
        */
        getFlexiFormDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "iseFormClone": "joi.string().required().label('icontract-lable-64__')",
                        "eFormId": "joi.string().allow(null).label('icontract-lable-65__')"
                    };
                validationUtility.addInternalSchema(schema);
                request.body = super.lodash.merge(request.body, { "contractId": request.params.contract_Id });
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getflexiformdetails`;
                    http.post(url, 'getFlexiFormDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "eFormId": { "type": "string" }, "dynamicInstanceId": { "type": "string" }, "mode": { "type": "string" }, "version": { "type": "number" }, "baseUrlEforms": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getContractEnumFilterData
        * @Description : Get get Contract EnumFilter Data for given module name
        * @return object / Throw Error
        */
        getContractEnumFilterData(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().required().valid('Authoring','Repository','Clause','Template').insensitive().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getContractEnumFilterData/${request.body.module}`;
                    http.get(url, 'getContractEnumFilterData', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "CONTRACT_STAGE": { "type": "array", "properties": { "id": { "type": "string" }, "value": { "type": "string" } } }, "CONTRACT_SOURCE": { "type": "array", "properties": { "id": { "type": "string" }, "value": { "type": "string" } } }, "TEMPLATETYPE": { "type": "array", "properties": { "id": { "type": "string" }, "value": { "type": "string" } } }, "CONTRACT_STATUS": { "type": "array", "properties": { "id": { "type": "string" }, "value": { "type": "string" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : categoriesList
         *
         * @Description : Get the list of contract categories
         * @return object / Throw Error
         */
        categoriesList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getallcontractcategories`;
                    http.post(url, 'categoriesList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "CONTRACT_CATEGORY": { "type": "array", "properties": { "id": { "type": "string" }, "categoryName": { "type": "string" }, "status": { "type": "boolean" }, "sequence": { "type": "number" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : foldersList
         *
         * @Description : Get the list of contract folder
         * @return object / Throw Error
         */
        foldersList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getFolders`;
                    http.post(url, 'foldersList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "totalRecords": { "type": "number" }, "FOLDER": { "type": "array", "properties": { "folderId": { "type": "number" }, "folderName": { "type": "string" }, "typeSubTypes": { "type": "string" }, "categories": { "type": "string" }, "active": { "type": "number" }, "createdDate": { "type": "none" }, "typeSubType": { "type": "none" }, "category": { "type": "none" }, "folderScopeSaved": { "type": "number" }, "status": { "type": "boolean" }, "isConfidential": { "type": "number" }, "isSearchable": { "type": "number" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : regionsList
         *
         * @Description : Get the list of contract regions
         * @return object / Throw Error
         */
        regionsList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getallregions`;
                    http.post(url, 'regionsList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "REGION": { "type": "array", "properties": { "id": { "type": "string" }, "region": { "type": "string" }, "status": { "type": "boolean" }, "sequence": { "type": "number" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : signersList
         *
         * @Description : Get the list of contract signers 
         * @return object / Throw Error
         */
        signersList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getcontractsigners`;
                    http.post(url, 'signersList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "CONTRACT_SIGNER": { "type": "array", "properties": { "contractSignerId": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "emailId": { "type": "string" }, "designation": { "type": "string" }, "companyName": { "type": "string" }, "party": { "type": "string" }, "contractId": { "type": "string" }, "createdBy": { "type": "string" }, "createdDate": { "type": "none" }, "modifiedBy": { "type": "string" }, "modifiedDate": { "type": "none" }, "signerDate": { "type": "none" }, "signingStatus": { "type": "string" }, "signingOrder": { "type": "number" }, "signingPlace": { "type": "string" }, "address": { "type": "string" }, "customAttributeJson": { "type": "none" }, "populateFromJson": { "type": "string" }, "signerIdentity": { "type": "number" }, "fullName": { "type": "string" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : ownersList
         *
         * @Description : Get the list of contract owners 
         * @return object / Throw Error
         */
        ownersList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getallcontractowner`;
                    http.post(url, 'ownersList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "CONTRACT_OWNER": { "type": "array", "properties": { "id": { "type": "string" }, "emailId": { "type": "string" }, "firstName": { "type": "string" }, "lastName": { "type": "string" }, "fullName": { "type": "string" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : vendorsList
         *
         * @Description : Get the list of contract owners 
         * @return object / Throw Error
         */
        vendorsList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getallvendorforfilter`;
                    http.post(url, 'vendorsList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "CONTRACTING_PARTY": { "type": "array", "properties": { "id": { "type": "string" }, "name": { "type": "string" }, "parentVendor": { "type": "none" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : hierarchyStatusList
         *
         * @Description : Get All Contract hierarchy Status List
         * @return object / Throw Error
         */
        hierarchyStatusList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/contract/getallhierarchystatus`;
                    http.post(url, 'getallhierarchystatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "pageNo": { "type": "number" }, "noOfRecordsPerPage": { "type": "number" }, "sortBy": { "type": "string" }, "searchText": { "type": "string" }, "searchColumn": { "type": "string" }, "startRowNumber": { "type": "number" }, "endRowNumber": { "type": "number" }, "filterParameters": { "type": "none" }, "appliedFiltersAndValuesMap": { "type": "none" }, "ascending": { "type": "boolean" }, "CONTRACT_HIERARCHY": { "type": "array", "properties": { "screenLabel": { "type": "string" }, "abbreviation": { "type": "string" }, "cannotHaveChild": { "type": "boolean" }, "cannotHaveParent": { "type": "boolean" }, "active": { "type": "boolean" }, "sequence": { "type": "number" }, "createdDate": { "type": "none" }, "modifiedDate": { "type": "none" }, "id": { "type": "string" }, "hierarchyStatus": { "type": "string" }, "legacy": { "type": "boolean" } } } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getDateNumeric
        * @Description : Get all date and numeric value
        * @return object / Throw Error
        */
        getDateNumeric(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/contract/getdateandnumericFilter`;
                http.get(url, 'getdateandnumericFilter', (error, result) => {
                    if (error) {
                        return callback(error, null);
                    } else {
                        const responseSchema = { "type": "object", "properties": { "CONTRACT_CREATION_DATE": { "type": "string" }, "CONTRACT_EFFECTIVE_DATE": { "type": "string" }, "CONTRACT_EXPIRATION_DATE": { "type": "string" }, "CONTRACT_MODIFIED_AT": { "type": "string" }, "CONTRACT_SIGNED_ON": { "type": "string" }, "CONTRACT_VALUE": { "type": "object", "properties": { "min": { "type": "number" }, "max": { "type": "number" } } } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : downloadTemplate
        * @Description : Get Template 
        * @return object / Throw Error
        */
        downloadTemplate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "entity": "joi.string().required().insensitive().label('icontract-lable-130__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloadTemplateForBulkUpload/${request.body.entity}`;
                    http.get(url, 'downloadTemplate', (error, result) => {
                        if (error) return callback(error, null);
                        else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : Create Contract
        * @Description : Create Contract
        * @return object / Throw Error
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().label('icontract-lable-8__')",
                        "authoringFieldsRequestDTO": `joi.object().keys({
                            bypassAuthoringWorkflow: joi.number().label('icontract-lable-208__'),
                            bypassNegotiateStage: joi.boolean().label('icontract-lable-209__'),
                            repoAmendment: joi.boolean().label('icontract-lable-210__'),
                            shouldDocumentsClone: joi.boolean().label('icontract-lable-211__'),
                            shouldLineItemsClone: joi.boolean().label('icontract-lable-212__'),
                            shouldMetaDataClone: joi.boolean().label('icontract-lable-213__'),
                            useCloneContractTemplate: joi.boolean().allow('',null).label('icontract-lable-214__'),                            
                        }).allow(null).label('icontract-lable-207__')`,
                        "subtypeId": "joi.string().label('icontract-lable-15__')",
                        "cloneContractId": "joi.string().allow('', null).label('icontract-lable-81__')",
                        "cloneContractCommonId": "joi.string().allow('', null).label('icontract-lable-82__')",
                        "oldHierarchyStatusId": "joi.string().allow('', null).label('icontract-lable-83__')",
                        "contractTitleConfigId": "joi.string().allow('',null).label('icontract-lable-84__')",
                        "draft": "joi.boolean().label('icontract-lable-85__')",
                        "autotitle": "joi.boolean().label('icontract-lable-86__')",
                        "confidentialityFeatureInUse": "joi.boolean().label('icontract-lable-87__')",
                        "clone": "joi.boolean().label('icontract-lable-88__')",
                        "flexiFormInstanceDTO": `joi.object().keys({
                            formInstance: joi.string().label('icontract-lable-90__'),
                            dynamicInstanceId: joi.string().label('icontract-lable-91__'),
                            dynamicFormId: joi.string().label('icontract-lable-92__'),
                            version: joi.number().label('icontract-lable-93__'),
                        }).allow(null).label('icontract-lable-89__')`,
                        "templateManager": `joi.object().keys({
                            id: joi.string().label('icontract-lable-95__'),
                            sections: joi.array().items(joi.object()).label('icontract-lable-96__'),
                            templateCreatedFrom: joi.number().label('icontract-lable-97__'),
                            templateDocId: joi.string().label('icontract-lable-98__'),
                            docHtml: joi.string().label('icontract-lable-99__'),                          
                        }).allow(null).label('icontract-lable-94__')`,
                        "fieldDTOs": `joi.array().items(
                            joi.object().keys({
                                fieldName: joi.string().label('icontract-lable-101__'),
                                fieldType: joi.string().allow('',null).label('icontract-lable-102__'),
                                fieldDisplayValue: joi.any().label('icontract-lable-103__'),
                                fieldDataBaseValue: joi.any().label('icontract-lable-104__'),
                            })
                        ).label('icontract-lable-100__')`,
                        "manyToManySubEntity": `joi.array().items(
                            joi.object().keys({
                                subEntityKey: joi.string().label('icontract-lable-106__'),
                                subEntityValue: joi.array().items(joi.string()).label('icontract-lable-107__')                               
                            })
                        ).label('icontract-lable-105__')`,
                        "oneToManySubEntity": `joi.array().items(
                            joi.object().keys({
                                subEntityKey: joi.string().label('icontract-lable-106__'),
                                subEntityValue: joi.array().items(joi.object().keys({
                                    id: joi.string().label('icontract-lable-95__'),
                                    fieldName: joi.string().label('icontract-lable-101__'),
                                    fieldType: joi.string().label('icontract-lable-102__'),
                                    maxLength: joi.number().label('icontract-lable-110__'),
                                    isMandatory: joi.boolean().label('icontract-lable-111__'),
                                    isVisible: joi.boolean().label('icontract-lable-112__'),
                                    isEditable: joi.boolean().label('icontract-lable-113__'),
                                    isVisibleInAuthoring: joi.boolean().label('icontract-lable-114__'),
                                    headerName: joi.string().label('icontract-lable-115__'),
                                    headerSequence: joi.number().label('icontract-lable-116__'),
                                    subHeaderName: joi.string().label('icontract-lable-117__'),
                                    subHeaderSequence: joi.number().label('icontract-lable-118__'),
                                    subFields: joi.array().items(joi.object()).label('icontract-lable-123__'),
                                    selectedValues: joi.array().items(joi.object().keys({
                                        id: joi.string().label('icontract-lable-95__'),
                                        isSelected: joi.boolean().label('icontract-lable-121__'),
                                        resourceKey: joi.string().label('icontract-lable-122__'),
                                        value: joi.object().label('icontract-lable-120__')
                                    })).label('icontract-lable-141__'),
                                    subEntityScreenLbl: joi.string().label('icontract-lable-124__'),
                                    toolTip: joi.string().label('icontract-lable-125__'),
                                    isSubEntityMandatory: joi.boolean().label('icontract-lable-126__'),
                                    fieldDisplayName: joi.string().label('icontract-lable-127__'),
                                    values: joi.array().items(joi.object().keys({
                                        id: joi.string().label('icontract-lable-95__'),
                                        value: joi.object().label('icontract-lable-120__'),
                                        resourceKey: joi.string().label('icontract-lable-122__'),
                                        isSelected: joi.boolean().label('icontract-lable-121__'),
                                    })).label('icontract-lable-119__'),                                    
                                })).label('icontract-lable-107__')                               
                            })
                        ).label('icontract-lable-108__')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/savecontract`;
                    http.post(url, 'create', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "commonContractId": { "type": "string" }, "contractId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : Update
        * @Description : Update Contract
        * @return object / Throw Error
        */
        update(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "module": "joi.string().required().label('icontract-lable-8__')",
                        "subtypeId": "joi.string().required().label('icontract-lable-15__')",
                        "contractCommonId": "joi.string().required().label('icontract-lable-202__')",
                        "oldContractDocId": "joi.string().allow('',null).label('icontract-lable-203__')",
                        "oldFolderId": "joi.string().allow('',null).label('icontract-lable-204__')",
                        "oldOwnerEmailId": "joi.string().email().label('icontract-lable-205__')",
                        "revisionComment": "joi.string().allow('',null).label('icontract-lable-206__')",
                        "oldHierarchyStatusId": "joi.string().allow('', null).label('icontract-lable-83__')",
                        "contractTitleConfigId": "joi.string().allow('',null).label('icontract-lable-84__')",
                        "draft": "joi.boolean().label('icontract-lable-85__')",
                        "autotitle": "joi.boolean().label('icontract-lable-86__')",
                        "confidentialityFeatureInUse": "joi.boolean().label('icontract-lable-87__')",
                        "clone": "joi.boolean().label('icontract-lable-88__')",
                        "flexiFormInstanceDTO": `joi.object().keys({
                            formInstance: joi.string().label('icontract-lable-90__'),
                            dynamicInstanceId: joi.string().label('icontract-lable-91__'),
                            dynamicFormId: joi.string().label('icontract-lable-92__'),
                            version: joi.number().label('icontract-lable-93__'),
                        }).allow(null).label('icontract-lable-89__')`,
                        "authoringFieldsRequestDTO": `joi.object().keys({
                            bypassAuthoringWorkflow: joi.number().label('icontract-lable-208__'),
                            bypassNegotiateStage: joi.boolean().label('icontract-lable-209__'),
                            repoAmendment: joi.boolean().label('icontract-lable-210__'),
                            shouldDocumentsClone: joi.boolean().label('icontract-lable-211__'),
                            shouldLineItemsClone: joi.boolean().label('icontract-lable-212__'),
                            shouldMetaDataClone: joi.boolean().label('icontract-lable-213__'),
                            useCloneContractTemplate: joi.boolean().label('icontract-lable-214__'),                            
                        }).allow(null).label('icontract-lable-207__')`,
                        "templateManager": `joi.object().keys({
                            id: joi.string().label('icontract-lable-95__'),
                            sections: joi.array().items(joi.object()).label('icontract-lable-96__'),
                            templateCreatedFrom: joi.number().label('icontract-lable-97__'),
                            templateDocId: joi.string().label('icontract-lable-98__'),
                            docHtml: joi.string().label('icontract-lable-99__'),                          
                        }).allow(null).label('icontract-lable-94__')`,
                        "fieldDTOs": `joi.array().items(
                            joi.object().keys({
                                fieldName: joi.string().label('icontract-lable-101__'),
                                fieldType: joi.string().allow('',null).label('icontract-lable-102__'),
                                fieldDisplayValue: joi.any().label('icontract-lable-103__'),
                                fieldDataBaseValue: joi.any().label('icontract-lable-104__'),
                            })
                        ).label('icontract-lable-100__')`,
                        "oldFieldIdDataDTOs": `joi.array().items(
                            joi.object().keys({
                                fieldName: joi.string().label('icontract-lable-101__'),
                                fileId: joi.string().label('icontract-lable-216__'),                               
                            })
                        ).label('icontract-lable-215__')`,
                        "manyToManySubEntity": `joi.array().items(
                            joi.object().keys({
                                subEntityKey: joi.string().label('icontract-lable-106__'),
                                subEntityValue: joi.array().items(joi.string()).label('icontract-lable-107__')                               
                            })
                        ).allow(null).label('icontract-lable-105__')`,
                        "oneToManySubEntity": `joi.array().items(
                            joi.object().keys({
                                subEntityKey: joi.string().label('icontract-lable-106__'),
                                subEntityValue: joi.array().items(joi.object().keys({
                                    id: joi.string().label('icontract-lable-95__'),
                                    fieldName: joi.string().label('icontract-lable-101__'),
                                    fieldType: joi.string().label('icontract-lable-102__'),
                                    maxLength: joi.number().label('icontract-lable-110__'),
                                    isMandatory: joi.boolean().label('icontract-lable-111__'),
                                    isVisible: joi.boolean().label('icontract-lable-112__'),
                                    isEditable: joi.boolean().label('icontract-lable-113__'),
                                    isVisibleInAuthoring: joi.boolean().label('icontract-lable-114__'),
                                    headerName: joi.string().label('icontract-lable-115__'),
                                    headerSequence: joi.number().label('icontract-lable-116__'),
                                    subHeaderName: joi.string().label('icontract-lable-117__'),
                                    subHeaderSequence: joi.number().label('icontract-lable-118__'),
                                    subFields: joi.array().items(joi.object()).label('icontract-lable-123__'),
                                    selectedValues: joi.array().items(joi.object().keys({
                                        id: joi.string().label('icontract-lable-95__'),
                                        isSelected: joi.boolean().label('icontract-lable-121__'),
                                        resourceKey: joi.string().label('icontract-lable-122__'),
                                        value: joi.object().label('icontract-lable-120__')
                                    })).label('icontract-lable-141__'),
                                    subEntityScreenLbl: joi.string().label('icontract-lable-124__'),
                                    toolTip: joi.string().label('icontract-lable-125__'),
                                    isSubEntityMandatory: joi.boolean().label('icontract-lable-126__'),
                                    fieldDisplayName: joi.string().label('icontract-lable-127__'),
                                    values: joi.array().items(joi.object().keys({
                                        id: joi.string().label('icontract-lable-95__'),
                                        value: joi.object().label('icontract-lable-120__'),
                                        resourceKey: joi.string().label('icontract-lable-122__'),
                                        isSelected: joi.boolean().label('icontract-lable-121__'),
                                    })).label('icontract-lable-119__'),                                    
                                })).label('icontract-lable-107__')                               
                            })
                        ).allow(null).label('icontract-lable-108__')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/updatecontract`;
                    http.post(url, 'create', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "commonContractId": { "type": "string" }, "contractId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : download
        * @Description : Download Files
        * @return object / Throw Error
        */
        downloadMainDocument(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contentType": "joi.string().label('icontract-lable-131__')",
                        "fileName": "joi.string().required().label('icontract-lable-132__')",
                        "content": "joi.string().label('icontract-lable-133__')",
                        "ids": "joi.array().items(joi.string()).label('icontract-lable-95__')",
                        "failureCount": "joi.number().label('icontract-lable-134__')",
                        "mode": "joi.string().label('icontract-lable-7__')",
                        "module": "joi.string().required().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/downloadMainDocument`;
                    http.post(url, 'downloadMainDocument', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : deleteDocument
        * @Description : delete Document 
        * @return object / Throw Error
        */
        deleteDocument(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contentType": "joi.string().label('icontract-lable-131__')",
                        "fileName": "joi.string().required().label('icontract-lable-132__')",
                        "content": "joi.string().label('icontract-lable-133__')",
                        "ids": "joi.array().items(joi.string()).label('icontract-lable-95__')",
                        "failureCount": "joi.number().label('icontract-lable-134__')",
                        "mode": "joi.string().label('icontract-lable-7__')",
                        "module": "joi.string().required().label('icontract-lable-8__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/deleteDocument`;
                    http.post(url, 'deleteDocument', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : Bulk Upload
        * @Description : Link Document with contract
        * @return object / Throw Error
        */
        bulkUpload(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contentType": "joi.string().label('icontract-lable-131__')",
                        "fileName": "joi.string().required().label('icontract-lable-132__')",
                        "content": "joi.string().label('icontract-lable-133__')",
                        "ids": "joi.array().items(joi.string()).required().label('icontract-lable-95__')",
                        "failureCount": "joi.number().label('icontract-lable-134__')",
                        "mode": "joi.string().required().label('icontract-lable-7__')",
                        "module": "joi.string().required().label('icontract-lable-8__')",
                        "entity": "joi.string().required().label('icontract-lable-130__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/bulkUpload/${request.body.entity}`;
                    delete request.body.entity;
                    http.post(url, 'bulkUpload', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : saveManyToManyFields
        * @Description : Save many to many fields for a contract
        * @return object / Throw Error
        */
        saveManyToManyFields(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "subTypeId": "joi.string().required().label('icontract-lable-15__')",
                        "manyToManyFieldName": "joi.string().required().label('icontract-lable-225__')",
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "mandatoryFlag": "joi.boolean().label('icontract-lable-227__')",
                        "manyToManyIds": "joi.array().items(joi.string().label('icontract-lable-226__')).required().label('icontract-lable-226__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/savemanytomanyfields`;
                    delete request.body.entity;
                    http.post(url, 'saveManyToManyFields', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "Status": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : deleteManyToManyFields
        * @Description : Delete many to many fields for a contract
        * @return object / Throw Error
        */
        deleteManyToManyFields(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "subTypeId": "joi.string().required().label('icontract-lable-15__')",
                        "manyToManyFieldName": "joi.string().required().label('icontract-lable-225__')",
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "mandatoryFlag": "joi.boolean().label('icontract-lable-227__')",
                        "manyToManyIds": "joi.array().items(joi.string().label('icontract-lable-226__')).required().label('icontract-lable-226__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/deletemanytomanyfields`;
                    delete request.body.entity;
                    http.post(url, 'deleteManyToManyFields', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "Status": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : contractOutline
        * @Description : Save contract OUTLINE
        * @return object / Throw Error
        */
        contractOutline(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "fileName": "joi.string().required().label('icontract-lable-132__')",
                        "fileID": "joi.string().required().label('icontract-lable-216__')",
                        "comments": "joi.string().allow('').label('icontract-lable-3__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/saveContractOutline`;
                    delete request.body.entity;
                    http.post(url, 'contractOutline', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        }
                        else {
                            const responseSchema = { "type": "object", "properties": { "contractId": { "type": "string" }, "fileName": { "type": "string" }, "fileID": { "type": "string" }, "comments": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getMailTemplate
        *
        * @Description : Get Mail Details 
        * @return object / Throw Error
        */
        getMailTemplate(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "mailActionId": "joi.number().required().label('icontract-lable-238__')"
                    };
                validationUtility.addInternalSchema(schema);
                const requestData = { "contractId": request.params.contractId, "mailActionId": request.params.mailActionId },
                    result = validationUtility.validate(requestData);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/contract/getmailtemplate`;
                    http.post(url, 'getMailTemplate', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "status": { "type": "string" }, "actionType": { "type": "number" }, "mailTemplateMap": { "type": "object", "properties": { "message": { "type": "none" }, "subject": { "type": "none" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : getLanguages
        * @Description : Get List Of languages
        * @return object / Throw Error
        */
       getLanguages(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/contract/getAllanguages`;
                http.get(url, 'getLanguages', (error, result) => {
                    if (error) return callback(error, null);
                    else {
                        const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "status": { "type": "boolean" }, "language": { "type": "string" }, "createdBy": { "type": "number" }, "modifiedBy": { "type": "number" }, "creationDate": { "type": "number" }, "modifiedDate": { "type": "number" }, "sequence": { "type": "number" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return Contract;
};
