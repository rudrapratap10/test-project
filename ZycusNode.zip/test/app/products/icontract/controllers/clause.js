/**
 * Clause Filter Controller
 * @description :: Provides Clause related CRUD operation.
 */
module.exports = (parentClass) => {
    class Clause extends parentClass {
        /**
         * @Method Name : getList
         *
         * @Description : Get the list of Clause 
         * @return object / Throw Error
         */
        getList(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('pagination');
                validationUtility.addCommonSchema('sort');
                validationUtility.addCommonSchema('criteriaGroup');
                validationUtility.addCommonSchema('criteriaGroupWithArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    if (typeof (request.body.criteriaGroup) != "undefined" && typeof (request.body.criteriaGroup.criteriaGroup) != "undefined" && !super.lodash.isEmpty(request.body.criteriaGroup.criteriaGroup)) {
                        request.body.criteriaGroup.logicalOperator = "AND";
                        request.body.criteriaGroup.criteria = request.body.criteriaGroup.criteria.concat(request.body.criteriaGroup.criteriaGroup[0].criteria);
                        delete request.body.criteriaGroup.criteriaGroup;
                    }
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.filter, super.appConstant.resHandler.filter),
                        url = `${request.productsURL.iContract["soa"]}/clause/filter`;
                    http.post(url, 'getClauseList', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "records": { "type": "array", "properties": { "title": { "type": "string" }, "id": { "type": "string" }, "groupId": { "type": "string" }, "sourceCode": { "type": "number" }, "clauseCategory": { "type": "string" }, "lastModificationDate": { "type": "none" }, "fallback": { "type": "number" }, "status": { "type": "number" }, "baseTypes": { "type": "none" }, "language": { "type": "string" }, "reviewers": { "type": "none" }, "alternateCount": { "type": "number" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            output.addCommonSchema('pagination', output.responseSchema.properties);
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : updateStatus
         *
         * @Description : Change the status of contracts (For clause Listing)
         * @return object / Throw Error
         */
        updateStatus(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "status": "joi.string().required().valid('Active','Inactive').insensitive().label('icontract-lable-6__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.resHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/clause/update/status`;
                    http.post(url, 'updateStatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());

                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : downloadDocuments
        * @Description : Get the multiple Attachment for given contract id's
        * @return object / Throw Error
        */
        downloadDocuments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "ids": "joi.array().items(joi.string().min(1).required().label('icontract-lable-2__')).min(1).unique().required().label('icontract-lable-2__')",
                        "mode": "joi.string().required().valid('Single','Bulk').insensitive().label('icontract-lable-7__')"
                    };

                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntity, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/clause/documents`;
                    http.post(url, 'downloadDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else if (result.errors) {
                            return callback(result.errors, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : suggestedAction
        * @Description : Get the suggested actions for given contract group id's
        * @return object / Throw Error
        */
        suggestedAction(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.addCommonSchema('idArray');
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.idArray, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/clause/suggestedaction`;
                    http.post(url, 'suggestedAction', request.body, (error, result) => {
                        if (error) return callback(error, null);
                        else return callback(null, request, result);
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getCategory
        * @Description : Get List Of Clause Category
        * @return object / Throw Error
        */
        getCategory(request, input, callback) {
            try {
                const http = new (super.httpService)(request),
                    url = `${request.productsURL.iContract["soa"]}/clause/getClauseCategory`;
                http.get(url, 'getCategory', (error, result) => {
                    if (error) return callback(error, null);
                    else {
                        const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "name": { "type": "string" }, "sequence": { "type": "string" } } },
                            output = (new (super.responseHandler)(request, result, responseSchema));
                        return callback(null, request, output.execute());
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };

    }
    return Clause;
};
