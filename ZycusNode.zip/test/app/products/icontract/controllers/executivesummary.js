/**
 * ExecutiveSummary Controller
 * @description :: Provides ExecutiveSummary related CRUD operation.
 */
module.exports = (parentClass) => {
    class ExecutiveSummary extends parentClass {
        /**
        * @Method Name : getTags
        * @Description : Get Tags to be used for Executive Summary
        * @return object / Throw Error
        */
        getTags(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contractId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, null, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/executivesummary/gettagsforexecutivesummary/contract/${request.params.contractId}`;
                    http.get(url, 'getTags', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "typeSubtypeId": { "type": "string" }, "typeSubtypeViewName": { "type": "string" }, "typeSubtypeColumnName": { "type": "string" }, "typeSubtypeMetadata": { "type": "string" }, "typeSubtypeColumnType": { "type": "string" }, "isAuthoring": { "type": "number" }, "screenLabel": { "type": "string" }, "subEntity": { "type": "string" }, "subEntityRelationship": { "type": "string" }, "header": { "type": "string" }, "subHeader": { "type": "string" }, "metadataId": { "type": "string" }, "hidden": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : showSummary
        * @Description : Show Executive Summary
        * @return object / Throw Error
        */
        showSummary(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contractId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/executivesummary/showexecutivesummary/contract/${request.params.contractId}`;
                    http.get(url, 'showSummary', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "status": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
        * @Method Name : create
        * @Description : Save Executive Summary
        * @return object / Throw Error
        */
        create(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "selectedSummaryType": "joi.string().required().label('icontract-lable-217__')",
                        "contractSummaryText": "joi.string().required().label('icontract-lable-218__')",
                        "isAuthoring": "joi.boolean().required().label('icontract-lable-139__')",
                        "hasAuthoringLogs": "joi.string().required().label('icontract-lable-219__')",
                        "sendInMail": "joi.string().required().label('icontract-lable-220__')",
                        "hasNegotiateLogs": "joi.string().required().label('icontract-lable-221__')",
                        "hasSignOffLogs": "joi.string().required().label('icontract-lable-222__')",
                        "uploadedCustomFileName": "joi.string().required().label('icontract-lable-223__')",
                        "uploadedCustomFileId": "joi.string().required().label('icontract-lable-224__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/executivesummary/saveexecutivesummarydetails`;
                    http.post(url, 'create', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };

        /**
        * @Method Name : getexecutivesummarydetails
        * @Description : Get Executive Summary Details for given Contract Id
        * @return object / Throw Error
        */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "showContractDetails": "joi.boolean().required().label('icontract-lable-228__')",
                        "isAuthoring": "joi.boolean().required().label('icontract-lable-139__')"
                    };
                validationUtility.addInternalSchema(schema);
                request.body = super.lodash.merge(request.body, { "contractId": request.params.contractId });
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/executivesummary/getexecutivesummarydetails`;
                    http.post(url, 'getDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "isSummaryContentEditable": { "type": "boolean" }, "isSummaryEditable": { "type": "boolean" }, "fileId": { "type": "string" }, "fileName": { "type": "string" }, "summaryContent": { "type": "string" }, "hasAuthLogs": { "type": "boolean" }, "hasSignOffLogs": { "type": "boolean" }, "hasNegotiateLogs": { "type": "boolean" }, "hasSummaryTiles": { "type": "boolean" }, "sendInMail": { "type": "boolean" }, "summaryFileId": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : exportSummary
        * @Description : Export Executive Summary
        * @return object / Throw Error
        */
        exportSummary(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "summaryDownloadFormat": "joi.string().required().label('icontract-lable-240__')",
                        "isAuthoring": "joi.boolean().required().label('icontract-lable-139__')"
                    };
                validationUtility.addInternalSchema(schema);
                request.body = super.lodash.merge(request.body, { "contractId": request.params.contractId });
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/executivesummary/exportexecutivesummary`;
                    http.post(url, 'exportSummary', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contentType": { "type": "string" }, "fileName": { "type": "string" }, "content": { "type": "none" }, "ids": { "type": "none" }, "failureCount": { "type": "number" }, "mode": { "type": "string" }, "module": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return ExecutiveSummary;
};
