/**
 * ScreenLabel Controller 
 * @description :: Provides ScreenLabel Labels Details.
 */
module.exports = (parentClass) => {
    class ScreenLabel extends parentClass {
        /**
        * @Method Name : getLabels
        * @param1 labelId 
        * @Description : Get UI Labels for a type
        * @return object / Throw Error
        */
        getLabels(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "labelId": "joi.string().required().valid('paginatedlist').label('icontract-lable-1__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/authoring/screenlabels/${request.body.labelId}`;
                    http.get(url, 'getLabels', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "region": { "type": "string" }, "contractTitleNo": { "type": "string" }, "status": { "type": "string" }, "contractStartDate": { "type": "string" }, "contractingParty": { "type": "string" }, "type": { "type": "string" }, "subtype": { "type": "string" }, "contractSignDate": { "type": "string" }, "stage": { "type": "string" }, "contractCategory": { "type": "string" }, "contractModificationDate": { "type": "string" }, "currency": { "type": "string" }, "contractEndDate": { "type": "string" }, "id": { "type": "string" }, "templateType": { "type": "string" }, "contractCreationDate": { "type": "string" }, "owner": { "type": "string" }, "contractTitle": { "type": "string" }, "contractValue": { "type": "string" }, "contractSource": { "type": "string" }, "contractNumber": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
    }
    return ScreenLabel;
};