/**
 * LineItem Controller
 * @description :: Provides LineItem related CRUD operation.
 */
module.exports = (parentClass) => {
    class Sign extends parentClass {
        /**
        * @Method Name : getSignersCount
        * @Description : Get Signers Count
        * @return object / Throw Error
        */
        getSignersCount(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.sign_Id });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/getesignatureuitagsforcontract/contract/${request.params.sign_Id}`;
                    http.get(url, 'getSignersCount', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "overallSigners": { "type": "number" }, "noOfInternalSigners": { "type": "number" }, "noOfExternalSigners": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                callback(error, null);
            }
        };
        /**
         * @Method Name : updateSigningStatus
         *
         * @Description : update Signing Status
         * @return object / Throw Error
         */
        updateSigningStatus(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "esigneSelected": "joi.boolean().required().label('icontract-lable-129__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/updatesigningtype`;
                    http.post(url, 'updateSigningStatus', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getBlockConfig
         * @return object / Throw Error
         */
        getBlockConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "blockUsageType": "joi.number().required().label('icontract-lable-138__')",
                        "isEsignatureSelected": "joi.boolean().required().label('icontract-lable-137__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/getsignatureblockconfig`;
                    http.post(url, 'getBlockConfig', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "signingTypeId": { "type": "string" }, "blockMasterId": { "type": "number" }, "elementLable": { "type": "string" }, "isMandatory": { "type": "boolean" }, "isCustome": { "type": "boolean" }, "isVisible": { "type": "boolean" }, "isPrefilled": { "type": "boolean" }, "sequence": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getSignerConfig
         * @return object / Throw Error
         */
        getSignerConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/getsignerconfiguration/contract/${request.body.contractId}`;
                    http.get(url, 'getSignerConfig', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            return callback(null, request, result);
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : saveBlockConfig
         * @return object / Throw Error
         */
        saveBlockConfig(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "deleteUITags": "joi.boolean().required().label('icontract-lable-142__')",
                        "contractSigningBlockElementList": `joi.array().items(
                            joi.object().keys({
                                id: joi.string().required().label('icontract-lable-95__'),    
                                signingTypeId: joi.string().required().label('icontract-lable-144__'),    
                                blockMasterId: joi.number().required().label('icontract-lable-145__'),    
                                elementLable: joi.string().required().label('icontract-lable-146__'),    
                                isMandatory: joi.boolean().required().label('icontract-lable-111__'),    
                                isCustome: joi.boolean().required().label('icontract-lable-147__'),    
                                isVisible: joi.boolean().required().label('icontract-lable-112__'),    
                                isPrefilled: joi.boolean().required().label('icontract-lable-148__'),    
                                sequence: joi.number().required().label('icontract-lable-136__'),    
                            })
                        ).required().label('icontract-lable-143__')`
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/savesignatureblockconfig`;
                    http.post(url, 'saveBlockConfig', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : saveSequence
         * @return object / Throw Error
         */
        saveSequence(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "signersSequence": "joi.object().required().label('icontract-lable-149__')",
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/savesignerssequence`;
                    http.post(url, 'saveSequence', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : getDetails
         * @return object / Throw Error
         */
        getDetails(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "signerId": "joi.string().allow('',null).label('icontract-lable-179__')",
                        "type": "joi.string().required().label('icontract-lable-10__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/getsignerpopupdetails`;
                    http.post(url, 'getDetails', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contractId": { "type": "string" }, "signer": { "type": "string" }, "supplierCompanyName": { "type": "string" }, "esignEnable": { "type": "string" }, "type": { "type": "string" }, "internalSignerCompanyName": { "type": "string" }, "workflowStages": { "type": "none" }, "workFlowApplicableForSignoff": { "type": "boolean" }, "contractLevelDocusign": { "type": "boolean" }, "contractSigningBlockElements": { "type": "array", "properties": { "id": { "type": "string" }, "signingTypeId": { "type": "string" }, "blockMasterId": { "type": "number" }, "elementLable": { "type": "string" }, "isMandatory": { "type": "boolean" }, "isCustome": { "type": "boolean" }, "isVisible": { "type": "boolean" }, "isPrefilled": { "type": "boolean" }, "sequence": { "type": "boolean" } } } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        saveAndUpdateSigner(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "signerId": "joi.string().allow('',null).label('icontract-lable-179__')",
                        "deleteUITags": "joi.boolean().label('icontract-lable-142__')",
                        "deleteSignerBlock": "joi.boolean().label('icontract-lable-180__')",
                        "contractSigner": `joi.object().keys({
                            contractSignerId : joi.string().allow('',null).label('icontract-lable-182__'),
                            firstName : joi.string().label('icontract-lable-183__'),
                            lastName : joi.string().label('icontract-lable-184__'),
                            emailId : joi.string().email().label('icontract-lable-185__'),
                            designation : joi.string().label('icontract-lable-186__'),
                            companyName : joi.string().label('icontract-lable-187__'),
                            party : joi.string().label('icontract-lable-188__'),
                            contractId: joi.string().label('icontract-lable-2__'),
                            createdBy: joi.string().label('icontract-lable-172__'),
                            createdDate: joi.string().label('icontract-lable-189__'),
                            modifiedBy: joi.string().label('icontract-lable-190__'),
                            modifiedDate: joi.string().label('icontract-lable-191__'),
                            signerDate: joi.string().label('icontract-lable-192__'),
                            signingStatus: joi.string().label('icontract-lable-193__'),
                            signingOrder: joi.number().label('icontract-lable-194__'),
                            signingPlace: joi.string().label('icontract-lable-195__'),
                            address: joi.string().label('icontract-lable-196__'),
                            customAttributeJson: joi.string().label('icontract-lable-197__'),
                            populateFromJson: joi.string().label('icontract-lable-198__'),
                            signerIdentity: joi.number().label('icontract-lable-199__'),
                            fullName: joi.string().label('icontract-lable-200__')
                        }).label('icontract-lable-181__')`,
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/addorupdatesigner`;
                    http.post(url, 'create', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : create
         * @return object / Throw Error
         */
        create(request, input, callback) {
            this.saveAndUpdateSigner(request, input, callback);
        };
        /**
         * @Method Name : update
         * @return object / Throw Error
         */
        update(request, input, callback) {
            this.saveAndUpdateSigner(request, input, callback);
        };
        /**
         * @Method Name : skipSigning 
         *
         * @Description : Skip Signing 
         * @return object / Throw Error
         */
        skipSigning(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    requestData = {
                        "contractId": request.params.contractId,
                        "tempFileId": request.params.tempFileId
                    },
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "tempFileId": "joi.string().required().label('icontract-lable-201__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(requestData);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/skipsigning`;
                    http.post(url, 'skipSigning', requestData, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
         * @Method Name : validateSigning 
         *
         * @Description : validate Signing 
         * @return object / Throw Error
         */
        validateSigning(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contractId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/validateSigning/contract/${request.params.contractId}`;
                    http.get(url, 'ValidateSigning', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "emailIds": { "type": "string" }, "isTagMissing": { "type": "boolean" }, "isValid": { "type": "boolean" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : loadDocument 
        *
        * @Description : Load consolidated contract documents 
        * @return object / Throw Error
        */
        loadDocument(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contractId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/loadConsolidatedDocuments/contract/${request.params.contractId}`;
                    http.get(url, 'ValidateSigning', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "contractConsolidatedDocuments": { "type": "array", "properties": { "documentId": { "type": "string" }, "documentName": { "type": "string" }, "templateId": { "type": "string" }, "templateName": { "type": "string" }, "uploadedBy": { "type": "string" }, "uploadedTemplate": { "type": "string" }, "uploadedTemplateId": { "type": "string" }, "isMandatory": { "type": "string" }, "status": { "type": "boolean" }, "templatePresent": { "type": "string" }, "configuredId": { "type": "string" }, "isAdminAdded": { "type": "string" }, "comments": { "type": "string" }, "uploadedOn": { "type": "none" }, "attachmentPageCount": { "type": "number" }, "filesizeInKB": { "type": "number" }, "contractId": { "type": "string" }, "documentOwner": { "type": "string" } } }, "savedConsolidatedDocuments": { "type": "array", "properties": { "id": { "type": "string" }, "contractId": { "type": "string" }, "docId": { "type": "string" }, "uploadedDocId": { "type": "string" }, "docOrder": { "type": "number" }, "documentPageCount": { "type": "number" } } }, "contractTitle": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
         * @Method Name : saveConsolidatedDocuments
         * @return object / Throw Error
         */
        consolidatedDocuments(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request);
                validationUtility.validObj = false;
                const schema = {
                    "docId": "joi.string().required().label('icontract-lable-229__')",
                    "contractId": "joi.string().required().label('icontract-lable-2__')",
                    "documentPageCount": "joi.number().required().required().label('icontract-lable-230__')",
                    "docOrder": "joi.number().required().label('icontract-lable-231__')",
                    "uploadedDocId": "joi.string().required().label('icontract-lable-232__')",
                    "skipSigning": "joi.boolean().required().label('icontract-lable-233__')"
                };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request, super.appConstant.reqHandler.businessEntities, super.appConstant.resHandler.businessEntity),
                        url = `${request.productsURL.iContract["soa"]}/signing/saveConsolidatedDocuments`;
                    http.post(url, 'consolidatedDocuments', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedBy": { "type": "string" }, "modifiedOn": { "type": "number" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : withdrawSigning
        *
        * @Description : Withdraw Signing
        * @return object / Throw Error
        */
        withdrawSigning(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "contractModule": "joi.string().required().label('icontract-lable-20__')",
                        "contractDeclined": "joi.boolean().required().label('icontract-lable-235__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/withdrawSigning`;
                    http.post(url, 'withdrawSigning', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : sendRemainder
        *
        * @Description : Send Reminder to a signer for signing document 
        * @return object / Throw Error
        */
        sendRemainder(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "signerEmailId": "joi.string().email().required().label('icontract-lable-236__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/sendesignreminder`;
                    http.post(url, 'sendesignreminder', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "Status": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : getEsign 
        *
        * @Description : Get ESignature UI Tags For Contract 
        * @return object / Throw Error
        */
        getEsign(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')"
                    };
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate({ "contractId": request.params.contractId });
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/getesignatureuitagsforcontract/contract/${request.params.contractId}`;
                    http.get(url, 'getEsign', (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "array", "properties": { "id": { "type": "string" }, "contractId": { "type": "string" }, "docId": { "type": "string" }, "uiElementId": { "type": "string" }, "elementId": { "type": "number" }, "top": { "type": "number" }, "left": { "type": "number" }, "elementHtml": { "type": "string" }, "pageNo": { "type": "number" }, "pageHeight": { "type": "number" }, "pageWidth": { "type": "number" }, "pdfPageHeight": { "type": "number" }, "pdfPageWidth": { "type": "number" }, "isSaved": { "type": "boolean" }, "isDeleted": { "type": "boolean" }, "signer": { "type": "string" }, "signerId": { "type": "string" }, "isSignerBlock": { "type": "boolean" }, "childElement": { "type": "array", "properties": { "id": { "type": "string" }, "contractId": { "type": "string" }, "docId": { "type": "string" }, "uiElementId": { "type": "string" }, "elementId": { "type": "number" }, "top": { "type": "number" }, "left": { "type": "number" }, "elementHtml": { "type": "string" }, "pageNo": { "type": "number" }, "pageHeight": { "type": "number" }, "pageWidth": { "type": "number" }, "pdfPageHeight": { "type": "number" }, "pdfPageWidth": { "type": "number" }, "isSaved": { "type": "boolean" }, "isDeleted": { "type": "boolean" }, "signer": { "type": "string" }, "signerId": { "type": "string" }, "isSignerBlock": { "type": "boolean" }, "childElement": { "type": "none" }, "topIn72DPI": { "type": "number" }, "leftIn72DPI": { "type": "number" } } }, "topIn72DPI": { "type": "number" }, "leftIn72DPI": { "type": "number" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : Destroy 
        *
        * @Description : Delete Signer
        * @return object / Throw Error
        */
        destroy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "signerId": "joi.string().required().label('icontract-lable-179__')",
                        "fromWithdrawSigner": "joi.boolean().required().label('icontract-lable-239__')",
                        "deleteUITags": "joi.boolean().required().label('icontract-lable-142__')",
                        "deleteSignerBlock": "joi.boolean().required().label('icontract-lable-180__')",
                    };
                request.body = super.lodash.merge(request.body, { "signerId": request.params.sign_Id })
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/deletesigner`;
                    http.post(url, 'Delete', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
        /**
        * @Method Name : saveUploadedSignedCopy 
        *
        * @Description : Save Uploaded signed document details 
        * @return object / Throw Error
        */
        saveUploadedSignedCopy(request, input, callback) {
            try {
                const validationUtility = super.utils.validationUtility(request),
                    schema = {
                        "contractId": "joi.string().required().label('icontract-lable-2__')",
                        "fileId": "joi.string().required().label('icontract-lable-216__')",
                        "comments": "joi.string().label('icontract-lable-3__')",
                    };             
                validationUtility.addInternalSchema(schema);
                const result = validationUtility.validate(request.body);
                if (result) {
                    const errorMsg = new (super.customError)(result, 'ValidationError', 3);
                    return callback(errorMsg, null);
                } else {
                    const http = new (super.httpService)(request),
                        url = `${request.productsURL.iContract["soa"]}/signing/saveUploadedSignedCopy`;
                    http.post(url, 'saveUploadedSignedCopy', request.body, (error, result) => {
                        if (error) {
                            return callback(error, null);
                        } else {
                            const responseSchema = { "type": "object", "properties": { "id": { "type": "string" }, "modifiedOn": { "type": "none" }, "modifiedBy": { "type": "string" }, "info1": { "type": "string" }, "info2": { "type": "string" } } },
                                output = (new (super.responseHandler)(request, result, responseSchema));
                            return callback(null, request, output.execute());
                        }
                    });
                }
            } catch (error) {
                return callback(error, null);
            }
        };
    }

    return Sign;
};
