"use strict";

/**
 * Icontract Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class Icontract {
    


}

module.exports = Icontract;