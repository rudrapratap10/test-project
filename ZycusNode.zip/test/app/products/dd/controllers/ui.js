/**
* UI Controller
*
* @description :: Provides to get the application configuration
*/

"use strict";

module.exports = (parentClass) => {

    class Ui extends parentClass {

        /**
        * @Method Name : getConfig
        *
        * @Description : Get the application config
        * @return object / Throw Error
        */

        getConfig(request, input, callback) {
            try {
                //Fetch Web URL of each products
                const access = request.user.access,
                      webUrl = [];
                access.forEach(item => {
                    webUrl.push(item.productInfo);
                });
                const result = {
                    'content-type': "jsonp",
                    userDetails: {
                        "userId": request.user.userId,
                        "tenantId": request.user.tenantId,
                        "emailId": request.user.emailId
                    },
                    webUrl: webUrl,
                    appConfig: require('@config/ui.config.json'),
                };
                result.appConfig['rainbowActivated'] = request.userSSODetails["@rainbowActivated"];
                if (request.userSSODetails["@rainbowActivated"] === "true") {
                    const endPath = '/ZycusCommonHeader/COMMON_HEADER.do?_sv='+request.tokenId;
                    if (!super.lodash.isUndefined(request.userSSODetails['@rainbowUrl'])) {
                        result.appConfig['rainbowUrl'] = request.userSSODetails['@rainbowUrl'] + endPath;
                    } else {
                        const tms = new (super.tmsHook({ request: request }))();
                        tms.getUserCompany(request, input, (error, response) => {
                            if (error) {
                                return callback(error, null);
                            } else {
                                if (response.data['@rainbowUrl']) {
                                    result.appConfig['rainbowUrl'] = response.data['@rainbowUrl'] + endPath;
                                }
                            }
                        });
                    }
                }
                return callback(null, request, { data: result });
            } catch (error) {
                return callback(error, null);
            }
        };

    };

    return Ui;
};
