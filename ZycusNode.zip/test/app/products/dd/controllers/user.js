"use strict";

module.exports = (parentClass) => {

    class User extends parentClass {

        logoutProcess(request, input, callback) {
            try {
                //Step 1: Clear TMS session
                const http = new (super.httpTmsService)(request),
                    tmsURL = request.productsURL.tms["sso-service"],
                    url = tmsURL + "/servicehandler?action=invalidate&who=" + request.user.emailId + "&tokenId=" + request.tokenId;
                
                //Calling tms logout api to kill the session
                http.get(url, 'logoutProcess', (error, response) => { });

                //Step 2: Clear Redis Cache
                super.redisClient.removeRedisData(super.utils.prepareRedisKey(request,"userDetails"), (err, res) => {
                    if (err) {
                        return callback(null, request, { "errors": err.message, "data": "" });
                    }
                    else {
                        delete request.user;
                        request.tokenId = "";
                        return callback(null, request, { "data": { redirectUrl: super.uiConfig.TMS_Web.SMT_LOGIN_URL }, "message": "dd-msg-2" });
                    }
                });
            } catch (error) {
                return callback(error, null);
            }
        };

        getDetails(request, input, callback) {
            try {
                const result = {
                    userDetails: {
                        "firstName": request.user.firstName,
                        "lastName": request.user.lastName,
                        "displayName": request.user.displayName,
                        "userId": request.user.userId,
                        "tenantId": request.user.tenantId
                    },
                    access: super.utils.encrypt(JSON.stringify(request.user.access), request.user.userId),
                    userSetting: super.utils.encrypt(JSON.stringify(request.user.userSettings), request.user.userId),
                    appConfig: require('@config/ui.config.json')
                }
                return callback(null, request, { data: result });
            } catch (error) {
                return callback(error, null);
            }
        };

        /**
        * @Method Name : getTokenId
        *
        * @Description : Get SAASTokenId of logged-in user
        * @return object / Throw Error
        */
        getTokenId(request, input, callback) {
            try {
                return callback(null, request, { "data": { "tokenId": request.tokenId } });
            } catch (error) {
                callback(error, null);
            }
        };

    };

    return User;
};
