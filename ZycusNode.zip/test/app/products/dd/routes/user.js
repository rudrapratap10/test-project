"use strict";
module.exports = {   
    /**
        * @swagger
        * /a/dd/users/logout:
        *   get:
        *     tags:
        *       - Dewdrops API
        *     summary: Customer Logout
        *     operationId: logout
        *     description: Customer Logout
        *     produces:
        *       - application/json
        *     responses:
        *       200:
        *         description: successful operation
    */
    logout: {
        pre: null,
        process: "user.logoutProcess",
        post: null,
        method: 'GET'
    },

    /**
        * @swagger
        * /a/dd/users/getTokenId:
        *   get:
        *     tags:
        *       - Dewdrops API
        *     summary: Get SAASTokenId
        *     operationId: getTokenId
        *     description: Get SAASTokenId of logged-in user
        *     produces:
        *       - application/json
        *     responses:
        *       200:
        *         description: successful operation
    */
    getTokenId: {
        pre: null,
        process: "user.getTokenId",
        post: null,
        method: 'GET'
    },

    /**
        * @swagger
        * /a/dd/users/getDetails:
        *   get:
        *     tags:
        *       - Dewdrops API
        *     summary: Get User Details
        *     operationId: Get User Details
        *     description: Get User Details
        *     produces:
        *       - application/json
        *     responses:
        *       200:
        *         description: successful operation
    */
    getDetails: {
        pre: null,
        process: "user.getDetails",
        post: null,
        method: 'GET'
    }

};


/**
   * @swagger
   * definitions:
   *   pagination:
   *     properties:
   *       perPageRecords:
   *         type: integer
   *       pageNo:
   *          type: integer
   */

  /**
   * @swagger
   * definitions:
   *   sort:
   *     properties:
   *        sorts:
   *          schema:
   *              type: array
   *              items:
   *                type: object
   *                properties:
   *                    fieldName:
   *                        type: string
   *                    direction:
   *                        type: string
   */



  /**
     * @swagger
     * definitions:
     *   criteria:
     *     type: object
     *     properties:
     *       fieldName:
     *         type: string
     *       operation:
     *         type: string
     *       value:
     *         type: string
     *       minValue:
     *         type: integer
     *       maxValue:
     *         type: integer
     *       multivalue:
     *         type: array
     *         items: 
     *           type: string
     */

     /**
     * @swagger
     * definitions:
     *   criteriaGroupArray:
     *     type: object
     *     properties:
     *       logicalOperator:
     *         type: string
     *       criteria:
     *         type: array
     *         items:
     *           - $ref: '#/definitions/criteria'
     */

  /**
     * @swagger
     * definitions:
     *   criteriaGroup:
     *     type: object
     *     properties:
     *       criteriaGroup:
     *         type: object
     *         properties:
     *            logicalOperator:
     *               type: string
     *            criteria:
     *               type: array
     *               items:
     *                  - $ref: '#/definitions/criteria'
     */

     /**
     * @swagger
     * definitions:
     *   criteriaGroupWithArray:
     *     type: object
     *     properties:
     *       criteriaGroup:
     *         type: object
     *         properties:
     *            logicalOperator:
     *               type: string
     *            criteria:
     *               type: array
     *               items:
     *                  - $ref: '#/definitions/criteria'
     *            criteriaGroup:
     *               type: array
     *               items:
     *                  - $ref: '#/definitions/criteriaGroupArray'
     */

  /**
    * @swagger
    * definitions:
    *   idArray:
    *     type: object
    *     properties:
    *        ids:
    *          type: array
    *          items:
    *            type: string
    *     required: [ids]
   */

  /**
   * @swagger
   * definitions:
   *   cmdSort:
   *     properties:
   *       sortColumn:
   *         type: string
   *       ascending:
   *          type: boolean
   */

    /**
    * @swagger
    * /a/dd/batch:
    *   post:
    *     tags:
    *       - Dewdrops API
    *     summary: Batch API
    *     operationId: batchRequest
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: body
    *         description: Run multiple APIs at once
    *         in: body
    *         required: true
    *         schema:
    *            required: [sse, data]
    *            properties:
    *               sse:
    *                   type: boolean
    *               data:
    *                   type: array
    *                   items:
    *                       properties:
    *                           url:
    *                             type: string
    *                           method:
    *                             type: string
    *                           body:
    *                             type: object
    *                       required: [url, method]
    *     responses:
    *       200:
    *         description: successful operation
    */     

    /**
    * @swagger
    * /a/dd/batch/{requestId}:
    *   get:
    *     tags:
    *       - Dewdrops API
    *     summary: Get the Batch API Response
    *     operationId: getBatchAPIResponse
    *     description: Get the API Response by SSE
    *     produces:
    *       - application/json
    *     parameters:
    *       - name: requestId
    *         description: Provide the requestId.
    *         in: path
    *         required: true
    *         type: string
    *     responses:
    *       200:
    *         description: successful operation
    */