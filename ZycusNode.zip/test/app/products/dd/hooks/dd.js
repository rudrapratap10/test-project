"use strict";
const rm = require('@service/require.module')(),
    mime = require('mime'),
    fs = require('fs');
/**
 * Dewdrops Hook
 *
 * @description :: Create common methods & used it throught out application.
 */
class Dewdrops {
    getFileStream(request, input, callback) {
        try {
            const validationUtility = rm.utils.validationUtility(request),
                schema = {
                    "filePath": "joi.string().required().label('dd-error-14__')"
                };
            validationUtility.addInternalSchema(schema);
            const result = validationUtility.validate({ "filePath": request.params.attachment_Id });
            if (result) {
                const errorMsg = new (rm.customError)(result, 'ValidationError', 3);
                return callback(errorMsg, null);
            } else {
                const productName = request.productName,
                    filePath = request.params.attachment_Id,
                    decodedPath = rm.utils.decrypt(filePath.replace(/@/g, "\/"), request.tokenId, true);
                if (decodedPath) {
                    let filePathSplit = decodedPath.split("~");
                    if (filePathSplit.length == 2) {
                        const path = filePathSplit[0],
                            filename = filePathSplit[1],
                            sftp = new (require('@provider/sftp'))(productName);
                        sftp.get(path, (error, fileStream) => {
                            if (error) {
                                return callback(new rm.customError('dd-error-404.1', "AppError"), null);
                            } else {
                                const responseData = {
                                    'file-data': fileStream,
                                    'filename': filename,
                                    'mimetype': mime.getType(filename),
                                    'content-type': 'fileStream'
                                };
                                return callback(null, responseData);
                            }
                        });
                    } else {
                        return callback(new rm.customError('dd-error-404.1', "AppError"), null);
                    }
                } else {
                    return callback(new rm.customError('dd-error-404.1', "AppError"), null);
                }
            }
        } catch (error) {
            return callback(error, null);
        }
    };
    /*
    * Getting Info from temp Folder 
    * After That Removing Files from Temp Folder
    */
    getFileInfo(result, callback) {
        try {
            fs.readFile(result.files[0].path, { encoding: 'base64' }, (error, content) => {
                if (error) {
                    return callback(error, null);
                } else {
                    let fileName = result.files[0].name,
                        contentType = result.files[0].type;
                    if (!rm.lodash.isEmpty(result.files[0])) {
                        fs.unlink(result.files[0].path, (error) => {
                            if (error) rm.logger.log({ level: "error", data: error });
                        });
                    }
                    return callback(null, { content, fileName, contentType });
                }
            });
        }
        catch (error) {
            return callback(error, null);
        }
    };
}

module.exports = Dewdrops;