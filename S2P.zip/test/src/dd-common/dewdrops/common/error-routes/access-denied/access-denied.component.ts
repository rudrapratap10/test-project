import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter
} from '@angular/core';

import { IMG_ACCESS_DENIED } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-access-denied',
  templateUrl: './access-denied.component.html',
  styleUrls: ['./access-denied.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccessDeniedComponent {

  @Output() retry = new EventEmitter();
  _imgPath: string;

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_ACCESS_DENIED;
  }
  retryClicked(event) {
    this.retry.emit();
  }
}
