import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter
 } from '@angular/core';

import { IMG_NO_REQ } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-no-request',
  templateUrl: './no-request.component.html',
  styleUrls : ['./no-request.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class NoRequestComponent {

  _imgPath: string;
  @Output() retry = new EventEmitter();
  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_NO_REQ;
  }
  retryClicked(event)
  {
    this.retry.emit();
  }
}
