import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter
} from '@angular/core';

import { IMG_SERVER_ERROR } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';
import { retry } from 'rxjs/operator/retry';


@Component({
  selector: 'dew-server-error',
  templateUrl:'./server-error.component.html',
  styleUrls :['./server-error-component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServerErrorComponent {

  _imgPath: string;

  @Output() retry = new EventEmitter();

  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_SERVER_ERROR;
  }

  retryClicked(event)
  {
    this.retry.emit(event);
  }

}
