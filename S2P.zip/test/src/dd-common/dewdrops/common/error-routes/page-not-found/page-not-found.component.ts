import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter
} from '@angular/core';

import { IMG_NOT_FOUND } from '@dewdrops/globals';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls :[ './page-not-found.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PageNotFoundComponent {

  _imgPath: string;

  @Output() report = new EventEmitter();
  @Output() backClick = new EventEmitter();
  
  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_NOT_FOUND;
  }
  reportClick(event)
  {
    this.report.emit();
  }
  backClicked(event)
  {
    this.backClick.emit();
  }
}
