import {
  Component,
  ChangeDetectionStrategy,
  Output,
  EventEmitter
} from "@angular/core";

import { IMG_CON_ERROR } from "@dewdrops/globals";
import { LanguageTranslateService } from "@dewdrops/services";

@Component({
  selector: "dew-connection-error",
  templateUrl: "./connection-error.component.html",
  styleUrls:["./connection-error.component.scss"],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConnectionErrorComponent {
  _imgPath: string;
  @Output() retry = new EventEmitter();
  constructor(private _language: LanguageTranslateService) {
    this._imgPath = IMG_CON_ERROR;
  }

  retryClicked(event) {
    this.retry.emit(event);
  }
}
