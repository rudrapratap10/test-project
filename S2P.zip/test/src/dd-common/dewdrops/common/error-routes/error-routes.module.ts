import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutModule, ButtonsModule } from '@dewdrops/bootstrap';
import { LanguageTranslateModule } from '@dewdrops/services';
import { Routes, RouterModule } from '@angular/router';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ConnectionErrorComponent } from './connection-error/connection-error.component';
import { ServerErrorComponent } from './server-error/server-error.component';
import { NoRequestComponent } from './no-request/no-request.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';

import {
  URL_NOT_FOUND,
  URL_CON_ERROR,
  URL_SERVER_ERROR,
  URL_NO_REQ,
  URL_ACCESS_DENIED
} from '@dewdrops/globals';
import { TranslateModule } from 'ng2-translate';

const EXPORTS = [
  PageNotFoundComponent,
  ConnectionErrorComponent,
  ServerErrorComponent,
  NoRequestComponent,
  AccessDeniedComponent
];

export const ErrorRoutes: Routes = [
  {
    path: URL_NOT_FOUND,
    component: PageNotFoundComponent
  },
  {
    path: URL_CON_ERROR,
    component: ConnectionErrorComponent
  },
  {
    path: URL_SERVER_ERROR,
    component: ServerErrorComponent
  },
  {
    path: URL_NO_REQ,
    component: NoRequestComponent
  },
  {
    path: URL_ACCESS_DENIED,
    component: AccessDeniedComponent
  },
  {
    path: '**',
    redirectTo: URL_NOT_FOUND,
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [
    CommonModule,
    LayoutModule,
    RouterModule,
    TranslateModule,
    ButtonsModule
  ],
  declarations: [
    ...EXPORTS
  ],
  exports: [
    ...EXPORTS
  ]
})
export class ErrorRoutesModule { }
