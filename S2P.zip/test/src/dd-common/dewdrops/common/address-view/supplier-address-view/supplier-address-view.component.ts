import { Component, OnInit, Input } from '@angular/core';
import { pick, toArray, pickBy, identity } from 'lodash';
import { SupplierAddressInterface } from '../../../core/interfaces/address/supplier-address.interface';
import { SupplierAddressService } from './supplier-address.service';

@Component({
  selector: 'dew-supplier-address-view',
  templateUrl: './supplier-address-view.component.html',
  styleUrls: ['./supplier-address-view.component.scss']
})
export class SupplierAddressViewComponent implements OnInit {


  @Input()
  data : SupplierAddressInterface;

  @Input()
  format : string = "MULTI"; 

  constructor(private supplierService : SupplierAddressService) { }

  ngOnInit() {
    //console.log("data :: " + this.data)
  }

  generateSingleLineAddress(value): any {
    return this.supplierService.generateSingleLineAddress(value);
  }

  generateLine1Address(value){
    return this.supplierService.generateLine1Address(value);
  }

}
