import { Component, OnInit, Input } from '@angular/core';
import { pick, toArray, pickBy, identity } from 'lodash';
import { BuyerAddressInterface } from '../../../core/interfaces/address/buyer-address.interface';

@Component({
  selector: 'dew-address-view',
  templateUrl: './buyer-address-view.component.html',
  styleUrls: ['./buyer-address-view.component.scss']
})
export class BuyerAddressViewComponent implements OnInit {

  @Input()
  data : BuyerAddressInterface;

  @Input()
  format : string = "MULTI"; 

  constructor() { }

  ngOnInit() {
  }

  generateSingleLineAddress(value): any {
    
    //Pick only keys which are required for address line structure
    let addressFields = pick(value, ["line1", "line2", "line3", "line4", "city", "state", "country", "zip"]);

    //Remove data which values are null / undefined
    let uniqAddressArr = toArray(pickBy(addressFields, identity));

    //Join the array data with ", "
    let formattedAddress = uniqAddressArr.join(', ');

    return formattedAddress;
  }

}
