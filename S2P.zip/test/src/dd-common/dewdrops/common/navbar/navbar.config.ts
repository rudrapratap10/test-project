import { environment } from 'environments/environment';

export const CreateOptions = [
  {
    display: 'Create iSource Event',
    action: 'iSourceEvent'
  },
  {
    display: 'Create eProc Event',
    action: 'iSourceEvent'
  },
  {
    display: 'Create BUP Request',
    action: 'iSourceEvent'
  }
];

export const QuickCreateOptions = [
  {
    display: 'Create iSource Event',
    action: 'iSourceEvent'
  },
  {
    display: 'Create eProc Event',
    action: 'iSourceEvent'
  },
  {
    display: 'Create BUP Request',
    action: 'iSourceEvent'
  }
];

export const UserProfileOptions = [
  {
    link: environment.profileLink,
    display: 'Edit Profile'
  },
  {
    link: 'logout',
    display: 'Logout'
  }
];
