import {
  Injectable,
  EventEmitter
} from '@angular/core';

@Injectable()
export class NavbarService {

  userTemplateRef: any;
  updateTpl = new EventEmitter();

  constructor() { }
}
