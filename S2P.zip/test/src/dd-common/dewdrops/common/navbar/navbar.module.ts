import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DropdownModule } from '@dewdrops/bootstrap';

import { NavbarComponent } from './navbar.component';
import { NavbarService } from './navbar.service';
import { TranslateModule } from 'ng2-translate';

@NgModule({
  imports: [
    CommonModule,
    DropdownModule,
    TranslateModule,
  ],
  declarations: [
    NavbarComponent
  ],
  exports: [
    NavbarComponent
   ],
  providers: [
    NavbarService
  ]
})
export class NavbarModule { }
