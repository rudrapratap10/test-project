import {
  Component,
  OnInit,
  HostBinding,
  HostListener,
  Inject
} from '@angular/core';

import {
  UserService
} from '@dewdrops/services';

import {
  CreateOptions,
  QuickCreateOptions,
  UserProfileOptions
} from './navbar.config';
import { Dispatcher } from '@dewdrops/globals';
import { DOCUMENT } from '@angular/platform-browser';

declare const window: any;

@Component({
  selector: 'dew-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {

  public scrollAfterSpotlight: boolean;
  private scroll;
  @HostBinding('class.navbar')
  @HostBinding('class.navbar-expand-lg')
  @HostBinding('class.navbar-dark')
  @HostBinding('class.fixed-top')
  _classNavbar: boolean;

  _createOptions: Array<any>;
  _quickCreateOptions: Array<any>;
  _userOptions: Array<any>;

  _userName: Array<any>;

  constructor(
    private _userService: UserService,
    @Inject(DOCUMENT)
    private document: Document
  ) {
    this._classNavbar = true;
    this._createOptions = CreateOptions;
    this._quickCreateOptions = QuickCreateOptions;
    this._userOptions = UserProfileOptions;
  }

  ngOnInit() {
    this._userService.update.subscribe((user) => {
      this._userName = user ? user.displayName || '' : '' ;
    });
  }

  /**
   * @class NavbarComponent
   * @returns void
   * @param  {any} item
   */
  _whenUserOptionSelected(item: any): void {
    if (item.link !== 'logout') {
      window.open(item.link, '_blank');
    }
    if (item.link === 'logout') {
      this._handleLogout();
    }
  }

  /**
   * @class NavbarComponent
   * @returns void
   */
  _handleLogout(): void {
    this._userService.userLogout();
  }

  // to check scroll height
  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollHeight = window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
    this.scroll = Dispatcher.subscribe(
      (event) => {
        if (scrollHeight > event) {
          this.scrollAfterSpotlight = true;
        } else {
          this.scrollAfterSpotlight = false;
        }
    });
  }

}
