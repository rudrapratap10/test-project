import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { List } from 'lodash';
import { map } from 'rxjs/operators';
import { FormGroup, FormBuilder } from '@angular/forms';

import { of } from 'rxjs/observable/of';
import { CollectionFactory } from '../../core/factories/collection/collection.factory';
@Component({
  selector: 'dew-autocomplete-uom',
  templateUrl: './autocomplete-uom.component.html',
  styleUrls: ['./autocomplete-uom.component.scss']
})
export class AutocompleteUomComponent implements OnInit {
  uomList: any = [];
  uomModel: any;
  staticArrData: any = [];
  public loader: boolean;

  @Input()
  minLength: number = 1;
  public _datasource: Array<any> | CollectionFactory<any>;
  @Input() set datasource(value: CollectionFactory<any>) {
    this._datasource = value;
    if (this._datasource instanceof Array) {
      this.uomList = this._datasource.map(
        (item, index) => {
          return item;
        }
      );
      this.staticArrData = this.uomList;
    }
  }
  @Input()
  isLeafNode: boolean;
  @Input()
  freeTextMode: boolean = true;
  @Input()
  searchByActive: boolean;
  @Input()
  requestUserIds: List<String>;
  @Output()
  onSelect = new EventEmitter();
  @Output()
  onInvalid = new EventEmitter();

  @Input() uom: any;

  @Input() uomFormGroupInstance: FormGroup = this.formBuilder.group({
    uom: [{ value: {}, disabled: false }]
  });

  constructor(private formBuilder: FormBuilder) { }
  ngOnInit() {
    
  }
  uomModelFnFactory() {
    return (data: any) => {
      return data;
    };
  }
  uomDisplayFn() {
    return (data: any) => {
      return data.name;
    };
  }
  uomViewToModelTranformFactoryFn() {
    return (value: string, model: string) => {
      model = value;
      return model;
    };
  }

  modelValueChanged(form,field){   
    if(!form.get(field).value && !this.freeTextMode){
      this.onInvalid.emit();
    }
  }

  onUomChange() {
    return (query: string) => {
      this.loader = true;
      this.uomList = [];
      if (this._datasource instanceof Array) {
        this.uomList = this.search(query);
        this.loader = false;    
        return of(this.uomList);
      }
      else {
        if(query.trim().length>0){
        this._datasource.extraParameters = {
          nameORcode: query
        };
        this._datasource.applyExtraParameters();
        this._datasource.commit();
        }
        return this._datasource.list$.pipe(map(
          (response) => {
            this.loader = false;           
            this.uomList = response ? response.map((uomModel) =>
            uomModel
            ) : this.uomList;
            return this.uomList;
          }
        )).catch((error) => {
          this.uomList = [];
          this.loader = false;
          return error;
        });
      }
    };
  }
  setUom(data) {
    this.onSelect.emit(data);
  }

  search(searchedText: string) {
    if (searchedText) {
      this.uomList = this.staticArrData;
      return this.uomList.filter(
        (dataList) => {
          // case insensitive comparision
          let found = -1;
          const displayName = (dataList.name || dataList.code);
          if (displayName) {
            found = displayName.toLowerCase().indexOf(searchedText.toLowerCase());
          }
          return found > -1;
        }
      );
    } else {
      return this.uomList;
    }
  }
}
