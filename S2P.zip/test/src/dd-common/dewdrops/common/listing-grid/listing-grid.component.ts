import {  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  TemplateRef,
  ContentChild,
  OnDestroy,
  OnChanges } from '@angular/core';

@Component({
  selector: 'dew-listing-grid',
  templateUrl: './listing-grid.component.html',
  styleUrls: ['./listing-grid.component.scss']
})
export class ListingGridComponent implements OnInit, OnDestroy, OnChanges {


  /**
   * Flag indicating table data to be iterated
   */
  @Input() data: Array<any>;

  /**
   * Flag indicating column data to be iterated
   */
  @Input() tableHeader: Array<any>;

  /**
   * Redraw table on change event or not
   */
  @Input() redrawOnChange?: boolean = false;

  /**
   * emits event with sorted key data
   */
  @Output() whenSorted = new EventEmitter();

  /**
   * Iternal reference for user template
   */
  @ContentChild(TemplateRef) userDataTpl: TemplateRef<any>;



  /**
   * Flag indicating tablehead data
   */
  _tableHeads: Array<any>;

  /**
   * @class TableComponent
   * @constructor
   * @param  {ViewContainerRef} private_viewContainerRef
   */
  constructor(
    // private _viewContainerRef: ViewContainerRef
  ) {
    this.data = [];
    this.tableHeader = [];
    this._tableHeads = [];
  }

  /**
   * @class TableComponent
   * @method ngOnInit
   * @returns void
   */
  ngOnInit(): void {
    if (this.redrawOnChange) {
      return;
    }
    this.tableHeader.forEach(tableHeader => {
      this._tableHeads.push({
        displayLang: tableHeader.displayLang,
        sortKey: tableHeader.sortKey,
        sortIcon: tableHeader.sortIcon,
        col:tableHeader.col,
        hideColumn: tableHeader.hideColumn || false ,
        asc: undefined
      });
    });
  }
  ngOnChanges(...args: any[]) {
      if (!this.redrawOnChange) {
        return;
      }
      this._tableHeads = [];
      this.tableHeader = args[0].columns.currentValue;
      this.tableHeader.forEach((column) => {
        this._tableHeads.push({
          displayLang: column.displayLang,
          sortKey: column.sortKey,
          sortIcon: column.sortIcon,
          col:column.col,
          hideColumn: column.hideColumn || false ,
          asc: undefined
        });
      });
  }

  /**
   * @class TableComponent
   * @method ngOnDestroy
   * @returns void
   */
  ngOnDestroy(): void {
    this.whenSorted.unsubscribe();
  }

  

  /**
   * @class TableComponent
   * @method _onSort
   * @param  {} header
   * @returns void
   */
  _onSort(header): void {
    header.asc = !header.asc;
    const fieldName = `SORT_BY_${header.sortKey.toUpperCase()}`;
    const direction = header.asc ? 'ASC' : 'DESC';
    this.whenSorted.emit({ fieldName, direction });
  }

  /**
   * @class TableComponent
   * @method _trackItems
   * @param  {number} index
   * @returns number
   */
  _trackItems(index: number): number {
    return index;
  }

}
