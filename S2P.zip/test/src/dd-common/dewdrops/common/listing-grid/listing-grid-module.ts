import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from 'ng2-translate';
import { ButtonsModule, ModalModule, ListViewModule, FormControlModule, TableModule, LayoutModule } from '@dewdrops/bootstrap';
import { ListingGridComponent } from './listing-grid.component';



@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    ButtonsModule,
    ModalModule,
    ListViewModule,
    FormControlModule,
    TableModule,
    LayoutModule
  ],
  declarations: [ListingGridComponent],
  exports: [ListingGridComponent],
})
export class ListingGridModule { }
