import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PowerAnalyticsRoutingModule } from './power-analytics-routing.module';

@NgModule({
  imports: [
    CommonModule,
    PowerAnalyticsRoutingModule
  ],
  declarations: []
})
export class PowerAnalyticsModule { }
