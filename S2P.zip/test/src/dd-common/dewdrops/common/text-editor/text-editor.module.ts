import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
// import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
// import {  TextEditorComponent, EmptyObj, sanitizerPipe } from './text-editor.component';
import {  TextEditorComponent } from './text-editor.component';
// Basic classes to create an editor.Constants

// new TextEditorComponent(null)
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    // CKEditorModule,
    // EmptyObj
  ],
  // declarations: [TextEditorComponent, sanitizerPipe],
  declarations: [TextEditorComponent],
  exports: [TextEditorComponent]

})
export class TextEditorModule { 
}
