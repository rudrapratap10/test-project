import { Component, OnInit, ViewChild, ElementRef, Injectable, NgModule, Output, HostListener, EventEmitter, ViewEncapsulation, Input, Pipe, PipeTransform } from '@angular/core';
// Basic classes to create an editor.
// import Editor from '@ckeditor/ckeditor5-core/src/editor/editor';
// import EditorUIView from '@ckeditor/ckeditor5-ui/src/editorui/editoruiview';
// import FocusTracker from '@ckeditor/ckeditor5-utils/src/focustracker';
// import ComponentFactory from '@ckeditor/ckeditor5-ui/src/componentfactory';
// import InlineEditableUIView from '@ckeditor/ckeditor5-ui/src/editableui/inline/inlineeditableuiview';
// import HtmlDataProcessor from '@ckeditor/ckeditor5-engine/src/dataprocessor/htmldataprocessor';
// import ElementReplacer from '@ckeditor/ckeditor5-utils/src/elementreplacer';

// Interfaces to extend the basic Editor API.
// import DataApiMixin from '@ckeditor/ckeditor5-core/src/editor/utils/dataapimixin';
// import ElementApiMixin from '@ckeditor/ckeditor5-core/src/editor/utils/elementapimixin';

// Helper function for adding interfaces to the Editor class.
// import mix from '@ckeditor/ckeditor5-utils/src/mix';
// import {DomSanitizer} from "@angular/platform-browser";

// Helper function that gets the data from an HTML element that the Editor is attached to.
// import getDataFromElement from '@ckeditor/ckeditor5-utils/src/dom/getdatafromelement';

// Helper function that binds the editor with an HTMLForm element.
// import attachToForm from '@ckeditor/ckeditor5-core/src/editor/utils/attachtoform';

// Basic features that every editor should enable.
// import Clipboard from '@ckeditor/ckeditor5-clipboard/src/clipboard';
// import Enter from '@ckeditor/ckeditor5-enter/src/enter';
// import Typing from '@ckeditor/ckeditor5-typing/src/typing';
// import Paragraph from '@ckeditor/ckeditor5-paragraph/src/paragraph';
// import UndoEditing from '@ckeditor/ckeditor5-undo/src/undo';
// Basic features associated with the edited content.
// import BoldEditing from '@ckeditor/ckeditor5-basic-styles/src/bold/boldediting';
// import ItalicEditing from '@ckeditor/ckeditor5-basic-styles/src/italic/italicediting';
// import UnderlineEditing from '@ckeditor/ckeditor5-basic-styles/src/underline/underlineediting';
// import HeadingEditing from '@ckeditor/ckeditor5-heading/src/headingediting';
// import AlignmentConfig from  '@ckeditor/ckeditor5-alignment/src/alignment';
// import Font from '@ckeditor/ckeditor5-font/src/font'
// import * as $ from 'jquery';
// import Autoformat from '@ckeditor/ckeditor5-autoformat/src/autoformat';
// import List from '@ckeditor/ckeditor5-list/src/list';
// import Highlight from '@ckeditor/ckeditor5-highlight/src/highlight'

// import { Editor } from '../angular-slickgrid';
// @Pipe({
//     name: 'sanitizerFilter'
//   })
//   export class sanitizerPipe implements PipeTransform {
//     constructor(private sanitizer:DomSanitizer) {}
//     transform(value): any {
//         return this.sanitizer.bypassSecurityTrustHtml(value)
//     }
//   }
// @NgModule() export class  EmptyObj {
    
//         plugins: [
//             Clipboard, Enter, Typing, Paragraph,AlignmentConfig,Font,Autoformat,List,Highlight,
//             BoldEditing, ItalicEditing, UnderlineEditing, HeadingEditing, UndoEditing
//         ]
    
// }
// @Injectable() export  class  BootstrapEditor extends Editor implements OnInit {


//     sourceElement: any;
//     data: any;
//     model: any;
//     ui: any;
//     _elementReplacer: any;
   
//     constructor(element:ElementRef, config: EmptyObj) {
//       let plugins ={
//         plugins: [
//             Clipboard, Enter, Typing, Paragraph, AlignmentConfig,Font,Autoformat,List,Highlight,
//             BoldEditing, ItalicEditing, UnderlineEditing, HeadingEditing, UndoEditing
//         ]
//       }  
//         super(plugins)
//         if(element&&config.plugins){
//             // super(config);
//         this.sourceElement = element.nativeElement;

//         // Use the HTML data processor in this editor.
//         this.data.processor = new HtmlDataProcessor();
    
//         // Create the ("main") root element of the model tree.
//         this.model.document.createRoot();
    
//         // The UI layer of the editor.
//         const textEditor = new TextEditorComponent(this);
//         this.ui = textEditor;
    
//         // When editor#element is a textarea inside a form element,
//         // the content of this textarea will be updated on form submit.
//         attachToForm( this );
    
//         // A helper to easily replace the editor#element with editor.editable#element.
//         this._elementReplacer = new ElementReplacer();
//     }
//     // Remember the element the editor is created with.
    
//     }
// ngOnInit(){
// }

//     get element() {
//         return this.ui.view.element;
//     }

//     destroy() {
//         // When destroyed, the editor sets the output of editor#getData() into editor#element...
//         // this.updateSourceElement();

//         // ...and restores the original editor#element...
//         this._elementReplacer.restore();

//         // ...and destroys the UI.
//         this.ui.destroy();

//         return super.destroy();
//     }

//     static create( element, config ) {
//         if(element&&config.plugins){   
//             const editor:Editor = new this(element, config);
//          return new Promise( resolve => {
            
//             const editable = editor.ui.view.editable;
            
//             resolve(
//                 editor.initPlugins()
//                     .then( () => {
//                         // Initialize the UI first. See the TextEditorComponentUI class to learn more.
//                         editor.ui.init();

//                         // Replace the editor#element with editor.editable#element.
//                         editor._elementReplacer.replace( element, editable.element );

//                         // Tell the world that the UI of the editor is ready to use.
//                         editor.fire( 'uiReady' );
//                     } )
//                     // Bind the editor editing layer to the editable in the DOM.
//                     .then( () => editor.editing.view.attachDomRoot( editable.element ) )
//                     // Fill the editable with the intial data.
//                     .then( () => editor.data.init( getDataFromElement( element ) ) )
//                     // Fire the events that announce that the editor is complete and ready to use.
//                     .then( () => {
//                         editor.fire( 'dataReady' );
//                         editor.fire( 'ready' );
//                     } )
//                     .then( () => editor )
//             );
//         } );}
//     }
// }

// Mixing interfaces, which extends the basic editor API.
// mix( BootstrapEditor, DataApiMixin );
// mix( BootstrapEditor, ElementApiMixin );
@Component({
  selector: 'dew-text-editor',
  templateUrl: './text-editor.component.html',
  styleUrls: ['./text-editor.component.scss'],
//   providers: [BootstrapEditor],
//   encapsulation: ViewEncapsulation.None
})
 export class TextEditorComponent implements OnInit{
    // editor: any;
    // view: any;
    // componentFactory: any;
    // focusTracker: any;
    // isTrue = false;
    // isalignTrue= false;
    // isfamilyTrue = false;
    // issizeTrue = false;
    // @Output() editorContent= new EventEmitter<any>();
    // @ViewChild('textEditor') textEditor:ElementRef;
    // @ViewChild('mainDiv') mainDiv:ElementRef;
    // @Input() htmlData = ``;
    // ishighlightTrue=false;
    // htmlString: any;
//     constructor(editor:BootstrapEditor) {
//         if(editor){
//             this.editor = editor;
//             // The global UI view of the editor. It aggregates various Bootstrap DOM elements.
//             const view = this.view = new EditorUIView( this.editor.locale );
//             // This is the main editor element in the DOM.
//             view.element = $( '.ck-editor' );
//             // This is the editable view in the DOM. It will replace the data container in the DOM.
//             view.editable = new InlineEditableUIView( this.editor.locale );
            
//             // References to the dropdown elements for further usage. See #_setupBootstrapHeadingDropdown.
//             view.dropdownMenu = view.element.find( '#dropdown-menu' );
//             view.dropdownToggle = view.element.find( '#dropdown-toggle' );
//             view.dropdownMenuAlignment = view.element.find( '#dropdown-menu-alignment' );
//             view.dropdownToggleAlignment = view.element.find( '#dropdown-toggle-alignment' );
//             view.fontFamilyMenu = view.element.find( '#font-family-menu' );
//             view.fontFamily = view.element.find( '#font-family-toogle' );
//             view.fontSizeMenu = view.element.find( '#font-size-menu' );
//             view.fontSize = view.element.find( '#font-size-toogle' );
//             view.highlightMenu = view.element.find( '#font-highlight-menu' );
//             view.highlight = view.element.find( '#font-highlight-toogle' );
//             view.editorField = view.element.find( '#editor' );
            
//             // this.htmlString = this.domSanitizer.bypassSecurityTrustHtml(this.htmlData);
//             // References to the toolbar buttons for further usage. See #_setupBootstrapToolbarButtons.
//             view.toolbarButtons = {};
            
//             [ 'bold', 'italic', 'underline', 'undo', 'redo','left', 'right','numberedList', 'bulletedList', 'indentList', 'outdentList'].forEach( name => {
//                 // Retrieve the jQuery object corresponding with the button in the DOM.
//                 view.toolbarButtons[ name ] = view.element.find( `#${ name }` );
//             } );
//             // Mandatory EditorUI interface components.
//             this.componentFactory = new ComponentFactory( this.editor );
//             this.focusTracker = new FocusTracker();
//             this.editor.on('change', function() { 
//             });
//         }
//     }
//     @HostListener('input') onInput() {
//         this.editorContent.emit(window['editor'].getData())
//       }
//       @HostListener('focusout') onFocusOut() {
//         this.editorContent.emit(window['editor'].getData())
//       }
//       @HostListener('focus') onFocus() {
//         this.editorContent.emit(window['editor'].getData())
//       }

// ngOnInit(){
//    new BootstrapEditor(this.textEditor.nativeElement,{
//         plugins: [
//             Clipboard, Enter, Typing, Paragraph,AlignmentConfig,Font,Autoformat,List,Highlight,
//             BoldEditing, ItalicEditing, UnderlineEditing, HeadingEditing, UndoEditing
//         ]
//     });
//     BootstrapEditor
//     .create( this.textEditor.nativeElement, {   
//         plugins: [
//             Clipboard, Enter, Typing, Paragraph,AlignmentConfig,Font,Autoformat,List,Highlight,
//             BoldEditing, ItalicEditing, UnderlineEditing, HeadingEditing, UndoEditing
//         ]
//     } )
//     .then( editor => {
//         window['editor'] = editor;
//     } )
//     .catch( err => {
//         console.error( err.stack );
//     } );
// }
// resetFocus(data){
//     switch (true) {
//         case data==='heading':
//         const isTrue = this.isTrue === true?false:true;
//             this.resetpopup(isTrue, false, false, false,false)
//             break;
//             case data==='align':
//         const isalignTrue = this.isalignTrue === true?false:true;
//         this.resetpopup(false, isalignTrue, false, false,false)
//             break;
//             case data==='family':
//         const isfamilyTrue = this.isfamilyTrue === true?false:true;
//         this.resetpopup(false, false, isfamilyTrue, false,false)
//             break;
//             case data==='size':
//         const issizeTrue = this.issizeTrue === true?false:true;
//         this.resetpopup(false, false, false, issizeTrue,false)
//             break;
//             case data==='highlight':
//         const ishighlightTrue = this.ishighlightTrue === true?false:true;
//         this.resetpopup(false, false, false, false,ishighlightTrue)
//             break;
//         default:
//         this.resetpopup(false, false, false, false,false)
//             break;
//     }
    
// }

// resetpopup(heading, align,family,size,highlight){
//     this.isTrue = heading;
//     this.isalignTrue= align;
//     this.isfamilyTrue = family;
//     this.issizeTrue = size
//     this.ishighlightTrue=highlight;
// }


// emitData(data){
// }

//     init() {
//         const editor = this.editor;
//         const view = this.view;

//         // Render the editable component in the DOM first.
//         view.editable.render();
//         // Create an editing root in the editing layer. It will correspond with the
//         // document root created in the constructor().
//         const editingRoot = editor.editing.view.document.getRoot();
        
//         // Bind the basic attributes of the editable in the DOM with the editing layer.
//         view.editable.bind( 'isReadOnly' ).to( editingRoot );
//         view.editable.bind( 'isFocused' ).to( editor.editing.view.document );
//         view.editable.name = editingRoot.rootName;
//         // Setup the existing, external Bootstrap UI so it works with the rest of the editor.
//         this._setupBootstrapHeadingDropdown();
//         this._setupBootstrapToolbarButtons();
//     }
    
//     destroy() {
//         this.view.editable.destroy();
//     }
 
//     // This method activates Bold, Italic, Underline, Undo and Redo buttons in the toolbar.
//     // This method activates Bold, Italic, Underline, Undo and Redo buttons in the toolbar.
    
//     _setupBootstrapToolbarButtons() {
//         const editor = this.editor;
      
//         let editorField = this.view.editorField;
//         // const view  = new EditorUIView( this.editor.locale );
//         // view.element = $( '#editor' );

//         // let element = view.element.find('#editor');
        
//         // editorField.HostListener('input', ()=>{
//         // })

//     for ( let name in this.view.toolbarButtons ) {
//         // Retrieve the editor command corresponding with the ID of the button in the DOM.
//         const button = this.view.toolbarButtons[ name ];
// const  value = name;
// if ( new Set( [ 'left', 'right' ] ).has( name ) ) {
//     name = 'alignment'; 
// }
// // const elementData = editor.ui.view.editable;
// this.editorContent.emit(true)

// const command = editor.commands.get( name );
// // Clicking the buttons should execute the editor command...
// button.click( () => {
//     if(name === 'alignment'){
//         editor.execute( name , { value: value })
        
//     }else{
//         editor.execute( name )
//         this.onInput()
//     }
// } );
// // ...but it should not steal the focus so the editing is uninterrupted.
// button.mousedown( evt => evt.preventDefault() );

// const onValueChange = () => {
//     button.toggleClass( 'active', command.value );
// };

// const onIsEnabledChange = () => {
//     button.attr( 'disabled', () => !command.isEnabled );
// };
// const onAlignmentValueChange = (name)=>{
//     button.toggleClass( 'active', command.value );
// }
// // Commands can become disabled, e.g. when the editor is read-only.
// // Make sure the buttons reflect this state change.
// command.on( 'change:isEnabled', onIsEnabledChange );
// onIsEnabledChange();

// // Bold, Italic and Underline commands have a value that changes
// // when the selection starts in an element the command creates.
// // The button should indicate that e.g. you are editing text which is already bold.
// if ( !new Set( [ 'undo', 'redo' ] ).has( name ) ) {
//     command.on( 'change:value', onValueChange );
//     onValueChange();
// }
// if ( new Set( [ 'alignment' ] ).has( name ) ) {
//     command.on( 'change:value', onAlignmentValueChange, ['left', 'right']);
//     onAlignmentValueChange(name);
// }
// }
// }

// // This method activates the headings dropdown in the toolbar.
// _setupBootstrapHeadingDropdown() {
//     const editor = this.editor;
//     let dropdownMenu = this.view.dropdownMenu;
//     const dropdownToggle = this.view.dropdownToggle;
//     let alignmentDropdownMenu = this.view.dropdownMenuAlignment;
//     const alignmentDropdownToggle = this.view.dropdownToggleAlignment;
//         let fontFamilyMenu = this.view.fontFamilyMenu;
//         const fontFamilyToggle = this.view.fontFamily;
//         let fontSizeMenu = this.view.fontSizeMenu;
//         const fontSizeToggle = this.view.fontSize;
//         let highlightMenu = this.view.highlightMenu;
//         const highlightToggle = this.view.highlight;
//         // Retrieve the editor commands for heading and paragraph.
//         const headingCommand = editor.commands.get( 'heading' );
//         const paragraphCommand = editor.commands.get( 'paragraph' );
//         const alignmentCommand =  editor.commands.get( 'alignment');
//         const fontFamilyCommand =  editor.commands.get('fontFamily');
//         const fontSizeCommand =  editor.commands.get('fontSize');
//         const highlightCommand =  editor.commands.get('highlight');
//         // Create a dropdown menu entry for each heading configuration option.
//             editor.config.get('fontSize.options').map( option => {
//             // Check if options is a paragraph or a heading as their commands differ slightly.
//             // const isParagraph = option.model === 'paragraph';
            
//             // Create the menu item DOM element.
            
//             const menuItem = $(
//                 `<span class="dropdown-item heading-item_${ option }">` +
//                 `${ option }` +
//                 '</span>'
//                 );
    
//             // Upon click, the dropdown menu item should execute the command and focus
//             // the editing view to keep the editing process uninterrupted.
//             menuItem.click( () => {
//                 const commandName = 'fontSize';
//                 const commandValue = { value: option };
//                 this.isfamilyTrue=this.isfamilyTrue===true?false:true
//                 editor.execute( commandName, commandValue );
//                  this.editorContent.emit(window['editor'].getData())                
//                 editor.editing.view.focus();

//             } );
    
//             fontSizeMenu.append( menuItem );
//             const command = fontSizeCommand;
            
//             // Make sure the dropdown and its items reflect the state of the
//             // currently active command.
//             const onValueChange =  onValueChangeFontSize;
//             command.on( 'change:value', onValueChange );
//             onValueChange();
            
//             // FontSize commands can become disabled, e.g. when the editor is read-only.
//             // Make sure the UI reflects this state change.
//             command.on( 'change:isEnabled', onIsEnabledChange );
//             command.on('change:isOpen', onOPen)
//             onOPen()
//             onIsEnabledChange();
            
//             function onValueChangeFontSize() {
//                 const isActive =  command.value === option;
                
//                 if ( isActive ) {
//                     fontSizeToggle.children( ':first' ).text( option );
//                 }
                
//                 menuItem.toggleClass( 'active', isActive );
//             }
            
//             function onIsEnabledChange() {
//                 fontSizeToggle.attr( 'disabled', () => !command.isEnabled );
//             }
//             function onOPen() {
//             }
//         } );


//         editor.config.get('highlight.options').map( option => {
//             // Check if options is a paragraph or a heading as their commands differ slightly.
//             // const isParagraph = option.model === 'paragraph';
            
//             // Create the menu item DOM element.
//             const menuItem = $(
//                 `<span class="dropdown-item heading-item_${ option.model }">` +
//                 `${ option.model }` +
//                 '</span>'
//                 );
    
//             // Upon click, the dropdown menu item should execute the command and focus
//             // the editing view to keep the editing process uninterrupted.
//             menuItem.click( () => {
//                 const commandName = 'highlight';
//                 const commandValue = { value: option.model };
//                 this.ishighlightTrue=this.ishighlightTrue===true?false:true;
                
//                 editor.execute( commandName, commandValue );
//         this.editorContent.emit(window['editor'].getData())
//                 editor.editing.view.focus();
//             } );
    
//             highlightMenu.append( menuItem );
//             const command = highlightCommand;
            
//             // Make sure the dropdown and its items reflect the state of the
//             // currently active command.
//             const onValueChange =  onValueChangeFontFamily;
//             command.on( 'change:value', onValueChange );
//             onValueChange();
            
//             // FontFamily commands can become disabled, e.g. when the editor is read-only.
//             // Make sure the UI reflects this state change.
//             command.on( 'change:isEnabled', onIsEnabledChange );
//             onIsEnabledChange();
            
//             function onValueChangeFontFamily() {
//                 const isActive =  command.value === option.model;
                
//                 if ( isActive ) {
//                     highlightToggle.children( ':first' ).text( option.model );
//                 }
                
//                 menuItem.toggleClass( 'active', isActive );
//             }
            
//             function onIsEnabledChange() {
//                 highlightToggle.attr( 'disabled', () => !command.isEnabled );
//             }
//         } );


//         [  'Arial',
//         'Courier New',
//         'Georgia',
//         'Lucida Sans Unicode',
//         'Tahoma',
//         'Times New Roman',
//         'Trebuchet MS',
//         'Verdana'
//     ].map( option => {
//             // Check if options is a paragraph or a heading as their commands differ slightly.
//             // const isParagraph = option.model === 'paragraph';
            
//             // Create the menu item DOM element.
//             const menuItem = $(
//                 `<span class="dropdown-item heading-item_${ option }">` +
//                 `${ option }` +
//                 '</span>'
//                 );
    
//             // Upon click, the dropdown menu item should execute the command and focus
//             // the editing view to keep the editing process uninterrupted.
//             menuItem.click( () => {
//                 const commandName = 'fontFamily';
//                 const commandValue = { value: option };
//                 this.isfamilyTrue=this.isfamilyTrue===true?false:true
//                 editor.execute( commandName, commandValue );
//         this.editorContent.emit(window['editor'].getData())                
//                 editor.editing.view.focus();
//             } );
    
//             fontFamilyMenu.append( menuItem );
//             const command = fontFamilyCommand;
            
//             // Make sure the dropdown and its items reflect the state of the
//             // currently active command.
//             const onValueChange =  onValueChangeFontFamily;
//             command.on( 'change:value', onValueChange );
//             onValueChange();
            
//             // FontFamily commands can become disabled, e.g. when the editor is read-only.
//             // Make sure the UI reflects this state change.
//             command.on( 'change:isEnabled', onIsEnabledChange );
//             command.on('change:isOpen', onOPen)
//             onOPen()
//             onIsEnabledChange();
            
//             function onValueChangeFontFamily() {
//                 const isActive =  command.value === option;
                
//                 if ( isActive ) {
//                     fontFamilyToggle.children( ':first' ).text( option );
//                 }
                
//                 menuItem.toggleClass( 'active', isActive );
//             }
            
//             function onIsEnabledChange() {
//                 fontFamilyToggle.attr( 'disabled', () => !command.isEnabled );
//             }
//             function onOPen() {
//             }
//         } );
//         editor.config.get( 'alignment.options' ).map( option => {
//             // Check if options is a paragraph or a heading as their commands differ slightly.
//             // const isParagraph = option.model === 'paragraph';
            
//             // Create the menu item DOM element.
//             const menuItem = $(
//                 `<a class="dropdown-item heading-item_${ option }">` +
//                 `${ option }` +
//                 '</a>'
//                 );
    
//             // Upon click, the dropdown menu item should execute the command and focus
//             // the editing view to keep the editing process uninterrupted.
//             menuItem.click( () => {
//                 const commandName = 'alignment';
//                 const commandValue = { value: option };
//                 this.isalignTrue=this.isalignTrue===true?false:true
//                 editor.execute( commandName, commandValue );
//         this.editorContent.emit(window['editor'].getData())               
//                 editor.editing.view.focus();
//             } );
    
//             alignmentDropdownMenu.append( menuItem );
//             const command = alignmentCommand;
            
//             // Make sure the dropdown and its items reflect the state of the
//             // currently active command.
//             const onValueChange =  onValueChangeAlignment;
//             command.on( 'change:value', onValueChange );
//             onValueChange();
            
//             // Alignment commands can become disabled, e.g. when the editor is read-only.
//             // Make sure the UI reflects this state change.
//             command.on( 'change:isEnabled', onIsEnabledChange );
//             command.on('change:isOpen', onOPen)
//             onOPen()
//             onIsEnabledChange();
            
//             function onValueChangeAlignment() {
//                 const isActive =  command.value === option;
                
//                 if ( isActive ) {
//                     alignmentDropdownToggle.children( ':first' ).text( option );
//                 }
                
//                 menuItem.toggleClass( 'active', isActive );
//             }
            
//             function onIsEnabledChange() {
//                 alignmentDropdownToggle.attr( 'disabled', () => !command.isEnabled );
//             }
//             function onOPen() {
//             }
//         } );
//         editor.config.get( 'heading.options' ).map( option => {
//             // Check if options is a paragraph or a heading as their commands differ slightly.
//             const isParagraph = option.model === 'paragraph';
            
//             // Create the menu item DOM element.
//             const menuItem = $(
//                 `<a class="dropdown-item heading-item_${ option.model }">` +
//                 `${ option.title }` +
//                 '</a>'
//                 );
    
//             // Upon click, the dropdown menu item should execute the command and focus
//             // the editing view to keep the editing process uninterrupted.
//             menuItem.click( () => {
//                 const commandName = isParagraph ? 'paragraph' : 'heading';
//                 const commandValue = isParagraph ? undefined : { value: option.model };
//                 this.isTrue=this.isTrue===true?false:true
//                 editor.execute( commandName, commandValue );
//         this.editorContent.emit(window['editor'].getData())
//                 editor.editing.view.focus();
//             } );
    
//             dropdownMenu.append( menuItem );
//             const command = isParagraph ? paragraphCommand : headingCommand;
            
//             // Make sure the dropdown and its items reflect the state of the
//             // currently active command.
//             const onValueChange = isParagraph ? onValueChangeParagraph : onValueChangeHeading;
//             command.on( 'change:value', onValueChange );
//             onValueChange();
            
//             // Heading commands can become disabled, e.g. when the editor is read-only.
//             // Make sure the UI reflects this state change.
//             command.on( 'change:isEnabled', onIsEnabledChange );
//             command.on('change:isOpen', onOPen)
//             onOPen()
//             onIsEnabledChange();
            
//             function onValueChangeHeading() {
//                 const isActive = !isParagraph && command.value === option.model;
                
//                 if ( isActive ) {
//                     dropdownToggle.children( ':first' ).text( option.title );
//                 }
                
//                 menuItem.toggleClass( 'active', isActive );
//             }
//             function onValueChangeParagraph() {
//                 if ( command.value ) {
//                     dropdownToggle.children( ':first' ).text( option.title );
//                 }
              
                
//                 menuItem.toggleClass( 'active', command.value );
//             }
            
//             function onIsEnabledChange() {
//                 dropdownToggle.attr( 'disabled', () => !command.isEnabled );
//             }
//             function onOPen() {
//             }
//         } );
//     }
constructor(){}
ngOnInit(){}
 }



