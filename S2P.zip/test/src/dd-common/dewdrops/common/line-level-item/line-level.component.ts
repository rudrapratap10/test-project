import {
  Component,
  Input,
  OnInit,
  ViewContainerRef,
  EventEmitter,
  Output
} from '@angular/core';
import { CommonOverlayBuilder } from '../overlay/overlay-builder.service';
import { TranslateService } from 'ng2-translate/src/translate.service';
import { Router } from '@angular/router';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemsForInvoicesService } from './line-level.service';
import { ILineLevel, IParentLineLevelData, ILineItems } from '@dewdrops/common';
import { generateUniqueIdForParent } from './line-level.utility';
@Component({
  selector: 'dew-line-item',
  templateUrl: './line-level.component.html',
  styleUrls: ['./line-level.component.scss']
})
export class DewLineItemComponent implements OnInit {
  totalDiscount = 0;
  applyHeaderDiscount: boolean;
  discountErr: boolean;
  tempLineItemId: string;
  @Input() lineLevelObj: IParentLineLevelData;
  @Input() lineLevelType;
  @Input() currency;
  @Input() categoryApiSpecifier;
  @Input() headerDiscount = 0;
  @Output() navigationToLineLevelItem:EventEmitter<{item:any,section:any}> = new EventEmitter();
  @Output() createDataShareService:EventEmitter<any> =new EventEmitter();
  @Output() totalDiscountEmitter:EventEmitter<number>=new EventEmitter();
  tempLinelevelObj: ILineLevel[];
  openItemModal = false;
  isDisabled: any;
  newItemCreated = {};
  srNo = 0;
 // lineTtems = [];
  itemNo = 0;
  itemName = '';
  selectedItem = {};
  addItemCount = 1;
  showDropDownCat = false;
  catData: any;
  isCatNameSelected = false;
  pageNoCat = 1;
  catList = [];
  isScroll = false;
  value: string;
  oldCatName = '';
  catName: string;
  lineNo: number;
  allItemSubTotal = 0;
  showDropDown = [];
  oldLineItemValues = [{
    itemName: '',
    category: '',
    marketPrice: '',
    amount: ''
  }];
  total = 0;
  addItemsFormGroup: FormGroup;
  itemModalForm: FormGroup;
  showDiscount=false;

  constructor(
    private viewContainer: ViewContainerRef,
    private overlayBuilder: CommonOverlayBuilder,
    private _language: TranslateService,
    private _router: Router,
    private _fb: FormBuilder,
    private _ItemsForInvoicesService: ItemsForInvoicesService,

  ) {
   this.isDisabled= {};
   this.applyHeaderDiscount=true;
  }

  ngOnInit() {
    if(this.headerDiscount) {
      this._ItemsForInvoicesService.isHeaderDiscount = true;
      this._ItemsForInvoicesService.discountValue = this.headerDiscount;
    }
    if(this._ItemsForInvoicesService.isHeaderDiscount){
      this.showDiscount=this._ItemsForInvoicesService.isHeaderDiscount;
      if(this.showDiscount) {
        this.headerDiscount=this._ItemsForInvoicesService.discountValue;
      }
    }
    // saved parent line level data to local storage
    if (this._ItemsForInvoicesService.getParentLineItemData()) {
      // const lineItems = getParentLineLevelData(this.lineLevelObj.parentId) as ILineItems[];
      this.lineLevelObj.parentId = this._ItemsForInvoicesService.getParentLineItemData().parentId;
      const lineItems = this._ItemsForInvoicesService.getParentLineItemData().lineItems;
      this.lineLevelObj.lineItems = lineItems;
    } else  {
      this._ItemsForInvoicesService.setParentLineItemData(null);
      // createObjectInLocalStorage(this.lineLevelObj);
      this._ItemsForInvoicesService.setParentLineItemData(this.lineLevelObj);
    }
    this.addItemsFormGroup = this._fb.group({
      lineItemsFormArray: this._fb.array([])
    });
    this.totalDiscount = 0;
    for (let index = 0; index < this.lineLevelObj.lineItems.length; index++) {
      this.lineItemsFormArray.push(this.createItem(this.lineLevelObj.lineItems[index]));
      if(this.lineLevelObj.lineItems[index].lineItemData.discountValue>0 || (this.lineLevelObj.lineItems[index].lineItemTax.length && this.lineLevelObj.lineItems[index].lineItemTax[0].taxAmount)){
        this.applyHeaderDiscount=false;
        this._ItemsForInvoicesService.isHeaderDiscount=this.applyHeaderDiscount;
      }
       this.totalDiscount+=this.lineLevelObj.lineItems[index].lineItemData.discountAmount
    }
    if(!this.totalDiscount) {
      this.totalDiscount = this.headerDiscount;
    }
    this.totalDiscountEmitter.emit(this.totalDiscount);
    this.addItemsFormGroup.get('lineItemsFormArray').valueChanges.subscribe((changes) => {
      if (changes.length === this.oldLineItemValues.length && changes.length === this.showDropDown.length) {
        changes.forEach((change, index) => {
          if (!change.itemName) {
            this.showDropDown[index] = false;
          } else if (change.itemName !== this.oldLineItemValues[index].itemName) {
            this.showDropDown[index] = true;
          } else {
            this.showDropDown[index] = false;
          }
        });
      }
      this.oldLineItemValues = changes.slice();
    });
  }


  addNewLineItem() {
    const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
    control.push(this.initLineItemsFormArray());
    this.showDropDown.push(false);

    const addItem = {
      lineItemData: {
          srNo: 0,
          itemName: '',
          category: '',
          currency: '',
          marketPrice: 0,
          itemQuantity: 0,
          uom: '',
          itemSubtotal: 0,
          lineItemId: ''
        } as ILineLevel,
        attachements: [] as string[],
        comment: '',
        lineItemTax: [],
        contractItemData: 0,
        additionalDetailsItem: [],
  } as ILineItems;

    let itemNo;
    this.srNo = this.lineLevelObj.lineItems.length + 1;
    this.isDisabled[addItem.lineItemData.lineItemId]=true;
    itemNo = this.srNo;
    addItem.lineItemData.srNo = itemNo;
    const fromGrouptest = control.controls[itemNo] as any;
    addItem.lineItemData.lineItemId = this.tempLineItemId;
    // if (this.addItemCount <= 20) {
      this.lineLevelObj.lineItems.push(addItem);
      this.addItemCount++;
      this.itemName = '';
      // updateObjectInLocalStorage(this.lineLevelObj);
      this._ItemsForInvoicesService.setParentLineItemData(this.lineLevelObj);

    // }
    this.newItemCreated[addItem.lineItemData.lineItemId] = true;
  }

  addLineItem(){
    if (this.addItemCount < 20) {
      this.addNewLineItem();
    }else{
      let count=0;
      this.addItemsFormGroup.value.lineItemsFormArray.forEach( (item) =>{
        if(!item.category && !item.marketPrice && !item.itemQuantity) {
          count++;
        }
      })
      if(count < 20){
          this.addNewLineItem();
          return;
      }
    }

  }

  CategorySelected(cat: any) {
    this.showDropDownCat = false;
    this.isCatNameSelected = true;
    this.catName = cat.name;
    this.oldCatName = cat;
    this.lineLevelObj.lineItems[this.lineNo].lineItemData.category = this.catName;
    const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
    control.at(this.lineNo).patchValue({
      category: this.catName
    });
    //this.lineLevelObj.lineItems[itemNo].lineItemData
  }

  categoryAutoClass(value: string, pageNo: any = 1) {
    this.value = value;
    if (value === '') {
      this.showDropDownCat = false;
      return;
    }
    if (this.catData) {
      this.catData.unsubscribe();
    }
    this.isCatNameSelected = false;
    this.pageNoCat = 1;
    this.catData = this._ItemsForInvoicesService.getCategory(this.categoryApiSpecifier, value, pageNo).
      subscribe((response) => {
        this.showDropDownCat = true;
        this.catList = [];
        if (response.data.records) {
          response.data.records.forEach((element) => {
            this.catList.push(element);
          });
        }
      });

  }

  createItem(res?: ILineItems) {
    return this._fb.group({
      itemName: res.lineItemData.itemName ? res.lineItemData.itemName : '',
      itemQuantity: res.lineItemData.itemQuantity ? res.lineItemData.itemQuantity : '',
      category: res.lineItemData.category ? res.lineItemData.category : '',
      marketPrice: res.lineItemData.marketPrice ? res.lineItemData.marketPrice : '',
      uom: res.lineItemData.uom ? res.lineItemData.uom : '',
      currency: res.lineItemData.currency ? res.lineItemData.currency : '',
      amount: res.lineItemData.marketPrice ? res.lineItemData.marketPrice : '',
      srNo: res.lineItemData.srNo ? res.lineItemData.srNo : '',
      itemSubtotal: res.lineItemData.marketPrice * res.lineItemData.itemQuantity ,
      lineItemId: res.lineItemData.lineItemId,
      checked: false
    })
  }

  deleteLineItem(itemNo) {
    this.overlayBuilder.confirm(this.viewContainer)({
      confirmTxt: 'Are you sure you want to delete this Item?',
      confirmBtnLabel: this._language.instant('DEWDROPS_YES_BTN_LBL'),
      rejectBtnLabel: this._language.instant('DEWDROPS_NO_BTN_LBL'),
      confirmFn: () => {
        const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
        control.removeAt(itemNo);
        this.lineLevelObj.lineItems.forEach((item) => {
          if ((+item.lineItemData.srNo)-1 === itemNo) {
            this.lineLevelObj.lineItems.splice((+item.lineItemData.srNo-1), 1);
            // if (this.lineLevelObj.lineItems.length === 0) {
            //   destroyObjectInLocalStorage(this.lineLevelObj.parentId);
            // } else {
            //   updateObjectInLocalStorage(this.lineLevelObj);
            // }
            this._ItemsForInvoicesService.setParentLineItemData(this.lineLevelObj);
          }


        });
      }
    });
    //updateObjectInLocalStorage(this.lineLevelObj);
  }

  // Open when click on item edit/create

  editModal(itemNo, itemName) {
    this.itemNo = itemNo;
    this.lineLevelObj.lineItems[itemNo].lineItemData.itemName = itemName;
    this.selectedItem = this.lineLevelObj.lineItems[itemNo].lineItemData;
    this.openItemModal = true;
  }
  openModal(itemNo, itemName) {
    this.itemName = itemName;
    this.itemNo = itemNo;
    this.selectedItem = {};
    this.openItemModal = true;
    }

    updateMarketPrice(itemno,price){
      this.lineLevelObj.lineItems[itemno].lineItemData.marketPrice=price;

    }
    updateQuantity(itemno,quantity){
      this.lineLevelObj.lineItems[itemno].lineItemData.itemQuantity=quantity;

    }

  focusoutCategory() {
    this.showDropDownCat = false;
  }

  myFunction(i: number) {
    this.lineNo = i;
  }

  get lineItemsFormArray(): FormArray {
    return this.addItemsFormGroup.get('lineItemsFormArray') as FormArray;
  }


  // TOD check this method
  // popup
  getItemData(item) {
    this.updateFormArray(item);
    let itemData = this.lineLevelObj.lineItems[this.itemNo];
    this.lineLevelObj.lineItems[this.itemNo].lineItemData = {
      srNo: this.itemNo + 1,
      itemName: item.itemName,
      category: item.category,
      currency: item.currency,
      marketPrice: item.marketPrice,
      itemQuantity: item.qtyOrAmt,
      itemno: item.itemno,
      receiptType:item.recvdBy,
      type: item.type,
      desc: item.desc,
      uom: item.uom,
      itemSubtotal: item.marketPrice * item.qtyOrAmt,
      lineItemId: item.lineItemId
    } as ILineLevel;
    // updateObjectInLocalStorage(this.lineLevelObj);
    this._ItemsForInvoicesService.setParentLineItemData(this.lineLevelObj);
   // this.sumOfItemSubTotal();
   this.newItemCreated[itemData.lineItemData.lineItemId] = false;

  }


// init
  initLineItemsFormArray() {
    this.tempLineItemId = generateUniqueIdForParent();
    return this._fb.group({
      itemName: [''],
      category: [''],
      marketPrice: [''],
      itemQuantity: [''],
      uom:[''],
      currency:[''],
      itemSubtotal: [''],
      lineItemId: [this.tempLineItemId],
      checked: [false]
    });
  }

  toggleModal(state) {
    this.openItemModal = state;
  }

  changeCbState(event,item){

    item.value.checked = event.target.checked;
  }

  selectAll(event,lineData){

      lineData.forEach((item, index)=>{
        const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
        control.at(index).patchValue({
          checked: event.target.checked
        });
      });
  }

  onScrollEndCat() {
    this.isScroll = true;
    this.pageNoCat = this.pageNoCat + 1;
    this.categoryAutoClass(this.value, this.pageNoCat);
  }

  navigate(lineItemId,itemNo, section) {
    this._ItemsForInvoicesService.isHeaderDiscount = this.showDiscount;
    this.navigationToLineLevelItem.emit({item:lineItemId , section:section});

  }

  transformCount(count) {
    if (count >= 0 && count <= 9) {
      return '0' + (+count);
    } else {
      return +count;
    }
  }

  getCount(event,itemNo){
    const data = this._ItemsForInvoicesService.getParentLineItemData();
    const lineItemData = data.lineItems[itemNo];
    if(event=='comment'){
      if(lineItemData.comment){
        return '01';

      }else {
        return '00';
      }
    }

    if(event=='attachments'){
      if(lineItemData.attachements.length){
        return this.transformCount(lineItemData.attachements.length);
      }else{
        return '00';
      }
    }
    if(event=='contracts'){
      if(lineItemData.contractItemData){
        return '01';
      }else{
        return '00';
      }
    }
    if(event=='tax'){
      if(lineItemData.lineItemTax[0])
      {
        if(lineItemData.lineItemTax[0].taxAmount){
          return this.transformCount(lineItemData.lineItemTax.length)
        }
      }   
        return '00';   
    }
    if(event=='discounts'){
      if(lineItemData.lineItemData.discountValue>0 ){
        return '01';
      }else{
        return '00';
      }
    }
    if(event=='advance field'){
      return '00';
    }

  }

  updateFormArray(item) {
    const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
    control.at(this.itemNo).patchValue({
      itemName: item.itemName,
      category: item.category,
      marketPrice: item.marketPrice,
      itemQuantity: item.qtyOrAmt,
      itemSubtotal: item.marketPrice*item.qtyOrAmt,
      uom:item.uom,
      currency:item.currency,
      lineItemId: item.lineItemId,
      checked: false
    });
  }

  get lineLevelControls() {
    const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
    return control.controls;
  }

  recalculateItemSubTotal(item, itemno) {
    const newSubTotal = item.value.marketPrice * item.value.itemQuantity;
    const control = this.addItemsFormGroup.controls['lineItemsFormArray'] as FormArray;
        control.at(itemno).patchValue({
          itemSubtotal: newSubTotal
    });
  }

  sumOfItemSubTotal(lineData) {
      this.total = 0;
        lineData.forEach((item, index)=>{
          this.total += +item.controls.itemSubtotal.value;
        });
        this.createDataShareService.emit(this.total) ;
        return this.total;

      }

      checkboxChange(event) {
        if(!event) {
          this.totalDiscount = 0;
          this.totalDiscountEmitter.emit(this.totalDiscount);
          this._ItemsForInvoicesService.discountValue = 0;
        }
      } 

      validateDiscount(event) {
        if (event > this.total) {
          this.discountErr = true;
        } else {
          this.discountErr = false;
          this._ItemsForInvoicesService.discountValue=event;
          this.totalDiscount = event;
          this.totalDiscountEmitter.emit(this.totalDiscount);
        }
      }
}
