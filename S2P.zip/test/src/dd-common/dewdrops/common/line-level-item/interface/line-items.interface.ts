import { ILineLevel } from "@dewdrops/common";

export interface ILineItems {
    lineItemData: ILineLevel;
    attachements: string[];
    comment: string;
    lineItemTax: any[];
    contractItemData: number;
    additionalDetailsItem: any;
    assetCodeType: number;
    assetCode: string;
    costBookingCostings: any;
    costBookingAccountings: any;
}