export interface ILineLevelFooter{
shipToCodeType: number;
contractId: string;
internalComment: any;
supplierComment: any;
shipToCode: number;
requesterId: string;
requesterName: string;
lineItemId: string;
purchaseOrderId:string;
itemId: string;
attachmentIds: any[];
lineNo: number;
itemTaxes: any[];
splitCostingType: string;
assetCodeType: string;
assetCode: string;
contractNo: string;
contractType: string;
discountType: string;
discountValue: number;
discountAmount:number;
}