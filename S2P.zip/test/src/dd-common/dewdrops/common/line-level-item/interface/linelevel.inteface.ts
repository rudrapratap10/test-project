export interface ILineLevel {
    itemName: string;
    itemQuantity: number;
    itemId: string;
    srNo: number;
    marketPrice: number;
    receiptType:any;
    category: string;
    categoryCode:string;
    uom: string;
    currency: string;
    itemSubtotal: number;
    lineItemId: string;
    itemno:any;
    type:any;
    desc:string;
    taxes: number;
    discountType: number;
    discountValue: any;
    discountAmount:number;
}