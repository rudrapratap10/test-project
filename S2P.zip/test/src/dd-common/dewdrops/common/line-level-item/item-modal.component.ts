import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { ItemsForInvoicesService } from './line-level.service';
import { ILineItems } from '@dewdrops/common';

// import { ItemsForInvoicesService } from '@einvoice/invoices/create-non-po/items-for-Invoices/item-for-invoices.service';

@Component({
  selector: 'item-modal',
  templateUrl: './item-modal.component.html',
  styleUrls: ['./item-modal.component.scss']
})

export class ItemModalComponent implements OnInit {

  @Input() newItem: any;
  @Input() openModal: any;
  @Input() selectedItem: any;
  @Input() currency:any;
  @Input() apiEndPointSpecifier = 'einvoice' as string;
  @Output() closeModal = new EventEmitter();
  // tslint:disable-next-line:no-output-on-prefix
  @Output() onNext = new EventEmitter();


  itemNameError = false;
  categoryError = false;
  qtyError = false;
  UOMError = false;

  uomData: any;
  isScroll = false;
  isUOMNameSelected = false;
  oldUOMName = '';
  catData: any;
  isScrollForCat = false;
  isCatNameSelected = false;
  oldCatName = '';
  catList = [];
  pageNoUOM = 1;
  pageNoCat = 1;

  itemName = '';
  // category = '';
  itemno = '';
  type = 0;
  recvdBy = 0;
  qtyOrAmt = 0;
  uom = '';
  marketPrice = 0;
  desc = '';
  lineItemId = '';
  itemModalForm: FormGroup;

  showDropDown = false;
  showDropDownCat = false;

  uomList: any[] = [];

  constructor(
      private router: Router,
      private _ItemsForInvoicesService: ItemsForInvoicesService) {
  }

  
  ngOnInit() {
    
    this.itemModalForm = new FormGroup({
      uomName: new FormControl(null,Validators.required),
      categoryName: new FormControl(null,Validators.required)
    });
  }

  toggleModal(state) {
    this.openModal = state;
    this.closeModal.emit(this.openModal);
    this.itemName = '';
    this.itemModalForm.controls.categoryName.setValue('');
    this.marketPrice = 0;
    this.qtyOrAmt = 0;
    this.itemModalForm.controls.uomName.setValue('');

    this.itemno = '';
    this.type = 0;
    this.recvdBy = 0;
    this.desc = '';
    this.itemNameError = false;
    this.categoryError = false;
    this.qtyError = false;
    this.UOMError = false;
  }

  addItemData() {
    if (!this.itemName && !this.selectedItem.itemName) {
      this.itemName = this.newItem;
    } else if (!this.itemName && this.selectedItem.itemName) {
      this.itemName = this.selectedItem.itemName;
    } else if (!this.itemName){
      this.itemNameError = true;
    }

    if (!this.itemModalForm.value.categoryName && !this.selectedItem.category) {
      this.categoryError = true;
    } else if (!this.itemModalForm.value.categoryName) {
      this.itemModalForm.controls.categoryName.setValue(this.selectedItem.category);
    }

    if (!this.qtyOrAmt && !this.selectedItem.itemQuantity) {
      this.qtyError = true;
    } else if (!this.qtyOrAmt) {
      this.qtyOrAmt = this.selectedItem.itemQuantity;
    }

    if (!this.itemModalForm.controls.uomName.value && !this.selectedItem.uom && this.recvdBy !== 1) {
      this.UOMError = true;
    } else if (!this.itemModalForm.controls.uomName.value) {
      this.itemModalForm.controls.uomName.setValue(this.selectedItem.uom);
    }

    this.lineItemId = this.selectedItem.lineItemId;

    if (Number(this.recvdBy) === 1) {
      this.marketPrice = 1;
    }
    if (!this.itemNameError && !this.categoryError && !this.qtyError &&
      !this.UOMError && this.currency) {
      this.itemNameError = false;
      this.categoryError = false;
      this.qtyError = false;
      this.UOMError = false;
      const data = {
        itemName: this.itemName,
        category: this.itemModalForm.value.categoryName,
        itemno: this.selectedItem.itemno,
        type: this.type,
        recvdBy: this.recvdBy,
        qtyOrAmt: this.qtyOrAmt,
        desc: this.selectedItem.desc,
        uom: this.itemModalForm.value.uomName,
        marketPrice: this.selectedItem.marketPrice,
        currency: this.currency,
        lineItemId: this.lineItemId
      };
      this.onNext.emit(data);
      this.closeModal.emit(false);
    }

  }

  limitDecimal(qtyOrAmt) {
    let amt;
    this.qtyOrAmt = qtyOrAmt;
    amt = +Number(this.qtyOrAmt).toFixed(14);
    this.qtyOrAmt = amt;
  }

  categoryAutoClass(pageNo: any = 1) {
    if (this.itemModalForm.value.categoryName === '') {
      this.showDropDownCat = false;
      return;
    }
    if (this.catData) {
      this.catData.unsubscribe();
    }
    this.isCatNameSelected = false;
    this.pageNoCat = 1;
    this.catData = this._ItemsForInvoicesService.getCategory(this.apiEndPointSpecifier, this.itemModalForm.value.categoryName, pageNo).
    subscribe((response) => {
      this.showDropDownCat = true;
      this.catList = [];
      if (response.data.records) {
        response.data.records.forEach((element) => {
          this.catList.push(element.name);
        });
      }
    });
  }



  getUOM(pageno: any = 1) {
    if (this.itemModalForm.value.uomName === '') {
      this.showDropDown = false;
      return;
    }
    if (this.uomData) {
      this.uomData.unsubscribe();
    }
    this.isUOMNameSelected = false;
    this.pageNoUOM = 1;
    this.uomData = this._ItemsForInvoicesService.getUOM(this.itemModalForm.value.uomName, pageno).
    subscribe((response) => {
      this.showDropDown = true;
      this.uomList = [];
      if (response.data.records) {
        response.data.records.forEach((element) => {
          this.uomList.push(element.name);
        });
      }
    });
  }

  onScrollEnd() {
    this.isScroll = true;
    this.pageNoUOM = this.pageNoUOM + 1;
    this.getUOM(this.pageNoUOM);
  }

  onScrollEndCat() {
    this.isScroll = true;
    this.pageNoCat = this.pageNoCat + 1;
    this.categoryAutoClass(this.pageNoCat);
  }

  focusout() {
    this.showDropDown = false;
    if (!this.isUOMNameSelected && this.itemModalForm.value.uomName !== '') {
      this.itemModalForm.controls.uomName.setValue(this.oldUOMName);
    }
  }

  uomSelected(uom: any) {
    this.showDropDown = false;
    this.isUOMNameSelected = true;
    this.itemModalForm.controls.uomName.setValue(uom);
    this.oldUOMName = uom;
  }

  focusoutCategory() {
    this.showDropDownCat = false;
    if (!this.isCatNameSelected && this.itemModalForm.value.categoryName !== '') {
      this.itemModalForm.controls.categoryName.setValue(this.oldCatName);
    }
  }

  CategorySelected(cat: any) {
    this.showDropDownCat = false;
    this.isCatNameSelected = true;
    this.itemModalForm.controls.categoryName.setValue(cat);
    this.oldCatName = cat;

  }
}
