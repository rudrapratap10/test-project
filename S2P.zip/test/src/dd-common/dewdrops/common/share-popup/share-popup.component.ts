import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ContentChildren,
  QueryList,
  AfterContentInit,
  ViewChildren,
  AfterViewInit
} from "@angular/core";
import { find, cloneDeep } from "lodash/index";
import { ISharePopupSchema } from "./IShareUnshareAllSchema.model";
import { ShareViewListWrapperComponent } from "./share-popup-view-list-wrapper/share-popup-view-list-wrapper.component";
import { ListingComponent, IListingSearchSchema, ISearchFilterColumn } from "..";

export class selectedEntity {
  kind: string;
  values: any[];
}

@Component({
  selector: 'dew-share-popup',
  templateUrl: './share-popup.component.html',
  styleUrls: ['./share-popup.component.scss']
})
export class SharePopUpComponent
  implements OnInit, AfterContentInit, AfterViewInit {

  @ContentChildren(ShareViewListWrapperComponent)

  listWrappers: QueryList<ShareViewListWrapperComponent>;
  selections: any = {};
  tempArray: any = {};
  selectedObject: any = {};
  @Input() allSchema: ISharePopupSchema[];
  @Input() openModel: boolean;


  @Input() isViewAll: boolean = false;
  @Input() showBackBtn: boolean = false;

  isSearch: boolean = false;

  listingSearchSchema = {
    columns: []
  } as IListingSearchSchema;

  currentListingSearch: IListingSearchSchema;

  currentSearchColumns: ISearchFilterColumn;
  @ViewChildren("listingCompo") listing: QueryList<ListingComponent>;
  public listWrappersList: any[];
  actionHeading: string;
  name: string;
  email: string;
  newShareArray = [];
  currentList: ListingComponent;
  currentCriteria: ISharePopupSchema;
  isSelected: boolean;
  isAddUserData: boolean = false;
  isSelectedNewUsers: boolean = false;
  isUserSelected: boolean = false;
  backFlag: boolean = false;
  constructor() { }

  @Output() closeModel = new EventEmitter();
  @Output() getSelectedEntity = new EventEmitter();
  @Output() clear = new EventEmitter();

  selectedEntity: selectedEntity;
  currentWrapper: any;

  ngOnInit() {
  }

  submit(form) {
    this.newShareArray.push(form);
    this.name = '';
    this.email = '';
  }

  deleate(i) {
    this.newShareArray.splice(i, 1);
  }


  toggleModalState(state) {
    this.openModel = state;
    this.closeModel.emit(state);
  }

  ngAfterContentInit() {
    this.actionHeading = this.allSchema[0].label;
    this.listWrappersList = this.listWrappers.toArray();
    this.currentWrapper = this.listWrappersList[0];
    this.allSchema.forEach(data => {
      this.selections[data.id] = [];
    });
    this.currentListingSearch = this.listWrappersList[0].listSearchCriteria;
  }

  getValue(event, actionHeading) {
    console.log(event);
  }

  getUpdatedCriteria(event, actionHeading) {
    this.currentList = find(this.listing.toArray(), o => {
      return o.schema.id === actionHeading;
    });
    this.currentList._dataSource.filterBy(event.searchCriteria.criteria).applyFilter();
    this.isSearch = true;
    this.currentList.getRecords(10, 1);
  }

  ngAfterViewInit() {
    const listingArray = this.listing.toArray();
    this.currentList = listingArray[0];
  }

  whenTabChange(event) {
    this.isAddUserData = false;
    this.actionHeading = event ? event.heading : "";
    if (this.actionHeading == 'EXTERNAL CONTACT (200)') {
      this.isAddUserData = true;
    }
    if (this.listing) {
      this.currentList = find(this.listing.toArray(), o => {
        return o.schema.id === this.actionHeading;
      });
    }
    this.currentWrapper = find(this.listWrappers.toArray(), o => {
      return o.schema.id === this.actionHeading;
    });
    this.currentListingSearch = this.currentWrapper.listSearchCriteria;

    this.currentSearchColumns =
      {
        fieldName: 'supplierName',
        label: event.heading,
        criteriaKey: 'username'
      };
    this.listingSearchSchema.columns = [];
    this.listingSearchSchema.columns.push(this.currentSearchColumns);
  }

  onSelect(selections: any[], type: string) {
    this.tempArray[
      type
    ] = selections;
  }

  clearAll(actionHeading) {
    this.currentList = find(this.listing.toArray(), o => {
      return o.schema.id === actionHeading;
    });
    this.currentList.selectedRecords.forEach((data) => {
      data._checked = false;
    });
    this.currentList.selectedRecords = [];
    this.clear.emit(this.currentList.selectedRecords);
  }

  removeFilter() {
    this.isSearch = false;
    this.listing.toArray().forEach(data => {
      const criteria = find(this.allSchema, o => {
        return o.label === data.schema.id;
      });
      if (criteria.getAllCriteria) {
        data._dataSource.removeFilter(criteria.getAllCriteria.fieldName);
        data.getRecords(10, 1);
      } else {
        data.getRecords(10, 1);
      }
    });
    this.isViewAll = true;
  }

  clickSelectedNewUser() {
    this.openModel = true;
    this.isUserSelected = true;
    this.isViewAll = false;
    this.isSelectedNewUsers = true;
  }

  doneClicked() {
    let sampleArray: any = [];
    this.listing.toArray().forEach(data => {
      this.selectedEntity = {
        kind: data.schema.id,
        values: data.selectedRecords
      };
      sampleArray.push(this.selectedEntity);
    });
    this.getSelectedEntity.emit(sampleArray);
    this.openModel = true;
    this.isSelected = true;
    this.isViewAll = false;
    this.currentWrapper = find(this.listWrappers.toArray(), o => {
      return o.schema.id === this.actionHeading;
    });
  }

  getSelected(actionHeading) {
    if (this.isUserSelected == true) {
      this.getSelectedEntity.emit(this.newShareArray);
      this.newShareArray = [];
    } else {
      this.currentList = find(this.listing.toArray(), o => {
        return o.schema.id === actionHeading;
      });
      this.selectedEntity = {
        kind: actionHeading,
        values: this.currentList.selectedRecords
      };
      this.getSelectedEntity.emit(this.selectedEntity);
    }
    this.isSelectedNewUsers = false;
    this.isUserSelected = false;
    this.isViewAll = true;
    this.openModel = false;
    this.isSelected = false;
    this.closeModel.emit(false);
  }

  historyBack(actionHeading) {
    this.currentList = find(this.listing.toArray(), o => {
      return o.schema.id === actionHeading;
    });
    const appliedCriterias = this.currentList._dataSource.criteriaGroup.criteria;
    appliedCriterias.forEach((criteria) => {
      this.currentList._dataSource.removeFilter(criteria.fieldName);
    });
    this.currentList.getRecords(10, 1);
    this.backFlag = true;
    this.showBackBtn = false;
    this.isSelected = false;
    this.isSelectedNewUsers = false;
    this.isViewAll = true;
  }

  goBack(actionHeading) {
    this.listing.toArray().forEach(data => {
      const criteria = find(this.allSchema, o => {
        return o.label === data.schema.id;
      });
      if (criteria.getAllCriteria) {
        data._dataSource.removeFilter(criteria.getAllCriteria.fieldName);
        criteria.getAllCriteria.multivalue = [];
        data.selectedRecords.forEach(data => {
          criteria.getAllCriteria.multivalue.push(data.id);
        });
        data._dataSource.filterBy(criteria.getAllCriteria).applyFilter();
        data.getRecords(10, 1);
        data.toggleSelection();
      } else {
        this.currentWrapper = find(this.listWrappers.toArray(), o => {
          return o.schema.id === actionHeading;
        });
        const newCriteria = {
          fieldName: this.currentWrapper.searchTerm,
          operation: "IN",
          multivalue: []
        };
        data.selectedRecords.forEach(data => {
          newCriteria.multivalue.push(data.id);
        });
        data._dataSource.filterBy(newCriteria).applyFilter();
        data.getRecords(10, 1);
        data.allSelected = true;
        this.isSelected = true;
        this.backFlag = false;
        this.selectedObject = {
          schema: this.listWrappersList[0].schema,
          dataSource: this.listWrappersList[0].dataSource,
          templateRefs: this.listWrappersList[0].templateRefs
        }
      }
    });
    this.isViewAll = false;
  }


  getLoadedData(event, currentListedItems) {
    if (this.backFlag) {
      const criteria = find(this.allSchema, o => {
        return o.label === currentListedItems.schema.id;
      });

      this.currentList = find(this.listing.toArray(), o => {
        return o.schema.id === currentListedItems.schema.id;
      });

      this.currentList.allSelected = false;

      if (criteria.getAllCriteria) {
        criteria.getAllCriteria.multivalue.forEach(data => {
          let mappedData = find(event, recordObj => {
            return recordObj[this.currentWrapper.feildName] === +data;
          });
          if (mappedData) {
            mappedData._checked = true;
            this.currentList.selectedRecords.push(mappedData);
            this.tempArray[
              currentListedItems.schema.id
            ] = this.currentList.selectedRecords;
          }
        });
      }
    }
    if (this.showBackBtn || !this.isViewAll || this.isSelected) {
      currentListedItems.toggleSelection();
    }
  }
}