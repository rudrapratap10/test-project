import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SharePopUpComponent } from './share-popup.component';
import {
  GlobalUIModule,
  ButtonsModule,
  ModalModule,
  ListViewModule,
  TabsModule
} from "@dewdrops/bootstrap";
import { TranslateModule } from "ng2-translate";
import { ListingViewModule } from "../listing-view/listing-view.module";
import { ListingCreateComponent } from "../listing-view/listing/listing-create/listing-create.component";
import { ListingComponent } from "../listing-view/listing/listing.component";
import { ListingColComponent } from "../listing-view/listing/listing-col/listing-col.component";
import { ListingViewsComponent } from "../listing-view/listing/listing-views/listing-views.component";
import { ListingSearchComponent } from "../listing-view/listing/listing-search/listing-search.component";
import { ShareViewListWrapperComponent } from "./share-popup-view-list-wrapper/share-popup-view-list-wrapper.component";
import { SharePopupFooterComponent } from "./share-popup-footer/share-popup-footer.component";
import { FormsModule } from "@angular/forms";


@NgModule({
    imports: [
      CommonModule,
      GlobalUIModule,
      ModalModule,
      ButtonsModule,
      TranslateModule,
      ListingViewModule,
      TabsModule,
      FormsModule,
      ListViewModule
    ],
    declarations: [SharePopUpComponent, ShareViewListWrapperComponent,SharePopupFooterComponent],
    exports: [SharePopUpComponent, ShareViewListWrapperComponent,SharePopupFooterComponent],
    entryComponents: [ListingComponent, ListingColComponent, ListingViewsComponent, ListingSearchComponent, ListingCreateComponent],
  })

export class sharePopUpModule {}





