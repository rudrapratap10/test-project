import { Component, OnInit, Input } from '@angular/core';
import { IListingSearchSchema } from '@dewdrops/common';

@Component({
  selector: 'dew-share-popup-wrapper',
  templateUrl: './share-popup-view-list-wrapper.component.html',
  styleUrls: ['./share-popup-view-list-wrapper.component.scss']
})
export class ShareViewListWrapperComponent implements OnInit {
  @Input() schema;
  @Input() dataSource;
  @Input() templateRefs: any[];
  @Input() feildName : string;
  @Input() searchTerm : string;
  @Input() listSearchCriteria : IListingSearchSchema;
  constructor() { }

  ngOnInit() {
  }

}
