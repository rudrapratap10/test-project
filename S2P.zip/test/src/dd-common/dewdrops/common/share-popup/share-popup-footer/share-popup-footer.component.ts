import {
    Component,
    ChangeDetectionStrategy
  } from '@angular/core';
  
  @Component({
    selector: 'dew-share-popup-footer',
    template: '<ng-content></ng-content>',
    changeDetection: ChangeDetectionStrategy.OnPush
  })
  export class SharePopupFooterComponent {
  
  }
  
  