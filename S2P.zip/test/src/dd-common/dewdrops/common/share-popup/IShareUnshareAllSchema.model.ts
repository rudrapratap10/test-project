import { CriteriaInterface } from "@dewdrops/interfaces";

export interface ISharePopupSchema {
  label :string;
  id: string; // same as listing id heading: string, // i18n label key
  getAllCriteria?: CriteriaInterface; // criteria for fetching selected records only by ID
}
