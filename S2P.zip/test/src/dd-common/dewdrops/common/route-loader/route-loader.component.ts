import {
  Component,
  AfterViewInit,
  AfterViewChecked
} from '@angular/core';
import {
  Router,
  NavigationEnd,
  NavigationStart,
  NavigationCancel,
  ChildActivationStart
} from '@angular/router';

@Component({
  selector: 'dew-route-loader',
  templateUrl: './route-loader.component.html',
  styleUrls: ['./route-loader.component.scss']
})
export class RouteLoaderComponent implements AfterViewInit {

  loading: boolean;

  constructor(
    private router: Router
  ) { }

  ngAfterViewInit() {
    this.router.events
      .subscribe((event) => {
        if (event instanceof NavigationStart) {
          this.loading = true;
        } else if (
          event instanceof NavigationEnd ||
          event instanceof NavigationCancel ||event instanceof ChildActivationStart
        ) {
          this.loading = false;
        }
      });
  }

}
