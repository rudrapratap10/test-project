import { Component, OnInit, ElementRef  } from '@angular/core';

@Component({
  selector: 'dew-app-root, app-root',
  templateUrl: './app-root.component.html',
  styleUrls: ['./app-root.component.scss']
})
export class AppRootComponent implements OnInit {

  public userDetails= {};

  constructor(private elementRef: ElementRef) { }

  ngOnInit() {
    this.userDetails['rainbow_header_url'] = "https://qc-rainbow.zycus.net/ZycusCommonHeader/COMMON_HEADER.do?_sv=b578b7131ef799c7b80617c23acf9311";
    this.userDetails['rainbow_url'] = "https://qc-rainbow.zycus.net";
    this.setRainbowHeader();
  }

  setRainbowHeader() {
    if (this.userDetails['rainbow_header_url']) {
      const code = 'var currentProduct = "Import Studio"; var tmsTokenId = "'
        + this.userDetails['rainbow_header_url']
        + '"; var rainbowContext = '
        + '{menuUniqueName: "IMPORT_STUDIO",'
        + ' menuDisplayname: "Import Studio",'
        + ' tmsProductName: "Import Studio",'
        + ' entityName: "", entityId: ""};';

      let step = document.createElement('script');
      step.appendChild(document.createTextNode(code));
      step.type = 'text/javascript';
      this.elementRef.nativeElement.appendChild(step);

      step = document.createElement('script');
      step.type = 'text/javascript';
      step.src = this.userDetails['rainbow_header_url'];
      this.elementRef.nativeElement.appendChild(step);
    }
  }

}
