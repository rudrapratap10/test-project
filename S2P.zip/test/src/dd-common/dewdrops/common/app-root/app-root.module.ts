import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AppRootComponent } from './app-root.component';
import { NavbarModule } from '../navbar/navbar.module';
import { SpotlightModule } from '../spotlight/spotlight.module';
import { FooterModule } from '../footer/footer.module';
import { DialogModule } from '../dialog/dialog.module';
import { RouteLoaderModule } from '../route-loader/route-loader.module';
import { RainbowModule } from '../rainbow-header/rainbow.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    NavbarModule,
    RainbowModule,
    SpotlightModule,
    DialogModule.root(),
    FooterModule,
    RouteLoaderModule
  ],
  declarations: [AppRootComponent],
  exports: [AppRootComponent],
  providers: []
})
export class AppRootModule { }
