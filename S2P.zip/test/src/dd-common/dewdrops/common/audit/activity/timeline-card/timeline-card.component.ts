import { Component, OnInit, Input, Output, EventEmitter, Optional, Inject } from '@angular/core';
import * as config from '../../config';
import { ActivityService } from '../activity.service';

@Component({
  selector: 'dew-timeline-card',
  templateUrl: './timeline-card.component.html',
  styleUrls: ['./timeline-card.component.scss']
})
export class TimelineCardComponent implements OnInit {

  @Input()
  item: any;
  @Input()
  oldest = false;
  @Input()
  showConversations: boolean;
  @Input()
  auditTrailApi: string;
  @Output()
  addReply = new EventEmitter();
  /**
   * Emit action when clicked version
   */
  @Output() whenClickedVersion = new EventEmitter();

  auditAction = config.AUDIT_ACTION;
  showReplyBox: any;
  showSharedModal: boolean = false;

  public userTableData = [];

  public userColumnData = [
    {
      display: 'NAME',
      displayLang: 'DEWDROPS_REQUISITION_TIMELINE_CARD_LBL_NAME'
    },
    {
      display: 'Email ID',
      displayLang: 'DEWDROP_LBL_EMAIL'
    }
  ];

  constructor(public activityService: ActivityService) {}

  ngOnInit() {
    this.userTableData = this.item.auditVariables.TO ? this.item.auditVariables.TO : [];
  }

  toggleReplyBox(showReplyBox ? ) {
    this.showReplyBox = (showReplyBox && showReplyBox !== this.showReplyBox) ? showReplyBox : false;
  }

  isConversation() {
    return this.item.event === 'APPROVAL_CONVERSATION_NEW';
  }

  sharedCount() {
    return this.item.auditVariables.TO ? this.item.auditVariables.TO.length : 0;
  }

  repliesCount() {
    return this.item['replies'] ? this.item['replies']['length'] : false;
  }

  attachCount() {
    return this.item.attachmentIds.length;
  }

  sendReply(data) {
    data.parentAuditTrailId = this.item.auditTrailId;
    this.addReply.emit(data);
  }

  onVersionClick(version,createdOn) {
    this.whenClickedVersion.emit({
      version, createdOn
    });
  }

}
