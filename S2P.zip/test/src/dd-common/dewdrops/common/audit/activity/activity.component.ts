import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivityService } from './activity.service';
import * as config from '../config';
import { LanguageTranslateService } from '@dewdrops/services';

@Component({
  selector: 'dew-activity',
  templateUrl: './activity.component.html',
  styleUrls: ['./activity.component.scss'],
  providers: [ActivityService]
})
export class ActivityComponent implements OnInit {

  audits: any;
  @Input()
  entityId: string;
  @Input()
  entityType: string;
  @Input()
  version: string;
  @Input()
  docId: string;
  @Input()
  auditTrailApiURL = {
    auditListURL: '',
    createReplyURL: '',
    createCommentURL: '',
    addAttachmentURL: ''
  }

  @Input()
  auditTrailReqParams: any = {};

  /**
   * Emit action when clicked
   */
  @Output() whenActivityVersionClicked = new EventEmitter();

  versionInfo: any;
  versionCount: number;
  loader = true;
  auditTrailMap = {};
  auditTrailIdMap = {};
  auditCreatedOn = {};
  linkAutoIds = {};
  @Input()
  filters = [
    'version',
    'conversation',
    'approval',
    'procurement',
    'integration',
    'others'
  ];
  @Input()
  showConversations: boolean;

  filterModel = {};

  constructor(private service: ActivityService, private _language: LanguageTranslateService) {
    this.versionInfo = {};
    this.versionCount = 0;

  }

  ngOnInit() {
    this.init();
  }

  init() {
    this.loader = true;
    this.service.docId = this.docId;
    this.service
    .fetchActivities(this.auditTrailReqParams ,this.auditTrailApiURL)
      .subscribe(data => {
        this.loader = false;
        this.audits = data;
        this.audits.forEach(
          (audit) => {
            this.versionInfo['' + audit.version] = audit.createdOn;
          }
        );
        this.setLinkedData();
      });
  }

  setLinkedData() {
    this.linkAutoIds = {};
    this.audits.forEach(data => {
      this.auditTrailMap[data['autoId']] = data;
      this.auditTrailIdMap[data['auditTrailId']] = data;
    });
    this.audits = this.audits.map(data => this.formatting(data));
    for (let at = this.audits.length - 1; at >= 0; at--) {
      if (!this.linkAutoIds[this.audits[at]['version']]) {
        this.linkAutoIds[this.audits[at]['version']] = this.audits[at]['autoId'];
      }
    }
  }

  clearFilter() {
    this.filterModel = {};
  }

  isNoData() {
    return document.querySelectorAll('dew-timeline-card').length
      === document.querySelectorAll('dew-timeline-card[hidden]').length
      && document.querySelectorAll('dew-timeline-card').length;
  }

  checkFilter(event, autoId) {
    return !this.service.checkFilter(event,
      autoId,
      this.filterModel,
      this.linkAutoIds,
      this.auditTrailMap);
  }

  addComment(data) {
    const params = {
      "entityType": this.entityType,
      "entityId": this.entityId,
      "version": 1,
      "comments": data.comment,
      "role": "REQUESTER",
      "attachmentIds": data.attachments,
      "toUserId": data.userIds,
      "visibleTo": data.visibleTo
    }
    this.service.addComment(params, this.auditTrailApiURL)
      .subscribe(() => this.init());
  }

  addReply(data) {
    const params = {
      "entityType": this.entityType,
      "entityId": this.entityId,
      "version": 1,
      "comments": data.comment,
      "role": "REQUESTER",
      "attachmentIds": data.attachments,
      "parentAuditTrailId": data.parentAuditTrailId
    }
    this.service.addReply(params, this.auditTrailApiURL)
      .subscribe(() => this.init());
  }

  formatting(auditTrails) {
    let comments = auditTrails['comments'];
    let auditTrailIdMapComment = this.auditTrailIdMap[auditTrails['auditTrailId']]['comments'];
    let attachmentSize = '';

    if (!(typeof auditTrailIdMapComment == 'object' && auditTrailIdMapComment != null)) {
      if (auditTrails['comments'] === '' || !auditTrails['comments']) {
        if (this.auditTrailMap[auditTrails['autoId']]['auditVariables']['ENTITY_OWNERSHIP_CHANGED'] == "true") {
          comments = 'Entity Ownership changed';
        } else {
          comments = config.AUDIT_COMMENTS[auditTrails['entityType'] + '_' + auditTrails['event']];
        }
      }

      if (comments == '{LBL_AT_COMMENT_REQUISITION_AWAITING_BUYER_ACTION}') {
        comments = config.AUDIT_COMMENTS['REQUISITION_AWAITING_BUYER_ACTION'];
      }

      if (comments == '{LBL_AT_PRIVATE}') {
        comments = '--PRIVATE--';
      } else if (comments == 'ERROR_IN_PROCESSING_APPROVAL') {
        comments = 'Error in processing approver action';
      } else if (comments == 'ERROR_IN_PROCESSING_APPROVAL_RESOLVED') {
        comments = 'Error in processing approver action resolved';
      }
    }

    let action = config.AUDIT_ACTION[auditTrails['entityType'] + '_' + auditTrails['event']];
    let actionLang = config.AUDIT_ACTION[auditTrails['entityType'] + '_' + auditTrails['event']];
    var parse = [];
    var auditVariableMap = this.auditTrailMap[auditTrails['autoId']]['auditVariables'];

    for (var auditKey in auditVariableMap) {
      var auditValue = auditVariableMap[auditKey];
      let auditKeyTemp = auditKey;
      var auditLink = this.service.prepareLink(auditKey, auditValue, auditVariableMap, auditTrails);
      if (actionLang.toLowerCase().indexOf(auditKeyTemp.toLowerCase()) != -1 && !parse[auditKeyTemp]) {
        parse[auditKeyTemp] = auditLink;
      }
      if ((auditTrails['comments'] === '' || !auditTrails['comments']) || auditTrails['comments'] === '{LBL_AT_COMMENT_ORDERED_AGAINST_PO}') {
        comments = comments.replace('{' + auditKey + '}', auditLink);
      }
      if (auditKey === 'FAILURE_REASON') {
        comments = config.AUDIT_COMMENTS[auditTrails['entityType'] + "_" + auditValue];
      }
      if(auditKey === 'REPLACE_MESSAGE') {
        comments = comments.replace(auditValue, auditLink);
      }
    }
    action = this.service.parseLang(action, parse);

    let createdByName = '';

    if (auditTrails['role'] == 'SYSTEM') {
      createdByName = 'SYSTEM';
    } else if (auditTrails['role'] == 'SUPPLIER') {
      createdByName = 'Supplier';
    } else if ((auditTrails['role'] == 'EXTERNAL_APPROVER'
      || auditTrails['role'] == 'EXTERNAL_SYSTEM')
      && this.entityType === 'REQUISITION') {
      createdByName = 'External System';
    } else {
      createdByName = auditTrails['createdBy']['firstName'] + ' ' + auditTrails['createdBy']['lastName'];
    }

    if (auditTrails['role'] == 'CUSTOM') {
      auditTrails['roleDisplay'] = this.auditTrailMap[auditTrails['autoId']]['auditVariables']['NODE_DISPLAY_NAME'];
    }

    auditTrails['comments'] = comments;
    auditTrails['action'] = action;
    auditTrails['createdByName'] = createdByName;
    return auditTrails;
  }

  onOlderVersionClick({ version, createdOn }) {
    if (createdOn == this.versionInfo[version]) {
      this.whenActivityVersionClicked.emit(version);
    }
  }

  isOldestAudit(createdOn: number, version: string) {
    return this.versionInfo[version] === createdOn;
  }

}
