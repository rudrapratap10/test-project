import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivityComponent } from './activity/activity.component';
import { ReplyComponent } from './activity/reply/reply.component';
import { TimelineCardComponent } from './activity/timeline-card/timeline-card.component';
import { MentionModule } from './activity/post-create/mention';
import { PostCreateComponent } from './activity/post-create/post-create.component';
import { ActivityService} from './activity/activity.service';
import { FormsModule } from '@angular/forms';
import { NoDataModule } from '@dewdrops/bootstrap';
import { ProgressModule } from '@dewdrops/bootstrap';
import { GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { DateformatPipeModule } from '../dateformat/dateformat.pipe.module';

@NgModule({
  imports: [
    CommonModule,
    GlobalUIModule,
    MentionModule,
    FormsModule,
    NoDataModule,
    ProgressModule,
    TranslateModule,
    DateformatPipeModule
  ],
  declarations: [ActivityComponent, ReplyComponent, TimelineCardComponent, PostCreateComponent],
  providers: [ActivityService],
  exports: [ActivityComponent]
})
export class AuditModule { }
