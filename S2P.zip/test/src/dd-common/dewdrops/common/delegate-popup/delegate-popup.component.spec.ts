import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DelegatePopupComponent } from './delegate-popup.component';

describe('DelegatePopupComponent', () => {
  let component: DelegatePopupComponent;
  let fixture: ComponentFixture<DelegatePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DelegatePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DelegatePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
