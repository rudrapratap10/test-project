import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DelegatePopupComponent } from './delegate-popup.component';

import { RouterModule } from '@angular/router';
import { TabsModule, LayoutModule, ButtonsModule, ModalModule, FormControlModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DewDetailsInfoModule } from '../details-info/details-info.module';
import { CharacterCountModule } from 'dd-common/dewdrops/core/bootstrap/character-count/character-count.module';


@NgModule({
  imports: [
    CommonModule,
    GlobalUIModule,
    TranslateModule,
    FormsModule
  ],
  declarations: [DelegatePopupComponent],
  exports: [
    DelegatePopupComponent
  ]
})
export class DelegatePopupModule { }

