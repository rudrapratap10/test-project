import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { CollectionFactory } from '@dewdrops/factories';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { UserModel } from 'dd-common/dewdrops/core/bootstrap/autocomplete-user/user.model';
export interface DelegateInterface {
  comment: any,
  userDetails: UserModel
}
@Component({
  selector: 'dew-delegate-popup',
  templateUrl: './delegate-popup.component.html',
  styleUrls: ['./delegate-popup.component.scss']
})


export class DelegatePopupComponent implements OnInit {
  
  constructor(private _form: FormBuilder) { }
  commentControl = new FormControl(['', [Validators.required]]);
  hasComment : boolean = true;
  isUserSelected : boolean = true;
 

  @Input() openModal : boolean;  
  @Input() data: any;
  @Input() showAlert: boolean;
  @Input() datasource : CollectionFactory
  @Output() closeModel = new EventEmitter();
  @Output() onActionClick = new EventEmitter();
  
  delegateForm : FormGroup
  delegateObject : DelegateInterface;
  selectedUser : UserModel;

  comment? : string;
  

  ngOnInit() {
    this.delegateForm = this._form.group({
      commentControl :  ['', [Validators.required]]
    });
  }
  toggleModalState(state)
  {
    this.openModal = state;
    this.closeModel.emit(state);
  }

  onAction()
  {
    if(this.comment === undefined || (this.comment.trim().length === 0))      
    {            
      this.hasComment = false;
    }
    else
    {
      this.delegateObject = {
        comment : this.comment,
        userDetails : this.selectedUser
      }
      this.onActionClick.emit(this.delegateObject);
      this.openModal = false;
      this.comment = ''
      this.closeModel.emit(false);
    }    
  }
  getSelectedUser(event)
  {
    this.selectedUser = event;    
    this.isUserSelected = true;
  }
  
  notSelected(event)
  {
    this.isUserSelected = false;
  }
  onFocusComment()
  {
    this.hasComment = true;
  }

}
