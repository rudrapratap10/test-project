import { CommonModule} from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonsModule, CardModule, ExtendModule, FormControlModule} from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';
import { TemplateSearchComponent } from './template-search.component';
import { ListingViewModule } from '../listing-view/listing-view.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    LayoutModule,
    ExtendModule,
    CardModule,
    ButtonsModule,
    FormControlModule,
    ReactiveFormsModule,
    TranslateModule,
    ListingViewModule
  ],
  declarations: [TemplateSearchComponent],
  exports: [TemplateSearchComponent]
})
export class TemplateSearch {

}
