/**
 * Defines the type for template search data
 */
export class TemplateSearchModel {
  eventName: string;
  ownerName: string;
  creationDate: string;
  eventType: string;
  eventId: string;
  isSelected: boolean;
  isLike: boolean;
}
