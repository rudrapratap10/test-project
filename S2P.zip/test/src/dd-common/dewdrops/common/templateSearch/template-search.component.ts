import {
  ChangeDetectorRef,
  Component,
  ContentChild,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CriteriaGroupInterface, CriteriaInterface } from '@dewdrops/interfaces';
import { APIClientService } from '@dewdrops/services';
import { CollectionFactory } from 'dd-common/dewdrops/core/factories/collection/collection.factory';
import { cloneDeep } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { debounceTime} from 'rxjs/operators';
import { TemplateSearchModel } from './templatesearch.model';
import { IListingSearchSchema } from '@dewdrops/common';

@Component({
  selector: 'dew-template-search',
  templateUrl: './template-search.component.html',
  styleUrls: ['./template-search.component.scss'],
  providers: []
})
export class TemplateSearchComponent implements OnInit {
  @ContentChild('cardContent') cardContentTmpl: TemplateRef<any>;

  @Input()
  placeholder = 'DEWDROPS_PLACEHOLDER_SEARCH';

  @Input() user: any;
  // for configuration of inner card elements

  @Input() templateConfigurable = {
    cardCount: 12,
    cardNos: 6,
    preferredBtnAction: true,
    likeaction: true,
    downloadaction: true,
    previewBtnAction: true
  };

  // search operation content will go here
  @Input()
  // tslint:disable-next-line:ban-types
  transformFn: Function;

  @Input()
  searchSchema: IListingSearchSchema;

  @Input()
  sortOptions: {
    defaultSortText: string,
    options: Array<{ id: any, name: any }>
  };

  @Input() set records(value: TemplateSearchModel[] | CollectionFactory<TemplateSearchModel>) {
    this._records = value;
    if (this._records instanceof Array) {
      this.dataList = this._records.map((item, index) => {
        const transformedItem = this.transform(item);
        transformedItem.id = index;
        return transformedItem;
      });
      this.data = cloneDeep(this.dataList);
    } else {
      this._records.count(this.templateConfigurable.cardCount);
      this._records.applyPaginate();
      this._records.list$.subscribe(
        (response) => {
          const carddata = response.map((item, index) => {
            const transformedItem = this.transform(item);
            transformedItem.id = index;
            return transformedItem;
          });
          this.livedataList = carddata;
           this.totalRecords = (this._records as CollectionFactory).totalRecords;
        },
        (error) => {
          return error;
        }
      );
    }
  }
  @Output() download = new EventEmitter(); // for download button action

  @Output() like = new EventEmitter(); // for like button action

  @Output() preview = new EventEmitter(); // preview button action

  @Output() select = new EventEmitter(); // select each card action

  @Output() searchCriteriaChange = new EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }>();

  @Output() searchTextCleared = new EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }>();
  isDataLoading = false;
  dataList: TemplateSearchModel[];
  livedataList: TemplateSearchModel[];
  // for search icon issue
  cancel = false;
  card = true;
  contractModel: string;
  data = [];
  cardId = new FormControl({ value: '' });
  templateForm: FormGroup = this.formBuilder.group({
    cardId: this.cardId
  });
  selectedSortOption: any;
  sortByChange = new EventEmitter<string>();

  public _records: TemplateSearchModel[] | CollectionFactory<TemplateSearchModel>;

  public totalRecords: number;

  constructor(
    public _apiClient: APIClientService,
    private _translate: TranslateService,
    private formBuilder: FormBuilder,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
  }

  searchTemplates(event: {
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }) {
    this.searchCriteriaChange.emit(event);
    if (event.searchCriteria.forField === '*') {
      const criteriaGrp: CriteriaGroupInterface = {
        logicalOperator: 'OR',
        criteria: []
      };
      if (this.searchSchema.criteriaTransformFn) {
        criteriaGrp.criteria = this.searchSchema.criteriaTransformFn(event.searchCriteria.criteria.value);
      }
      (this._records as CollectionFactory).removeSubCriteriaGroupFilter();
      (this._records as CollectionFactory).addSubCriteriaGroupFilter(criteriaGrp);
      (this._records as CollectionFactory).applyFilter();
    } else {
      const criteriaGrp: CriteriaGroupInterface = {
        logicalOperator: 'OR',
        criteria: []
      };
      if (this.searchSchema.criteriaTransformFn) {
        criteriaGrp.criteria = this.searchSchema.criteriaTransformFn(event.searchCriteria.criteria.value);
      } else {
        criteriaGrp.criteria = [event.searchCriteria.criteria];
      }
      (this._records as CollectionFactory).removeSubCriteriaGroupFilter();
      (this._records as CollectionFactory).addSubCriteriaGroupFilter(criteriaGrp);
      (this._records as CollectionFactory).applyFilter();
    }
    this.isDataLoading = true;
    (this._records as CollectionFactory).count(this.templateConfigurable.cardCount);
    (this._records as CollectionFactory).first();
    (this._records as CollectionFactory).applySort();
    (this._records as CollectionFactory).applyPaginate();
    (this._records as CollectionFactory).list$.subscribe( (response) =>
    {
      if(response){
        const carddata = response.map((item, index) => {
          const transformedItem = this.transform(item);
          transformedItem.id = index;
          return transformedItem;
        });
        this.livedataList = carddata;
        this.totalRecords = (this._records as CollectionFactory).totalRecords;
        this.isDataLoading = false;
      }
      else{
        this.livedataList = [];
        this.totalRecords = 0;
      }

    }
    );
  }

  removeSearchFilters(event: {
    defaultCriteria: CriteriaInterface,
    searchCriteria: { forField?: string, criteria: CriteriaInterface }
  }) {
    if (this.searchSchema.columns) {
        const subCriteriaGroup = cloneDeep((this._records as CollectionFactory).criteriaGroup.criteriaGroup);
        (this._records as CollectionFactory).removeSubCriteriaGroupFilter();
        (this._records as CollectionFactory).applyFilter();
        if (subCriteriaGroup && subCriteriaGroup.length !== 0) {
          this.isDataLoading = true;
          (this._records as CollectionFactory).first();
          (this._records as CollectionFactory).applySort();
          (this._records as CollectionFactory).applyPaginate();
          (this._records as CollectionFactory).list$.subscribe( (response) =>
          {
            if(response){
            const carddata = response.map((item, index) => {
              const transformedItem = this.transform(item);
              transformedItem.id = index;
              return transformedItem;
            });
            this.livedataList = carddata;
            this.totalRecords =  (this._records as CollectionFactory).totalRecords;
            this.isDataLoading = false;
            this.cdRef.detectChanges();
          }
          else{
            this.livedataList = [];
            this.totalRecords = 0;
          }
        }
          )
      }
      }
  }

  applySort(event) {
    this.sortByChange.emit(event);
  }

  // check mark template card
  toogleMark(index) {
    for (let i = 0; i < this.livedataList.length; i++) {
      if (i === index) {
        this.livedataList[i].isSelected = this.livedataList[i].isSelected === true ? false : true;
      } else {
        this.livedataList[i].isSelected = false;
      }
    }
  }
  // download the template card
  emitDownloadIndex(i) {
    this.download.emit(i);
  }

  // like the template card
  emitLikeIndex(i) {
    this.livedataList[i].isLike = this.livedataList[i].isLike === true ? false : true;
    this.like.emit(i);
  }

  // previewing the template card
  emitPreviewIndex(i) {
    this.preview.emit(i);
  }

  selectCard(i) {
    this.select.emit(this.livedataList[i]);
  }

  // for transform the search results and show in corresponding card
  public transform(transformFnArgs: any) {
    if (this.transformFn) {
      return this.transformFn(transformFnArgs);
    } else {
      return {
        eventName: transformFnArgs.eventName,
        ownerName: transformFnArgs.ownerName,
        creationDate: transformFnArgs.creationDate,
        eventType: transformFnArgs.eventType
      };
    }
  }

  loadNext() {
    const dataSource = this._records as CollectionFactory;
    dataSource.count(this.templateConfigurable.cardCount);
    dataSource
      .next()
      .applyPaginate()
      .applySort()
      .applyFilter();
     dataSource
      .list$
      .subscribe((response) => {
        if(response){
          const carddata = response.map((item, index) => {
            const transformedItem = this.transform(item);
            transformedItem.id = index;
            return transformedItem;
          });
          this.livedataList = [...this.livedataList, ...carddata];
          this.totalRecords = dataSource.totalRecords;
          this.isDataLoading = false;
        }
      });
  }

}
