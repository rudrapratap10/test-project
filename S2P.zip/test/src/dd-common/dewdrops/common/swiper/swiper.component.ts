import {
  AfterContentInit,
  AfterViewInit,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  ViewEncapsulation
} from '@angular/core';
import Swiper from 'swiper';
import { ISwiperOptions } from './models/swiper-options.model';
import { SwiperItemComponent } from './swiper-item/swiper-item.component';

@Component({
  selector: 'dew-swiper',
  templateUrl: './swiper.component.html',
  styleUrls: ['./swiper.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SwiperComponent implements OnInit, AfterContentInit, AfterViewInit {

  public swiperItems: SwiperItemComponent[];

  /**
   * swiper options to configure swiper
   *
   * @see `ISwiperOptions` for the available configurable options
   */
  @Input()
  public options: ISwiperOptions;

  /**
   * Total no. of records present in database
   */
  @Input()
  totalRecords: number;

  /**
   * emits event when user reaches the last slide in the view
   */
  @Output()
  public loadNextItems: EventEmitter<any> = new EventEmitter<any>();

  /**
   * @ignore not available for now. To be implemented on requirement
   *
   * emits event on clicking previous arrow
   */
  @Output()
  public loadPrevItems: EventEmitter<any>;

  /**
   * Querylist of SwiperItemComponent
   */
  @ContentChildren(SwiperItemComponent)
  private swiperItemsQueryList: QueryList<SwiperItemComponent>;

  /**
   * instance of Swiper (from swiper library)
   */
  private mySwiper: Swiper;

  constructor() { }

  ngOnInit() {

  }

  ngAfterContentInit(): void {
    this.swiperItems = this.swiperItemsQueryList.toArray();
    this.swiperItemsQueryList.changes.subscribe((changes) => {
      this.swiperItems = this.swiperItemsQueryList.toArray();
      setTimeout(() => {
        this.mySwiper.update();
      });
    });
  }

  ngAfterViewInit(): void {
    this.initSwiper();
  }

  /**
   * Initializes swiper
   */
  initSwiper(): void {
    this.mySwiper = new Swiper('.swiper-container', {
      direction: this.options.direction ? this.options.direction : 'horizontal',
      loop: this.options.loop ? this.options.loop : false,
      slidesPerView: this.options.slidesPerView ? this.options.slidesPerView : 1,
      spaceBetween: this.options.spaceBetween ? this.options.spaceBetween : 20,
      // If we need pagination
      // pagination: {
      //   el: '.swiper-pagination',
      // },

      // Navigation arrows
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },

      on: {
        reachEnd: () => { this.loadNextSwiperItems(); }
      },

      // And if we need scrollbar
      // scrollbar: {
      //   el: '.swiper-scrollbar',
      // },
    });
  }

  /**
   * method called when user reaches the last slide in the view
   */
  loadNextSwiperItems() {
    if (this.mySwiper === undefined || (this.mySwiper && (this.totalRecords !== this.mySwiper.slides.length))) {
      this.loadNextItems.emit(true);
    }
  }

}
