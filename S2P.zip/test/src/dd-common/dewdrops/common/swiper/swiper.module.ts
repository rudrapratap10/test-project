import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SwiperItemComponent } from './swiper-item/swiper-item.component';
import { SwiperComponent } from './swiper.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SwiperComponent, SwiperItemComponent],
  exports: [SwiperComponent, SwiperItemComponent]
})
export class SwiperModule { }
