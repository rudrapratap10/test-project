export interface ISwiperOptions {

  /**
   * Number of slides per view (slides visible at the same time on slider's container)
   */
  slidesPerView: number;

  /**
   * Could be 'horizontal' or 'vertical' (for vertical slider).
   *
   * @default 'horizontal'
   */
  direction?: 'horizontal' | 'vertical';

  /**
   * to make the navigation circular after last slide
   *
   * @default false
   */
  loop?: boolean;

  /**
   * Distance between slides in px.
   */
  spaceBetween?: number;
}
