import {
  Component,
  ContentChild,
  OnInit,
  ViewChild
} from '@angular/core';

@Component({
  selector: 'dew-swiper-item',
  templateUrl: './swiper-item.component.html',
  styleUrls: ['./swiper-item.component.scss']
})
export class SwiperItemComponent implements OnInit {

  /**
   * stores template of swiper item
   */
  @ViewChild('swiperItemTemplate')
  public swiperItemTemplate: any;

  constructor() { }

  ngOnInit() {
  }

}
