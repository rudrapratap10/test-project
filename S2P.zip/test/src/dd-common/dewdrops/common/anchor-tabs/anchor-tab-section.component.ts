import { Component, OnInit, ContentChildren, QueryList, TemplateRef, ContentChild, ViewChild, Input } from '@angular/core';

@Component({
  selector: 'dew-anchor-tab-section',
  template: ` <ng-template #template>
    <ng-content></ng-content>
  </ng-template>
  `
})
export class AnchorTabSectionComponent implements OnInit {

  @Input()
  heading;
  @Input()
  id;
  
  @ViewChild('template')
  template: TemplateRef<any>;
  
  constructor() { }

  ngOnInit() {
  }

}
