import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnchorTabsComponent } from './anchor-tabs.component';

describe('AnchorTabsComponent', () => {
  let component: AnchorTabsComponent;
  let fixture: ComponentFixture<AnchorTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnchorTabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnchorTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
