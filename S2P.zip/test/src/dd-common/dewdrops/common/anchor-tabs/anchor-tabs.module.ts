import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule, ProgressModule, TabsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { AnchorTabsComponent } from './anchor-tabs.component';
import { AnchorTabSectionComponent } from './anchor-tab-section.component';

@NgModule({
  imports: [
    CommonModule,
    TabsModule,
    LayoutModule,
    TranslateModule,
    ProgressModule
  ],
  declarations: [AnchorTabsComponent, AnchorTabSectionComponent],
  exports: [AnchorTabsComponent, AnchorTabSectionComponent]
})
export class AnchorTabsModule { }
