import { Component, OnInit, ContentChildren, QueryList, Input, ViewChild, ElementRef, Inject, Optional, HostListener, Renderer2 } from '@angular/core';
import { AnchorTabSectionComponent } from './anchor-tab-section.component';

@Component({
  selector: 'dew-anchor-tabs',
  templateUrl: './anchor-tabs.component.html',
  styleUrls: ['./anchor-tabs.component.scss']
})
export class AnchorTabsComponent implements OnInit {

  @ContentChildren(AnchorTabSectionComponent)
  sectionList: QueryList<AnchorTabSectionComponent>;
  public tabId:string;

  @ViewChild('anchorTabs', {read: ElementRef})
  anchorTabs: ElementRef;

  spotlightWidth:any;

  constructor(  
    @Inject('spotlight')
    @Optional()
    private _spotlightWidthProperty: any,
    private _renderer: Renderer2
  ) {

  }
   //To get the dynamic spotlight width on resizing the screen
  @HostListener('window:resize', ['$event'])
  onResize(event){
    this.spotlightWidth = this._spotlightWidthProperty.spotlightElement.spotlight.nativeElement.offsetWidth;
    this.ngAfterViewInit();
    
  }
  ngOnInit() {
    this.spotlightWidth = this._spotlightWidthProperty.spotlightElement.spotlight.nativeElement.offsetWidth;
  }

  ngAfterViewInit() {
    //To set the width of anchor tab equal to the spotlight width irrespective of the width of its parent in all screensizes
    if(this.spotlightWidth){
      this.spotlightWidth = this._spotlightWidthProperty.spotlightElement.spotlight.nativeElement.offsetWidth;
      const anchorTabsWidth = this.anchorTabs.nativeElement.offsetWidth;
      const elem = this.anchorTabs.nativeElement.children[0].children[0];
      this._renderer.setStyle(elem, 'margin-left', `-${((this.spotlightWidth-anchorTabsWidth)/2)}px`);
      this._renderer.setStyle(elem, 'margin-right', `-${((this.spotlightWidth-anchorTabsWidth)/2)}px`);
    }
  }
}
