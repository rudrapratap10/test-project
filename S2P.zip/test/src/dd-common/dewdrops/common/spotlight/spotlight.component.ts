import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ElementRef,
  Output,
  EventEmitter,
  HostListener
} from '@angular/core';
import { Location } from '@angular/common';

@Component({
  selector: 'dew-spotlight',
  templateUrl: './spotlight.component.html',
  styleUrls: ['./spotlight.component.scss']
})
export class SpotlightComponent implements OnInit {

  @Input() backOption:boolean;
  // @Output() spotlightElementWidth = new EventEmitter<number>();
  @ViewChild('spotlight')
  spotlight: ElementRef;
  tpl: any;
  constructor(private _location: Location) {
    // this.tpl = 'home';
  }
  
  ngOnInit() {
   
  }

  ngAfterViewInit() {
  }

  navigateBack() {
    this._location.back();
  }
}
