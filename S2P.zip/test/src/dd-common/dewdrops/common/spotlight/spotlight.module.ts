import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  RouterModule
} from '@angular/router';

import { BreadcrumbModule  } from '@dewdrops/bootstrap';

import { SpotlightComponent } from './spotlight.component';
import { UtilityModule } from '../utility/utility.module';

@NgModule({
  imports: [
    CommonModule,
    BreadcrumbModule,
    RouterModule,
    UtilityModule
  ],
  declarations: [
    SpotlightComponent
  ],
  exports: [
    SpotlightComponent
  ]
})
export class SpotlightModule { }
