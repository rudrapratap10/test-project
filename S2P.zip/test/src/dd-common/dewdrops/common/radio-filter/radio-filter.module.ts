import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RadioFilterComponent } from './radio-filter.component';
import { TranslateModule } from 'ng2-translate';
import { ProgressModule, FormControlModule, GlobalUIModule, AutoCompleteModule } from '@dewdrops/bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    AutoCompleteModule,
    TranslateModule,
    ProgressModule,
    FormsModule,
    ReactiveFormsModule,
    FormControlModule,
    GlobalUIModule
  ],
  declarations: [RadioFilterComponent],
  exports : [RadioFilterComponent]
})
export class RadioFilterModule { }
