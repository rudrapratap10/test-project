import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Optional,
  Output,
  ViewChild
} from "@angular/core";
import {
  IRadioProperties,
  RadioComponent
} from "dd-common/dewdrops/core/bootstrap/form-control/radio/radio.component";

@Component({
  selector: "dew-radio-filter",
  templateUrl: "./radio-filter.component.html",
  styleUrls: ["./radio-filter.component.scss"]
})
export class RadioFilterComponent implements OnInit {
  @Input() radioOptions: Array<IRadioProperties>;
  @Output() selectedRadio: EventEmitter<any> = new EventEmitter<any>();
  @Output() clearRadio: EventEmitter<any> = new EventEmitter<any>();
  @Output() whenApplied: EventEmitter<any> = new EventEmitter<any>();
  @Output() whenSelectionChanged: EventEmitter<string[]> = new EventEmitter<
    string[]
  >();
  @ViewChild("radioGrp") radioGrp: RadioComponent;

  @Input() name: string;
  @Input() applier = true;

  constructor(
    @Inject("FILTER_PIPE_LINE")
    @Optional()
    private _filterPipeLine: any
  ) {}

  defaultIndex: number;
  radioModel: any;
  ngOnInit() {
    this._filterPipeLine.resetFiltersSub.subscribe((state: boolean) => {
      if (state) {
        this.resetFilter();
      }
    });
  }

  modelChanged(event) {
    this.radioGrp.writeValue(event);
    this._filterPipeLine.put(this.name, event);
    this.whenSelectionChanged.emit(event);
  }

  clearRadioFilter() {
    this.resetFilter();
    this._filterPipeLine.put(this.name, this.radioModel);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  resetFilter() {
    this.radioModel = '';
    this.radioGrp.writeValue(null);
    this.clearRadio.emit(this.radioModel);
  }

  applyRadioFilter(radio) {
    this._filterPipeLine.put(this.name, radio);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
    this.selectedRadio.emit(radio);
  }
}
