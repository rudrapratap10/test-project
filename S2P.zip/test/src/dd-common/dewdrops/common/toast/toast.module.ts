import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GlobalServicesModule } from '@dewdrops/services';
import { ToastComponent } from './toast.component';

@NgModule({
  imports: [
    CommonModule,
    GlobalServicesModule
  ],
  declarations: [ToastComponent],
  exports: [ToastComponent]
})
export class ToastModule { }
