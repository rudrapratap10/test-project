import { Component, OnInit } from '@angular/core';
import { RequestNotifyService } from '@dewdrops/services';

@Component({
  selector: 'dew-toast',
  templateUrl: './toast.component.html',
  styleUrls: ['./toast.component.scss']
})
export class ToastComponent implements OnInit {

  _showProgress: boolean;
  _toasts = [];

  constructor(
    private _notify: RequestNotifyService
  ) {
    this._showProgress = false;
  }

  ngOnInit() {
    this._notify.progressChange.subscribe((state) => {
      this._showProgress = state;
    });
    this._notify.toastChange.subscribe((message) => {
      this._toasts.push(message);
    });
  }

  _closeToast(): void {
    this._toasts = [];
  }

  _closeMessage(index: number): void {
    this._toasts.splice(index, 1);
  }
}
