import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';
import { ContractsComponent } from './contracts.component';
import { ContractsService } from './contracts.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GlobalUIModule } from '../../core/bootstrap/global-ui.module';
@NgModule({
imports: [
    CommonModule,
    TranslateModule,
     LayoutModule,
     FormsModule,
     ReactiveFormsModule,
     GlobalUIModule
],
declarations: [ ContractsComponent ],
providers: [ContractsService],
exports: [ ContractsComponent ],
})
export class ContractsModule { }
