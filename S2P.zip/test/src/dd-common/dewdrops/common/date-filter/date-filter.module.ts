import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutoCompleteModule } from 'dd-common/dewdrops/core/bootstrap/autocomplete/autocomplete.module';
import { LayoutModule, ProgressModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { DateFilterComponent } from './date-filter.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    AutoCompleteModule,
    LayoutModule,
    TranslateModule,
    ProgressModule,
    GlobalUIModule,
    FormsModule
  ],
  declarations: [DateFilterComponent],
  exports:[DateFilterComponent]
  
})
export class DateFilterModule { }
