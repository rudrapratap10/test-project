import {
  Component,
  OnInit,
  Input,
  ViewChild,
  ElementRef,
  Output,
  EventEmitter,
  Inject,
  Optional
} from "@angular/core";
import { TimezoneService } from "@dewdrops/services";
import { TranslateService } from "ng2-translate";

@Component({
  selector: "dew-date-filter",
  templateUrl: "./date-filter.component.html",
  styleUrls: ["./date-filter.component.scss"]
})
export class DateFilterComponent implements OnInit {
  isDateApplied: boolean;
  date: number;
  dateWithin: number;
  period: number;
  today = new Date();
  day: Date;
  startDate: Date;
  endDate: Date;
  optionLastWeek: boolean;
  optionLastMonth: boolean;
  optionLastSixMonth: boolean;
  radioOptions = [
    {
      value: "",
      label: this._language.instant("DEWDROPS_DOCUMENT_DATE")
    }
  ];
  radioOptions1 = [
    {
      value: "",
      label: this._language.instant("DEWDROPS_DOCUMENT_DATE_WITHIN")
    }
  ];
  radioOptions2 = [
    {
      value: "",
      label: this._language.instant("DEWDROPS_LBL_PERIOD")
    }
  ];

  @Input()
  applier = true;

  @Input()
  name: string;

  @ViewChild("date1") radio1: ElementRef;
  @ViewChild("date2") radio2: ElementRef;
  @ViewChild("date3") radio3: ElementRef;
  /**
   * Emit action when date input value changed
   */
  @Output() whenDate = new EventEmitter();

  @Output()
  whenApplied = new EventEmitter();

  constructor(
    @Inject("FILTER_PIPE_LINE")
    @Optional()
    private _filterPipeLine: any,
    private tez: TimezoneService,
    private _language: TranslateService
  ) {
    this.isDateApplied = false;
    this.date = 0;
    this.dateWithin = 0;
    this.period = 0;
    this.day = null;
    this.startDate = null;
    this.endDate = null;
    this.optionLastWeek = false;
    this.optionLastMonth = false;
    this.optionLastSixMonth = false;
  }

  ngOnInit() {
    this._filterPipeLine.resetFiltersSub.subscribe((state: boolean) => {
      if (state) {
        this.resetFilter();
      }
    });
  }

  applyLastWeek() {
    this.dateWithin = 2;
    this.optionLastWeek = true;
    this.optionLastMonth = false;
    this.optionLastSixMonth = false;
    this.radio1.nativeElement.checked = true;
    this.radio1.nativeElement.checked = false;
    this.radio3.nativeElement.checked = false;
  }

  applyLastMonth() {
    this.dateWithin = 2;
    this.optionLastWeek = false;
    this.optionLastMonth = true;
    this.optionLastSixMonth = false;
    this.radio1.nativeElement.checked = true;
    this.radio1.nativeElement.checked = false;
    this.radio3.nativeElement.checked = false;
  }

  applyLastSixMonth() {
    this.dateWithin = 2;
    this.optionLastWeek = false;
    this.optionLastMonth = false;
    this.optionLastSixMonth = true;
    this.radio1.nativeElement.checked = true;
    this.radio1.nativeElement.checked = false;
    this.radio3.nativeElement.checked = false;
  }

  activateDateOption() {
    this.date = 1;
    this.dateWithin = 0;
    this.period = 0;
  }

  activatePeriodOption() {
    this.period = 3;
    this.date = 0;
    this.dateWithin = 0;
  }
  /**
   * Apply Document Date Filter
   * @param searchValue
   */
  applyDateFilter(updateBuffer?: boolean) {
    this.isDateApplied = true;

    if (this.date) {
      if (this.day) {
        let fromDate = this.tez.convertDateToTimestamp(
          this.tez.parseStartDate(this.day)
        );
        let toDate = this.tez.convertDateToTimestamp(
          this.tez.parseEndDate(this.day)
        );
        let selectedDate = [fromDate, toDate];
        this._filterPipeLine.put(this.name, selectedDate);
        if (!updateBuffer) {
          this._filterPipeLine.apply();
          this.whenApplied.emit();
        }
      }
    }

    if (this.period) {
      if (this.startDate && this.endDate) {
        let fromDate = this.tez.convertDateToTimestamp(
          this.tez.parseStartDate(this.startDate)
        );
        let toDate = this.tez.convertDateToTimestamp(
          this.tez.parseEndDate(this.endDate)
        );
        let selectedDate = [fromDate, toDate];
        this._filterPipeLine.put(this.name, selectedDate);
        if (!updateBuffer) {
          this._filterPipeLine.apply();
          this.whenApplied.emit();
        }
      }
      if (this.startDate && !this.endDate) {
        let fromDate = this.tez.convertDateToTimestamp(
          this.tez.parseStartDate(this.startDate)
        );
        let toDate = 33099614466859;
        let selectedDate = [fromDate, toDate];
        this._filterPipeLine.put(this.name, selectedDate);
        if (!updateBuffer) {
          this._filterPipeLine.apply();
          this.whenApplied.emit();
        }
      }
      if (!this.startDate && this.endDate) {
        let fromDate = -24754863472934;
        let toDate = this.tez.convertDateToTimestamp(
          this.tez.parseEndDate(this.endDate)
        );
        let selectedDate = [fromDate, toDate];
        this._filterPipeLine.put(this.name, selectedDate);
        if (!updateBuffer) {
          this._filterPipeLine.apply();
          this.whenApplied.emit();
        }
      }
    }

    if (this.dateWithin && this.optionLastWeek) {
      let date1 = this.tez.getCurrentUserPrefDate();
      let fromDate = this.tez.convertDateToTimestamp(
        this.tez.parseStartDate(this.tez.subtractFromDate(date1, 7, "days"))
      );
      let toDate = this.tez.convertDateToTimestamp(
        this.tez.parseEndDate(date1)
      );
      let selectedDate = [fromDate, toDate];
      this._filterPipeLine.put(this.name, selectedDate);
      if (!updateBuffer) {
        this._filterPipeLine.apply();
        this.whenApplied.emit();
      }
    }

    if (this.dateWithin && this.optionLastMonth) {
      let date1 = this.tez.getCurrentUserPrefDate();
      let fromDate = this.tez.convertDateToTimestamp(
        this.tez.parseStartDate(this.tez.subtractFromDate(date1, 1, "month"))
      );
      let toDate = this.tez.convertDateToTimestamp(
        this.tez.parseEndDate(date1)
      );
      let selectedDate = [fromDate, toDate];
      this._filterPipeLine.put(this.name, selectedDate);
      if (!updateBuffer) {
        this._filterPipeLine.apply();
        this.whenApplied.emit();
      }
    }

    if (this.dateWithin && this.optionLastSixMonth) {
      let date1 = this.tez.getCurrentUserPrefDate();
      let fromDate = this.tez.convertDateToTimestamp(
        this.tez.parseStartDate(this.tez.subtractFromDate(date1, 6, "month"))
      );
      let toDate = this.tez.convertDateToTimestamp(
        this.tez.parseEndDate(date1)
      );
      let selectedDate = [fromDate, toDate];
      this._filterPipeLine.put(this.name, selectedDate);
      if (!updateBuffer) {
        this._filterPipeLine.apply();
      }
    }

    if (!updateBuffer) {
      this.whenApplied.emit();
    }
  }
  /**
   * Clear Filter
   * @param Value
   */
  clearDateFilter(Value) {
    this.resetFilter();
    this._filterPipeLine.put(this.name, []);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  resetFilter() {
    this.isDateApplied = false;
    this.radio1.nativeElement.checked = false;
    this.radio2.nativeElement.checked = false;
    this.radio3.nativeElement.checked = false;
    this.day = null;
    this.startDate = null;
    this.endDate = null;
  }

  updateSelections() {
    this.applyDateFilter(true);
  }

}
