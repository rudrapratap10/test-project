// dependency imports
import {
  Component,
  OnInit,
  Inject,
  Input,
  ViewChild,
  ElementRef,
  Output,
  EventEmitter,
  ViewContainerRef,
  ChangeDetectorRef,
  AfterContentInit
} from "@angular/core";
import { Observable } from 'rxjs/Observable';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { map } from "rxjs/operators";
// services imports
import { clone } from 'lodash/index';
// import { ViewInvoicesService } from '@einvoice/services/view-invoices.service';
import { TranslateService } from "ng2-translate";
// import { DocumentViewService } from '@einvoice/services/document-view.service.ts';
import { UserService } from "@dewdrops/services";
import { APIClientService } from "@dewdrops/services";
import { AutocompleteComponent } from "dd-common/dewdrops/core/bootstrap/autocomplete/autocomplete/autocomplete.component";
import { CommonOverlayBuilder } from "../overlay/overlay-builder.service";
import { AutoCompleteTriggerDirective } from "dd-common/dewdrops/core/bootstrap/autocomplete/autocomplete.trigger.directive";
import { checkWarningMsg } from '../utility/check-warning-msg.utility';

// component imports
@Component({
  selector: "dew-supplier-info",
  templateUrl: "./supplier-info.component.html",
  styleUrls: ["./supplier-info.component.scss"]
})
export class DewSupplierInfoComponent implements OnInit {

  @Input() suppliarBaseurl: string;
  locationCode: string;
  @Input() supplierForm: FormGroup;
  @Input() warnings: any[] = [];
  @Input() errors: any[] = [];
  
  @Output() getsupplierData = new EventEmitter();
  @Output() inValid = new EventEmitter<boolean>();
  @ViewChild("ac2")
  acSupplier: AutocompleteComponent;

  
  @ViewChild("ac33")
  acAdd: AutocompleteComponent;
  //ac21
  @ViewChild("ac21")
  aCurency: AutocompleteComponent;
  //ac211
  @ViewChild("ac211")
  aContact: AutocompleteComponent;
  
  
  @ViewChild("dropDownAdd")
  suppliarAddressDropDown:  AutoCompleteTriggerDirective;
  // dropDownREadd
  @ViewChild("dropDownREadd")
  suppliarREaddressDropDown:  AutoCompleteTriggerDirective;


  
  @ViewChild("suppliarAddress")
  suppliarAddress: ElementRef;
  @ViewChild("suppliarRemitAddress")
  suppliarRemitAddress: ElementRef;  

  public checkWarningMsg = checkWarningMsg;
  creditDays : number
  address : string;
  searchText: string;
  toggle: boolean;
  supplierCount: number;
  supplierAddress = [];
  supplierId: any;
  supplierData : any;
  cmdBaseUrl = "/api/a/cmd";
  addressId: any;
  supplierFilterList = [];
  addressFilterList = false;
  remitFilterList = false;
  currencyFilterList = false;
  currencyLoader = false;
  oldCurrency : string;
  paymentFilterList = false;
  contactFilterList = false;
  isScroll = false;
  loader = false;
  contactLoader = false;
  inputField = "";
  userId = "";
  paymentTerms = ''
  currency = ''
  erpId = ''
  cutRefNum = ''
  showErp : boolean;
  showISTax : boolean;
  showABN : boolean;
  supplierBody = {
    perPageRecords: 200,
    pageNo: 1,
    criteriaGroup: {
      logicalOperator: "AND",
      criteria: [
        {
          fieldName: "SEARCH_BY_NAME",
          operation: "EQUALS",
          value: ""
        },
        {
          fieldName: "SEARCH_BY_ACTIVE_ONHOLD_SUPPLIERS",
          operation: "EQUALS",
          value: "true"
        }
      ]
    }
  };
  openPopupFlag: number = -1;
  currencyBody = {
    code:'',
    perPageRecords: 70,
    pageNo: 1
  };
  paymentBody = {
    name: "",
    code: "",
    perPageRecords: 200,
    pageNo: 1
  };
  contactBody = {
    addressId: this.addressId, //this value will come after selecting address
    referConfig: false
  };
  reactiveValue: FormControl;
  addressData = [] as any[];
  currencyData = [] as any[];
  contactData = [] as any[];
  paymentList = [] as any[];
  supplierName : ''
  formatData: string;
  showAdd : boolean = true;
  contact: string;
  suppAddress: string;
  
  constructor(
    private apiClient: APIClientService,
    private _userService: UserService,
    private overlayBuilder: CommonOverlayBuilder,
    private viewContainer: ViewContainerRef
  ) {}

  ngOnInit() {
    
    this.getEinvoiceAppConfig().subscribe((res)=>
    {
      this.showErp = res.data.EPROC_INVOICE_SHOW_ERP_ID;    
    });
    
    this.supplierName =this.supplierForm.controls.supplierName.value;
    this.currency = this.supplierForm.controls.currency.value;
    this.contact = this.supplierForm.controls.contact.value;
    this.reactiveValue = new FormControl(null);
    this.userId = this._userService.details["userId"];
    this.suppAddress = this.supplierForm.controls.address.value;
    const url = `/api/a/eproc/users/${this.userId}/getBuyingUnit`;
    this.apiClient.read(url).subscribe(res => {
      this.locationCode = res.data.location.code;
      this.getSupplierSpecificPaymentTerm();
    });
    if (this.supplierForm.controls.supplierId.value) {
      this.supplierId = this.supplierForm.controls.supplierId.value;
      this.triggerAddressInputs();
      
    }
    
  }
 

  
  preSelectPaymentTerm()
  {

  }

  //for auto suggest
  suggestionStreamFactoryFn() {
   
    return (query: string) => {
      if (!query) {
        this.getsupplierData.emit(this.supplierData);
      }
      this.supplierFilterList = []
      this.loader  =true
      this.supplierBody.criteriaGroup.criteria[0].value = query;
      const url = this.suppliarBaseurl + "/list";
      return this.apiClient.create(url, this.supplierBody).pipe(
        map((response: any) => {
          this.loader = false
          if(response.data.records)
          {
            this.supplierFilterList = []
            this.supplierFilterList = response.data.records.slice();
            return this.supplierFilterList;
          }else{
            this.supplierFilterList = []
            return this.supplierFilterList;
          }
        })
      );
    };
  }

  displayFn() {
    return (data: any) => data.name;
  }
  
  getModelBody(event) {
    this.supplierId = event.supplierId;
    //this.getSupplierSpecificPaymentTerm();
    const url = `/api/a/einvoice/suppliers/paymentTerm`;
    const body = {
      supplierId :this.supplierId,
      locationCode : this.locationCode
    };
    this.apiClient.list(url, body).subscribe((res)=>{
      
      this.paymentTerms = res.data.paymentTerm
      this.creditDays = res.data.creditDays
      this.currency = res.data.currency
      this.cutRefNum = res.data.customerId
      this.oldCurrency = this.currency;
      this.supplierData = {
        supplierId : this.supplierId,
        creditDays : this.creditDays,
        currency : this.currency,
        discountDays : res.data.daysAvailDiscount,
        rate : res.data.rate,
      }
      this.getsupplierData.emit(this.supplierData);
      this.supplierForm.controls.paymentTerms.setValue(this.paymentTerms);
      this.supplierForm.controls.paymentTerms.updateValueAndValidity();
      this.supplierForm.controls.currency.setValue(this.currency);
      this.supplierForm.controls.currency.updateValueAndValidity();
    });
    
    
    this.erpId = event.erpId
    if(event.customObj.ABNNUMBER)
    {
      this.showABN = true;
      this.supplierForm.controls.abnNumber.setValue(event.customObj.ABNNUMBER)
    }
    if(event.customObj.TAXEXAMPT)
    {
      this.showISTax = true;
      this.supplierForm.controls.isTaxExempt.setValue(event.customObj.TAXEXAMPT)
    }
    this.triggerAddressInputs();
  }

  triggerAddressInputs() {
  setTimeout(
    function() {
      this.suppliarAddress.nativeElement.focus();
      this.suppliarRemitAddress.nativeElement.focus();
    }.bind(this),
    0
  );
  }

  
  modelFnFactory() {
    return (data: any) => {
      return {
        erpId: data.erpId,
        name: data.name,
        supplierId: data.supplierId,
        customObj : data.customObjects
      };
    };
  }

  //for address

  suggestionStreamFactoryFnForAddress() {
    return (query: string) => {
      return this.apiClient
        .read(this.suppliarBaseurl + `/${this.supplierId}/addressDetails`)
        .pipe(
          map((data: any) => {
            
            this.addressData = data.data.records;
            if(this.addressData.length === 1)
            {
              this.acAdd.select( 
                {
                  addressId: this.addressData[0].addressId,
                  addressAccountGroupId: this.addressData[0].addressAccountGroupId,
                  name: this.addressData[0].name,
                  street1: this.addressData[0].street1,
                  street2: this.addressData[0].street2,
                  street3: this.addressData[0].street3,
                  country: this.addressData[0].country,
                  city: this.addressData[0].city,
                  state: this.addressData[0].state,
                  zip: this.addressData[0].zip,
                  poBox: this.addressData[0].poBox,
                  phone: this.addressData[0].phone,
                  fax: this.addressData[0].fax,
                  headQuarter: this.addressData[0].headQuarter,
                  order: this.addressData[0].order,
                  remitt: this.addressData[0].remit
                },
                0
              );
             
             this.supplierForm.controls.address.disable();
             this.suppliarREaddressDropDown.close();
             this.supplierForm.controls.remitAddress.disable();             
            }
            else
            {
              return()=>{
                
                return this.addressData;                
              }   
            }
            
          })
        );
    };
  }

  displayAddress() {
    return (data: any) =>  data.street1 +  ' ' + (data.addressAccountGroupId ? ('[' + data.addressAccountGroupId + ']' + '\n') : '\n')
    + (data.street2 ? (data.street2 + ',\n')  : '')
    + ( data.street3 ? (data.street3 + ',\n')  : '' )  +
     ( data.city 	 ? (data.city 	+ ',') 	 : '' ) 	 +
    (data.state   ? (data.state 	+ ',\n')  : '') 	  +
     ( data.zip   	 ? (data.zip 	+ ',') 	 : '') 		  +
    ( data.country ? (data.country + ',') 	 : '')	 +  (data.phone ? data.phone : '')
  }


  modelFnFactoryForAddredd() {
    return (data: any) => {
    
    
      
        this.formatData =   data.street1 +  ' ' + (data.addressAccountGroupId ? ('[' + data.addressAccountGroupId + ']' + '\n') : '\n')
      + (data.street2 ? (data.street2 + ',\n')  : '')
      + ( data.street3 ? (data.street3 + ',\n')  : '' )  +
       ( data.city 	 ? (data.city 	+ ',') 	 : '' ) 	 +
      (data.state   ? (data.state 	+ ',\n')  : '') 	  +
       ( data.zip   	 ? (data.zip 	+ ',') 	 : '') 		  +
      ( data.country ? (data.country + ',') 	 : '')	 +  (data.phone ? data.phone : '');
      
        
    
      return {
        addressId: data.addressId,
        addressAccountGroupId: data.addressAccountGroupId,
        name: data.name,
        street1: data.street1,
        street2: data.street2,
        street3: data.street3,
        country: data.country,
        city: data.city,
        state: data.state,
        zip: data.zip,
        poBox: data.poBox,
        phone: data.phone,
        fax: data.fax,
        headQuarter: data.headQuarter,
        order: data.order,
        remitt: data.remit
      };
    };
  }
  getSelectedAddressBody(event) {
    if(event.addressId)
    {
      this.addressId = event.addressId;
      
    }    
  }

  //for remit address
  displayRemitAddress() {
    return (data: any) =>  data.street1 +  ' ' + (data.addressAccountGroupId ? ('[' + data.addressAccountGroupId + ']' + '\n') : '\n')
    + (data.street2 ? (data.street2 + ',\n')  : '')
    + ( data.street3 ? (data.street3 + ',\n')  : '' )  +
     ( data.city 	 ? (data.city 	+ ',') 	 : '' ) 	 +
    (data.state   ? (data.state 	+ ',\n')  : '') 	  +
     ( data.zip   	 ? (data.zip 	+ ',') 	 : '') 		  +
    ( data.country ? (data.country + ',') 	 : '')	 +  (data.phone ? data.phone : '')
  }
  getSelectedRemitAddressBody(event) {
  }
  modelFnFactoryForRemitAddredd() {
    return (data: any) => {
      return {
        addressId: data.addressId
      };
    };
  }
  //for currency list
  suggestionStreamFactoryFnFoCurrency() {
   
    return (query: string) => {
      this.currencyData = []
      this.currencyLoader = true
      this.currencyBody.code = query
      const urlCurr = this.cmdBaseUrl + "/currencies/list";
      return this.apiClient.list(urlCurr, this.currencyBody).pipe(
        map((response: any) => {
          this.currencyLoader = false
          if(response.data.records)
          {
            this.currencyData = response.data.records;
            return this.currencyData;
          }
          else
          {
            this.currencyData =[];
            return this.currencyData;
          }
        })
      );
    };
  }
  getSelectedCurrency(event) {
    this.oldCurrency = clone(this.currency);
    this.overlayBuilder.confirm(this.viewContainer)({
      confirmTxt: 'Changing the Supplier Currency will overwrite the existing currency. This might cause a change in all the amounts in the document. Do you want to Change or Keep the existing currency?',
      confirmBtnLabel: 'OK',
      rejectBtnLabel: 'Cancel',
      confirmFn: () => {        
        this.currency = event.code;        
      },
      rejectFn: () => {
        this.supplierForm.controls.currency.setValue(this.oldCurrency); 
      }
    });
  }
  modelFnFactoryForCurrency() {
    return (data: any) => {
      return {
        code: data.code,
        name: data.name
      };
    };
  }
  displaycurrency() {
    
    return (data: any) => {
      if (data.code !== this.currency) {
        return this.currency;
      }
      return data ? data.code : null;
    };
    
  }
  

  //for supplier contact

  displaySupplierContact() {
    return (data: any) => data.firstName + " " + data.lastName;
  }
  modelFnFactoryForSupplierContact() {
    return (data: any) => {
      return {
        firstName: data.firstName,
        lastName: data.lastName
      };
    };
  }
  suggestionStreamFactoryFnForSupplierContact() {
    
    return (query: string) => {      
      this.contactData = []
      this.contactLoader = true
      const urlSupCon =
        this.suppliarBaseurl + `/${this.supplierId}/getContactDetails`;
      const supplierContactBody = {
        addressId: this.addressId,
        referConfig: false
      };
      return this.apiClient.create(urlSupCon, supplierContactBody).pipe(
        map((response: any) => {
          this.contactData = []
          this.contactLoader = false;
          if(response.data.records)
          {
            this.contactData = response.data.records;
            return this.contactData;
          }
          else
          {
            this.contactData = [];
            return this.contactData;
          }
        })
      );
    };
  }
  getModelBodyForContact(event) {
  }


  //for payment terms


  getSupplierSpecificPaymentTerm()
  {
    
    const url = `/api/a/einvoice/suppliers/paymentTerm`;
    const body = {
      supplierId :this.supplierId,
      locationCode : this.locationCode
    };
    this.apiClient.list(url, body).subscribe((res)=>{
      
      this.paymentTerms = res.data.paymentTerm
      this.creditDays = res.data.creditDays
      this.currency = res.data.currency
      this.cutRefNum = res.data.customerId
      this.supplierForm.controls.paymentTerms.setValue(this.paymentTerms);
      this.supplierForm.controls.paymentTerms.updateValueAndValidity();
      this.supplierForm.controls.currency.setValue(this.currency);
      this.supplierForm.controls.currency.updateValueAndValidity();
    });
  }

  displaySupplierPaymentTerms() {
    return (data: any) => data.code;
  }
  modelFnFactoryForPaymentTerms() {

    return (data: any) => {
      return {
        code : data.code,
        creditDays : data.creditDays,
        discountDays : data.daysAvailDiscount,
        percentDiscount : data.percentDiscount
      };
    };
  }
  suggestionStreamFactoryFnForSupplierPayment() {
    return (query: string) => {

        const body = {
            "perPageRecords": 20,
            "pageNo": 1
        }
        const url = '/api/a/cmd/paymentterms/list';
        return this.apiClient.list(url,body).pipe(
          map((response: any) => {
            this.paymentList = response.data.records;
            return this.paymentList;
          })
        );;
    };
  }
  getModelBodyForPayment(event) {
    
  }
  onPaymntTermChange(event){
    if(event.target.value === "") {
      this.supplierForm.patchValue({
        paymentTerms: null,
      });
      this.supplierForm.controls.paymentTerms.updateValueAndValidity();
    }
  }
  getEinvoiceAppConfig(): Observable<any> {
    const url = '/api/a/einvoice/configs/getInvoiceConfig';
    const body = {
      configKeys: [
        'EPROC_INVOICE_SHOW_ERP_ID',
      ]
    };
    return this.apiClient.list(url, body);
}
getData(event)
  {
    if(event.target.value === '')
    {
      this.inValid.emit(true);
      this.erpId = '';
      this.addressData = []
      this.supplierId = '';
      this.formatData = null;
      this.showAdd = true;
      this.currency='';
      this.showABN =false;
      this.showISTax = false;
      this.contact = '';
      this.paymentTerms = '';
      this.aContact.select({firstName :'',lastName : ''},0)
     // this.aCurency.select({code : ''},0)
      this.acAdd.select(
        {
          addressId: '',
        addressAccountGroupId: '',
        name: '',
        street1: '',
        street2: '',
        street3:'',
        country: '',
        city:'',
        state: '',
        zip: '',
        poBox:'',
        phone: '',
        fax:'',
        headQuarter: '',
        order: '',
        remitt: ''
        },
        0
      );
      this.supplierForm.controls.address.enable();
      this.supplierForm.controls.remitAddress.enable(); 
    }
  }
  onCurrencyChange(event) {
    if(event.target.value === ""){
      this.supplierForm.patchValue({
        currency: null
      });
      this.supplierForm.controls.currency.updateValueAndValidity();
    }
  }

}
