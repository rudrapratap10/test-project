import { Injectable } from '@angular/core';
import { APIClientService } from '@dewdrops/services';

const cmdURL = 'cmd';

@Injectable()
export class TaxService {

    constructor(private _apiClient: APIClientService) {

    }

    getTaxTypes(name) {
        const params = {
            "name": name,
            "perPageRecords": 10,
            "pageNo": 1
        };
        const url = `/api/a/${cmdURL}/taxes/getTypes`;
        return this._apiClient.list(url, params);
    }

    getTaxNameAndRate(taxReqObj) {
        const url = `/api/a/${cmdURL}/taxes/list`;
        return this._apiClient.list(url, taxReqObj);
    }
    getCurrencyPrecision(decimalPrecision){
        const url = `/api/a/${cmdURL}/currencies/list`;
        return this._apiClient.list(url, decimalPrecision)
    }

}
