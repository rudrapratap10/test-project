export enum TaxSetupMode {
    VIEW = 'VIEW',
    EDIT = 'EDIT'
}

export enum TaxType {
    GENERAL = 'GENERAL',
    FREIGHT = 'FREIGHT',
    COMPOUND = 'COMPOUND'
}