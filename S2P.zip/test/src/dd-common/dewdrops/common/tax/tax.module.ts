/**
 * @module TaxModule
 *
 * @description This module defines services for managing overlays, dialogs etc as
 * dynamic components.
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UtilitiesModule } from '@dewdrops/core/utilities';
import { TranslateModule } from 'ng2-translate';
import { GlobalUIModule } from '../../core/bootstrap/global-ui.module';
import { UtilityModule } from '../utility/utility.module';
import { TaxFooterComponent } from './tax-footer/tax-footer.component';
import { TaxHeaderComponent } from './tax-header/tax-header.component';
import { TaxInputComponent } from './tax-input/tax-input.component';
import { TaxComponent } from './tax.component';
import { TaxService } from './tax.service';

const declarationsArray = [
  TaxInputComponent,
  TaxComponent,
  TaxHeaderComponent,
  TaxFooterComponent,
];

@NgModule({
  imports: [CommonModule,
            GlobalUIModule,
            TranslateModule,
            FormsModule,
            UtilityModule,
            UtilitiesModule,
            ReactiveFormsModule],
  declarations: declarationsArray,
  providers: [
    TaxService
  ],
  exports: declarationsArray,
  entryComponents: [
  ]
})
export class TaxModule {

}
