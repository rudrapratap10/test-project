import {
    Component,
    Input,
    OnInit, Output
} from '@angular/core';
import { EventEmitter } from '@angular/core';
import {
    AbstractControl,
    ControlContainer,
    FormArray,
    FormBuilder,
    FormControl,
    FormControlName,
    FormGroup,
    FormGroupDirective,
    FormGroupName,
    FormsModule,
    ReactiveFormsModule,
    ValidatorFn,
    Validators
} from '@angular/forms';
import { FormatCurrency } from '@dewdrops/core/utilities';
import { CurrencyFormat } from '@dewdrops/services';
import { LanguageTranslateService } from '@dewdrops/services';
import { find } from 'lodash/index';
import { map } from 'rxjs/operators';
import { checkWarningMsg } from '../utility/check-warning-msg.utility';
import { TaxSetupMode, TaxType } from './constants';
import { Tax } from './tax';
import { TaxService } from './tax.service';
@Component({
    selector: 'dew-tax',
    templateUrl: './tax.component.html',
    styleUrls: ['./tax.component.scss']
})
export class TaxComponent implements OnInit {

    // Specifies mode eg view  or edit
    @Input() mode: string = TaxSetupMode.VIEW;
    @Input() taxType = TaxType.GENERAL;
    // ISO Currency code from CMD, can be null, default null
    @Input() currency: any = null;
    // Entity amount
    @Input() amount = 0;
    @Input() discount = 0;
    @Input() localizationLabels = {
        GRID_TAX_TYPE_LABEL: 'DEWDROPS_TAX_TAX_TYPE_LABEL',
        GRID_TAX_NAME_LABEL: 'DEWDROPS_TAX_TAX_NAME_LABEL',
        GRID_TAX_RATE_LABEL: 'DEWDROPS_TAX_RATE_LABEL',
        GRID_TAX_AMOUNT_LABEL: 'DEWDROPS_TAX_AMOUNT_LABEL',
        GRID_TAX_ITEMSUBTOTAL_LABEL: 'DEWDROPS_ITEM_SUBTOTAL_LABEL',
        TAX_ON_TEXT_LABEL: 'DEWDROPS_TAX_ON_TEXT',
        ERR_PLEASE_ENTER_VALID_TAX_RATE: 'ERR_PLEASE_ENTER_VALID_TAX_RATE'
    };
    // List of taxes applicable on an item
    @Input() set taxes(value: any) {
        if (value) {
            this.taxCollection = [];
            this.taxCollection = value;
            this.fillTaxValidations();
            // in edit mode add a disabled tax row
            if (this.mode === TaxSetupMode.EDIT && this.taxCollection && this.taxCollection.length === 0) {
                this.addTaxRow();
            }
            if (this.taxType === TaxType.COMPOUND) {
                this.calculateTaxAmountForAllTaxesIfCompound();
            } else {
                this.calculateTaxAmountForAllTaxes();
            }
        }
    }
    // move to icon
    public addIcon = '/assets/images/common/add-row.svg';
    // Whether to show tax grid
    @Input() showTaxGrid = true;

    @Input() showFooter = false;

    @Input() showCheckBox = false;

    @Input() taxableAmountTitle: string;

    @Input() applyTaxOnAllLine = false;

    @Input() isAllowNegetiveTax = false;

    @Input() warnings: any[] = [];

    @Input() errors: any[] = [];

    @Output() taxChange = new EventEmitter();

    @Output() emitBorneByBuyerTax = new EventEmitter();

    public checkWarningMsg = checkWarningMsg;
    public taxTypes: any;
    public taxNames: any;
    public taxCollection: Array<Tax>;
    public taxDetail: Array<any>;
    public taxSetupModes = TaxSetupMode;
    public scale = 6;
    taxesFormGroup: FormGroup;
    public taxesForm: FormArray;
    public isTaxNameValid = true;
    validationError = false;
    private taxNameFoucs = [];

    constructor(public taxService: TaxService,
        private _currencyFormat: CurrencyFormat,
        private formBuilder: FormBuilder
        // private _callerForm: FormGroupDirective
    ) {
        this.taxesFormGroup = this.formBuilder.group({
            taxesForm: this.formBuilder.array([])
        });
    }

    ngOnInit() {

        if (this.currency) {
            const currencyFormatInfo = this._currencyFormat.getFormat(this.currency);
            try {
                this.scale = currencyFormatInfo.scale;
            } catch {

            }
        }

        if (!this.amount) {
            this.amount = 0;
        }        
    }

    updateTheTaxAndEmit(event: any, tax: Tax) {
        tax.borneByBuyerCheck = event.target.checked;
        this.emitChange();
    }

    emitChange() {
        // Return only valid tax rows
        const filteredTaxCollection = this.taxCollection.filter((tax) => {
            if (tax.type !== null && tax.type !== undefined && tax.type !== '') {
                return true;
            } else {
                return false;
            }
        });
        this.taxChange.emit((filteredTaxCollection) as any);
    }

    // Fills tax validation array which holds all the form groups
    fillTaxValidations() {
        try {
            for (let index = 0; index < this.taxCollection.length; index++) {
                const tax = this.taxCollection[index];
                const validationRow = this.formBuilder.group({
                    type: [{ value: tax.type }],
                    name: [{ value: tax.name, disabled: true }, Validators.required],
                    rate: [{ value: tax.rate }],
                    borneTax: [{value: tax.borneByBuyerCheck}]
                });
                if (this.taxesFormGroup) {
                    this.taxesForm = this.taxesFormGroup.get('taxesForm') as FormArray;
                    this.taxesForm.push(validationRow);
                }
                this.setTaxValidations(index);
            }
        } catch { }
    }

    createValidationRow(): FormGroup {
        return this.formBuilder.group({
            type: [{ value: '' }],
            name: [{ value: '', disabled: true }, Validators.required],
            rate: [{ value: '', disabled: true }],
            borneTax: [{value: false, disabled: true}]
        });
    }

    addValidationRow() {
        if (this.taxesFormGroup) {
            this.taxesForm = this.taxesFormGroup.get('taxesForm') as FormArray;
            this.taxesForm.push(this.createValidationRow());
        }
    }

    // Emitter event from tax-input component
    updateTaxSelection(event: Tax, index) {
        try {
            this.taxCollection[index].type = event.type;
            this.taxCollection[index].name = event.name;
            this.setTaxRate(this.taxCollection[index],this.taxCollection[index].rate);
            if(event.type === '') {
                this.clearRowOnTaxTypeChange(index);
            }
            this.calculateTaxAmount(this.taxCollection[index]);
            this.setTaxValidations(index);
            this.emitChange();
        } catch { }
    }

    addTaxRow() {
        const tax = new Tax();
        if (this.taxType === TaxType.COMPOUND) {
            tax.taxableAmount = this.amount + this.calculateTaxSum();
        } else {
            tax.taxableAmount = (this.taxType ===  TaxType.GENERAL) ? ((+this.amount) - (+this.discount)) : +this.amount;
        }
        this.taxCollection.push(tax);
        this.addValidationRow();
    }
    updateTextRows() {
        if (this.taxCollection) {
        this.taxCollection.forEach((tax, index) => {
            tax.taxableAmount = 0;
            this.setTaxValidations(index);
            if (this.taxType === TaxType.COMPOUND) {
                tax.taxableAmount = this.amount + this.calculateTaxSum();
                this.calculateTaxAmount(tax);
            } else {
                tax.taxableAmount = (this.taxType === TaxType.FREIGHT) ? this.amount : (this.amount - this.discount);
            }
            if (this.taxType === TaxType.GENERAL && tax.rate) {
                    tax.taxAmount = (tax.rate * (this.amount - this.discount) / 100);
            }
            if (this.taxType === TaxType.FREIGHT && tax.rate) {
                    tax.taxAmount = (tax.rate * this.amount  / 100);
            }
        });
    }
    }

    setTaxValidations(index) {
        try {
            const chk = !this.hasTaxType(index);
            const action = chk ? 'disable' : 'enable';
            const taxArr = this.taxesFormGroup.get('taxesForm') as FormArray;
            const frmGrp = taxArr.controls[index]['controls'];
            Object.keys(frmGrp).forEach((field) => {
                if (field !== 'type') {
                    frmGrp[field][action]();
                    if (chk) {
                        frmGrp[field].clearValidators();
                        frmGrp[field].markAsUntouched();
                    } else {
                        frmGrp[field].setValidators([Validators.required]);
                    }
                    frmGrp[field].updateValueAndValidity();
                }
            });

        } catch {

        }
    }

    isValid(fieldName: string, index: number) {
        const taxArr = this.taxesFormGroup.get('taxesForm') as FormArray;
        const frmGrp = taxArr.controls[index]['controls'];
        return this.taxTypeAndNameUniquenessValidator(this.taxCollection, frmGrp, index);
    }

  

    deleteTaxRow(index) {
        this.taxCollection.splice(index, 1);
        this.taxesFormGroup.controls['taxesForm']['controls'].splice(index, 1);
        if (this.taxType === TaxType.COMPOUND) {
            this.updateTextRows();
        }
        this.emitChange();
    }

    clearRowOnTaxTypeChange(rowIndex) {
        this.taxCollection[rowIndex]['name'] = undefined;
        this.taxCollection[rowIndex]['rate'] = undefined;
        this.taxCollection[rowIndex]['taxAmount'] = undefined;

    }

    getFormGroupAt(index) {
        return this.taxesFormGroup.controls['taxesForm']['controls'][index] as FormGroup;
    }

    isGrpFieldValid(field: string, idx: number): boolean {
        try {
            return (!this.taxesFormGroup.controls['taxesForm']['controls'][idx]['controls'][field].valid) &&
                this.taxesFormGroup.controls['taxesForm']['controls'][idx]['controls'][field].touched;
        } catch {
            return false;
        }
    }

    setTaxType(tax, value) {
        tax.type = value;
        this.emitChange();
    }

    setTaxName(tax, value) {
        tax.name = value;
        this.emitChange();
    }

    setTaxRate(tax, value?) {
        if (value !== undefined && value !== null) {
            tax.rate = value;
        }
        this.emitChange();
    }

    setTaxAmount(tax, value?) {
        if (value !== undefined && value !== null && value !== '-') {
            tax.taxAmount = +value;
        }
        this.emitChange();
    }

    hasTaxType(index) {
        try {
            const tax = this.taxCollection[index];
            if (tax.type != null && tax.type !== undefined && tax.type !== '') {
                return true;
            } else {
                return false;
            }
        } catch {

        }
        return false;
    }

    calculateTaxRate(tax: Tax) {
        const totalPrice = tax.taxableAmount;
        if (tax.taxAmount) {
            tax.rate = +((+tax.taxAmount * 100) / (totalPrice));
        } else {
            tax.rate = 0;
        }
        this.emitChange();
    }

    calculateTaxAmount(tax: Tax) {
        const totalPrice = tax.taxableAmount;
        if (tax.rate !== undefined && tax.rate !== null) {
            tax.taxAmount = +((totalPrice / 100) * (+tax.rate)).toFixed(this.scale);
        } else {
            tax.taxAmount = undefined;
        }
        if(this.taxType === TaxType.COMPOUND) {
            this.calculateTaxAmountForAllTaxesIfCompound();

        }
        this.emitChange();
    }

    calculateTaxAmountForAllTaxes() {
        try {
            for (let tax of (this.taxCollection as Array<Tax>)) {
                const rate = tax.rate;
                if (tax.taxableAmount === null || tax.taxableAmount === undefined) {
                    tax.taxableAmount = +this.amount;
                }
                if (rate && tax.taxableAmount) {
                    tax.taxAmount = +(+rate * tax.taxableAmount / 100).toFixed(this.scale);
                }
            }
        } catch {

        }
        this.emitChange();
    }

    calculateTaxAmountForAllTaxesIfCompound() {
        try {
            let taxAmount = 0;
            for (let tax of (this.taxCollection as Array<Tax>)) {
                const rate = tax.rate;
                tax.taxableAmount = this.amount + taxAmount;
                if (rate && tax.taxableAmount) {
                    tax.taxAmount = +(rate * tax.taxableAmount / 100).toFixed(this.scale);
                    taxAmount = taxAmount + tax.taxAmount;
                }
            }
        } catch {

        }
        this.emitChange();
    }

    setTaxData() {
        try {
            let taxAmount = 0;
            for (let tax of (this.taxCollection as Array<Tax>)) {
                const rate = tax.rate;
                if (tax.taxableAmount === null || tax.taxableAmount === undefined) {
                    tax.taxableAmount = this.amount;
                    if (this.taxType === TaxType.COMPOUND) {
                        tax.taxableAmount = this.amount + taxAmount;
                    }
                }
                if (rate && this.amount) {
                    tax.taxAmount = (rate * tax.taxableAmount / 100);
                    taxAmount = taxAmount + tax.taxAmount;
                }
            }
        } catch {

        }
    }

    calculateTaxSum(): number {
        try {
            let taxAmount = 0;
            for (let tax of (this.taxCollection as Array<Tax>)) {
                const rate = tax.rate;
                if (rate && tax.taxableAmount) {
                    tax.taxAmount = (rate * tax.taxableAmount / 100);
                    taxAmount = taxAmount + tax.taxAmount;

                }
            }
            return taxAmount;
        } catch {
            return 0;
        }
    }

    taxTypeAndNameUniquenessValidator(taxes: Tax[], formGroup: FormGroup, index: number) {
        //const taxName = formGroup['name'].value;
        const taxType = formGroup['type'].value;
        let validationFailure = false;
        const taxName = taxes[index].name
        if (taxes && taxes.length) {
            for (let i = 0; i < taxes.length; i++) {
                if (index !== i && taxes[i].name === taxName && taxes[i].type === taxType){
                    validationFailure = true;
                    break;
                }
            }
        }   
      return validationFailure;
  }

      onTaxTypeSelectChanged(event, i){
        this.taxNameFoucs[i] = event;
      }

      getFocusNeededOnTaxName(i) {
          return this.taxNameFoucs[i];
      }
}


