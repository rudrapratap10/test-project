import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dew-tax-name',
  templateUrl: './tax-name.component.html',
  styleUrls: ['./tax-name.component.scss']
})
export class TaxNameComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
