import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaxNameComponent } from './tax-name.component';

describe('TaxNameComponent', () => {
  let component: TaxNameComponent;
  let fixture: ComponentFixture<TaxNameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaxNameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaxNameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
