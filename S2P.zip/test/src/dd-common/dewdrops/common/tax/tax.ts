/**
 * Defines the type for `Tax`
 */
export class Tax {

    type: string;
    name: string;
    rate: number;
    compound?: boolean;
    taxableAmount?: number;
    taxAmount?: number;
    alwaysApplicable?: boolean;
    isUseTaxType? : boolean;
    borneByBuyerCheck? = this.rate < 0 as boolean;
}
