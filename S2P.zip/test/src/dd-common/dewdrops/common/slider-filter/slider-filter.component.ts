import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  ElementRef,
  Inject,
  Optional
} from "@angular/core";

@Component({
  selector: "dew-slider-filter",
  templateUrl: "./slider-filter.component.html",
  styleUrls: ["./slider-filter.component.scss"]
})
export class SliderFilterComponent implements OnInit {
  constructor(
    @Inject("FILTER_PIPE_LINE")
    @Optional()
    private _filterPipeLine: any
  ) { }

  ngOnInit() {
    this.from = this.minScaleValue;
    this.to = this.maxScaleValue;
    this._filterPipeLine.resetFiltersSub.subscribe((state: boolean) => {
      if (state) {
        this.resetFilter();
      }
    });
  }

  @Input() withoutMinThumb: boolean = false;
  @Input() minScaleValue: number;
  @Input() maxScaleValue: number;
  @Input() minSliderPosition: number;
  @Input() maxSliderPosition: number;

  @Input()
  applier = true;

  @Input()
  name: string;

  @Output() currentMaxValue = new EventEmitter();
  @Output() currentMinValue = new EventEmitter();
  @Output()
  whenApplied: EventEmitter<any> = new EventEmitter<any>();

  @ViewChild("minText")
  minText: ElementRef;

  @ViewChild("maxText")
  maxText: ElementRef;

  from = this.minSliderPosition;
  to = this.maxSliderPosition;

  getSelectedRadio(event) {
    console.log(event);
  }

  clearAllRadio(event) {
    console.log(event);
  }
  changeMax(event) {
    this.to = event;
    this.maxSliderPosition = event;
    this.currentMaxValue.emit(event);
    if (this.withoutMinThumb) {
      this._filterPipeLine.put(this.name, event);
      this._filterPipeLine.apply();
      this.whenApplied.emit();
    }

  }
  changeMin(event) {
    this.from = event;
    this.minSliderPosition = event;
    this.currentMinValue.emit(event);
  }

  go() {
    if (
      this.from <= this.to &&
      this.to <= this.maxScaleValue &&
      this.from >= this.minScaleValue
    ) {
      this.minSliderPosition = +this.from;
      this.maxSliderPosition = +this.to;
      this.currentMaxValue.emit(this.maxSliderPosition);
      this.currentMinValue.emit(this.minSliderPosition);
      const values = {
        minValue: this.minScaleValue,
        maxValue: this.maxScaleValue
      };
      this._filterPipeLine.put(this.name, values);
      this._filterPipeLine.apply();
      this.whenApplied.emit();
    }
    this.to = +this.maxSliderPosition;
    this.from = +this.minSliderPosition;
  }

  minInputKey(event) {
  }

  clearSliderFilter() {
    if (this.withoutMinThumb) {
      this.maxSliderPosition = this.maxScaleValue;
    } else {
      const values = {
        minValue: 0,
        maxValue: 0
      };
      this.maxSliderPosition = this.maxScaleValue;
      this.minSliderPosition = this.minScaleValue;
      this.from = this.minScaleValue;
      this.to = this.maxScaleValue;
      this._filterPipeLine.put(this.name, values);
      this._filterPipeLine.apply();
      this.whenApplied.emit();
    }
  }

  resetFilter() {
    if (this.withoutMinThumb) {
      this.maxSliderPosition = this.maxScaleValue;
    } else {
      const values = {
        minValue: 0,
        maxValue: 0
      };
      this.maxSliderPosition = this.maxScaleValue;
      this.minSliderPosition = this.minScaleValue;
      this.from = this.minScaleValue;
      this.to = this.maxScaleValue;
    }
  }
}
