import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SliderFilterComponent } from './slider-filter.component';
import { RangeModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { FormsModule } from '@angular/forms';
import { NumericDirective } from '../utility/numericals/numeric.directive';
import { UtilityModule } from '../utility/utility.module';

@NgModule({
  imports: [
    CommonModule,
    GlobalUIModule,
    UtilityModule,
    RangeModule,    
    FormsModule
  ],
  declarations: [SliderFilterComponent],
  exports: [SliderFilterComponent]
  
})
export class SliderFilterModule { }
