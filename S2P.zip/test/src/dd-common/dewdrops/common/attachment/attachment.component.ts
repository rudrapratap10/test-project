import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { IAttachmentApiOptions } from './models/attachment-api-options.model';

@Component({
  selector: 'dew-attachment',
  templateUrl: './attachment.component.html',
  styleUrls: ['./attachment.component.scss']
})
export class AttachmentComponent implements OnInit {

  /**
   * @default add
   * @example 'view' or 'add'
   */
  @Input()
  mode = 'add';

  @Input() expandedViewToggle: boolean;

  @Input()
  uploadBtnLabel = 'Browse';

  @Input()
  uploadPlaceholder = 'Drop file here or browse file (format: xls, pdf, jpg etc.)';

  @Input() showAttachmentDetails: boolean;

  @Input()
  attachmentApiOptions: IAttachmentApiOptions;

  @Input()
  canAddDetails: boolean;

  @Input()
  attachmentList: string[];

  @Input()
  enableWebLink: boolean;
  @Input()
  fileCharactersLimit=50;

  @Output() viewModeChange = new EventEmitter<string>();
  @Input()
  maxUpload: string;

  @Input() maxFileSize: number = 10000;

  @Output()
  createAttachmentIds: EventEmitter<string[]> = new EventEmitter<string[]>();

  @Output()
  createAttachmentObjects: EventEmitter<any[]> = new EventEmitter<any[]>();

  @Input() allowFileTypes: string[];

  @Input() fullWidth: boolean ;
  constructor() { }

  ngOnInit() {
  }

}
