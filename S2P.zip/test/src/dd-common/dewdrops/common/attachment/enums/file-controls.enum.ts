export enum FileControls {
  ZOOM_IN = 1,
  ZOOM_OUT,
  ROTATE,
  EXPAND
}
