export enum Attachment {
  WEBLINK = 1,
  ATTACHMENT = 2
}
