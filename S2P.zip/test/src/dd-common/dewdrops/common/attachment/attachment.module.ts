import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AngularSplitModule } from 'angular-split';
import { AddAttachmentsModule } from './add-attachments/add-attachments.module';
import { AttachmentComponent } from './attachment.component';
import { ViewAttachmentsModule } from './view-attachments/view-attachments.module';

@NgModule({
  imports: [
    CommonModule,
    AngularSplitModule.forRoot(),
    AddAttachmentsModule,
    ViewAttachmentsModule
  ],
  declarations: [AttachmentComponent],
  exports: [AttachmentComponent]
})
export class AttachmentModule { }
