export class AttachmentModel {
  public id: string;
  public name: string;
  public size: number;
  public path: string;
  public type: any;
  public comments: string;
  public visibility: boolean;

  constructor(id, name, size, path, type, comments, visibility) {
    this.id = id;
    this.name = name;
    this.size = size;
    this.path = path;
    this.type = type;
    this.comments = comments;
    this.visibility = visibility;
  }
}
