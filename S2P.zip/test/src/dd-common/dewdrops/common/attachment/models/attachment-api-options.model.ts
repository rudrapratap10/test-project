import { HttpHeaders } from '@angular/common/http';

interface IUpdateorSaveAttachment {

  /**
   * url for uploading or updating attachment
   */
  url?: string;

  /**
   * type of http call
   * @example GET | POST
   */
  method?: string;

  /**
   * Need to be set if adding visibility and comments for an attachment
   *
   * (optional attribute)
   */
  data?: [{ attachmentId: '', visibility: '', comments: '' }];

  /**
   * set this if any additional headers need to be added for `update or upload attachment` api
   */
  httpHeaders?: HttpHeaders;

  bodyTransformFn?: ((transformBody: ITransformBody) =>  {url:string, body:any, httpHeaders:HttpHeaders, method:string} );
}

interface IDownloadAttachment {

  httpHeaders?: HttpHeaders;

  body?: any;

  /**
   * url for downloading attachment file
   */
  url?: string;
  bodyTransformFn?: ((transformBody: ITransformBody) =>  {url:string, body:any, httpHeaders:HttpHeaders} );
}

interface IDeleteAttachment {

  body?: any;

  method?: string

  /**
   * url for Delete attachment file
   */
  url?: string;

  /**
   * set this if any additional headers need to be added for `update or upload attachment` api
   */
  httpHeaders?: HttpHeaders;

  bodyTransformFn?: ((transformBody: ITransformBody) =>  {url:string, body:any, httpHeaders:HttpHeaders, method:string} );
}

interface IGetAttachmentDetailsById {

  /**
   * url for fetching attachment details by its id
   */
  url?: string;

  /**
   * type of http call
   * @example GET | POST
   */
  method?: string;

  httpHeaders?: HttpHeaders;

  body?: any;

  bodyTransformFn?: ((transformBody: ITransformBody) =>  {url:string, body:any, httpHeaders:HttpHeaders, method:string} );
}

interface IWeblink {

  /**
   * url for weblink
   */
  url?: string;

  /**
   * request body for weblink api
   */
  body?: any;

  httpHeaders?: HttpHeaders;

  bodyTransformFn?: ((transformBody: ITransformBody) =>  {url:string, body:any, httpHeaders:HttpHeaders} );
}

export interface IAttachmentApiOptions {

  /**
   * @type `IUpdateorSaveAttachment`
   *
   * config for uploading or updating an already uploaded attachment file
   */
  updateorSaveAttachment?: IUpdateorSaveAttachment;

  /**
   * @type `IDownloadAttachment`
   *
   * set this config if you want to configure attachment download
   */
  downloadAttachment?: IDownloadAttachment;

  /**
   * @type `IDeleteAttachment`
   *
   * set this config if you want to configure attachment delete
   */
  deleteAttachment?: IDeleteAttachment;

  /**
   * @type `IGetAttachmentDetailsById`
   *
   * config to fetch attachment details by attachment id
   */
  getAttachmentDetailsById?: IGetAttachmentDetailsById;

  /**
   * @type IWeblink
   *
   * config for weblink upload
   *
   * Add this config if `enableWeblink` property of AttachmentComponent is set to true
   */
  weblink?: IWeblink;

}

export interface ITransformBody {

  attachmentId?: string;
  name?: string;
  size?: any;
  path?: any;
  type?: any;

}