import { TranslateService } from 'ng2-translate';

export class AttachmentVisibilityOptions {

  public attachmentVisibilityInternal: string;
  public attachmentVisibilitySupplier: string;
  public attachmentLabelInternal: string;
  public attachmentLabelSupplier: string;
  public attachModal: boolean;

  constructor(private _translate: TranslateService) {
    this.getTranslations();
  }

  getTranslations() {
    this._translate.get('DEWDROPS_ATTACHMENT_VISIBILITY_INTERNAL').subscribe(
      (translatedValue: string) => {
        this.attachmentVisibilityInternal = translatedValue;
      });
    this._translate.get('DEWDROPS_ATTACHMENT_VISIBILITY_SUPPLIER').subscribe(
      (translatedValue: string) => {
        this.attachmentVisibilitySupplier = translatedValue;
      });
    this._translate.get('DEWDROPS_ATTACHMENT_INTERNAL_LABEL').subscribe(
      (translatedValue: string) => {
        this.attachmentLabelInternal = translatedValue;
      });
    this._translate.get('DEWDROPS_ATTACHMENT_SUPPLIER_LABEL').subscribe(
      (translatedValue: string) => {
        this.attachmentLabelSupplier = translatedValue;
      });
  }
}
