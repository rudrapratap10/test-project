export class FileSupportedFormat {
  // tslint:disable-next-line:max-line-length
  static commonFileUploadFormat = '.7z, .bz2, .gz, .gzip, .rar,.zip, .zipx, .3ga, .aac, .aif, .aifc, .aiff, .au, .caf, .flac, .gsm, .kar, .m4a, .m4p, ' +
  '.m4r, .mid, .midi, .mmf, .mp2, .mp3, .mpa, .mpga, .ogg, .oma, .opus, .ra, .ram, .wav, .wma, .xspf, .3ds, .max, ' +
  // tslint:disable-next-line:max-line-length
  '.obj, .chm, .doc, .docx, .dot, .dotx, .eml, .log, .m3u, .msg, .odt, .pages, .pdf, .pub, .rtf, .sxw, .txt, .wpd, .wps, ' +
  // tslint:disable-next-line:max-line-length
  '.xml, .xps, .azw, .azw3, .cbr, epub, .lit, .lrf, .mbp, .mobi, .prc, .tcr, .cda, .cfg, .dat, .dem, .deskthemepack, .dmp, ' +
  // tslint:disable-next-line:max-line-length
  '.dtd, .fla, .gam, .ics, .img, .indd, .inf, .ini, .ipa, .iso, .kml, .kmz, .lnk, .mim, .nes, .otf, .pes, .pkg, .rom, .sav, ' +
  // tslint:disable-next-line:max-line-length
  '.ttf, .vcd, .vcf, .key, .odp, .pps, .ppsx, .ppt, .pptm, .pptx, .arw, .bmp, .cr2, .crw, .dcm, .dds, .djvu, .dmg, .dng, .fpx, ' +
  // tslint:disable-next-line:max-line-length
  '.gif, .hdr, .icns, .ico, .ithmb, .jp2, .jpeg, .jpg, .nef, .nrw, .orf, .pcd, .pcx, .pict, .png, .psd, .sfw, .tga, .tif, .tiff, ' +
  // tslint:disable-next-line:max-line-length
  '.wbmp, .webp, .xcf, .yuv, .csv, .ods, .xls, .xlsx, .ai, .cdr, .emz, .eps, .odg, .svg, .vsd, .wmf, .wpg, .3g2, .3gp, .3gpp, ' +
  // tslint:disable-next-line:max-line-length
  '.asf, .avi, .divx, .f4v, .flv, .m4v, .mkv, .mod, .mov, .mp4, .mpeg, .mpg, .mswmm, .mts, .ogv, .rm, .srt, .swf, .vob, .webm, ' +
  '.wlmp, .wmv, .cer, .css, .pform, .cform, .stp, .st, iges, .model, .dwg ';
}
