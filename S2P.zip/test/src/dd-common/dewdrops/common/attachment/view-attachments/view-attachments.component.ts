import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { AUTH_API } from '@dewdrops/globals';
import { DateformatPipe } from 'dd-common/dewdrops/common/dateformat/dateformat.pipe';
import { TranslateService } from 'ng2-translate';
import {
  getFileSizeInKb,
  getFileType
} from '../../utility/file-utility';
import { Attachment } from '../enums/attachment.enum';
import { IAttachmentApiOptions } from '../models/attachment-api-options.model';

@Component({
  selector: 'dew-view-attachments',
  templateUrl: './view-attachments.component.html',
  styleUrls: ['./view-attachments.component.scss']
})
export class ViewAttachmentsComponent implements OnInit {

  @Input() attachmentApiOptions: IAttachmentApiOptions;

  @Input() attachmentList: string[];

  public attachmentDetails: false;
  public viewingAttachment;
  public getFileSizeInKb = getFileSizeInKb;
  public getFileType = getFileType;
  constructor(
    private _language: TranslateService) {
    this.viewingAttachment = undefined;
  }
  ngOnInit() {
  }

  setViewAttachment(fileObject) {
    this.viewingAttachment = fileObject;
    this.viewingAttachment.fileType = getFileType(this.viewingAttachment.name);
  }

  downloadAttachmentFile(filePath, fileType) {
    try {
      if (fileType === Attachment.WEBLINK) {
        window.open(filePath, '_blank');
      }
      const url = `${AUTH_API}/${this.attachmentApiOptions.downloadAttachment.url}/`;
      window.open(`${url}${filePath}`);
    } catch (ex) {
      // to do
    }

  }

  getSize(bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) { return '0 Byte'; }
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
    }
}
