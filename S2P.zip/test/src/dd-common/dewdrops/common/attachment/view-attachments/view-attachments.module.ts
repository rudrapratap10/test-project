import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule } from '../../../core/bootstrap/layout/layout.module';
import { ViewAttachmentsComponent } from './view-attachments.component';
@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    LayoutModule
  ],
  declarations: [ ViewAttachmentsComponent ],
  exports: [ ViewAttachmentsComponent ]
})
export class ViewAttachmentsModule { }
