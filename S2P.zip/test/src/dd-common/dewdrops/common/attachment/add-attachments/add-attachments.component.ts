import { HttpClient, HttpEventType, HttpHeaders, HttpParams, HttpRequest, HttpResponse } from '@angular/common/http';
import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild, OnChanges } from '@angular/core';
import { AUTH_API } from '@dewdrops/globals';
import { LanguageTranslateService, RestClientService, UserService } from '@dewdrops/services';
import { each } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { Observable } from 'rxjs/Rx';
import { Attachment } from '../enums/attachment.enum';
import { FileControls } from '../enums/file-controls.enum';
import { IAttachmentApiOptions } from '../models/attachment-api-options.model';
import { AttachmentVisibilityOptions } from '../models/attachment-visibility-options.model';
import { AttachmentModel } from '../models/attachment.model';
import { FileSupportedFormat } from '../models/file-type.model';
import { FileUploadModel } from '../models/file-upload.model';
import { AttachmentService } from '../service/attachment.service';

@Component({
  selector: 'dew-add-attachments',
  templateUrl: './add-attachments.component.html',
  styleUrls: ['./add-attachments.component.scss'],
  providers: [AttachmentService, LanguageTranslateService]
})
export class AddAttachmentsComponent implements OnInit, OnChanges {

  @Input()
  attachmentApiOptions: IAttachmentApiOptions;

  @Input()
  uploadBtnLabel: string;

  @Input()
  uploadPlaceholder: string;

  @Input()
  showAttachmentDetails: boolean;

  @Input()
  canAddDetails: boolean;

  @Input()
  attachmentList: string[];

  @Input()
  enableWebLink: boolean;

  @Input() expandedViewToggle: boolean;

  @Input() mode: string;

  @Input() maxFileSize: number = 10000;

  @Output() expandedViewChange = new EventEmitter<string>();

  @Output()
  createAttachmentIds: EventEmitter<string[]>;

  @Output()
  createAttachmentObjects: EventEmitter<any[]>;

  @ViewChild('webLink') webLink: ElementRef;

  public shouldShowExpandedView: boolean;
  @Input()
  maxUpload: string;
  @Input()
  fileCharactersLimit = 50;

  @Input() allowFileTypes: string[];

  @Input() fullWidth: boolean;

  public attachmentVisibilityOptions: AttachmentVisibilityOptions;
  public fileUploadObj: FileUploadModel;
  public visibilityRadioOptions: Array<{ label: string, value: string }>;
  public path: string;
  public isFileLimitExceeded: boolean;
  public indexFileOpen: number;
  public currentDate = new Date();

  public fileUploadStart: boolean;
  public isInvalidURL: boolean;
  public isFileEmpty: boolean;
  public isFileUploadValid = true;
  public supportedFileFormat: any;
  public invalidFile: boolean;

  public fileUploadCharacterLimit = false;
  public fileUploaded = [];
  public uploadedFileToBackend = [];
  public uploadedFile = {};
  public tempCurrentfile: any;
  public fileInCurrentView: any;
  public fileControls: {
    actualWidth?: number,
    modifiedWidth?: number,
    transform?: number,
    isMinWidth: boolean,
    isMaxWidth: boolean
  };
  public fileControlsEnum = FileControls;

  public auth_api = AUTH_API;

  MAXUPLOADS;
  isFileSizeExceeded = false;
  _userName: string;
  constructor(
    private _translate: TranslateService,
    private _language: LanguageTranslateService,
    private _userService: UserService,
    private rest: RestClientService,
    private _attachService: AttachmentService,
    private http: HttpClient) {

    this.attachmentVisibilityOptions = new AttachmentVisibilityOptions(this._translate);
    this.createAttachmentIds = new EventEmitter<string[]>();
    this.createAttachmentObjects = new EventEmitter<any[]>();
    this._language.switchLanguage(_userService.locale);
    this.fileControls = {
      modifiedWidth: 100,
      actualWidth: 100,
      transform: 0,
      isMinWidth: false,
      isMaxWidth: false
    };
  }

  ngOnInit() {
    this.supportedFileFormat = FileSupportedFormat.commonFileUploadFormat;

    this._userService.update.subscribe((user) => {
      this._userName = user ? user.displayName || '' : '';
    });
    this._attachService.attachmentObj = [];
    if (!this.attachmentList) {

      this.attachmentList = [];
    }
    this.shouldShowExpandedView = this.mode === 'add' ? false : true;
    this.getExistingFileDetails(this.attachmentList);
  }

  ngOnChanges() {
    this.MAXUPLOADS  = this.maxUpload ? this.maxUpload : 10;
    }

  validateURL(path) {
    let urlValidationStr = path.trim();
    if (urlValidationStr.length === 0) {
      return true;
    }
    if (!/^(https?|ftp):\/\//i.test(urlValidationStr)) {
      urlValidationStr = 'http://' + urlValidationStr;
      this.path = urlValidationStr;
    }
    // tslint:disable-next-line:max-line-length
    return /^(ftp|https?)?(:\/\/)?(([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3})|((|([A-Za-z0-9\.]+)\.)([A-Za-z0-9\.]+[\-]*[\.A-Z0-9a-z]+)\.([A-Za-z\-\.]+[A-za-z]+)))(\:[0-9]+)?($|(\/|\?|#)[A-Za-z0-9\!\*\'\(\%\)\;\:\@\&\=\+\$\,\/\?\#\[\]\-\_\.\~]*)?$/.test(urlValidationStr);
  }

  addWebLink() {
    if (this._attachService.attachmentObj.length + 1 > this.MAXUPLOADS) {
      this.isFileLimitExceeded = true;
      const removeAlerts = Observable.timer(3000);
      removeAlerts.subscribe(() => {
        this.isFileLimitExceeded = false;
      });
      return;
    }
    this.path = this.webLink.nativeElement.value;
    if (this.path === '') {
      return;
    }
    if (!this.validateURL(this.path)) {
      this.isInvalidURL = true;
      const removeAlerts = Observable.timer(3000);
      removeAlerts.subscribe(() => {
        this.isInvalidURL = false;
      });
      return;
    } else {
      this.isInvalidURL = false;
    }
    let webLinkName;
    this._translate.get('DEWDROPS_WEBLINK_FILENAME').subscribe(
      (translatedValue: string) => {
        webLinkName = translatedValue;
      });
    const webItem = new AttachmentModel('', webLinkName,
      0, this.path, Attachment.WEBLINK, '', false);
    this.fileUploaded.push(webItem);
    // this._changeDetectorRef.detectChanges();
    this.webLink.nativeElement.value = '';
    const body = this.attachmentApiOptions.weblink.body;
    body.path = this.path;
    this._attachService.addWeblink(this.attachmentApiOptions.weblink.url, body);
  }

  getExistingFileDetails(attachmentArr) {
    for (const attachment of attachmentArr) {
      const tempAttachmentArr = [];
      const options: any = {};
      options.url = `${this.attachmentApiOptions.getAttachmentDetailsById.url}/${attachment}`;
      options.method = this.attachmentApiOptions.getAttachmentDetailsById.method;
      // const url = copy.url.replace(':', attachmentArr[i]);
      // copy.url = url;
      this.rest.request(options).subscribe((response) => {
        tempAttachmentArr.push(new AttachmentModel(
          response.data.attachmentId,
          response.data.name,
          response.data.fileSize,
          response.data.path,
          response.data.type,
          '',
          false));
        this.fileUploaded = this.retResponse(tempAttachmentArr, this.fileUploaded);
        this.updateAttachServiceObj(this.fileUploaded);
        // this._changeDetectorRef.detectChanges();
      });
    }
  }

  saveAttachment(attachmentId, visibility, comments) {
    this.attachmentVisibilityOptions.attachModal = false;
    this.attachmentApiOptions.updateorSaveAttachment.data = [{ attachmentId: '', visibility: '', comments: '' }];
    this.attachmentApiOptions.updateorSaveAttachment.data[0].attachmentId = attachmentId;
    this.attachmentApiOptions.updateorSaveAttachment.data[0].visibility = visibility;
    this.attachmentApiOptions.updateorSaveAttachment.data[0].comments = comments;
    let  transformData: any;
    let url: any;
    if(this.attachmentApiOptions.updateorSaveAttachment.bodyTransformFn)
    {
     transformData = this.attachmentApiOptions.updateorSaveAttachment.bodyTransformFn(attachmentId);
      url = `${AUTH_API}/${transformData.url}`;
    }
    
    if(transformData !== undefined){
      this.http.put(url, transformData.body,
        { headers: transformData.httpHeaders }).subscribe((response) => {
        });
    } else{
       url = `${AUTH_API}/${this.attachmentApiOptions.updateorSaveAttachment.url}`;
      this.http.put(url, this.attachmentApiOptions.updateorSaveAttachment.data,
        { headers: this.attachmentApiOptions.updateorSaveAttachment.httpHeaders }).subscribe((response) => {
        });
    }
    
    this.rest.request(this.attachmentApiOptions.updateorSaveAttachment).subscribe((response) => {
    });
    this._attachService.attachmentObj[this.indexFileOpen].comments = comments;
    this._attachService.attachmentObj[this.indexFileOpen].visibility = visibility;
    this.fileUploaded[this.indexFileOpen].comments = comments;
    this.fileUploaded[this.indexFileOpen].visibility = visibility;
    this.fileUploaded[this.indexFileOpen].saved = true;
  }

  public toggleModalState(state, fileObject, index, attachmentId): void {
    this.addVisibilityOption();
    if (state === false) {
      this.uploadedFile = {};
    } else {
      this.uploadedFile = fileObject;
      this.getuploadedfileDetails(attachmentId);
      this.indexFileOpen = index;
    }
    this.attachmentVisibilityOptions.attachModal = state;
  }
getCurreentFiles(currentFile) {
  const files = [];
  // tslint:disable-next-line:prefer-for-of
  for (let i = 0; i < currentFile.length; i++) {
    if (this.validateAttachment(currentFile[i])) {
      // currentFile.splice(i, 1);
      files.push(currentFile[i]);
    }
  }
  return files;
}
  fileSelected(event) {
    const currentFile = event.currentFile;
    this.isFileLimitExceeded = false;
    if (currentFile.length > 0) {
      this.fileUploadCharacterLimit = false;
      // tslint:disable-next-line:no-shadowed-variable
      const files = this.getCurreentFiles(currentFile);

      // if (currentFile.length === 0) {
      //   this.fileUploadCharacterLimit = true;
      // } else {
      //   this.fileUploadCharacterLimit = false;
      // }

      if (this.fileUploaded.length + currentFile.length > this.MAXUPLOADS) {
      this.SetErrors(true, false, false, false);
      } else if (this.invalidFile) {
        this.SetErrors(false, true, false, false);
      } else if (this.isFileSizeExceeded) {
        this.SetErrors(false, false, true, false);
      } else if (this.fileUploadCharacterLimit) {
        this.SetErrors(false, false, false, true);
      }
      // if (!this.fileUploadCharacterLimit && !this.isFileLimitExceeded) {
      const fileArr = [];
        // tslint:disable-next-line:prefer-for-of
      for (let i = 0; i < files.length; i++) {
          if (i !== this.MAXUPLOADS) {
            fileArr.push(files[i]);
          } else { break; }
        }
        if(this.fileUploaded.length<this.MAXUPLOADS){
          this.uploadAttachment(fileArr, 'headerAttachment');
        }
      // }
    }

    const removeAlerts = Observable.timer(3000);
    removeAlerts.subscribe(() => {
      this.SetErrors(false, false, false, false);
    });
  }
  SetErrors(limit, type, size, wc) {
    this.isFileLimitExceeded = limit;
    this.invalidFile = type;
    this.isFileSizeExceeded = size;
    this.fileUploadCharacterLimit = wc;
  }
  validateAttachment(currentFile) {
    this.isFileEmpty = false;
    const ext = this.getFileExtension(currentFile);
    if (this.supportedFileFormat.indexOf(ext) === -1 ||
    (this.allowFileTypes && this.allowFileTypes.indexOf(ext) === -1)) {
      this.invalidFile = true;
      return false;
    } else {
      this.invalidFile = false;
    }
    this.isFileUploadValid = false;
    if (currentFile.name.length > this.fileCharactersLimit) {
      this.fileUploadCharacterLimit = true;
      return false;
    } else if (currentFile.size === 0) {
      this.isFileEmpty = true;
      return false;
    } else if (currentFile.size >= this.maxFileSize) {
      this.isFileSizeExceeded = true;
      return false;
    } else {
      this.isFileUploadValid = true;
    }
    return this.isFileUploadValid;
  }

  getFileExtension(uploadedFile) {
    return uploadedFile.name.substr(uploadedFile.name.lastIndexOf('.') + 1, uploadedFile.name.length).toLowerCase();
  }

  public uploadAttachment(files, moduleName) {
    if (moduleName === 'headerAttachment') {
      // this.fileUploaded = [...this.fileUploaded, ...files];
      each(files, (file) => {
        this.fileUploadStart = true;
        file.fileUploadObj = file.fileUploadObj ? file.fileUploadObj : new FileUploadModel();
        file.fileUploadObj.percentageUploaded = 0;
        file.fileUploadObj.totalUploaded = 0;
        this.fileUploaded.push(file);
        this.setAttachmentOneByOne(file).subscribe(
          (data) => {
            if (data.type === HttpEventType.UploadProgress) {
              file.fileUploadObj.percentageUploaded = Math.round(100 * data.loaded / data.total);
              file.fileUploadObj.totalUploaded = +(file.fileUploadObj.percentageUploaded *
                (file.fileUploadObj.size / 100)).toFixed(2);
            } else if (data instanceof HttpResponse) {
              this.fileUploadStart = false;
              file.fileUploadObj.uploaded = true;
              if (data.body.data && data.body.data.id) {
                file.fileUploadObj.id = data.body.data.id;
                file.fileUploadObj.path = data.body.data.path;
                file.fileUploadObj.type = data.body.data.type;
                this.fileUploaded = this.fileUploaded.filter((fileObj) => fileObj !== file);
                this.fileUploaded = this.retResponse([data.body.data], this.fileUploaded, file);
              } else {
                file.fileUploadObj.id = data.body.data.records[0].id;
                file.fileUploadObj.path = data.body.data.records[0].path;
                file.fileUploadObj.type = data.body.data.records[0].type;
                if (data.body.data && data.body.data.records.length > 0) {
                  this.fileUploaded = this.fileUploaded.filter((fileObj) => fileObj !== file);
                  this.fileUploaded = this.retResponse(data.body.data.records, this.fileUploaded);
                }
              }
              this.updateAttachServiceObj(this.fileUploaded);
            }
          },
          (error) => {
            this.fileUploaded.pop();
          });
        return file.fileUploadObj;
      });
    }
  }

  setAttachmentOneByOne(file): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', file.file);
    const requestOptions = {
      params: new HttpParams()
    };
    let  transformData: any;
    let url: any;
    let req: any;
    if(this.attachmentApiOptions.updateorSaveAttachment.bodyTransformFn)
    {
     transformData = this.attachmentApiOptions.updateorSaveAttachment.bodyTransformFn(file);
    }
    if(transformData !== undefined) {
       url = `${AUTH_API}/${transformData.url}`;
       req = new HttpRequest(transformData.method, url, transformData.body, {
      reportProgress: true,
      headers: transformData.httpHeaders
    });
    return this._attachService.addAttachmentOneByOne(req);
  } else{
     url = `${AUTH_API}/${this.attachmentApiOptions.updateorSaveAttachment.url}`;
     req = new HttpRequest(this.attachmentApiOptions.updateorSaveAttachment.method, url, formData, {
      reportProgress: true,
      headers: this.attachmentApiOptions.updateorSaveAttachment.httpHeaders
    });
    return this._attachService.addAttachmentOneByOne(req);
  }
  }

  public setAttachment(files): Observable<any> {
    const formData: FormData = new FormData();
    for (const file of files) {
      formData.append('file', file.file);
    }
    return this._attachService.uploadAttachment(
      `${AUTH_API}/${this.attachmentApiOptions.updateorSaveAttachment.url}`, formData, {
      reportProgress: true,
      headers: this.attachmentApiOptions.updateorSaveAttachment.httpHeaders
    });
  }

  downloadAttachment(filePath, fileType) {
    try {
      let  transformData: any;
      let url: any;
    if(this.attachmentApiOptions.downloadAttachment.bodyTransformFn)
    {
     transformData = this.attachmentApiOptions.downloadAttachment.bodyTransformFn(filePath);
    }
      if (fileType === Attachment.WEBLINK) {
        window.open(filePath, '_blank');
      }
      if(transformData !== undefined){
        url = `${AUTH_API}/${transformData.url}/`;
        window.open(`${url}${transformData.path}`, '_self');
      }else {
        url = `${AUTH_API}/${this.attachmentApiOptions.downloadAttachment.url}/`;
        window.open(`${url}${filePath}`, '_self');
      }
      
    } catch (ex) {
      // to do
    }

  }

    // delete attachment
    deleteAttachment(attachmentId) {
      let  transformData: any;
      let url: any;
    if(this.attachmentApiOptions.deleteAttachment.bodyTransformFn)
    {
      transformData = this.attachmentApiOptions.deleteAttachment.bodyTransformFn(attachmentId);
      url = `${AUTH_API}/${transformData.url}/${attachmentId}`;
    }
        if(this.attachmentApiOptions.deleteAttachment.url)
      {
        if(transformData !== undefined){
          const options = {
            body: transformData.body  
        }
        this._attachService.deleteAttachment(url, transformData.headers, options)
          .subscribe((res) => {
          for (let i = 0; i < this.fileUploaded.length; i++) {
            if (attachmentId === this.fileUploaded[i].path) {
              this.fileUploaded.splice(i, 1);
              this._attachService.attachmentObj.splice(i, 1);
            }
          }
          this.updateAttachServiceObj(this.fileUploaded);
        });
      } else{
       url = `${AUTH_API}/${this.attachmentApiOptions.deleteAttachment.url}/${attachmentId}`;
      this._attachService.deleteAttachment(
        url,
        this.attachmentApiOptions.deleteAttachment.httpHeaders, this.attachmentApiOptions.deleteAttachment.body)
        .subscribe((res) => {
        for (let i = 0; i < this.fileUploaded.length; i++) {
          if (attachmentId === this.fileUploaded[i].path) {
            this.fileUploaded.splice(i, 1);
            this._attachService.attachmentObj.splice(i, 1);
          }
        }
        this.updateAttachServiceObj(this.fileUploaded);
      });
    }
  }else{
    for (let i = 0; i < this.fileUploaded.length; i++) {
      if (attachmentId === this.fileUploaded[i].path) {
        this.fileUploaded.splice(i, 1);
        this._attachService.attachmentObj.splice(i, 1);
      }
    }
    this.updateAttachServiceObj(this.fileUploaded);
  }
  }

  public getuploadedfileDetails(attachmentId) {
    let  transformData: any;
    if(this.attachmentApiOptions.getAttachmentDetailsById.bodyTransformFn)
    {
     transformData = this.attachmentApiOptions.getAttachmentDetailsById.bodyTransformFn(attachmentId);
    }
    this.uploadedFileToBackend = [];
    const options: any = {};
    if(transformData !== undefined){
      options.method = transformData.method;
      options.url = `${transformData.url}/${transformData.attachmentId}`;
      // options.body = transformData.body;
      this.rest.request(options).subscribe((response) => {
        this.uploadedFileToBackend = response.data;
        // this._changeDetectorRef.detectChanges();
      });
    } else{
      options.method = this.attachmentApiOptions.getAttachmentDetailsById.method;
      options.url = `${this.attachmentApiOptions.getAttachmentDetailsById.url}/${attachmentId}`;
    this.rest.request(options).subscribe((response) => {
      this.uploadedFileToBackend = response.data;
      // this._changeDetectorRef.detectChanges();
    });
  }
  }

  updateAttachServiceObj(attachmentInfo: any[]) {
    this._attachService.attachmentObj = [];
    const attachmentId = [];
    for (let i = 0; i < attachmentInfo.length; i++) {
      this._attachService.attachmentObj.push({
        attachmentId: '',
        comments: '',
        visibility: this.attachmentVisibilityOptions.attachmentVisibilityInternal
      });
      this._attachService.attachmentObj[i].attachmentId = attachmentInfo[i].id;
      // this._changeDetectorRef.detectChanges();
      attachmentId.push(attachmentInfo[i].id);
    }
    this.createAttachmentIds.emit(attachmentId);
    this.createAttachmentObjects.emit(this.fileUploaded);
  }

  retResponse(input, output, file?) {
    const res = input.map((element: AttachmentModel) => {
      return {
        id: element.id,
        name: element.name || file.name,
        size: element.size ? (element.size / 1024).toFixed(2) : file.size.toString(),
        path: element.path || element.id,
        type: (element.type || element.type === 0)? element.type : file.type,
        max: 2000,
        saved: false,
        comments: '',
        visibility: this.attachmentVisibilityOptions.attachmentVisibilityInternal,
        fileUploadObj: input.fileUploadObj
      };
    });
    return [...output, ...res];
  }

  addVisibilityOption() {
    this.visibilityRadioOptions = [];
    this.visibilityRadioOptions.push({
      value: this.attachmentVisibilityOptions.attachmentVisibilityInternal,
      label: this.attachmentVisibilityOptions.attachmentLabelInternal,
    },
      {
        value: this.attachmentVisibilityOptions.attachmentVisibilitySupplier,
        label: this.attachmentVisibilityOptions.attachmentLabelSupplier
      });
  }

  showExpandedView(shouldShow?: boolean) {
    this.mode = shouldShow ? 'expanded' : 'add';
    this.shouldShowExpandedView = shouldShow;
    this.expandedViewChange.emit(this.mode);
  }

  viewFile(fileToView: any) {
    this.fileInCurrentView = fileToView;
    this.fileControls.actualWidth = document.querySelector('.file-in-current-view').clientWidth;
  }

  modifyFileInCurrentView(mode: FileControls) {
    switch (mode) {
      case this.fileControlsEnum.ZOOM_IN:
        if (!this.fileControls.isMaxWidth) {
          const maxZoomInLimit = this.fileControls.actualWidth + (3 * (0.33 * this.fileControls.actualWidth));
          this.fileControls.isMinWidth = false;
          this.fileControls.modifiedWidth = this.fileControls.modifiedWidth + (0.33 * this.fileControls.actualWidth);
          if ((this.fileControls.modifiedWidth / this.fileControls.actualWidth) * 100 >= maxZoomInLimit) {
            this.fileControls.isMaxWidth = true;
          } else {
            this.fileControls.isMaxWidth = false;
          }
        }
        break;
      case this.fileControlsEnum.ZOOM_OUT:
        if (!this.fileControls.isMinWidth) {
          const maxZoomOutLimit = this.fileControls.actualWidth / 3;
          this.fileControls.isMaxWidth = false;
          this.fileControls.modifiedWidth = this.fileControls.modifiedWidth - (0.33 * this.fileControls.actualWidth);
          if ((this.fileControls.modifiedWidth / this.fileControls.actualWidth) * 100 <= maxZoomOutLimit) {
            this.fileControls.isMinWidth = true;
          } else {
            this.fileControls.isMinWidth = false;
          }
        }
        break;
      case this.fileControlsEnum.ROTATE:
        this.fileControls.transform = this.fileControls.transform + 90;
        break;
      case this.fileControlsEnum.EXPAND:
        // to do
        break;
    }
  }

}
