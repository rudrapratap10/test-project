import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ExtendModule, LayoutModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { ButtonsModule } from '../../../core/bootstrap/buttons/buttons.module';
import { FormControlModule } from '../../../core/bootstrap/form-control/form-control.module';
import { ModalModule } from '../../../core/bootstrap/modal/modal.module';
import { DateformatPipeModule } from '../../dateformat/dateformat.pipe.module';
import { AddAttachmentsComponent } from './add-attachments.component';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    ButtonsModule,
    ModalModule,
    FormControlModule,
    LayoutModule,
    ExtendModule,
    DateformatPipeModule
  ],
  declarations: [AddAttachmentsComponent],
  exports: [AddAttachmentsComponent]
})
export class AddAttachmentsModule { }
