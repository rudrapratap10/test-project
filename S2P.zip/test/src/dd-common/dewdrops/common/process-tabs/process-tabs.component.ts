import { Component, OnInit, ContentChildren, QueryList, AfterViewChecked, AfterContentInit, Input, Output, EventEmitter } from '@angular/core';
import {
  Router,
  NavigationEnd
} from '@angular/router';

@Component({
  selector: 'dew-process-tabs',
  templateUrl: './process-tabs.component.html',
  styleUrls: ['./process-tabs.component.scss']
})
export class ProcessTabsComponent implements OnInit, AfterContentInit {
  public tabId:string;
  @Input() showSectionTab: false;
  @Input()
  processTabsObj = [
    {
      label: '',
      id:'',
      queryParams: {
        tabId: ''
      },
      replaceUrl: true,
      path: '',
      activeOnLoad: false,
      isDisabled: false
    }
  ];
 
  constructor(private router: Router) { }

  ngOnInit() {
  }
  
  ngAfterContentInit() {
  }

  onTabChange(event){
    this.tabId = event.id;
    for( let i = 0; i < this.processTabsObj.length; i++){
      if(this.tabId === this.processTabsObj[i].id){
        this.router.navigate([this.processTabsObj[i].path], {
          queryParams: this.processTabsObj[i].queryParams,
          replaceUrl: this.processTabsObj[i].replaceUrl
      });
      }
    }
  }

}
