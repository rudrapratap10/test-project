import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule, ProgressModule, TabsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { ProcessTabsComponent } from './process-tabs.component';

@NgModule({
  imports: [
    CommonModule,
    TabsModule,
    LayoutModule,
    TranslateModule,
    ProgressModule
  ],
  declarations: [ProcessTabsComponent],
  exports: [ProcessTabsComponent]
})
export class ProcessTabsModule { }
