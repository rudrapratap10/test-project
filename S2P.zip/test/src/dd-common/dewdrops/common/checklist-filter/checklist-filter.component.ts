import { Component, EventEmitter, Inject, Input, OnInit, Optional, Output, ViewChild } from '@angular/core';
import { CollectionFactory } from '@dewdrops/factories';
import { CriteriaInterface } from '@dewdrops/interfaces';
import { ChecklistComponent } from '../../core/bootstrap/checklist/checklist.component';
import { ChecklistModel } from '../../core/bootstrap/checklist/checklist.model';

@Component({
  selector: 'dew-checklist-filter',
  templateUrl: './checklist-filter.component.html',
  styleUrls: ['./checklist-filter.component.scss']
})
export class ChecklistFilterComponent implements OnInit {

  @Input()
  applier = true;

  @Input()
  name: string;

  @Input()
  viewTransformFn: (() => any);

  @Input()
  placeholder: string;

  @Input()
  allowSelectAll: boolean;

  @Input()
  listName: string;

  @Input()
  datasource: ChecklistModel[] | CollectionFactory<ChecklistModel>;

  @Input()
  criteria: CriteriaInterface;

  /**
   * Emits the application/ clearing out status of checklist filter
   */
  @Output()
  whenApplied: EventEmitter<any> = new EventEmitter<any>();

  /**
   * Emits the array of ids of selected items
   * @output
   */
  @Output()
  whenSelectionChanged: EventEmitter<string[]> = new EventEmitter<string[]>();

  @Output()
  whenAllSelected: EventEmitter<{ id, label, value, checked }> = new EventEmitter<{ id, label, value, checked }>();

  public searchedText: string;
  private selectedIds: string[] = [];

  @ViewChild(ChecklistComponent)
  private checklistComponent: ChecklistComponent;

  constructor(
    @Inject('FILTER_PIPE_LINE')
    @Optional()
    private _filterPipeLine: any
  ) {}

  ngOnInit() {
    this._filterPipeLine.resetFiltersSub.subscribe((state: boolean) => {
      if (state) {
        this.resetFilter();
      }
    });
  }

  /**
   * Applies checklist filter
   */
  /**
   * Apply Invoice No Filter
   * @param searchValue
   */
  applyChecklistFilter(searchValue) {
    this._filterPipeLine.put(this.name, this.selectedIds);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  /**
   * Clear checklist filter
   * @param Value
   */
  clearChecklistFilter(value?) {
    this.resetFilter();
    this._filterPipeLine.put(this.name, []);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  resetFilter() {
    this.checklistComponent.toggleAllSelection(false);
    this.checklistComponent.searchedText = undefined;
    this.searchedText = undefined;
  }

  /**
   * Updates the criteria object with the current selection
   * @param idsArr array of ids of selected items from the list of items
   */
  updateSelectedIds(idsArr: string[]) {
    this.selectedIds = idsArr;
    this._filterPipeLine.put(this.name, this.selectedIds);
    this.whenSelectionChanged.emit(idsArr);
  }

  /**
   * Modifies the criteria object with `select all` type of value if `Select All` option is `checked`
   * @param selectAllObj contains the information about `select all` option
   */
  checkAllSelected(selectAllObj: { id: string[], label: any, value: any[], checked: boolean }) {
    if (selectAllObj.checked) {
      this.selectedIds = selectAllObj.id;
      this._filterPipeLine.put(this.name, this.selectedIds);
      this.whenSelectionChanged.emit(this.selectedIds);
    }
    this.whenAllSelected.emit(selectAllObj);
  }
}
