import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ButtonsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { ChecklistModule } from '../../core/bootstrap/checklist/checklist.module';
import { ChecklistFilterComponent } from './checklist-filter.component';

@NgModule({
  imports: [
    CommonModule,
    ChecklistModule,
    TranslateModule,
    ButtonsModule
  ],
  declarations: [ChecklistFilterComponent],
  exports: [ChecklistFilterComponent]
})
export class ChecklistFilterModule { }
