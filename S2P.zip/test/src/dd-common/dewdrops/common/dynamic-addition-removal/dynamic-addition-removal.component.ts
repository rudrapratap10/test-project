import { Component, OnInit, Input } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormControlName,
  FormGroup,
  FormArray
} from '@angular/forms';
@Component({
  selector: 'dew-dynamic-addition-removal',
  templateUrl: './dynamic-addition-removal.component.html',
  styleUrls: ['./dynamic-addition-removal.component.scss']
})
export class DynamicAdditionRemovalComponent implements OnInit {

  @Input()
  dynamicAddRemoveForm: FormGroup;
  @Input() additionRemovalIndex: number;
  public formArrayName: string;
  public addIcon = '/assets/images/common/add-row.svg';
  constructor(private _fb: FormBuilder) { }

  ngOnInit() {
    let dynamicAddRemoveFormObject = Object.keys(this.dynamicAddRemoveForm.controls);
    for(let i = 0; i< dynamicAddRemoveFormObject.length;i++){
      if(this.dynamicAddRemoveForm.controls[dynamicAddRemoveFormObject[i]]['controls']){
        this.formArrayName = dynamicAddRemoveFormObject[i]
      }
    }
  }

  createRow(): FormGroup {
    let formBuilderObj = {};
    let formControlStructure = Object.keys(this.dynamicAddRemoveForm.controls[this.formArrayName]['controls'][0].controls);
    for(let i = 0; i< formControlStructure.length; i++){
      formBuilderObj[formControlStructure[i]] = new FormControl(null);
    }
    return this._fb.group(formBuilderObj);
  }

  addNewRow() {
    // control refers to your formarray
    const control = <FormArray>this.dynamicAddRemoveForm.controls[this.formArrayName];
    // add new formgroup
    control.push(this.createRow());
  }

  deleteRow(index: number) {
    // control refers to your formarray
    const control = <FormArray>this.dynamicAddRemoveForm.controls[this.formArrayName];
    // remove the chosen row
    control.removeAt(index);
  }

}
