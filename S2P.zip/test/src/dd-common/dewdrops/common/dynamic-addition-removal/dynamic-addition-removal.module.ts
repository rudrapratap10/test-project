import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import {DynamicAdditionRemovalComponent} from './dynamic-addition-removal.component';
import { TabsModule, LayoutModule, ButtonsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { GlobalUIModule } from '@dewdrops/bootstrap';

@NgModule({
  imports: [
    CommonModule,
    TabsModule,
    TranslateModule,
    LayoutModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonsModule,
    GlobalUIModule
  ],
  declarations: [
    DynamicAdditionRemovalComponent,
  ],
  exports: [
    DynamicAdditionRemovalComponent
  ]
})
export class DynamicAdditionRemovalModule { }
