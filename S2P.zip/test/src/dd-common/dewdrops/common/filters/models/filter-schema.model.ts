import { TemplateRef } from '@angular/core';
import { CriteriaInterface } from '@dewdrops/interfaces';
import { IFilter } from '../filter/filter';

export interface IFilterSchema {
  /**
   * @param [required] Filters that will appear in the filter spotlight bar
   */
  spotlightFilters: IFilterArray[];

  /**
   * @param [optional] Filters that will appear in the master filters container
   */
  masterFilters?: IFilterArray[];
}

export interface IFilterArray {
  /**
   * @param {string} [optional]
   * Id of the field, if this filter is specific to a column specified in the column schema
   */
  fieldName?: string;

  /**
   * i18n language label key for the filter headering.
   *
   * This may or may not be different from the column heading. It is recommended to keep it same.
   */
  label: string;

  /**
   * i18n language label key for the filter headering.
   *
   * This may or may not be different from the column heading. It is recommended to keep it same.
   */
  placeholder?: string;

  /**
   * Instance of the filter component (implementing FilterInterface) to be used
   */
  filterTemplate: TemplateRef<IFilter>;

  /**
   * @param {boolean} [optional]
   * specifies whether the filter is default filter
   *
   * If specfied, the filter will appear in filter-spotlight bar.
   */
  default?: boolean;

  /**
   * The criteria's fieldName to be used when transforming the data to and from a CriteriaInterface.
   */
  criteriaKey?: string;

  /**
   * The `criteriaKey` is optional if you provide a transformation fn' to extract value from Criteria.
   *
   * The function would accept a list of applied Criteria and return the raw selected value
   */
  fromCriteriaFn?: ((allCriteria: CriteriaInterface[]) => any);

  /**
   * The `criteriaKey` is optional if you provide both the transformation functions.
   *
   * This function would accept the raw selected value and return a list of applicable Criteria
   */
  toCriteriaFn?: ((value: any) => CriteriaInterface);
}
