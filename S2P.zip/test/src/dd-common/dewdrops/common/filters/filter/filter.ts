export interface IFilter {
  clear: () => void;
  apply: () => void;
  criteria?: any;
}
