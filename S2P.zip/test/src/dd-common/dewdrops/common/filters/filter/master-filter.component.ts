import { NgPlural } from '@angular/common';
import {
  Component,
  EventEmitter,
  forwardRef,
  Inject,
  Input,
  OnInit,
  Optional,
  Output,
  TemplateRef
} from '@angular/core';
import { CriteriaInterface } from '@dewdrops/interfaces';
import { IFilterArray, IFilterSchema } from '../models/filter-schema.model';
import { IFilter } from './filter';

@Component({
  selector: 'dew-master-filter',
  styleUrls: ['./master-filter.component.scss'],
  templateUrl: './master-filter.component.html',
})
export class MasterFilterComponent implements OnInit, IFilter {

  @Input()
  filters: IFilterSchema;

  allFilters: IFilterArray[] = [];

  filterTemplateList: Array<TemplateRef<IFilter>> = [];

  // contains the spotlight filters
  spotlightFilters: any[] = [];

  /**
   * an object hash of all children filter
   * mapping `string` ===> `Filter` component
   */
  public filterMap: { [key: string]: TemplateRef<IFilter> } = {};
  public filtersCountMap:
    { [k: string]: string } = { '=0': 'filters', '=1': 'filter', 'other': 'filters' };
  public filterSearchText: string;

  constructor(
    @Inject('FILTER_PIPE_LINE')
    @Optional()
    private _filterPipeLine: any
  ) {}

  ngOnInit() {
    this.allFilters = [...this.filters.spotlightFilters, ...this.filters.masterFilters];
    this.allFilters.forEach((filter) => {
      this.filterMap[filter.label] = filter.filterTemplate;
      this.filterTemplateList.push(filter.filterTemplate);
    });
  }
  apply() {
    this._filterPipeLine.apply();
  }
  clear() {
    this._filterPipeLine.resetFiltersSubject.next(true);
    this._filterPipeLine.clear();
  }
}
