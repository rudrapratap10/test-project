import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef
} from '@angular/core';
import { CriteriaInterface } from '@dewdrops/interfaces';
import { IFilterSchema } from '../models/filter-schema.model';
import { IFilter } from './filter';

@Component({
  selector: 'dew-filter-spotlight',
  templateUrl: './filter-spotlight.component.html',
  styleUrls: ['./filter-spotlight.component.scss']
})
export class FilterSpotlightComponent implements OnInit {

  @Input()
  filters: IFilterSchema;

  // keys of default filter
  @Input()
  default: string[] = [];

  // contains the default spotlight filters
  defaultSpotlight: string[] = [];

  /**
   * an object hash of all children filter
   * mapping `string` ===> `Filter` component
   */
  filterMap: {[key: string]: TemplateRef<IFilter>} = {};

  placeholderMap: {[key: string]: string} = {};

  // contains the spotlight filters
  spotlightFilters: any[] = [];

  shouldShowMasterFilters: boolean;

  @Output()
  showMasterFilters: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
    this.filters.spotlightFilters.forEach(
      (filter) => {
        this.filterMap[filter.label] = filter.filterTemplate;
        this.placeholderMap[filter.label] = filter.placeholder;
      }
    );

    this.filters.spotlightFilters.forEach(
      (filter) => {
        if (filter.default) {
          this.defaultSpotlight.push(filter.label);
          this.spotlightFilters.push(filter.label);
        }
    });
  }

  toggleMasterFilterView() {
    this.shouldShowMasterFilters = !this.shouldShowMasterFilters;
    this.showMasterFilters.emit(this.shouldShowMasterFilters);
  }

  refresh(selectionState: {[key: string]: CriteriaInterface | CriteriaInterface[]} ) {
    const ref = [];
    const criteriaProcessorFn = (key: string) => {
      return (criteria: CriteriaInterface) => {
        if (criteria.value || criteria.multivalue) {
          ref.push(key);
        } else if (this.defaultSpotlight.includes(key)) {
          this.spotlightFilters.push(key);
        }
      };
    };
    for (const key in selectionState) {
      if (selectionState[key]) {
        // remove filters from the `spotlightFilters`
        this.removeFilterFromSpotlight(key);
        // collect the still-applied filters
        if (selectionState[key] instanceof Array) {
          const hasValue = (selectionState[key] as CriteriaInterface[]).some(
           (criteria) => criteria.value || criteria.multivalue ? true : false
          );
          if (hasValue) {
            ref.push(key);
          } else if (this.defaultSpotlight.includes(key)) {
              this.spotlightFilters.push(key);
          }
        } else {
          criteriaProcessorFn(key)(selectionState[key] as CriteriaInterface);
        }
      }
    }

    if (ref.length > 0) {
    // sort the applied filters
    ref.sort();
    // sort the un-applied filters (which includes only defaults)
    this.spotlightFilters.sort();
    // insert `ref` in the beginning of `spotlightFilters`
    this.spotlightFilters.unshift(...ref);
    } else {
      this.spotlightFilters = this.defaultSpotlight.slice();
    }
  }

  removeFilterFromSpotlight(filtername: string) {
    const removeFromPos = this.spotlightFilters.indexOf(filtername);
    if (removeFromPos  > -1) {
      this.spotlightFilters.splice(removeFromPos, 1);
    }
  }

  changeExecContext(methodFn: any, context: any) {
    return methodFn.bind(context);
  }

  trackByFn(index, value) {
    return value;
  }
}
