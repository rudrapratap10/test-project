import {
  Component, EventEmitter, forwardRef, Input,
  OnChanges, OnInit, Output, SimpleChanges, ViewChild
} from '@angular/core';
import { each } from 'lodash/index';
import { Subject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { PopoverComponent } from '../../../core/bootstrap/popover/popover.component';
import { CriteriaInterface } from '../../../core/interfaces/list/criteria.interface';
import { IFilterArray, IFilterSchema } from '../models/filter-schema.model';
import { FilterSpotlightComponent } from './filter-spotlight.component';

const provider = {
  provide: 'FILTER_PIPE_LINE',
  useExisting: forwardRef(() => FilterPipeLineComponent)
};

@Component({
  selector: 'dew-filter-pipe-line',
  templateUrl: './filter-pipe-line.component.html',
  styleUrls: ['./filter-pipe-line.component.scss'],
  providers: [provider]
})
export class FilterPipeLineComponent implements OnInit, OnChanges {
  @Input()
  isViewSwitched: boolean;

  @Input()
  filterSchema: IFilterSchema;

  showFilters: boolean;

  @Output()
  whenChanged: EventEmitter<any>;

  @Output()
  resetFilters: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  filterViewToggle: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild(FilterSpotlightComponent)
  spotlightComponent: FilterSpotlightComponent;

  @ViewChild(PopoverComponent)
  popover: PopoverComponent;

  shouldShowMasterFilters: boolean;

  addBtnBackgroundColor: boolean;

  // contains the last applied filter values
  selectionState: { [key: string]: CriteriaInterface } = {};

  buffer: { [key: string]: any } = {};

  cookMap: { [key: string]: (value: any) => CriteriaInterface } = {};

  public resetFiltersSubject = new Subject<boolean>();
  public resetFiltersSub = this.resetFiltersSubject.asObservable();

  constructor() {
    this.whenChanged = new EventEmitter();
  }

  ngOnInit() {
    this.addBtnBackgroundColor = false;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.showFilters && !changes.showFilters.currentValue) {
      this.shouldShowMasterFilters = false;
    }
    if (changes.filterSchema && changes.filterSchema.currentValue) {
      this.cookByToCriteriaFn();
    }
  }

  cookByToCriteriaFn() {
    each(this.filterSchema.spotlightFilters, (filterObj: IFilterArray) => {
      if (filterObj.toCriteriaFn) {
        this.cook(filterObj.criteriaKey, filterObj.toCriteriaFn);
      }
    });
  }

  put(key: string, value: any) {
    if (this.isViewSwitched) {
      this.buffer = {};
    }
    this.buffer[key] = value;
  }

  get(key) {
    return this.buffer[key];
  }

  cook(key: string, value: any) {
    this.cookMap[key] = value;
  }

  getCook(key) {
    return this.cookMap[key];
  }

  apply() {
    if (this.isViewSwitched) {
      this.selectionState = {};
    }
    // tslint:disable-next-line:forin
    for (const key in this.buffer) {
      const cook = this.getCook(key);
      this.selectionState[key] = cook(this.get(key));
    }
    this.whenChanged.emit(this.selectionState);
    // this.spotlightComponent.refresh(this.selectionState);
    this.popover.close();
  }

  clear() {
    // tslint:disable-next-line:forin
    for (const key in this.buffer) {
      this.put(key, null);
      const cook = this.getCook(key);
      this.selectionState[key] = cook(this.get(key));
    }
    // this.spotlightComponent.refresh(this.selectionState);
    this.resetFilters.emit(true);
    this.popover.close();
  }

  toggleFilterContainer(popoverState: boolean) {
    this.addBtnBackgroundColor = popoverState;
    if (!popoverState && this.shouldShowMasterFilters) {
      this.showFilters = !popoverState;
    } else {
      this.showFilters = popoverState;
    }
    this.filterViewToggle.emit(popoverState);
  }
}
