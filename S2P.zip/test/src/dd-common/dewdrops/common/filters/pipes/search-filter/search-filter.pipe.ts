import { Pipe, PipeTransform } from '@angular/core';
import { filter } from 'lodash/index';
import { TranslateService } from 'ng2-translate';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {
  constructor(private translateService: TranslateService) {}

  transform(allFilters: any, searchText: string): any {
    if (!searchText) {
      return allFilters;
    }
    const filteredArr = filter(allFilters, (eachFilter) => {
      return this.translateService
        .instant(eachFilter.label)
        .toLowerCase()
        .includes(searchText.toLowerCase());
    });
    return filteredArr || (filteredArr && filteredArr.length === 0) ? filteredArr : allFilters;
  }
}
