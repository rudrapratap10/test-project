import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule, PopoverModule, ButtonsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { FilterPipeLineComponent } from './filter/filter-pipe-line.component';
import { FilterSpotlightComponent } from './filter/filter-spotlight.component';
import { MasterFilterComponent } from './filter/master-filter.component';
import { FormsModule } from '@angular/forms';
import { NgPipesModule } from 'ngx-pipes';
import { SearchFilterPipe } from './pipes/search-filter/search-filter.pipe';
import { ChecklistFilterModule } from '../checklist-filter/checklist-filter.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    TranslateModule,
    PopoverModule,
    LayoutModule,
    ButtonsModule,
    NgPipesModule,
    ChecklistFilterModule
  ],
  declarations: [
    MasterFilterComponent,
    FilterPipeLineComponent,
    FilterSpotlightComponent,
    SearchFilterPipe
  ],
  exports: [
    MasterFilterComponent,
    FilterPipeLineComponent,
    FilterSpotlightComponent
  ]
})
export class FiltersModule { }
