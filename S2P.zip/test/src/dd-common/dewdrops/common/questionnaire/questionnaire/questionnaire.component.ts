import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ElementRef
} from '@angular/core';
import { NgForm } from '@angular/forms';
import { IRadioProperties } from 'dd-common/dewdrops/core/bootstrap/form-control/radio/radio.component';
import { cloneDeep, filter, find } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { IQuestion } from '../models/questionnaire.interface';

@Component({
  selector: 'dew-questionnaire',
  templateUrl: './questionnaire.component.html',
  styleUrls: ['./questionnaire.component.scss']
})

export class QuestionnaireComponent implements OnInit {

  readonly questionTypeValues = {
    multipleChoice: 'MULTISELECT',
    text: 'TEXT',
    yesNo: 'YESNO',
    singleSelect: 'SINGLESELECT',
    numeric: 'NUMERIC',
    attachments: 'ATTACHMENTS',
    table: 'TABLE',
    comments: 'COMMENTS'
  };

  readonly questionTypeKeys = {
    multipleChoice: 'Multiple Choice',
    text: 'Text',
    yesNo: 'Yes / No',
    singleSelect: 'Single Choice',
    numeric: 'Numeric',
    attachments: 'Attachments',
    table: 'Table',
    comments: 'Comments'
  };
  selectQuestiontypes: Array<{
    key: string;
    value: string;
    icon?: string;
  }> = [
      { key: this.questionTypeKeys.multipleChoice, value: this.questionTypeValues.multipleChoice, icon: 'checkbox' },
      { key: this.questionTypeKeys.text, value: this.questionTypeValues.text, icon: 'pdf' },
      // { key: 'DROP DOWN', value: 'Dropdown', icon: 'page'},
      { key: this.questionTypeKeys.yesNo, value: this.questionTypeValues.yesNo, icon: 'radio-button-on' },
      { key: this.questionTypeKeys.singleSelect, value: this.questionTypeValues.singleSelect, icon: 'note' },
      { key: this.questionTypeKeys.numeric, value: this.questionTypeValues.numeric, icon: 'sort-by' },
      { key: this.questionTypeKeys.attachments, value: this.questionTypeValues.attachments, icon: 'browse' },
      { key: this.questionTypeKeys.table, value: this.questionTypeValues.table, icon: 'note' },
      { key: this.questionTypeKeys.comments, value: this.questionTypeValues.comments, icon: 'page' }
    ];
  displaySelectedQuestionType = this.questionTypeKeys.text;

  @Input() questionMaxLength: number;
  @Input() htmlData: any = '';
  @Output() questionnaireObject: EventEmitter<IQuestion> = new EventEmitter<
    IQuestion
  >();

  @Output()
  deleteQuestionObject: EventEmitter<IQuestion> = new EventEmitter<IQuestion>();

  @Output()
  setRules: EventEmitter<boolean> = new EventEmitter<boolean>();

  @ViewChild('form') ngForm: NgForm;

  @Input() questionInst: IQuestion;
  questionObject: IQuestion;
  selectedIcon = 'pdf';
  shouldShowInputBox = false;
  showNoteTextBox = false;
  text1: string;
  radioOptions: IRadioProperties[];
  preVIndex: number;
  inputTypeRef: ElementRef;

  columnType = [
    { id: '1', name: 'TEXT' },
    { id: '2', name: 'NUMBER' },
    { id: '3', name: 'LIST' }
  ];

  showInsertLengthPopup: boolean = false;
  showTableStructurePopup: boolean = false;
  tableConfig: any = {
    rows: 1,
    columns: 1
  };

  activeColObj: any;
  defaultColIndex: any;
  colType: string = '';
  @ViewChild('colOptionForm') colOptionForm: NgForm;
  defaultOptions = [{
    sequence: 1,
    textValue: 'Option 1',
    isEditable: false,
    isSelected: false
  },
  {
    sequence: 2,
    textValue: 'Option 2',
    isEditable: false,
    isSelected: false
  }];

  oldValue = '';
  disableOther: boolean;
  minError = false;
  maxError = false;
  copyOfOptions = [];
  copyOfDefaultOption: string;
  constructor(
    private _language: TranslateService
  ) {
    this.initilizeQuestionObject();
  }

  ngOnInit() {

    this.radioOptions = [
      { value: 'Yes', label: 'Yes', isDisabled: false },
      { value: 'No', label: 'No', isDisabled: false },
      { value: 'Maybe', label: 'Maybe', isDisabled: false }
    ];

    this.resetValue(this.questionTypeValues.text);
    this.initilizeQuestionObject(this.questionInst);

    this.ngForm.form.valueChanges.subscribe((x) => {
      this.questionObject.id = this.questionInst ? this.questionInst.id : null;
      this.questionnaireObject.emit(this.questionObject);
    });
  }

  emitQuestionObject() {
    this.questionnaireObject.emit(this.questionObject);
  }
  getEditorData(data) {
    this.questionObject.text = data;
    this.emitQuestionObject();
  }
  initilizeQuestionObject(editCase?: IQuestion) {
    this.questionObject = {
      id: editCase ? editCase.id : null,
      text: editCase ? editCase.text : '',
      options: editCase ? editCase.options : [],
      type: editCase ? editCase.type : this.questionTypeValues.text,
      notes: editCase ? editCase.notes : '',
      answer: editCase ? editCase.answer : [],
      properties: {
        isSupplierCommentDisable: editCase ? editCase.properties.isSupplierCommentDisable : false,
        isHidden: editCase ? editCase.properties.isHidden : false,
        isMandatory: editCase ? editCase.properties.isMandatory : false
      },
      settings: {
        maxTextLength: (editCase && editCase.settings) ? editCase.settings.maxTextLength : 2000,
        minValue: (editCase && editCase.settings) ? editCase.settings.minValue : 0,
        maxValue: (editCase && editCase.settings) ? editCase.settings.maxValue : 0,
        label: '',
        rowCalculation: 'NONE',
        columnCalculation: 'TOTAL',
        isDataSetupOnRow: true,
        rowHeaders: {
          header: []
        },
        columnHeaders: {
          header: []
        }
      },
      status: editCase ? editCase.status : 'DEFAULT',
      sequence: editCase ? editCase.sequence : 1,
      comment: editCase ? editCase.comment : ''
    };
    if (editCase) {
      this.displaySelectedQuestionType = this.questionTypeKeys[editCase.type];
      this.selectedOption(find(this.selectQuestiontypes, ['value', editCase.type]));
    }
  }

  selectedOption(event) {
    this.selectedIcon = '';
    this.displaySelectedQuestionType = '';
    this.questionObject.type = event.value;
    this.displaySelectedQuestionType = event.key;
    this.selectedIcon = event.icon;

    this.resetValue(event.value);
    if (event.key === 'Table') {
      this.showTableStructurePopup = true;
    }
  }
  // empty options' value on changing the question type
  resetValue(data) {
    this.disableOther = false;
    if (this.oldValue === '') {
      this.oldValue = this.questionObject.type;
    } else if (this.oldValue !== data) {
      this.oldValue = data;
      this.questionObject.options = [];
      this.questionObject.answer = [];
      if (this.questionObject.type === this.questionTypeValues.multipleChoice
        || this.questionObject.type === this.questionTypeValues.singleSelect) {
        for (let index = 0; index < 3; index++) {
          const data1 = this.dataObject(`option ${index + 1}`);
          this.questionObject.options.push(data1);
        }
      }

      this.copyOfOptions = cloneDeep(this.questionObject.options);

      if (data === this.questionTypeValues.yesNo) {
        this.questionObject.options.push(...this.radioOptions);
      }
    }
  }

  dataObject(data) {
    return {
      value: data,
      isEditable: false
    };
  }

  // on click of add push a data and show input box
  addOption(other?: string) {
    if (other && !this.disableOther) {
      const data = this.dataObject(other);
      this.questionObject.options.push(data);
      this.shouldShowInputBox = false;
      this.disableOther = true;
    } else if (!other) {
      this.text1 = '';
      this.shouldShowInputBox = true;
    }
  }

  // delete respective data
  deleteOptions(index, selectedOption?) {
    if (selectedOption !== undefined) {
      this.questionObject.options.splice(index, 1);
      this.copyOfOptions = cloneDeep(this.questionObject.options);
      this.questionObject.answer = this.questionObject.answer.filter((ele) => {
        if (!Object.is(ele.value, selectedOption.value)) {
          return true;
        }
      });
      if (selectedOption.value === 'Other') {
        this.disableOther = false;
      }
    } else {
      this.shouldShowInputBox = false;
    }

  }

  edit(index, event) {
    if (this.questionObject.options[index].value !== 'Other') {
      this.questionObject.options[index].isEditable = true;
    } else {
      return false;
    }

  }

  hideEditInputBox(index) {
    const regex = /.*[^ ].*/;
    if (!(this.questionObject.options[index].value.match)(regex)) {
      this.questionObject.options[index].value = this.copyOfOptions[index].value;
    } else {
      this.copyOfOptions[index].value = this.questionObject.options[index].value;
    }
    this.questionObject.options[index].isEditable = false;
  }

  // show note textarea
  shouldShowNoteTextBox() {
    this.showNoteTextBox = !this.showNoteTextBox;
    if (!this.showNoteTextBox) {
      this.questionObject.notes = '';
    }
  }

  // validation for characters
  preventInput(event) {
    const value = this.questionObject.settings.maxTextLength;
    if (value >= 2000) {
      event.preventDefault();
      this.questionObject.settings.maxTextLength = parseInt(
        value.toString().substring(0, 2), 10);
    }
  }

  // pass selected to option to answer if YES_NO selected as question type
  // selectedAnswer(event) {
  //   this.questionObject.answer = [];
  //   const data = this.dataObject(event);
  //   data.isSelected = true;
  //   this.questionObject.answer.push(data);
  // }

  // add data to options
  pushDataToQuestionsOptions() {
    const regex = /.*[^ ].*/;
    if (this.text1) {
      const data = this.dataObject(this.text1);
      if ((data.value.match)(regex)) {
        this.questionObject.options.push(data);
        this.copyOfOptions = cloneDeep(this.questionObject.options);
        this.text1 = '';
      }
    }
    this.shouldShowInputBox = false;


    // const regex = /.*[^ ].*/;
    // if ((this.text1.match) (regex)) {
    //   this.questionObject.options[index].isEditable = false;
    //   this.questionObject.options[index].label = this.text1;
    //   this.questionObject.options[index].value = this.text1;
    // } else {
    //     this.text1 = this.questionObject.options[index].value;
    //     this.questionObject.options[index].isEditable = false;

    // }

    // const regex = /.*[^ ].*/;
    // if (this.text1) {
    //   if ((this.text1.match) (regex)) {
    //     alert("hi");
    //   } else {
    //       const data = this.dataObject(this.text1);
    //       this.questionObject.options.push(data);
    //       this.text1 = undefined;
    //   }
    // }
    // this.shouldShowInputBox = false;
  }

  // push selected data to answer
  selectoptions(event, selectedOption) {
    const optionInAns = find(this.questionObject.answer, (ans) => ans.value === selectedOption.value);
    if (optionInAns) {
      if (event.srcElement.checked) {
        optionInAns.isSelected = event.srcElement.checked;
      } else {
        this.questionObject.answer = filter(this.questionObject.answer, (ans) => ans.value !== selectedOption.value);
      }
    } else {
      if (event.srcElement.checked) {
        const ansToPush = cloneDeep(selectedOption);
        ansToPush.isSelected = event.srcElement.checked;
        this.questionObject.answer.push(ansToPush);
      }
    }

    this.emitQuestionObject();
  }

  // return
  minValidation() {
    if (
      this.questionObject.settings.minValue >
      this.questionObject.settings.maxValue
    ) {
      this.minError = true;
      this.maxError = false;
    } else {
      this.minError = false;
      this.maxError = false;
    }
  }

  maxValidation() {
    if (
      this.questionObject.settings.maxValue <
      this.questionObject.settings.minValue
    ) {
      this.minError = false;
      this.maxError = true;
    } else {
      this.minError = false;
      this.maxError = false;
    }
  }

  emitSetRule() {
    this.setRules.emit(true);
  }

  deleteObject() {
    this.deleteQuestionObject.emit(this.questionObject);
  }

  onTableConfigChange() {
    this.tableConfig.rows = this.questionObject.settings.rowHeaders.header.length;
    this.tableConfig.columns = this.questionObject.settings.columnHeaders.header.length;
    this.saveTableStructurePopup();
  }

  addCol(column, index, criteria) {
    // Cloning object -- Need to be optimized with alternate approach
    const newCol = JSON.parse(JSON.stringify(column));
    newCol.tempId = Math.floor(Math.random() * new Date().getMilliseconds()) + newCol.tempId;

    switch (criteria) {
      case 'RIGHT':
        this.questionObject.settings.columnHeaders.header.splice(index, 0, newCol);
        break;
      case 'LEFT':
        this.questionObject.settings.columnHeaders.header.splice(index - 1, 0, newCol);
        break;
      case 'REMOVE':
        // tslint:disable-next-line:max-line-length
        this.questionObject.settings.columnHeaders.header.length > 1 ? this.questionObject.settings.columnHeaders.header.splice(index, 1) : '';
        break;
    }

  }

  addRow(row, index, criteria) {
    // Cloning object -- Need to be optimized with alternate approach
    const newRow = JSON.parse(JSON.stringify(row));
    newRow.tempId = Math.floor(Math.random() * new Date().getMilliseconds()) + newRow.tempId;

    switch (criteria) {
      case 'TOP':
        this.questionObject.settings.rowHeaders.header.splice(index, 0, newRow);
        break;
      case 'BOTTOM':
        this.questionObject.settings.rowHeaders.header.splice(index - 1, 0, newRow);
        break;
      case 'REMOVE':
        // tslint:disable-next-line:max-line-length
        this.questionObject.settings.rowHeaders.header.length > 1 ? this.questionObject.settings.rowHeaders.header.splice(index, 1) : '';
        break;
    }

  }

  openInsertLengthPopup(item, index) {
    this.defaultColIndex = index;
    this.activeColObj = cloneDeep(item);
    if (this.activeColObj.dataTypeSetup.options && this.activeColObj.dataTypeSetup.options.option.length > 0) {
      this.activeColObj.dataTypeSetup.options = {
        option: this.activeColObj.dataTypeSetup.options.option
      };
    } else {
      this.activeColObj.dataTypeSetup.options = {
        option: this.defaultOptions
      };
    }
    this.colType = this.activeColObj.dataTypeSetup.type;
    this.showInsertLengthPopup = true;
  }

  closeInsertLengthPopup() {
    this.showInsertLengthPopup = false;
  }

  saveInsertLengthPopup() {

    if (this.questionObject.settings.isDataSetupOnRow) {
      this.questionObject.settings.rowHeaders.header[this.defaultColIndex] = this.activeColObj;
    } else {
      this.questionObject.settings.columnHeaders.header[this.defaultColIndex] = this.activeColObj;
    }
    this.defaultColIndex = null;
    this.showInsertLengthPopup = false;
  }

  edit2(index, data) {
    if (data.textValue !== 'Other') {
      this.copyOfDefaultOption = data.textValue;
      data.isEditable = true;
    } else {
      return false;
    }

  }

  hideEditInputBox2(data) {
    const regex = /.*[^ ].*/;
    if (!(data.textValue.match)(regex)) {
      data.textValue = this.copyOfDefaultOption;
    }
    data.isEditable = false;
  }

  addOption2(colArr: any[]) {
    this.copyOfDefaultOption = 'Option ' + Number(colArr.length + 1);
    colArr.push({ 'sequence': Number(colArr.length + 1), 'textValue': '', 'isSelected': null, 'isEditable': true });
  }

  deleteOptions2(index, arr) {
    if (this.activeColObj.dataTypeSetup.options.option.length > 1) {
      arr.splice(index, 1);
    } else {
      alert('Minimum 1 option need to be present')
    }
  }

  saveTableStructurePopup() {
    this.questionObject.settings.rowHeaders.header = [];
    this.questionObject.settings.columnHeaders.header = [];
    for (var i = 0; i < this.tableConfig.rows; i++) {
      var defaultRowObj = {
        "title": "Row Title " + Number(i + 1),
        "tempId": i + 1,
        "dataTypeSetup": {
          "type": "TEXT",
          "options": null,
          "textMaxLength": null,
          "numberMinValue": null,
          "numberMaxValue": null
        }
      };
      this.questionObject.settings.rowHeaders.header.push(defaultRowObj);
    }

    for (var i = 0; i < this.tableConfig.columns; i++) {
      var defaultColObj = {
        "title": "Col Title " + Number(i + 1),
        "tempId": i + 1,
        "dataTypeSetup": {
          "type": "TEXT",
          "options": null,
          "textMaxLength": null,
          "numberMinValue": null,
          "numberMaxValue": null
        }
      };
      this.questionObject.settings.columnHeaders.header.push(defaultColObj);
    }
    this.showTableStructurePopup = false;
  }

  closeTableStructurePopup() {
    this.displaySelectedQuestionType = this.questionTypeKeys['text'];
    this.selectedOption(find(this.selectQuestiontypes, ['value', this.displaySelectedQuestionType.toUpperCase()]));
    this.showTableStructurePopup = false;
  }

}
