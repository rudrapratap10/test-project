import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { FormArray, FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { IRadioProperties } from 'dd-common/dewdrops/core/bootstrap/form-control/radio/radio.component';
import { cloneDeep, filter, find } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { IQuestion } from '../models/questionnaire.interface';
import { UnderscorePipe } from 'ngx-pipes';

@Component({
  selector: 'dew-question',
  templateUrl: './question-reactive.component.html',
  styleUrls: ['./question-reactive.component.scss']
})

export class QuestionComponent implements OnInit {

  readonly questionTypeValues = {
    multipleChoice: 'MULTISELECT',
    text: 'TEXT',
    yesNo: 'YESNO',
    singleSelect: 'SINGLESELECT',
    numeric: 'NUMERIC',
    attachments: 'ATTACHMENTS',
    table: 'TABLE',
    comments: 'COMMENTS'
  };

  readonly questionTypeKeys = {
    multipleChoice: 'Multiple Choice',
    text: 'Text',
    yesNo: 'Yes / No',
    singleSelect: 'Single Choice',
    numeric: 'Numeric',
    attachments: 'Attachments',
    table: 'Table',
    comments: 'Comments'
  };

  selectQuestiontypes: Array<{
    key: string;
    value: string;
    icon?: string;
  }> = [
      { key: this.questionTypeKeys.multipleChoice, value: this.questionTypeValues.multipleChoice, icon: 'checkbox' },
      { key: this.questionTypeKeys.text, value: this.questionTypeValues.text, icon: 'pdf' },
      { key: this.questionTypeKeys.yesNo, value: this.questionTypeValues.yesNo, icon: 'radio-button-on' },
      { key: this.questionTypeKeys.singleSelect, value: this.questionTypeValues.singleSelect, icon: 'note' },
      { key: this.questionTypeKeys.numeric, value: this.questionTypeValues.numeric, icon: 'sort-by' },
      { key: this.questionTypeKeys.attachments, value: this.questionTypeValues.attachments, icon: 'browse' },
      { key: this.questionTypeKeys.table, value: this.questionTypeValues.table, icon: 'note' },
      { key: this.questionTypeKeys.comments, value: this.questionTypeValues.comments, icon: 'page' }
    ];

  oldValue: string;
  disableOther: boolean;
  shouldShowInputBox: boolean;
  displaySelectedQuestionType = this.selectQuestiontypes[0].key;
  selectedIcon = 'checkbox';
  text1: string;
  showNoteTextBox = false;

  copyOfOptions = new FormArray([]);
  radioOptions: FormArray;

  @Input()
  questionForm: FormGroup;
  @Output()
  questionFormChange: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

  @Output()
  deleteQuestionObject: EventEmitter<FormGroup> = new EventEmitter<FormGroup>();

  constructor(
    private formBuilder: FormBuilder
  ) {}

  ngOnInit() {
    this.radioOptions = this.formBuilder.array([
      { value: 'Yes', label: 'Yes', isDisabled: false },
      { value: 'No', label: 'No', isDisabled: false },
      { value: 'Maybe', label: 'Maybe', isDisabled: false }
    ]);

    this.formInitialization(this.questionForm);
    this.pushStaticDataToOptions(this.questionForm);

    this.questionForm.valueChanges.subscribe((res) => {
      console.log(this.questionForm);
      this.questionFormChange.emit(this.questionForm);
    });
  }

  // formInitialization() {
  //   this.questionForm = this.formBuilder.group({
  //     id: [null],
  //     text: ['', Validators.maxLength(2000)],
  //     options: this.formBuilder.array([]),
  //     type: [this.selectQuestiontypes[0]],
  //     notes: [''],
  //     settings: this.formBuilder.group({
  //       maxTextLength: [null, Validators.max(2000)],
  //       minValue: [null, Validators.compose([Validators.min(-1), Validators.max(999999999999999)])],
  //       maxValue: [null, Validators.compose([Validators.min(-1), Validators.max(999999999999999)])]
  //     }),
  //     properties: this.formBuilder.group({
  //       isSupplierCommentDisable: [false],
  //       isHidden: [false],
  //       isMandatory: [false]
  //     })
  //   });
  // }

  formInitialization(userFormDataa?) {
    const userFormData = userFormDataa ? userFormDataa.value : undefined;
    this.questionForm = this.formBuilder.group ({
      id: [userFormData ? userFormData.id : null],
      // tslint:disable-next-line:max-line-length
      text: [userFormData ? userFormData.text : '', Validators.compose([Validators.required, Validators.maxLength(2000)])],
      options: this.formBuilder.array([]),
      type: [userFormData ? userFormData.type : this.selectQuestiontypes[0]],
      notes: [userFormData ? userFormData.notes : ''],
      settings: this.formBuilder.group({
        maxTextLength: [userFormData ? userFormData.settings.maxTextLength : null, Validators.max(2000)],
        // tslint:disable-next-line:max-line-length
        minValue: [userFormData ? userFormData.settings.minValue : null, Validators.compose([Validators.min(-1), Validators.max(999999999999999)])],
        // tslint:disable-next-line:max-line-length
        maxValue: [userFormData ? userFormData.settings.maxLength : null, Validators.compose([Validators.min(-1), Validators.max(999999999999999)])]
      }),
      properties: this.formBuilder.group({
        isSupplierCommentDisable: [ userFormData ? userFormData.isSupplierCommentDisable : false],
        isHidden: [ userFormData ? userFormData.isHidden : false],
        isMandatory: [ userFormData ? userFormData.isMandatory : false]
      })
    });
  }

  get options(): FormArray {
    return this.questionForm.get('options') as FormArray;
  }

  selectedOption(event) {
    this.selectedIcon = '';
    this.selectedIcon = event.icon;
    this.questionForm.get('type').patchValue(event);
    this.displaySelectedQuestionType = this.questionForm.get('type').value.value;
    this.resetValue(event);
  }

  // empty options' value on changing the question type
  resetValue(data) {
    this.disableOther = false;
    if (this.oldValue === '') {
      this.oldValue = this.questionForm.get('type').value;
    } else if (this.oldValue !== data) {
      this.oldValue = data;

      this.options.controls.splice(0, this.options.controls.length);

      this.pushStaticDataToOptions();

      if (data.key === this.questionTypeKeys.yesNo) {
        this.radioOptions.controls.forEach((ele) => {
          this.options.push(ele);
        });
      }
    }
  }

  pushStaticDataToOptions(userFormData?) {
    const userForm = userFormData;
    if (userForm.value && userForm.value.options.length) {
      this.options.push(userForm.value.options);
    } else {
      if (this.questionForm.get('type').value.value === this.questionTypeValues.multipleChoice
      || this.questionForm.get('type').value.value === this.questionTypeValues.singleSelect) {
        for (let index = 0; index < 3; index++) {
          const data1 = this.dataObject(`option ${index + 1}`);
          this.options.push(data1);
        }
      }
    }

    if (this.options.controls && this.options.controls.length) {
      this.options.controls.forEach((ele) => {
        this.copyOfOptions.push(ele);
      });
    }
  }

  // delete respective data
  deleteOptions(index, selectedOption?) {
    if (selectedOption !== undefined) {
      this.options.controls.splice(index, 1);
      // this.copyOfOptions = cloneDeep(this.questionObject.options);
      if (selectedOption.value.value === 'Other') {
        this.disableOther = false;
      }
    } else {
      this.shouldShowInputBox = false;
    }
  }

  dataObject(data) {
    return this.formBuilder.group({
      value: data,
      isEditable: false
    });
  }

  edit(index, event) {
    if (this.options.controls[index].value !== 'Other') {
      (this.options.controls[index] as FormGroup).controls.isEditable.setValue(true);
    } else {
      return false;
    }
  }

  // add data to options
  pushDataToQuestionsOptions() {
    const regex = /.*[^ ].*/;
    if (this.text1) {
      const data = this.dataObject(this.text1);
      if ((data.value.value.match)(regex)) {
        this.options.push(data);
        this.text1 = '';
      }
    }
    this.shouldShowInputBox = false;

  }

  hideEditInputBox(index) {
    const regex = /.*[^ ].*/;
    if (!(this.options.controls[index].value.value.match)(regex)) {
      this.options.controls[index].value.setValue(this.copyOfOptions[index].controls.value.value);
    } else {
      (this.copyOfOptions.controls[index] as FormGroup).controls.value
      .setValue((this.options.controls[index] as FormGroup).controls.value.value);
    }
    (this.options.controls[index] as FormGroup).controls.isEditable.setValue(false);
  }

  addOption(other?: string) {
    if (other && !this.disableOther) {
      const data = this.dataObject(other);
      this.options.push(data);
      this.shouldShowInputBox = false;
      this.disableOther = true;
    } else if (!other) {
      this.text1 = '';
      this.shouldShowInputBox = true;
    }
  }

  // show note textarea
  shouldShowNoteTextBox() {
    this.showNoteTextBox = !this.showNoteTextBox;
    if (!this.showNoteTextBox) {
      this.questionForm.get('notes').patchValue('');
    }
  }

  // // validation for characters
  // preventInput(event) {
  //   console.log(this.questionForm.value.settings.maxTextLength);

  //   const value = this.questionForm.value.settings.maxTextLength;
  //   if (value >= 2000) {
  //     event.preventDefault();
  //     this.questionForm.value.settings.maxTextLength = parseInt(value.toString().substring(0, 2), 10);
  //   }
  // }

  deleteObject() {
    this.deleteQuestionObject.emit(this.questionForm);
  }

}
