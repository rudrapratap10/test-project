import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { CharacterCountModule } from '../../core/bootstrap/character-count/character-count.module';
import { ListingViewModule } from '../listing-view/listing-view.module';
import { TextEditorModule } from '../text-editor/text-editor.module';
import { UtilityModule } from '../utility/utility.module';
import { QuestionComponent } from './question-reactive/question-reactive.component';
import { QuestionnaireComponent } from './questionnaire/questionnaire.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    GlobalUIModule,
    CharacterCountModule,
    TranslateModule,
    TextEditorModule,
    ListingViewModule,
    UtilityModule,
    ReactiveFormsModule
  ],
  declarations: [
    QuestionnaireComponent,
    QuestionComponent
  ],
  exports: [
    QuestionnaireComponent,
    QuestionComponent
  ]
})
export class QuestionnaireModule { }
