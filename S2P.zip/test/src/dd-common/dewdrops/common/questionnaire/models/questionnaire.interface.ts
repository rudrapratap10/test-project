export interface IActions {
  isSupplierCommentDisable: boolean;
  isHidden: boolean;
  isMandatory: boolean;
}
export interface ITableRowHeader {
  title?: string;			// not null
  tempId?: any;
  sequence?: number;		// should be a number and not null
  dataTypeSetup?: {
    type?: string;		// TEXT; NUMBER or LIST
    options?: {
      option: any[]
    };
    textMaxLength?: number;		// number
    numberMinValue?: any;
    numberMaxValue?: any
  };
}

export interface ITableColumnHeader {
  title?: string;		// not null
  tempId?: any;
  sequence?: number;		// should be a number and not null
  dataTypeSetup?: any;
}

export interface IQuestion {
  id?: number;
  text: string; // user's question
  options: any[]; // user's option given for the respective question
  type: string;
  notes?: string;
  answer?: any[]; // user's given answer
  settings: {
    maxTextLength: number, minValue: number, maxValue: number,
    label?: string,		// cannot be null
    rowCalculation?: string,			// NONE, TOTAL or AVERAGE
    columnCalculation?: string,		// NONE, TOTAL or AVERAGE
    isDataSetupOnRow?: boolean,	// should be true or false, cannot be null
    rowHeaders?: {		// cannot be null
      header?: ITableRowHeader[]
    },
    columnHeaders?: {		// cannot be null
      header?: ITableColumnHeader[]
    },
    deletedTableCells?: any
  };
  properties: IActions; // footer settings,
  status?: 'DEFAULT';
  sequence?: number;
  comment?: string;
}
