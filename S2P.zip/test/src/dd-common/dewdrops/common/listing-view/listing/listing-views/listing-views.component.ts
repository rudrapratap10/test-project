import { Component, EventEmitter, Input, OnInit, Output, ViewContainerRef } from '@angular/core';
import { FilterInterface } from '@dewdrops/interfaces';
import { find } from 'lodash/index';
import { TranslateService } from 'ng2-translate';
import { CommonOverlayBuilder } from '../../../overlay/overlay-builder.service';
import { IListingViewsApi, IListingViewsSchema, IViewData } from '../../interfaces/listing-view.interface';
import { ListingViewsService } from './service/listing-views/listing-views.service';

export enum ListingViewActionType {
  NONE = 1,
  RENAME,
  DEFAULT,
  DUPLICATE,
  NEW_VIEW,
  DELETE,
  UPDATE_EXISTING_VIEW
}

@Component({
  selector: 'dew-listing-views',
  templateUrl: './listing-views.component.html',
  styleUrls: ['./listing-views.component.scss']
})
export class ListingViewsComponent implements OnInit {
  @Input()
  listingViewsSchema: IListingViewsSchema;

  public selectedViewName: string;

  @Input()
  public defaultViewName: string;

  @Input()
  public totalRecords: number;

  @Input()
  public gridColumns: any[];

  public viewList: any[];

  @Output()
  productDefaultViewSwitched = new EventEmitter();

  /**
   * emits view item object
   */
  @Output()
  selectedViewChanged: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  selectedViewUpdated: EventEmitter<ListingViewActionType> = new EventEmitter<ListingViewActionType>();

  public isUserView: boolean;
  public togglePopupType = ListingViewActionType;
  public activePopupType: ListingViewActionType;
  public setDefaultView = false;
  public setProductDefaultView = false;
  public selectedViewId: string;
  private defaultViewId: string;
  private loadDefaultView: boolean;
  private loadProductDefaultView: boolean;
  private progressOverlay;
  constructor(
    private viewContainer: ViewContainerRef,
    private overlayBuilder: CommonOverlayBuilder,
    private listViewService: ListingViewsService,
    private _language: TranslateService) { }

  ngOnInit() {
    this.getViewsDetails();
  }

  defaultViewSelected() {
    if (this.defaultViewName) {
      this.selectedViewName = this.defaultViewName;
      this.selectedViewId = this.defaultViewId;
      this.productDefaultViewSwitched.emit(true);
    } else {
      this.defaultViewNotPresent();
    }
  }

  getViewsDetails() {
    // this.progressOverlay =
      // this.overlayBuilder.progress(this.viewContainer)(this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING'));
    if (this.listingViewsSchema) {
    this.listViewService.getAllViews(this.listingViewsSchema.getAllViews).subscribe((response) => {
      this.viewList = [];
      this.isUserView = false;
      if (response.data) {
        if (response.data.records) {
          if (response.data.records.length >= 1 ) {
            response.data.records.forEach((record) => {
              const viewObj: any = {};
              viewObj.viewId = record.filterId || record.viewId;
              viewObj.viewName = record.filterName || record.viewName;
              viewObj.filters = record.filters;
              viewObj.sorts = record.sorts;
              this.viewList.push(viewObj);
              if (record.isDefault) {
                this.loadDefaultView = true;
                this.defaultViewName = record.filterName || record.viewName;
                this.defaultViewId = record.filterId || record.viewId;
                this.selectedViewName = this.defaultViewName;
                this.selectedViewId = this.defaultViewId;
              }
            });
          }
        }
      }
      this.viewList.sort((a, b) => {
        const textA = a.viewName.toLowerCase();
        const textB = b.viewName.toLowerCase();
        return textA < textB ? -1 : textA > textB ? 1 : 0;
      });
      if (this.viewList.length) {
        this.isUserView = true;
      }
      if (this.loadDefaultView === true) {
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
        this.getSavedView(this.defaultViewId);
        this.loadDefaultView = false;
      } else {
        this.loadProductDefaultView = true;
        this.switchToProductDefaultView();
      }
      if (!this.defaultViewName && this.viewList.length) {
        this.defaultViewNotPresent();
      }
      // this.progressOverlay.clear();
    },
    // (error) => {
    //   if (this.progressOverlay) {
    //     this.progressOverlay.clear();
    //   }
    // }
    );
  }
  }

  updateViewSelection(item) {
    this.selectedViewName = item.filterName || item.viewName;
    this.selectedViewId = item.filterId || item.viewId;
    this.selectedViewChanged.emit(item);
  }

  defaultViewNotPresent() {

      this.defaultViewName = this.viewList[0].viewName;
      this.defaultViewId = this.viewList[0].viewId;
      this.selectedViewName = this.defaultViewName;
      this.selectedViewId = this.defaultViewId;
      this.updateViewSelection(this.viewList[0]);

  }

  getSavedView(viewId) {
    if (this.progressOverlay) {
      this.progressOverlay.clear();
    }
    this.progressOverlay =
      this.overlayBuilder.progress(this.viewContainer)(this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING'));
    this.listViewService
      .getViewById(this.listingViewsSchema.getViewById, viewId)
      .subscribe((response) => {
        this.selectedViewName = response.data.filterName || response.data.viewName;
        this.selectedViewId = response.data.filterId || response.data.viewId;
        this.progressOverlay.clear();
      });
  }

  switchToProductDefaultView() {
    this.selectedViewId = this.defaultViewId;
    this.selectedViewName = this.defaultViewName;
    this.productDefaultViewSwitched.emit(true);
  }

  setParam(isDefaultt: boolean, filters: any, currentView?: string): any {
    let updateViewParam;
    if (this.setDefaultView || this.setProductDefaultView) {
      if (this.setDefaultView) {
        updateViewParam = {
          pageName: this.listingViewsSchema.pageName,
          filterName: currentView,
          isDefault: true,
          advancedFilters: null,
          filters: JSON.stringify(filters),
          sortColumn: -1,
          sortType: null,
          displayRecords: 10
        };
      } else if (this.setProductDefaultView) {
        updateViewParam = {
          pageName: this.listingViewsSchema.pageName,
          filterName: currentView,
          isDefault: false,
          advancedFilters: null,
          filters: JSON.stringify(filters),
          sortColumn: -1,
          sortType: null,
          displayRecords: 10
        };
      }
    } else if (this.activePopupType === this.togglePopupType.RENAME) {
      updateViewParam = {
        pageName: this.listingViewsSchema.pageName,
        filterName: currentView,
        isDefault: isDefaultt,
        advancedFilters: null,
        filters: JSON.stringify(filters),
        sortColumn: -1,
        sortType: null,
        displayRecords: 10
      };
    } else if (this.activePopupType === this.togglePopupType.DUPLICATE) {
      updateViewParam = {
        pageName: this.listingViewsSchema.pageName,
        filterName: currentView,
        isDefault: false,
        advancedFilters: null,
        filters: JSON.stringify(filters),
        sortColumn: -1,
        sortType: null,
        displayRecords: filters.perPageRecords
      };
    } else if (this.activePopupType === this.togglePopupType.NEW_VIEW) {
      updateViewParam = {
        pageName: this.listingViewsSchema.pageName,
        filterName: currentView,
        isDefault: isDefaultt || false,
        advancedFilters: null,
        filters: JSON.stringify(filters),
        sortColumn: -1,
        sortType: null,
        displayRecords: filters.perPageRecords
      };
    } else {
      updateViewParam = {
        pageName: this.listingViewsSchema.pageName,
        filterName: currentView,
        isDefault: isDefaultt,
        advancedFilters: null,
        filters: JSON.stringify(filters),
        sortColumn: -1,
        sortType: null,
        displayRecords: 10
      };
    }

    return updateViewParam;
  }

  updateView(eventObj: { type: ListingViewActionType; data: any }) {
    this.progressOverlay =
      this.overlayBuilder.progress(this.viewContainer)(this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING'));
    if (eventObj.type === this.togglePopupType.RENAME) {
      this.renameView(eventObj);
    } else if (eventObj.type === this.togglePopupType.UPDATE_EXISTING_VIEW) {
      this.updateExistingView(eventObj);
    } else if (eventObj.type === this.togglePopupType.DUPLICATE) {
      this.duplicateCurrentView(eventObj);
    } else if (eventObj.type === this.togglePopupType.NEW_VIEW) {
      this.createNewView(eventObj);
    } else if (eventObj.type === this.togglePopupType.DEFAULT) {
      this.updateDefaultView(eventObj);
    }
  }

  updateDefaultView(eventObj) {
    if (!this.setProductDefaultView) {
      this.defaultViewId = eventObj.data.id;
      this.defaultViewName = eventObj.data.value;
      const filters = this.listingViewsSchema.viewCriteria;
      const filterCriteria = filters.criteriaGroup.criteria.filter((obj) => delete obj.operation );
      let updateViewParam;
      if (this.listingViewsSchema.defaultView.bodyTransformFn) {
        updateViewParam = this.listingViewsSchema.createNewView.bodyTransformFn({
          id: this.selectedViewId,
          name: eventObj.data.value,
          gridColumns: this.gridColumns,
          filters: filterCriteria,
        } as IViewData);
      } else {
        if (this.listingViewsSchema.defaultView.body &&
        this.listingViewsSchema.defaultView.body.viewId !== undefined) {
        updateViewParam = {
          viewId: eventObj.data.id.toString()
        };
      } else {
        updateViewParam =  this.setParam(
          true,
          filters,
          this.defaultViewName
        );
      }
      }
      const apiConfig: IListingViewsApi = {
        url: this.listingViewsSchema.defaultView.url,
        body: updateViewParam,
        method: this.listingViewsSchema.defaultView.method
      };

      this.listViewService.setDefaultView(apiConfig, this.defaultViewId).subscribe((response) => {
        this.getViewsDetails();
        this.getSavedView(this.defaultViewId);
      });
    } else {
      this.switchToProductDefaultView();
    }
    this.setDefaultView = false;
    this.setProductDefaultView = false;
  }

  createNewView(eventObj) {
    // const updateViewParam = this.setParam(
    //   eventObj.data.isDefault,
    //   this.listingViewsSchema.viewCriteria,
    //   eventObj.data.value
    // );
    let updateViewParam: any;
    const filter = this.listingViewsSchema.viewCriteria;
    const filterCriteria = filter.criteriaGroup.criteria.filter((obj) => delete obj.operation );
    if (this.listingViewsSchema.createNewView.bodyTransformFn) {
      updateViewParam = this.listingViewsSchema.createNewView.bodyTransformFn({
        id: this.selectedViewId,
        name: eventObj.data.value,
        gridColumns: this.gridColumns,
        filters: filterCriteria,
      } as IViewData);
    } else {
      if (this.listingViewsSchema.createNewView.body &&
        this.listingViewsSchema.createNewView.body.viewId !== undefined) {
        updateViewParam = {
          viewId: this.selectedViewId,
          viewName: this.selectedViewName,
          gridColumns: this.gridColumns,
          filters: filterCriteria
        };
      } else {
        updateViewParam =  this.setParam(
          eventObj.data.isDefault,
        this.listingViewsSchema.viewCriteria,
        eventObj.data.value
        );
      }
    }
    const apiConfig: IListingViewsApi = {
      url: this.listingViewsSchema.createNewView.url,
      body: updateViewParam,
      method: this.listingViewsSchema.createNewView.method
    };
    this.listViewService.createView(apiConfig).subscribe(
      (response) => {
        const obj = {
          viewId: response.data.id,
          viewName: eventObj.data.value
        };
        this.viewList.push(obj);
        if (eventObj.data.isDefault) {
          this.getSavedView(response.data.id);
          this.defaultViewId = response.data.id;
          this.defaultViewName = eventObj.data.value;
        }
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
        this.activePopupType = this.togglePopupType.NONE;
      }, (error) => {
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
        this.activePopupType = this.togglePopupType.NONE;
      });

  }

  duplicateCurrentView(eventObj) {
    let updateViewParam: any;
    const filters = this.listingViewsSchema.viewCriteria;
    if (this.listingViewsSchema.duplicateView.bodyTransformFn) {
      updateViewParam = this.listingViewsSchema.duplicateView.bodyTransformFn({
        id: this.selectedViewId.toString(),
        name: eventObj.data.value,
      } as IViewData);
    } else {
      if (this.listingViewsSchema.duplicateView.body &&
        this.listingViewsSchema.duplicateView.body.viewId !== undefined) {
        updateViewParam = {
          viewId: this.selectedViewId.toString(),
          gridColumns: this.gridColumns
        };
      } else {
        updateViewParam =  this.setParam(
          true,
          filters,
          this.defaultViewName
        );
      }
    }

    const apiConfig: IListingViewsApi = {
      url: this.listingViewsSchema.duplicateView.url,
      body: updateViewParam,
      method: this.listingViewsSchema.duplicateView.method
    };
    this.listViewService.createView(apiConfig, this.selectedViewId.toString()).subscribe(
      (response) => {
        const viewObj = {
          viewId: response.data.id,
          viewName: eventObj.data.value
        };
        this.viewList.push(viewObj);
        this.activePopupType = this.togglePopupType.NONE;
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
      },
      (error) => {
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
        this.activePopupType = this.togglePopupType.NONE;
      }
    );
  }

  updateExistingView(eventObj) {
    let updateViewParam: any;
    const filter = this.listingViewsSchema.viewCriteria;
    const mappedViewItem = find(this.viewList, (viewObj) => {
      return viewObj.viewId === eventObj.data.id;
    });
    const filterCriteria = filter.criteriaGroup.criteria.forEach((obj) => delete obj.operation );
    if (this.listingViewsSchema.updateView.body &&
      this.listingViewsSchema.updateView.body.viewId !== undefined) {
      updateViewParam = {
        viewId: this.selectedViewId,
        viewName: this.selectedViewName,
        gridColumns: this.gridColumns,
        filters: filter.criteriaGroup.criteria
      };
    } else {
      updateViewParam =  this.setParam(
        mappedViewItem.viewId === this.defaultViewId,
          filter,
          mappedViewItem.viewName
      );
    }
    // const filters = this.listingViewsSchema.viewCriteria;
    // const updateViewParam = this.setParam(
    //   mappedViewItem.viewId === this.defaultViewId,
    //   filters,
    //   mappedViewItem.viewName
    // );
    const apiConfig: IListingViewsApi = {
      url: this.listingViewsSchema.updateView.url,
      body: updateViewParam,
      method: this.listingViewsSchema.updateView.method
    };
    this.listViewService.updateView(apiConfig, eventObj.data.id).subscribe((response) => {
      this.activePopupType = this.togglePopupType.NONE;
      if (this.progressOverlay) {
        this.progressOverlay.clear();
      }
      this.getSavedView(eventObj.data.id);
    });
  }

  renameView(eventObj) {
    let url = this.listingViewsSchema.getViewById.url;
    url = url.replace(url.slice(url.indexOf('{'), url.indexOf('}') + 1), eventObj.data.id);
    this.listingViewsSchema.getViewById.url = url;
    this.listViewService
        .getViewById(this.listingViewsSchema.getViewById, eventObj.data.id)
        .subscribe((response) => {
          const filters = response.data.filters;
          let updateViewParam;
          if (this.listingViewsSchema.renameView.bodyTransformFn) {
            updateViewParam = this.listingViewsSchema.renameView.bodyTransformFn({
              id: this.selectedViewId,
              name: eventObj.data.value,
            } as IViewData);
          } else {
            if (this.listingViewsSchema.renameView.body &&
              this.listingViewsSchema.renameView.body.viewName !== undefined) {
              updateViewParam = this.listingViewsSchema.renameView.body;
              updateViewParam.viewName = eventObj.data.value;
              updateViewParam.viewId = eventObj.data.id;
            } else {
              updateViewParam = this.setParam(false, filters, eventObj.data.value);
            }
          }
          const apiConfig: IListingViewsApi = {
            url: this.listingViewsSchema.renameView.url,
            body: updateViewParam,
            method: this.listingViewsSchema.renameView.method
          };

          this.listViewService.renameView(apiConfig, eventObj.data.id).subscribe((updatedView) => {
              this.activePopupType = this.togglePopupType.NONE;
              const mappedViewItem = find(this.viewList, (viewObj) => {
                return viewObj.viewId === eventObj.data.id;
              });
              if (mappedViewItem) {
                mappedViewItem.viewName = eventObj.data.value;
              }
              if (this.progressOverlay) {
                this.progressOverlay.clear();
              }
              this.getSavedView(eventObj.data.id);
            });
        });
  }

  deleteView() {
    let confirmText;
    if (this.selectedViewName === this.defaultViewName) {
          confirmText = this._language.instant('DEWDROPS_CONFIRM_MSG_ON_PERMANENT_DELETE', {
            viewName: this.selectedViewName
          });
        } else {
          confirmText = this._language.instant('DEWDROPS_CONFIRM_MSG_ON_DELETE', {
            viewName: this.selectedViewName
          });
        }
    this.overlayBuilder.confirm(this.viewContainer)({
          confirmTxt: confirmText,
          confirmBtnLabel: this._language.instant('DEWDROPS_DELETE_BTN_LBL'),
          rejectBtnLabel: this._language.instant('DEWDROPS_CANCEL_BTN_LBL'),
          confirmFn: () => {
            this.progressOverlay = this.overlayBuilder.progress(this.viewContainer)(
              this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING')
            );
            this.listViewService
              .deleteView(this.listingViewsSchema.deleteView, this.selectedViewId)
              .subscribe((response) => {
                this.selectedViewUpdated.emit(this.togglePopupType.DELETE);
                this.activePopupType = this.togglePopupType.NONE;
                this.getViewsDetails();
              },
              (error) => {
                if (this.progressOverlay) {
                  this.progressOverlay.clear();
                }
                this.activePopupType = this.togglePopupType.NONE;
              });
          }
        });
  }

  exportView() {
    this.progressOverlay =
      this.overlayBuilder.progress(this.viewContainer)(this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING'));
    this.listViewService.exportView(this.listingViewsSchema.exportView, this.selectedViewId)
      .subscribe((response) => {
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
      },
      (error) => {
        if (this.progressOverlay) {
          this.progressOverlay.clear();
        }
      });
  }

  togglePopup(popupType: ListingViewActionType, event?: any) {
    switch (popupType) {
      case this.togglePopupType.DEFAULT:
        if (this.selectedViewName !== this.defaultViewName) {
          this.setDefaultView = true;
        } else {
          this.setProductDefaultView = true;
        }
        this.activePopupType = this.togglePopupType.DEFAULT;
        break;

      case this.togglePopupType.DELETE:
        this.activePopupType = this.togglePopupType.DELETE;
        this.deleteView();
        break;

      case this.togglePopupType.DUPLICATE:
        this.activePopupType = this.togglePopupType.DUPLICATE;
        break;

      case this.togglePopupType.RENAME:
        this.activePopupType = this.togglePopupType.RENAME;
        break;

      case this.togglePopupType.NEW_VIEW:
        this.activePopupType = this.togglePopupType.NEW_VIEW;
        break;

      case this.togglePopupType.NONE:
        this.activePopupType = this.togglePopupType.NONE;
        break;
    }
  }
}
