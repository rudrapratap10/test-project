import { Component, Input, OnInit, ElementRef, Renderer2, ViewChild, ContentChild, TemplateRef, AfterViewInit, AfterContentInit } from '@angular/core';

@Component({
  selector: 'dew-listing-col',
  template: '<ng-content></ng-content>',
  styleUrls: ['./listing-col.component.scss']
})
export class ListingColComponent implements OnInit, AfterViewInit, AfterContentInit {

  @Input() fieldName: string;
  // @ViewChild(TemplateRef) templateRef: TemplateRef<HTMLTemplateElement>;
  @ContentChild(TemplateRef) templateRef: any;

  constructor(private elt: ElementRef, private renderer: Renderer2) { }

  ngOnInit() {
  }

  ngAfterContentInit() {
  }

  ngAfterViewInit() {
  }

}
