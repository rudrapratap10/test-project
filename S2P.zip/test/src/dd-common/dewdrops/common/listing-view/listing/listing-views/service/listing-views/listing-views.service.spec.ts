import { TestBed, inject } from '@angular/core/testing';

import { ListingViewsService } from './listing-views.service';

describe('ListingViewsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListingViewsService]
    });
  });

  it('should be created', inject([ListingViewsService], (service: ListingViewsService) => {
    expect(service).toBeTruthy();
  }));
});
