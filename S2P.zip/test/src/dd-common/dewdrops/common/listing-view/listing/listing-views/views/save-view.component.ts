import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewContainerRef
} from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { CommonOverlayBuilder } from '../../../../overlay/overlay-builder.service';
import { ListingViewActionType } from '../listing-views.component';

@Component({
  selector: 'dew-save-view',
  templateUrl: './save-view.component.html',
  styleUrls: ['./save-view.component.scss']
})
export class SaveViewsComponent implements OnInit {

  public isViewError = false;
  public viewErrorMessage = '';

  public isDefaultView: boolean;

  @Input()
  currentView: string;

  @Output()
  whenSaved = new EventEmitter();

  @Output()
  whenClosed = new EventEmitter();

  saveNewViewModal = true;
  newViewName = '';
  public togglePopupTypes = ListingViewActionType;

  constructor(
    private _language: TranslateService,
    private overlayBuilder: CommonOverlayBuilder,
    private viewContainer: ViewContainerRef
  ) { }

  ngOnInit() {
    this.newViewName = this.currentView;
  }

  saveView() {
    if (this.newViewName === '') {
      this.isViewError = true;
      this.viewErrorMessage = this._language.instant('EINVOICE_VALIDATION_MSG_VIEW_NAME_CANNOT_BE_EMPTY');
      return;
    } else if (this.newViewName === this.currentView) {
      this.isViewError = true;
      this.viewErrorMessage = this._language.instant('EINVOICE_VALIDATION_MSG_VIEW_NAME_CANNOT_BE_SAME');
      return;
    }
    this.whenSaved.emit(
      { type: this.togglePopupTypes.NEW_VIEW,
        data: {
        value: this.newViewName,
        isDefault: this.isDefaultView
      }});
  }

  toggeleSaveNewView(state): void {
    this.saveNewViewModal = state;
    this.whenClosed.emit(state);
  }

  setViewToDefaultWarningDialog(checked: boolean) {
    if (checked) {
      this.overlayBuilder.confirm(this.viewContainer)({
        confirmTxt: this._language.instant(
          'EINVOICE_CONFIRM_MSG_ON_SET_DEFAULT_VIEW', {viewName: this.newViewName}),
        confirmBtnLabel: this._language.instant('DEWDROPS_YES_BTN_LBL'),
        rejectBtnLabel: this._language.instant('DEWDROPS_NO_BTN_LBL'),
        rejectFn: () => {
          this.isDefaultView = false;
        }
      });
    }
  }

}
