import { Component } from '@angular/core';

@Component({
selector: 'dew-listing-filter',
template: '<ng-content></ng-content>',
})
export class ListingFilterComponent {
}
