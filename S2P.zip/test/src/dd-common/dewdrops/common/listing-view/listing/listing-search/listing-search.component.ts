import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ChangeDetectorRef
} from '@angular/core';
import { IListingColumnSchema, IListingSearchSchema } from '@dewdrops/common';
import { CriteriaGroupInterface, CriteriaInterface } from '@dewdrops/interfaces';
import { fromEvent } from 'rxjs/observable/fromEvent';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'dew-listing-search',
  templateUrl: './listing-search.component.html',
  styleUrls: ['./listing-search.component.scss']
})
export class ListingSearchComponent implements OnInit, OnDestroy {
  @Input()
  listingSearchSchema: IListingSearchSchema;

  @Input()
  placeholder = 'DEWDROPS_PLACEHOLDER_SEARCH';

  @Output()
  search: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  searchTextCleared: EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }> = new EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }>();

  @Output()
  searchCriteriaChange: EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }> = new EventEmitter<{
    defaultCriteria: CriteriaInterface;
    searchCriteria: {
      forField?: string;
      criteria: CriteriaInterface;
    };
  }>();

  searchText: string;
  isSearchOpen = false;
  shouldShowSuggestions: boolean;
  hasSelectedSuggestion: boolean;
  searchCriteriaToEmit: { defaultCriteria: CriteriaInterface; searchCriteria: {
    forField?: string;
    criteria: CriteriaInterface;
  } };
  searchboxCloseSubscription: Subscription;

  constructor(private elementRef: ElementRef, private cdRef: ChangeDetectorRef, private translate: TranslateService) {}

  ngOnInit() {
    this.searchCriteriaToEmit = {
      defaultCriteria: this.listingSearchSchema.defaultCriteria,
      searchCriteria: {} as any
    };
  }

  toggleSearch() {
    this.isSearchOpen = this.isSearchOpen ? false : true;
    if (!this.isSearchOpen) {
      this.searchText = undefined;
      this.shouldShowSuggestions = false;
      this.hasSelectedSuggestion = true;
      if (this.searchboxCloseSubscription && !this.searchboxCloseSubscription.closed) {
        this.searchboxCloseSubscription.unsubscribe();
      } else {
        this.searchboxCloseHandler();
      }
    } else {
      if (this.searchboxCloseSubscription === undefined ||
        (this.searchboxCloseSubscription && this.searchboxCloseSubscription.closed)) {
        this.searchboxCloseHandler();
      }
    }
  }

  searchTextInput(value: string) {
    this.searchText = value;
    if (value && (value.trim().length >=
          (this.listingSearchSchema.minWordLength ? this.listingSearchSchema.minWordLength : 3))) {
      if (this.isSearchOpen) {
        this.shouldShowSuggestions = true;
        this.hasSelectedSuggestion = true;
      }
    } else {
      this.shouldShowSuggestions = false;
      this.hasSelectedSuggestion = true;
      if (!value || value.length === 0) {
        this.searchTextCleared.emit(this.searchCriteriaToEmit);
      }
    }
    this.search.emit(value);
  }

  clearSearchInput() {
    if (this.searchText) {
      this.searchText = undefined;
      this.shouldShowSuggestions = false;
      this.searchTextCleared.emit(this.searchCriteriaToEmit);
      this.hasSelectedSuggestion = true;
    }
    this.search.emit(this.searchText);
  }

  /**
   * @desc handler for closing of search box when clicked outside of it
   */
  searchboxCloseHandler() {
    this.searchboxCloseSubscription = fromEvent(document, 'click')
      .pipe(
        filter((event: any) => {
          return !this.elementRef.nativeElement.contains(event.target);
        })
      )
      .subscribe(() => {
        this.shouldShowSuggestions = false;
        if (!this.searchText || (this.searchText && this.searchText.length <= 0)) {
          this.isSearchOpen = false;
          this.hasSelectedSuggestion = false;
          this.searchboxCloseSubscription.unsubscribe();
        }
        this.cdRef.detectChanges();
      });
  }

  prepareAllColumnCriteria() {
    this.searchCriteriaToEmit.searchCriteria = {
      forField: '*',
      criteria: {
        fieldName: '*',
        operation: 'CONTAINS',
        value: this.searchText.trim()
      }
    };
    this.searchCriteriaChange.emit(this.searchCriteriaToEmit);
    this.shouldShowSuggestions = false;
    this.hasSelectedSuggestion = true;
  }

  prepareCriteria(column) {
    this.searchCriteriaToEmit.searchCriteria = {
      forField: column.fieldName,
      criteria: {
        fieldName: column.criteriaKey,
        operation: 'CONTAINS',
        value: this.searchText.trim()
      }
    };
    this.searchCriteriaChange.emit(this.searchCriteriaToEmit);
    this.shouldShowSuggestions = false;
    this.hasSelectedSuggestion = true;
  }

  openSuggestions(event) {
    if ((this.searchText && this.searchText.trim().length >=
        (this.listingSearchSchema.minWordLength ? this.listingSearchSchema.minWordLength : 3)) &&
        !this.shouldShowSuggestions) {
      this.shouldShowSuggestions = true;
      this.hasSelectedSuggestion = false;
    }
  }

  ngOnDestroy(): void {
    if (this.searchboxCloseSubscription && !this.searchboxCloseSubscription.closed) {
      this.searchboxCloseSubscription.unsubscribe();
    }
    this.hasSelectedSuggestion = true;
  }
}
