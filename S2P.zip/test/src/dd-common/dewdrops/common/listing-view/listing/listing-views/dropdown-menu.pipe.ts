import {
  Directive,
  ElementRef,
  HostBinding,
  HostListener,
  OnInit,
  OnDestroy
} from '@angular/core';
import { Subscription } from 'rxjs';
import { fromEvent } from 'rxjs/observable/fromEvent';
import { filter } from 'rxjs/operators';

@Directive({
  selector: '[viewDropdown]'
})

export class ViewDropdownDirective implements OnInit, OnDestroy {

  closeSubscription: Subscription;

  @HostBinding('class.show') isOpen = false;

  constructor(private _host: ElementRef) { }

  ngOnInit() {
    this.initCloseHandler();
  }

  ngOnDestroy() {
    if (this.closeSubscription) {
      this.closeSubscription.unsubscribe();
    }
  }

  initCloseHandler() {
    this.closeSubscription = fromEvent(document, 'click').pipe(
      filter((event: any) => {
        return event;
      })
    ).subscribe((event) => {
      if (!this._host.nativeElement.contains(event.target)) {
        this.isOpen = false;
      } else {
        this.isOpen = !this.isOpen;
      }
    });
  }

  // @HostListener('click') toggleOpen() {
  //   this.isOpen = !this.isOpen;

  // }

  // @HostListener('document: click', ['$event.target']) toggleClose(target: Node) {
  //   if (this.isOpen) {
  //     if (!this._host.nativeElement.contains(target)) {
  //       this.isOpen = false;
  //     }
  //   }
  // }
}
