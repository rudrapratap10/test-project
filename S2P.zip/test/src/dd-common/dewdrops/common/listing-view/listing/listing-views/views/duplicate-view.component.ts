import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewContainerRef
} from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { CommonOverlayBuilder } from '../../../../overlay/overlay-builder.service';
import { ListingViewActionType } from '../listing-views.component';

@Component({
  selector: 'dew-duplicate-view',
  templateUrl: './duplicate-view.component.html',
  styleUrls: ['./duplicate-view.component.scss']
})
export class DuplicateViewComponent implements OnInit {

  public isViewError = false;
  public viewErrorMessage = '';

  public isDefaultView: boolean;

  public progressOverlay;

  @Input()
  currentView: string;

  @Output()
  whenduplicated = new EventEmitter();

  @Output()
  updateIsDefaultView = new EventEmitter<boolean>();

  @Output()
  whenClosed = new EventEmitter();
  duplicateNewViewModal = true;
  duplicateViewName = '';
  public togglePopupTypes = ListingViewActionType;

  constructor(
    private _language: TranslateService,
    private overlayBuilder: CommonOverlayBuilder,
    private viewContainer: ViewContainerRef
  ) { }

  ngOnInit() {
    this.duplicateViewName = this.currentView + ' - Copy';
  }

  duplicateView() {
    this.isViewError = false;
    if (this.duplicateViewName === '') {
      this.isViewError = true;
      this.viewErrorMessage = this._language.instant('EINVOICE_VALIDATION_MSG_VIEW_NAME_CANNOT_BE_EMPTY');
      return;
    } else if (this.duplicateViewName === this.currentView) {
      this.isViewError = true;
      this.viewErrorMessage = this._language.instant('EINVOICE_VALIDATION_MSG_VIEW_NAME_CANNOT_BE_SAME');
      return;
    }
    this.isViewError = false;
    this.whenduplicated.emit({type: this.togglePopupTypes.DUPLICATE, data: {value: this.duplicateViewName}});
  }

  toggeleDuplicateNewView(state): void {
    this.duplicateNewViewModal = state;
    this.whenClosed.emit(state);
  }

}
