import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveViewsComponent } from './save-view.component';

describe('SaveViewsComponent', () => {
  let component: SaveViewsComponent;
  let fixture: ComponentFixture<SaveViewsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaveViewsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveViewsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
