import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewContainerRef
  } from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { ListingViewActionType } from '../listing-views.component';
import { OverlayService } from '../../../../overlay/overlay.service';
import { CommonOverlayBuilder } from '../../../../overlay/overlay-builder.service';

@Component({
  selector: 'dew-update-view',
  templateUrl: './update-view.component.html',
  styleUrls: ['./update-view.component.scss']
})
export class UpdateViewsComponent implements OnInit {

  @Input()
  viewId: any;

  @Input()
  defaultViewId: any;

  @Input()
  currentView: any;

  @Input()
  setUserDefaultView: any;

  @Input()
  setProductDefaultView: any;

  @Input()
  renameCurrentView: boolean;

  @Input()
  updateCurrentView: boolean;

  @Output()
  whenUpdated = new EventEmitter();

  @Output()
  whenClosed = new EventEmitter();

  public viewNameErrorMsg = false;
  public updateViewError = '';
  public previousDefault;
  public togglePopupTypes = ListingViewActionType;

  private progressOverlay;
  constructor(
    private overlayService: OverlayService,
    private viewContainer: ViewContainerRef,
    private overlayBuilder: CommonOverlayBuilder,
    private _language: TranslateService
  ) { }

  ngOnInit() {
    if (this.setUserDefaultView || this.setProductDefaultView) {
      this.updateView();
    }
  }

  updateView() {
    if (this.renameCurrentView) {
      if (!this.currentView) {
        this.viewNameErrorMsg = true;
      } else {
        this.viewNameErrorMsg = false;
      }
      if (!this.viewNameErrorMsg) {
        this.whenUpdated.emit(
          {
            type: this.togglePopupTypes.RENAME,
            data: {
              id: this.viewId,
              value: this.currentView
            }
          });
      }
    } else if (this.updateCurrentView) {
      this.whenUpdated.emit(
        {
          type: this.togglePopupTypes.UPDATE_EXISTING_VIEW,
          data: {id: this.viewId}
        });
    } else if (this.setUserDefaultView || this.setProductDefaultView) {
      this.overlayBuilder.confirm(this.viewContainer)({
        confirmTxt: this._language.instant('EINVOICE_CONFIRM_MSG_ON_SET_DEFAULT_VIEW',
          { viewName: this.currentView }),
        confirmBtnLabel: this._language.instant('DEWDROPS_YES_BTN_LBL'),
        rejectBtnLabel: this._language.instant('DEWDROPS_NO_BTN_LBL'),
        confirmFn: () => {
          this.progressOverlay =
          this.overlayBuilder.progress(this.viewContainer)(this._language.instant('DEWDROPS_SPINNER_TEXT_LOADING'));
          this.whenUpdated.emit(
            {
              type: this.togglePopupTypes.DEFAULT,
              data: {id: this.viewId, value: this.currentView}
            });
        },
        rejectFn: () => {
          this.whenClosed.emit(false);
        }
      });
    }
  }

  toggleRenameView(state): void {
    this.renameCurrentView = state;
    this.whenClosed.emit(state);
  }
}
