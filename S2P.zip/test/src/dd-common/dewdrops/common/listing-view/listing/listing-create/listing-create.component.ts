import { Component,
         EventEmitter,
         Input,
         OnInit,
         Output} from '@angular/core';

@Component({
  selector: 'dew-listing-create',
  templateUrl: './listing-create.component.html',
})
export class ListingCreateComponent implements OnInit {

  @Input() label: string;
  @Output() create: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  onCreate() {
      this.create.emit();
  }
}
