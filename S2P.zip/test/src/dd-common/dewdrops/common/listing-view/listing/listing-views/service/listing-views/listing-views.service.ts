import { Injectable } from '@angular/core';
import { APIClientService } from '@dewdrops/services';
import { Observable } from 'rxjs/Observable';
import { IListingViewsApi } from '../../../../interfaces/listing-view.interface';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class ListingViewsService {

  constructor(
    private apiClient: APIClientService,
    private http: HttpClient
  ) { }

  createView(apiConfig: IListingViewsApi, viewInvoiceId?: string): Observable<any> {
    let url = apiConfig.url;
    if (viewInvoiceId) {
      url = `${apiConfig.url.replace('{viewId}', viewInvoiceId)}`;
      url = `${url.replace('{filterId}', viewInvoiceId)}`;
    }
    const body = apiConfig.body;

    if (apiConfig.method) {
      return this.http[apiConfig.method](url, body);
    } else {
      return this.apiClient.create(url, body);
    }
  }

  updateView(apiConfig: IListingViewsApi, viewInvoiceId: string): Observable<any> {
    let url = `${apiConfig.url}`;
    url = `${apiConfig.url.replace('{viewId}', viewInvoiceId)}`;
    url = `${url.replace('{filterId}', viewInvoiceId)}`;
    const body = apiConfig.body;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, body);
    } else {
      return this.apiClient.update(url, body);
    }
  }

  renameView(apiConfig: IListingViewsApi, viewInvoiceId?: string): Observable<any> {
    let url = apiConfig.url;
    if (viewInvoiceId) {
      url = `${apiConfig.url.replace('{viewId}', viewInvoiceId)}`;
      url = `${url.replace('{filterId}', viewInvoiceId)}`;
    }
    const body = apiConfig.body;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, body);
    } else {
      return this.apiClient.list(url, body);
    }
  }

  deleteView(apiConfig: IListingViewsApi, viewInvoiceId: string): Observable<any> {
    let url = `${apiConfig.url}/${viewInvoiceId}`;
    url = `${apiConfig.url.replace('{viewId}', viewInvoiceId)}`;
    url = `${url.replace('{filterId}', viewInvoiceId)}`;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, apiConfig.body);
    } else {
      return this.apiClient.delete(url);
    }
  }

  getAllViews(apiConfig: IListingViewsApi): Observable<any> {
    const url = apiConfig.url;
    const body = apiConfig.body;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, body);
    } else {
      return this.apiClient.list(url, body);
    }
  }

  getViewById(apiConfig: IListingViewsApi, viewId: string): Observable<any> {
    let url = `${apiConfig.url.replace('{viewId}', viewId)}`;
    url = `${url.replace('{filterId}', viewId)}`;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, apiConfig.body);
    } else {
      return this.apiClient.read(url);
    }
  }

  setDefaultView(apiConfig: IListingViewsApi, viewId: string): Observable<any> {
    let url = `${apiConfig.url.replace('{viewId}', viewId)}`;
    url = `${url.replace('{filterId}', viewId)}`;
    const body = apiConfig.body;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url, body);
    } else {
      return this.apiClient.list(url, body);
    }
  }

  exportView(apiConfig: IListingViewsApi, viewId: string) {
    let url = `${apiConfig.url.replace('{viewId}', viewId)}`;
    url = `${url.replace('{filterId}', viewId)}`;
    if (apiConfig.method) {
      return this.http[apiConfig.method](url);
    } else {
      return this.apiClient.read(url);
    }
  }

}
