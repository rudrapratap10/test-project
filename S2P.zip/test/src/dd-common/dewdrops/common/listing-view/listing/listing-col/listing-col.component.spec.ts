import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListingColComponent } from './listing-col.component';

describe('ListingColComponent', () => {
  let component: ListingColComponent;
  let fixture: ComponentFixture<ListingColComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListingColComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListingColComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
