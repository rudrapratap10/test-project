import { CommonModule } from '@angular/common';
import { AfterContentInit,
         AfterViewChecked,
         AfterViewInit,
         ChangeDetectionStrategy,
         ChangeDetectorRef,
         Component,
         ContentChild,
         ContentChildren,
         ElementRef,
         EventEmitter,
         Input,
         OnChanges,
         OnInit,
         Output,
         QueryList,
         SimpleChanges,
         ViewChild} from '@angular/core';
import { CollectionFactory } from '@dewdrops/factories';
import { CriteriaGroupInterface, CriteriaInterface } from '@dewdrops/interfaces';
import { APIClientService, StorageService } from '@dewdrops/services';
import {
  cloneDeep,
  filter,
  find,
  forEach,
  remove
} from 'lodash/index';
import { IListingSchema } from '../interfaces/listing.schema.interface';
import { ListingColComponent } from './listing-col/listing-col.component';
import { ListingCreateComponent } from './listing-create/listing-create.component';
import { ListingSearchComponent } from './listing-search/listing-search.component';
import { ListingViewsComponent } from './listing-views/listing-views.component';

import { Event, Router } from '@angular/router';
import {
  URL_ACCESS_DENIED,
  URL_CON_ERROR,
  URL_NO_REQ,
  URL_NOT_FOUND,
  URL_SERVER_ERROR
} from '@dewdrops/globals';
import { TranslateService } from 'ng2-translate';
import { MultiSelectOrderedListComponent } from '../../multiselection-order-list/mselect-order-list.component';
import { IListingColumnSchema } from '../interfaces/listing.column.interface';
import { ISearchFilterColumn } from '../interfaces/listing.search.interface';

@Component({
  selector: 'dew-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ListingComponent implements OnInit, AfterContentInit, OnChanges, AfterViewInit, AfterViewChecked {

  // @Input() dataSource: CollectionFactory<any>;
  @Input() set dataSource(value: CollectionFactory) {
    this._dataSource = value;
  }
  @Input() schema: IListingSchema;

  @Input() isInContainer = true;

  @Input() removeActionHeader =  false;
  @Input() minConfigurableColumns: number;;
  @Input() userViewName = "View All";
  @Output()
  select: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  load: EventEmitter<any> = new EventEmitter<any>();

  @ContentChildren(ListingColComponent) listCols: QueryList<ListingColComponent>;
  @ContentChild(ListingViewsComponent) listViews: ListingViewsComponent;
  @ContentChild(ListingSearchComponent) listSearch: ListingSearchComponent;
  @ContentChild(ListingCreateComponent) createItem: ListingCreateComponent;
  @ContentChild(ListingSearchComponent) searchItem: ListingSearchComponent;
  @ViewChild('columnGrouper') columnGrouper: ElementRef;
  @ViewChild(MultiSelectOrderedListComponent) msoComponent: MultiSelectOrderedListComponent;
  listData: any[];
  columnTemplate: any = [];
  hoveringIndex: number; // To style on row hover
  configurableColumns = []; // columns that will appear for drag and drop in the gear icon
  userConfiguredColumns = [];
  defaultFields = [];
  childField: string;

  totalRecords = 0;
  recordsPerPageOptions = [10, 25, 50, 100];
  perPageRecords = 10;
  pageNo = 1;
  isSorted = false;
  currentSortDirection = 'ASC';
  currentSortedColumn = {};
  isDataLoading = false;
  colSpanForFixedBlock = 0;
  allSelected = false;
  selectedRecords = [];
  fixedColSpan = 3;
  lastColSpan = 3;
  middleColSpan;
  beginningIndexForFixedColumn = 0; // This is required to align flag column below helptext column

  addRowImageUrl = '/assets/images/common/add-row.svg';
  removeRowImageUrl = '/assets/images/common/remove-row.svg';

  selectedViewName: string;
  selectedViewId: string;

  showFilters = false;
  isProductDefaultViewSwitched = false;
  public isViewChanged = false;
  public defaultSort = {
    fieldName: 'createdOn',
    direction: 'DESC'
  };

  public _dataSource: CollectionFactory;
  // test remove aftre use

  public criteriaGroup: CriteriaInterface = {
    fieldName: 'name',
    operation: 'CONTAINS',
  };
  private _session_storage_key;

  private searchBufferColumns: IListingColumnSchema[] = [];

  constructor(
    private apiClient: APIClientService,
    private router: Router, private _storageService: StorageService, private _translate: TranslateService,
    private cd: ChangeDetectorRef) {
      this.currentSortedColumn = {};
     }

  ngOnInit() {
    // Initially make this undefined so that none of the row is highlighted
    this.hoveringIndex = undefined;
    this._session_storage_key = this.schema.id;
    const sessionData = this.getSessionData();
    if (sessionData) {
      if (sessionData.pageNo) {
        this.pageNo = sessionData.pageNo || 1;
      }
      if (sessionData.pageSize) {
        this.perPageRecords = sessionData.pageSize || 10;
      }
      window.scrollTo(0, 0);
    }
    this.getRecords(this.perPageRecords, this.pageNo);
    this.selectedRecords = [];
    this.currentSortedColumn = {};
  }

  ngAfterContentInit() {
    this.createTamplateMapForCell();
    this.setConfigurableColumns();
  }
  ngAfterViewInit() {

  }

  ngAfterViewChecked() {
   this.cd.detectChanges();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.getColSpanForFixedBlock();
    if (this.schema) {
      // If the listing view has a flag field and it has the
      // checkboxes and if a helptext icon has to come in the header,
      // then  beginningIndexForFixedColumn = 0. ie Under the assumption
      // that flag field is the first column, then flag field shouldn't have a header column.
      // Therefore skip the first column while iterating column headers.
      if (this.schema.flaggable && this.schema.checkable && this.schema.columns[0].helpText) {
        this.beginningIndexForFixedColumn = 1;
      } else {
        this.beginningIndexForFixedColumn = 0;
      }
      if (this.schema.views) {
        this.schema.views.viewCriteria = {
          pageNo: 1, perPageRecords: 10,
          sorts: this._dataSource.sorts,
          criteriaGroup: this._dataSource.criteriaGroup
       };
        this.schema.views.listInfo = {
        isFilterApplied: false,
        isSorted: false,
        isPageRecordsChanged: false,
        noRecordsFound: false
        };
      }
    }
  }

  public getRecords(perPageRecords, pageNo) {
    this.isDataLoading = true;
    this._dataSource
      .jump(pageNo).count(perPageRecords).applyPaginate();

    this.apiClient.list(this._dataSource.url, this._dataSource.body).subscribe((response) => {
      this.listData = response.data.records ? response.data.records : [];
      // for(let data of this.listData) {
      //   data['child'] = [data, data, data];
      // }
      // If no records and page no > 1, redirect to page 1
      if (this.listData.length === 0 && this.pageNo > 1) {
        this.onPageChange(1);
        return;
      }
      this.totalRecords = response.data.totalRecords ? response.data.totalRecords : 0;
      if (this.totalRecords === 0) {
        if (this.schema.views && this.schema.views.listInfo) { this.schema.views.listInfo.noRecordsFound = true; }
      }
      this.isDataLoading = false;
      this.selectedRecords = [];
      this.load.emit(this.listData);
      this.select.emit(this.selectedRecords);

    }, (error) => {
      this.isDataLoading = false;
      this.router.navigate([URL_SERVER_ERROR]);

      return error;
    });
  }

  // Call this function to refresh this list. Existing pagination configurations will be applied
  // No sorts and filter will be applied
  refreshList() {
    this.allSelected = false;
    this.getRecords(this.perPageRecords, this.pageNo);
    if (this.schema.views && this.schema.views.listInfo) {
    this.schema.views.listInfo.isPageRecordsChanged = false;
    this.schema.views.listInfo.isSorted = false;
    this.schema.views.listInfo.noRecordsFound = false;
  }
}

  getColSpanForFixedBlock() {
    if (this.schema.columns && this.schema.fixedColumns) {
      let colSpan = 0;
      for (let index = 0; index < this.schema.fixedColumns; index++) {
        // default column span is 2
        colSpan = colSpan + (this.schema.columns[index].columnSpan ? this.schema.columns[index].columnSpan : 2);
      }
      this.fixedColSpan = colSpan;
      this.lastColSpan = this.schema.columns[this.schema.columns.length - 1].columnSpan ?
        this.schema.columns[this.schema.columns.length - 1].columnSpan : 2;
      // Calculate how much middle column must take in a 12 column grid structure.
      this.middleColSpan = 12 - (this.fixedColSpan + this.lastColSpan);
    }
  }
  // Get the template for each cell.
  createTamplateMapForCell() {
    if (this.listCols) {
      try {
        this.userConfiguredColumns = [];
        this.defaultFields = [];
        // store the child field where data has to be fetched from
        this.childField = this.schema.child;
        forEach(this.schema.columns, (columnMeta, data) => {
          if (this.schema.fixedColumns) {
            if (columnMeta.visible && !columnMeta.default &&
              columnMeta.orderable === true && data !== this.schema.columns.length - 1) {
              this.defaultFields.push(columnMeta);
              this.userConfiguredColumns.push(columnMeta);
            }
          } else {
            if (columnMeta.visible || columnMeta.default) {
              this.defaultFields.push(columnMeta);
              this.userConfiguredColumns.push(columnMeta);
            }
          }

          this.colSpanForFixedBlock = this.colSpanForFixedBlock + (columnMeta.columnSpan ? columnMeta.columnSpan : 0);
          const columnWithTemplate = this.listCols.find((columnItem) => columnItem.fieldName === columnMeta.fieldName);
          this.columnTemplate[columnMeta.fieldName] = columnWithTemplate ? columnWithTemplate.templateRef : '';
        });
      } catch { }
      return true;
    }
  }

  /**
   * @class ListingComponent
   * @param  {number} rowIndex
   * @returns void
   */
  rowHover(rowIndex) {
    this.hoveringIndex = rowIndex;
  }

  /**
   * @class ListingComponent
   * @returns void
   */
  rowLeave() {
    this.hoveringIndex = undefined;
  }

  checkIfScrollPresent() {
    // check this logic.
    try {
      if (this.columnGrouper.nativeElement.scrollWidth > this.columnGrouper.nativeElement.clientWidth) {

        return true;

      }
    } catch {

    }
    return false;
  }
  // on selectAll checkbox click
  toggleSelection() {
    this.allSelected = !this.allSelected;
    if (this.allSelected) {
      this.selectedRecords = this.listData.slice(); // copies an array and not a reference
      this.listData.map((data) => {
        data._checked = true;
      });
    } else {
      this.listData.map((data) => {
        data._checked = false;
      });
      this.selectedRecords = [];
    }
    this.select.emit(this.selectedRecords);
  }

  // on selectAll checkbox click
  toggleItemSelection(data, index) {
    data._checked = !data._checked;
    if (data._checked) {
      this.selectedRecords.push(data);
    } else {
      const removeIndex = this.selectedRecords.findIndex((record) => record === data);
      this.selectedRecords.splice(removeIndex, 1);
    }
    if (this.selectedRecords.length === this.listData.length) {
      this.allSelected = true;
    } else {
      this.allSelected = false;
    }
    this.select.emit(this.selectedRecords);
  }

  // Sort Related functions

  sort(column, direction: string[]) {
    this.pageNo = 1; // setting the page no to 1
    this._dataSource
      .jump(this.pageNo).count(this.perPageRecords).applyPaginate();
    this.setSessionData(this.pageNo, this.perPageRecords, null, null);
    this.removeAllSorts();
    this.sortByDirection(column);
    this.currentSortedColumn = column;
  }

  sortByDirection(column, direction?: string) {

    if (this.currentSortedColumn && (this.currentSortedColumn as any).fieldName === column.fieldName) {
      this.currentSortDirection = this.currentSortDirection === 'ASC' ? 'DESC' : 'ASC';
    } else {
      this.currentSortDirection = 'ASC';
    }

    // if (this.currentSortDirection === 'ASC') {
    //   this.currentSortDirection = 'DESC';
    // } else {
    //   this.currentSortDirection = 'ASC';
    // }

    // new sort object
    const sortCriteria = {
      fieldName: column.fieldName,
      direction: this.currentSortDirection
    };

    this._dataSource.sortBy(sortCriteria).applySort();
    // might change the place where api is called
    this.isDataLoading = true;
    this.apiClient.list(this._dataSource.url, this._dataSource.body).subscribe((response) => {
      this.listData = response.data.records;
      this.isSorted = true;
      if (this.schema.views && this.schema.views.listInfo) {
      this.schema.views.listInfo.isSorted = true;
      }
      this.totalRecords = response.data.totalRecords ? response.data.totalRecords : 0;
      this.isDataLoading = false;
      this.selectedRecords = [];
      this.select.emit(this.selectedRecords);
      this.load.emit(this.listData);

    }, (error) => {
      this.router.navigate([URL_SERVER_ERROR]);

      return error;
    });
  }

  removeAllSorts() {
    this.schema.columns.map((column) => {
      this._dataSource.removeSort(column.fieldName);
    });
    this.isSorted = false;
  }

  onPageChange(pageNo: number) {
    this.allSelected = true;
    this.toggleSelection();
    this.pageNo = pageNo;
    window.scrollTo(0, 0);
    this.setSessionData(this.pageNo, this.perPageRecords, null, null);
    this.getRecords(this.perPageRecords, this.pageNo);
  }

  trackByFn(index, item) {
    return index;
  }

  onRecordsPerPageChange(perPageRecords: number) {
    this.allSelected = true;
    this.toggleSelection();
    this.pageNo = 1;
    this.perPageRecords = perPageRecords;
    if (this.schema.views && this.schema.views.listInfo) {
    this.schema.views.listInfo.isPageRecordsChanged = true; }
    this.setSessionData(this.pageNo, this.perPageRecords, null, null);
    this.getRecords(this.perPageRecords, this.pageNo);
  }

  // For multi selection of columns
  setConfigurableColumns() {
    if (this.listCols) {
      for (let index = 0; index < this.schema.columns.length - 1; index++) {
        const column = this.schema.columns[index];
        if (column.orderable || column.default) {
          let configureColumn = {};
          if (column.orderable) {
            if (column.default) {
              configureColumn = {
                label: this._translate.instant(column.label), id: column.fieldName,
                selected: column.visible, disable: column.default
              };
            } else {
              configureColumn = {
                label: this._translate.instant(column.label), id: column.fieldName,
                selected: column.visible, disable: false
              };
            }
          }
          // const configureColumn = { label: column.label, id: column.fieldName,
          //                           selected: column.visible, disable: column.default };
          this.configurableColumns.push(configureColumn);
        }
      }
    }
  }

  // CallBack for multiSelect component(configure)
  onConfigureFields(configuredColumns) {
    // for fixed template grid
    let actionsColumn = {};
    if (!this.schema.fixedColumns) {
      actionsColumn = this.userConfiguredColumns.pop();
    }

    // tslint:disable-next-line:prefer-for-of
    for (let index = 0; index < configuredColumns.length; index++) {

      const existingIndex = this.userConfiguredColumns.findIndex((column) => {
        return column.fieldName === configuredColumns[index].id;
      });

      if (existingIndex !== -1) {
        this.userConfiguredColumns.splice(existingIndex, 1);
      }

      if (configuredColumns[index].selected === true && !configuredColumns[index].disable) {
        const columnDefinition = this.schema.columns.find((column) => {
          return column.fieldName === configuredColumns[index].id;
        });
        this.userConfiguredColumns.push(columnDefinition);
      } else if (configuredColumns[index].selected === true &&
        configuredColumns[index].disable && !this.schema.fixedColumns) { // for fixed template columns
        const columnDefinition = this.schema.columns.find((column) => {
          return column.fieldName === configuredColumns[index].id;
        });
        this.userConfiguredColumns.push(columnDefinition);
      }

    }
    if (!this.schema.fixedColumns) {
      this.userConfiguredColumns.push(actionsColumn);
    }
    this.configurableColumns = configuredColumns;
  }

  toggleAccordion(data) {
    if (data._childOpened) {
      data._childOpened = false;
    } else {
      data._childOpened = true;
    }
  }

  getSessionData() {
    if (this._storageService.readSession(this._session_storage_key)) {
      const data = this._storageService.readSession(this._session_storage_key);
      return data;
    }
  }

  setSessionData(pageNo, pageSize, sort, search) {
    try {
      let data = {
        pageNo: pageNo,
        pageSize: pageSize,
        sort: sort,
        search: search
      };
      this._storageService.saveSession(this._session_storage_key, data);
    } catch {

    }
  }

  /**
   * whenever user selects the provided suggestions
   * to search the search text under any column this method gets invoked
   *
   * @param searchCriterias array which may contain two criterias; one criteria is mapped to
   * user's selection of search term under a column and one will be the default criteria (if present)
   */
  applySearchCriterias(searchCriterias: {
    defaultCriteria: CriteriaInterface,
    searchCriteria: { forField?: string, criteria: CriteriaInterface }
  }) {
    this.schema.search.columns.forEach((column: ISearchFilterColumn) => {
      this._dataSource.removeFilter(column.criteriaKey);
    });
    if (searchCriterias.defaultCriteria) {
      this._dataSource.filterBy(searchCriterias.defaultCriteria).applyFilter();
    }
    if (searchCriterias.searchCriteria.forField === '*') {
      const criteriaGrp: CriteriaGroupInterface = {
        logicalOperator: 'OR',
        criteria: []
      };
      if (this.schema.search.criteriaTransformFn) {
        criteriaGrp.criteria = this.schema.search.criteriaTransformFn(searchCriterias.searchCriteria.criteria.value);
      } else {
        this.schema.search.columns.forEach((column: ISearchFilterColumn) => {
          criteriaGrp.criteria.push({
            fieldName: column.criteriaKey,
            operation: 'CONTAINS',
            value: searchCriterias.searchCriteria.criteria.value
          });
        });
      }
      this._dataSource.removeSubCriteriaGroupFilter();
      this._dataSource.addSubCriteriaGroupFilter(criteriaGrp);
      this._dataSource.applyFilter();
    } else {
      const criteriaGrp: CriteriaGroupInterface = {
        logicalOperator: 'OR',
        criteria: []
      };
      if (this.schema.search.criteriaTransformFn) {
        criteriaGrp.criteria = this.schema.search.criteriaTransformFn(searchCriterias.searchCriteria.criteria.value);
      } else {
        criteriaGrp.criteria = [searchCriterias.searchCriteria.criteria];
      }
      this._dataSource.removeSubCriteriaGroupFilter();
      this._dataSource.addSubCriteriaGroupFilter(criteriaGrp);
      this._dataSource.applyFilter();
    }
    const mappedColumn = find(this.userConfiguredColumns, (column: IListingColumnSchema) => {
      return column.fieldName === searchCriterias.searchCriteria.forField;
    });
    if (!mappedColumn) {
      const columnToAdd = find(this.configurableColumns, (column: any) => {
        return column.id === searchCriterias.searchCriteria.forField;
      });
      if (columnToAdd) {
        columnToAdd.selected = true;
        this.msoComponent.validateAndSyncSelectAll(columnToAdd);
        this.msoComponent.onOKDone();
        this.searchBufferColumns.push(cloneDeep(columnToAdd));
      }
    }
    this._dataSource.first();
    this._dataSource.applyPaginate();
    this.pageNo = 1;
    this.isDataLoading = true;
    this.apiClient.list(this._dataSource.url, this._dataSource.body).subscribe((response) => {
    this.listData = response.data.records;
    this.checkAndExpandChildAccordion();
    this.totalRecords = response.data.totalRecords ? response.data.totalRecords : 0;
    this.isDataLoading = false;

    });
  }

  /**
   * Method responsible to expand the child row (if present) if it matches the search criteria
   */
  checkAndExpandChildAccordion() {
    if (this.childField && this.listData && this.listData.length > 0) {
      this.listData.forEach((data) => {
        if (data[this.childField] && data[this.childField].length > 0) {
          this.toggleAccordion(data);
        }
      });
    }
  }

  /**
   * Whenever user clears search text, this method will be invoked
   * (and filters will be cleared from `_datasource` if search text is undefined/empty)
   *
   * @param searchCriterias has the search criteria to be applied and the default criteria to be applied (if any)
   */
  removeSearchFilters(searchCriterias: {
    defaultCriteria: CriteriaInterface,
    searchCriteria: { forField?: string, criteria: CriteriaInterface }
  }) {
    if (this.schema.search.columns) {
        const subCriteriaGroup = cloneDeep(this._dataSource.criteriaGroup.criteriaGroup);
        this._dataSource.removeSubCriteriaGroupFilter();
        if (searchCriterias.defaultCriteria) {
          this._dataSource.filterBy(searchCriterias.defaultCriteria).applyFilter();
        }
        if (this.searchBufferColumns.length > 0) {
          this.searchBufferColumns.forEach((bufferColumn: any) => {
            const columnToRemove = find(this.configurableColumns, (column: any) => {
              return column.id === bufferColumn.id;
            });
            if (columnToRemove) {
              bufferColumn.selected = false;
              columnToRemove.selected = false;
            }
          });
          this.searchBufferColumns = [];
          this.msoComponent.validateAndSyncSelectAll();
          this.msoComponent.onOKDone();
      }
        if (subCriteriaGroup && subCriteriaGroup.length !== 0) {
          this.isDataLoading = true;
          this.apiClient
            .list(this._dataSource.url, this._dataSource.body)
            .subscribe((response) => {
              this.listData = response.data.records;
              this.totalRecords = response.data.totalRecords ? response.data.totalRecords : 0;
              this.isDataLoading = false;
            });
      }
      }
  }

 selectedViewChanged(viewObj) {
   let objFilters;
   objFilters = viewObj.filters;

   this.selectedViewName = viewObj.viewName;
   this.selectedViewId = viewObj.viewId;
   if (viewObj.filters) {
     objFilters.map((obj) => {
       const tempObj = {
         fieldName: obj.fieldName,
         operation: 'CONTAINS',
         value: obj.value
       };
       this._dataSource.filterBy(tempObj);
     });
   }
   let sortCriteria: { fieldName: string, direction: string };
   if (viewObj.sorts) {
      sortCriteria = {} as any;
      sortCriteria.fieldName = objFilters.sorts[0].fieldName;
      sortCriteria.direction = objFilters.sorts[0].direction;
    }

   if (sortCriteria) {
     this.removeAllSorts();
     this._dataSource.sortBy(sortCriteria);
    }
   this._dataSource.applyFilter();
   this.getRecords(this.perPageRecords, this.pageNo);

   if (this.schema.views && this.schema.views.listInfo) {
    this.schema.views.listInfo.noRecordsFound = false;
    this.schema.views.listInfo.isSorted = false;
    this.schema.views.listInfo.isPageRecordsChanged = false;
   }
}

 createAction() {
   this.createItem.create.emit();
 }

 productDefaultViewSwitched(event) {
    this.isProductDefaultViewSwitched = event;
    if (this.isProductDefaultViewSwitched) {
      const filters = this._dataSource.criteriaGroup.criteria;
      if (filters && filters.length > 0) {
        filters.forEach((criteria) => {
          this._dataSource.removeFilter(criteria.fieldName);
        });
      }
      this._dataSource.applyFilter();
      this.getRecords(this.perPageRecords, this.pageNo);
    }
  }

}
