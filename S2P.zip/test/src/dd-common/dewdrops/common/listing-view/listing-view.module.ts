import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { LayoutModule, ModalModule } from '@dewdrops/bootstrap';
import { PaginationModule } from '@dewdrops/bootstrap';
import { ButtonsModule } from '@dewdrops/bootstrap';
import { TooltipModule } from '@dewdrops/bootstrap';
import { FormControlModule } from '@dewdrops/bootstrap';
import { SummaryHoverModule } from '@dewdrops/bootstrap';
import { ExtendModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { MultiSelectOrderListModule } from '../multiselection-order-list/multiselection-order-list.module';
import { OverlayModule } from '../overlay/overlay.module';
import { ListingColComponent } from './listing/listing-col/listing-col.component';
import { ListingCreateComponent } from './listing/listing-create/listing-create.component';
import { ListingFilterComponent } from './listing/listing-filter/listing-filter.component';
import { ListingSearchComponent } from './listing/listing-search/listing-search.component';
import { ViewDropdownDirective } from './listing/listing-views/dropdown-menu.pipe';
import { ListingViewsComponent } from './listing/listing-views/listing-views.component';
import { ListingViewsService } from './listing/listing-views/service/listing-views/listing-views.service';
import { DuplicateViewComponent } from './listing/listing-views/views/duplicate-view.component';
import { SaveViewsComponent } from './listing/listing-views/views/save-view.component';
import { UpdateViewsComponent } from './listing/listing-views/views/update-view.component';
import { ListingComponent } from './listing/listing.component';

const components = [
  UpdateViewsComponent,
  SaveViewsComponent,
  DuplicateViewComponent,
  ViewDropdownDirective,
  ListingComponent,
  ListingColComponent,
  ListingViewsComponent,
  ListingSearchComponent,
  ListingFilterComponent,
  ListingCreateComponent];

@NgModule({
  imports: [
    CommonModule,
    LayoutModule,
    PaginationModule,
    ButtonsModule,
    FormControlModule,
    FormsModule,
    SummaryHoverModule,
    TooltipModule,
    ExtendModule,
    TranslateModule,
    MultiSelectOrderListModule,
    ModalModule,
    OverlayModule
  ],
  providers: [ListingViewsService],
  exports: components,
  declarations: components
})
export class ListingViewModule { }
