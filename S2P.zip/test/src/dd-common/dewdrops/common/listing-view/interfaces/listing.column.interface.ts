export interface IListingColumnSchema {
// The id to be used when referring to this field in code
fieldName: string;

// i18n language label key to be passed, not the translated text
label: string;

// i18n language label key for the help text, if applicable for this column
helpText: string;

// Enable/disable sorting for this column. The fieldName will be used for sort criteria.
sortable: boolean;

// Controls whether the column will be displayed by default in the listing grid
// The end-user can override the defaults using the add/remove column feature.
default: boolean;

// Internal field that would decide upon the fate of this column to be displayed or not
// Passing any value from the parent component is of no use. Use the "default" field.
visible: boolean;

// Decides if this call can be ordered. ie can appear in the setting icon for drag and drop
orderable: boolean;
// Number of columns this column should span. Follows bootstrap grid structure of total 12 columns in a grid.
columnSpan: number;
}
