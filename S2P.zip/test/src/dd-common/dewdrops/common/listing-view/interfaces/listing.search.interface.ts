import { CriteriaGroupInterface, CriteriaInterface } from '@dewdrops/interfaces';

export interface IListingSearchSchema {
  /**
   * The default criteria to be used when the user is using the generic search box.
   */
  defaultCriteria?: CriteriaInterface;

  /**
   * array of columns in which search has to be performed
   */
  columns: ISearchFilterColumn[];

  /**
   * min length of search text which will trigger the search
   *
   * Default length to trigger search is 3
   */
  minWordLength?: string;

  /**
   * set it if want to show/hide `search <searchtext> in Everywhere` option
   */
  canSearchInAllColumns?: boolean;

  /**
   * `NOTE: only to be used when using with listing component and not the listing-search component independently`
   *
   * transform function to take the searchText and create criteria  as required
   * (if not being used, then it will create criteria by its own)
   */
  criteriaTransformFn?: ((searchText: string) => CriteriaInterface[]);
}

export interface ISearchFilterColumn {
  /**
   * field name respective to list column's field name
   */
  fieldName: string;

  /**
   * label to be displayed in search suggestions
   */
  label: string;

  /**
   * criteria key to be added in the fieldName property of criteria object
   */
  criteriaKey: string;
}
