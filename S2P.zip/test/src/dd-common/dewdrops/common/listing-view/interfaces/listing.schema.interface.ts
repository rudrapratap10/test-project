import { IListingColumnSchema } from './listing.column.interface';
import { IListingFilterSchema } from './listing.filter.interface';
import { IListingSearchSchema } from './listing.search.interface';
import { IListingViewsSchema } from './listing-view.interface';

export interface IListingSchema {
// Unique identifier for the listing instance. For example: "requisition_all_listing".
// This may be used to store listing specific data locally

id: string;

// Enable the checkbox column to allow entity selection
// This would enable the parent component to capture selected entities via an output event
checkable: boolean;

// Indicates if the records can have flag stating important. This option is important
// so that helptext gets aligned with the flag column
flaggable: boolean;

// The number of columns that are to be displayed in the fixed + scrollable layout
// If there's only one fixed column on the left, and one fixed column on the right, pass 1
// If all columns are fixed, ie, there is no horizontal scrolling, skip this option or pass null
fixedColumns: number;

// List of columns configured for this listing, see corresponding interface for details
columns: IListingColumnSchema[];

// List of filters applicable for this listing, see corresponding interface for details
filters: IListingFilterSchema[];

search: IListingSearchSchema;

views?: IListingViewsSchema;

// i18n language label key to be passed, not the translated text
defaultViewLabel: string;

// use this field when accessing child records. If value is defined, it means the listing supports accordion
child: string;
}
