import { FilterInterface } from '@dewdrops/interfaces';

export interface IListingViewsSchema {
  pageName: string;

  listInfo?: {
    isFilterApplied: boolean,
    isSorted: boolean,
    isPageRecordsChanged: boolean,
    noRecordsFound: boolean
  };

  viewCriteria?: FilterInterface;

  getAllViews: IListingViewsApi;

  getViewById?: IListingViewsApi;

  updateView?: IListingViewsApi;

  createNewView?: IListingViewsApi;

  renameView?: IListingViewsApi;

  duplicateView?: IListingViewsApi;

  deleteView?: IListingViewsApi;

  defaultView?: IListingViewsApi;

  saveView?: IListingViewsApi;

  exportView?: IListingViewsApi;
}

export interface IListingViewsApi {

  /**
   * @optional
   * type of api call
   * for example: get, post, put, delete
   */
  method?: string;

  /**
   * url of the api call
   *
   * if any url contains any id or other parameter to be added, then
   * add it like {nameOfParameter} in between the url
   *
   * example:
   * if you want to pass view id, then the sample url can look like:
   * api/a/{viewId}/exportView
   */
  url: string;

  /**
   * request body for the api
   *
   * @optional
   */
  body?: any;

  /**
   * use this if you want to create request body manually with the
   * view details provided by this transform function
   */
  bodyTransformFn?: ((viewData: IViewData) =>  any );
}

export interface IViewData {
  id?: string;
  name?: string;
  filters?: any;
  sorts?: any;
  gridColumns?: any;
}
