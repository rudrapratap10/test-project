import { CriteriaInterface } from '@dewdrops/interfaces';
import { IFilterComponent } from './filter.component.interface';

export interface IListingFilterSchema {
    // Optional, id of the field, if this filter is specific to a column specified in the column schema
    fieldName: string;

    // i18n language label key for the filter headering.
    // This may or may not be different from the column heading. It is recommended to keep it same.
    label: string;

   // Instance of the filter component (implementing FilterInterface) to be used
    filter: IFilterComponent;

    // The criteria's fieldName to be used when transforming the data to and from a CriteriaInterface.
    criteriaKey: string;

    // The criteriaKey is optional if you provide a transformation fn' to extract value from Criteria
    // The function would accept a list of applied Criteria and return the raw selected value
    fromCriteriaFn: (criteria: CriteriaInterface[]) => any;

    // The criteriaKey is optional if you provide both the transformation functions
    // This function would accept the raw selected value and return a list of applicable Criteria
    toCriteriaFn: (value: any) => CriteriaInterface[];
}
