export interface IFilterComponent {

}
