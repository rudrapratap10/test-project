import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dew-listing-nav-tabs',
  templateUrl: './listing-nav-tabs.component.html',
  styleUrls: ['./listing-nav-tabs.component.scss']
})
export class ListingNavTabsComponent implements OnInit {
  @Input() listingNavTabsObj = [
    {
      label: '',
      link:'',
      show:true
    }
  ];
  constructor() { }

   ngOnInit() {
  
   }

}
