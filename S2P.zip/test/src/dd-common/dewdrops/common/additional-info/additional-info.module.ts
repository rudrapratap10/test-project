import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import {
  RouterModule
} from '@angular/router';
import {AdditionalInfoComponent} from './additional-info.component';
import {CommonAddressComponent} from '../details-info/common-address/common-address.component';
import { TabsModule, LayoutModule, ButtonsModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import {DewDetailsInfoModule} from '../details-info/details-info.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    TabsModule,
    TranslateModule,
    LayoutModule,
    DewDetailsInfoModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonsModule
  ],
  declarations: [
    AdditionalInfoComponent,
  ],
  exports: [
    AdditionalInfoComponent
  ]
})
export class AdditionalInfoModule { }
