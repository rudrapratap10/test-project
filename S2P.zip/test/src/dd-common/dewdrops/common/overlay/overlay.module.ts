/**
 * @module OverlayModule
 *
 * @description This module defines services for managing overlays, dialogs etc as
 * dynamic components.
 */

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { AlertComponent } from './alert/alert.component';
import { ConfirmComponent } from './confirm/confirm.component';
import { LocationService } from './location.service';
import { CommonOverlayBuilder } from './overlay-builder.service';
import { OverlayMarkerDirective } from './overlay-marker.directive';
import { OverlayService } from './overlay.service';
import { ProgressOverlayComponent } from './progress-overlay/progress-overlay.component';

const declarations = [
  OverlayMarkerDirective,
  ProgressOverlayComponent,
  AlertComponent,
  ConfirmComponent
];

@NgModule({
  imports: [CommonModule, GlobalUIModule, TranslateModule],
  declarations: declarations,
  providers: [
    OverlayService,
    CommonOverlayBuilder,
    LocationService
  ],
  exports: declarations,
  entryComponents: [
    ProgressOverlayComponent,
    AlertComponent,
    ConfirmComponent
  ]
})
export class OverlayModule {

}
