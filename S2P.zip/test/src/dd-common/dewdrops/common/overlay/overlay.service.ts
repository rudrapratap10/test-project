import {
  Injectable,
  ComponentFactoryResolver,
  Injector,
  ViewContainerRef,
  Optional,
  Type,
  Provider
} from '@angular/core';
import { Overlay } from './overlay';
import { LocationService } from './location.service';

@Injectable()
export class OverlayService {

  constructor(
    private _componentFactoryResolver: ComponentFactoryResolver,
    private _locationService: LocationService
    ) {

  }

  /**
   * Creates the overlay represented by the component identified by the param `componentClass`
   * @param componentClass
   */
  public create<T extends Overlay>(componentClass: Type<T>) {
    return this.doCreate(componentClass, this._locationService.location);
  }

  public createIn<T extends Overlay>(viewContainerRef: ViewContainerRef): (componentClass: Type<T>) => T {
    return (componentClass: Type<T>) => this.doCreate(componentClass, viewContainerRef);
  }

  doCreate<T extends Overlay>(componentClass: Type<T>, viewContainerRef: ViewContainerRef) {
    const componentFactory = this._componentFactoryResolver.resolveComponentFactory(componentClass);
    const componentRef = viewContainerRef.createComponent(componentFactory);
    componentRef.instance.registerClearFn(() => componentRef.destroy());
    return componentRef.instance;
  }
}
