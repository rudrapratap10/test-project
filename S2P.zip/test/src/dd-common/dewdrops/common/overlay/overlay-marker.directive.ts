import {
  Directive,
  ViewContainerRef,
  OnInit
} from '@angular/core';
import { LocationService } from './location.service';

@Directive({
  selector: '[dewOverlayMarker]'
})
export class OverlayMarkerDirective implements OnInit {

  constructor(private _host: ViewContainerRef, private _locationService: LocationService) {
  }

  ngOnInit() {
    this._locationService.location = this._host;
  }
}
