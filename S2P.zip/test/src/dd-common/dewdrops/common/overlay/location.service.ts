import {
  Injectable,
  ViewContainerRef
} from '@angular/core';

@Injectable()
export class LocationService {

  private _location: ViewContainerRef;

  constructor() {}

  get location() {
    return this._location;
  }

  set location(value: ViewContainerRef) {
    this._location = value;
  }
}
