import {
  Component,
  OnInit,
  Input,
  OnDestroy,
  Output,
  EventEmitter
} from '@angular/core';
import {
  AlertDialog,
  AlertErrorHandlerEvent
} from '../overlay';
import { Subject } from 'rxjs/Subject';
import { ReplaySubject } from 'rxjs/ReplaySubject';

@Component({
  selector: 'dew-alert-overlay',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements OnInit, AlertDialog {


  @Input()
  public successIcon = `/assets/images/common/success.svg`;
  @Input()
  public failureIcon = `/assets/images/common/error.svg`;
  @Input()
  public warningIcon = `/assets/images/common/warning.svg`;

  @Input() type: string;

  @Input() alertTitle: string;

  @Input() alertText: string;

  @Input() clearBtnLabel: string;

  @Input() mainActionBtnLabel: string;

  @Input() autoClose: boolean;

  @Input() closeIn: number;

  @Input() errorHandler: any;

  // tslint:disable-next-line:no-output-on-prefix
  @Output() onClear: EventEmitter<any>;

  close$: Subject<any>;

  clearFn: any;

  constructor() {
    this.close$ = new ReplaySubject(0);
    this.onClear = new EventEmitter();
  }

  ngOnInit() {
    if (!this.errorHandler && this.autoClose) {
      setTimeout(
        () => this.clear(),
        this.closeIn
      );
    }
  }

  clear() {
    this.close$.next();
    this.onClear.emit();
    if (this.clearFn) {
      this.clearFn();
    }
  }

  handleError() {
    this.errorHandler();
    this.clear();
  }

  registerClearFn(clearFn: any): void {
    this.clearFn = clearFn;
  }

}
