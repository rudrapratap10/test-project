import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

/**
 * Defines the interface for an overlay component
 */
export interface Overlay {

  // method to be called when the overlay is to be cleared off (destroyed) the view
  clear: () => void;

  /**
   * method called by the overlay creator to pass in the function that will destroy
   * (clear off the view) the overlay when {@link clear} is called
   */
  registerClearFn: (fn: any) => void;
}

/**
 * Defines the interface for a dialog component
 */
export interface Dialog extends Overlay {
  close$: Subject<any>;
}

/**
 * Defines the interface to be implemented by an alert dialog component
 */
export interface AlertDialog extends Dialog {
  alertText: string;
  type: string;
  clearBtnLabel: string;
  mainActionBtnLabel?: string;
}

/**
 * Defines the inteface to be implemented by a confirmation dialog component
 */
export interface ConfirmDialog extends Dialog {
  confirmTxt: string;
  confirmBtnLabel: string;
  rejectBtnLabel: string;
}

export const DEW_ALERT_DLG = '[Alert] dialog component token';
export const DEW_CONFIRM_DLG = '[Confirmation] dialog component token';

export enum ConfirmEventType {
  REJECT = -1,
  CONFIRM = 1,
  DISMISS = 0
}

export interface ConfirmEvent {
  type: ConfirmEventType;
  data?: any;
}

export enum AlertType {
  FAILURE = 'failure',
  SUCCESS = 'success',
  WARNING = 'warning'
}

export const AlertErrorHandlerEvent = 'alert error handler';
