import { Component, OnInit, ContentChildren, QueryList, Input, ViewChild, ElementRef, forwardRef } from '@angular/core';
import { PageWrapperContent } from './page-content.component';
const provider = {
  provide: 'spotlight',
  useExisting: forwardRef(() => PageWrapperComponent)
};

@Component({
  selector: 'dew-page-wrapper',
  templateUrl: './page-wrapper.component.html',
  styleUrls: ['./page-wrapper.component.scss'],
  providers: [provider]
})
export class PageWrapperComponent implements OnInit {

  @Input()
  formattedPageTitle: string;

  @Input()
  showBackOption: boolean;

  @ViewChild('spotlightElement')
  spotlightElement: ElementRef;

  @ContentChildren(PageWrapperContent)
  pageContentQueryList: QueryList<PageWrapperContent>;
  
  constructor() { }

  ngOnInit() {
  }
  
}
