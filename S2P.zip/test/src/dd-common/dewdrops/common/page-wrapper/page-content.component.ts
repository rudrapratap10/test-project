import { Component, OnInit, ContentChildren, QueryList, TemplateRef, ContentChild, ViewChild, Input } from '@angular/core';

@Component({
  selector: 'dew-page-content',
  template: `
    <ng-content></ng-content>
  `
})
export class PageWrapperContent implements OnInit {

  @ViewChild('template')
  template: TemplateRef<any>;
  
  constructor() { }

  ngOnInit() {
  }

}
