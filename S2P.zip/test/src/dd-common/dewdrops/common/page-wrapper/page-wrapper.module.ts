import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule, ProgressModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { SpotlightModule } from '../spotlight/spotlight.module';
import { PageWrapperComponent } from './page-wrapper.component';
import { PageWrapperContent } from './page-content.component';

@NgModule({
  imports: [
    CommonModule,
    SpotlightModule,
    LayoutModule,
    TranslateModule,
    ProgressModule
  ],
  declarations: [PageWrapperComponent,  PageWrapperContent],
  exports: [PageWrapperComponent,  PageWrapperContent]
})
export class PageWrapperModule { }
