import { Component } from '@angular/core';
import { Dialog } from '../dialog';
import { DialogService } from '../dialog.service';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Closable } from '../closable';
import { Observable, Subscribable } from 'rxjs/Observable';
import { interval } from 'rxjs/observable/interval';
import { take } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'dew-alert-dialog',
  templateUrl: './alert-dialog.component.html',
  styleUrls: ['./alert-dialog.component.scss']
})
export class AlertDialogComponent extends Dialog implements Closable {

  alertText: string;

  // indicates the type of alert dialog
  type:string;

  // indicates the corresponding type of icon
  iconType:string;

  enableBackdrop = true;

  // holds a reference to close function provided by dialog service
  closeFn;

  routerSubscribe: Subscription;

  constructor(private router: Router) {
    super();
    this.close = new ReplaySubject(0);
  }

  ngOnInit() {
     // to close the dialog when navigate
    this.routerSubscribe = this.router.events.subscribe((val) => this.closeFn())
  }

  onClose() {
    this.close.next();
    if (this.closeFn) {
      this.closeFn();
    }
  }

  // to close the dialog after 6 secs automatically
  autoClose(closeFn){
    this.closeFn = closeFn;
    interval(5000).pipe(
      take(1)
    ).subscribe(() => this.closeFn());
  }

    saveCloseHandler(closeFn) {
      this.closeFn = closeFn;
    }

    ngOnDestroy() {
      this.routerSubscribe.unsubscribe();
    }
  }




  