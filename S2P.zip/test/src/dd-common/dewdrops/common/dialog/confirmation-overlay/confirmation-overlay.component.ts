import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dew-confirmation-overlay',
  templateUrl: './confirmation-overlay.component.html',
  styleUrls: ['./confirmation-overlay.component.scss']
})
export class ConfirmationOverlayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
