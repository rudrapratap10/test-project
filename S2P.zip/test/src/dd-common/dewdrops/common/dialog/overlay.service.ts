import {
  Injectable,
  ComponentFactoryResolver,
  Injector,
  ViewContainerRef
} from '@angular/core';
import { Closable } from './closable';
import { Dialog } from './dialog';
import { DialogMediator } from './dialog-mediator.service';
import { SpinnerComponent } from './spinner/spinner.component';
import { ConfirmDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ConfirmEventType, ConfirmEvent } from './confirmation-dialog/confirm-event';

@Injectable()
export class OverlayService {

  constructor(private dialogMediator: DialogMediator,
    private componentFactoryResolver: ComponentFactoryResolver) {
  }

  showOverlay(componentClass: any) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentClass);
    const componentRef = this.dialogMediator.dialogHostViewContainer.createComponent(componentFactory);
    (<Closable> componentRef.instance).saveCloseHandler(() => componentRef.destroy());
    return (<Closable> componentRef.instance);
  }
}
