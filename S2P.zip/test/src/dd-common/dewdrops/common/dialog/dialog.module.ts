import { NgModule, Optional, ComponentFactoryResolver } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertDialogComponent } from './alert-dialog/alert-dialog.component';
import { DialogHostDirective } from './dialog-host.directive';
import { DialogMediator } from './dialog-mediator.service';
import { DialogService } from './dialog.service';
import { SpinnerComponent } from './spinner/spinner.component';
import { ConfirmDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ModuleWithProviders } from '@angular/compiler/src/core';/* 
import { AlertOverlayComponent } from './alert-overlay/alert-overlay.component'; */
import { ConfirmationOverlayComponent } from './confirmation-overlay/confirmation-overlay.component';
import { UtilityModule } from '../utility/utility.module';

const components = [
  SpinnerComponent,
  ConfirmDialogComponent,
  AlertDialogComponent,
  ConfirmationOverlayComponent
];

const dialogServiceProvider = (dialogService: DialogService, dialogMediator: DialogMediator,
      componentFactoryResolver: ComponentFactoryResolver) => {
        if (dialogService) {
          return dialogService;
        } else {
          return new DialogService(dialogMediator, componentFactoryResolver);
        }
};

export class DlgService {}
export class DlgMediator {}
@NgModule({
  declarations: [...components, DialogHostDirective],
  entryComponents: components,
  exports: [
    DialogHostDirective,
    ConfirmationOverlayComponent
    ],
  imports: [
    CommonModule,
    UtilityModule
  ]
})
export class DialogModule {
  static root(): ModuleWithProviders {
    return {
      ngModule: DialogModule,
      providers: [
        DialogMediator,
        {provide: DlgService, useClass: DialogService, deps: [DialogMediator, ComponentFactoryResolver]}]
    };
  }

  static child(): ModuleWithProviders {
    return {
      ngModule: DialogModule,
      providers: [
        {provide: DialogService, useExisting: DlgService}
      ]
    };
  }
}
