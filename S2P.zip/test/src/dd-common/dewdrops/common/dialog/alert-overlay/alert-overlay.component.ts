import { Component, OnInit, Input } from '@angular/core';
import { IMG_DIR  } from '@dewdrops/globals';

@Component({
  selector: 'dew-alert-overlay',
  templateUrl: './alert-overlay.component.html',
  styleUrls: ['./alert-overlay.component.scss']
})
export class AlertOverlayComponent implements OnInit {

  @Input()
  public successIcon = `${IMG_DIR}/common/ic-posted.svg`;
  @Input()
  public failureIcon = `${IMG_DIR}/common/ic-posted-failed.svg`;
  @Input() type: string;
  @Input() title: string;
  @Input() message: string;
  @Input() btnText: string;
  constructor() { }

  ngOnInit() {
  }

}
