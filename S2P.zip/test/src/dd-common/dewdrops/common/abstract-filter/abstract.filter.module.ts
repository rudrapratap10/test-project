import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  RouterModule
} from '@angular/router';

import { AbstractFilterComponent } from './abstract-filter.component';
import { GlobalUIModule } from '@dewdrops/bootstrap';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    GlobalUIModule
  ],
  declarations: [
    AbstractFilterComponent,
  ],
  exports: [
    AbstractFilterComponent
  ]
})
export class AbstractFilterModule { }
