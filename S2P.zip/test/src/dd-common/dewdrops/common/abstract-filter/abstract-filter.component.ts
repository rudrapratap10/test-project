import {
  Component,
  OnInit,
  Inject,
  Optional,
  Input,
  OnChanges,
  Output,
  EventEmitter
} from "@angular/core";

@Component({
  selector: "dew-abstract-filter",
  templateUrl: "./abstract.filter.component.html",
  styleUrls: ["./abstract.filter.component.scss"]
})
export class AbstractFilterComponent implements OnInit, OnChanges {
  @Input() value: any;
  @Input() name: any;
  @Output() whenApplied: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    @Inject("FILTER_PIPE_LINE")
    @Optional()
    private _filterPipeLine: any
  ) {}

  ngOnInit() {}

  applyChecklistFilter() {
    this._filterPipeLine.put(this.name, this.value);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  clearChecklistFilter(value?) {
    this._filterPipeLine.put(this.name, this.value);
    this._filterPipeLine.apply();
    this.whenApplied.emit();
  }

  ngOnChanges() {
    if (this.value) {
      this.applyChecklistFilter();
    }
  }
}
