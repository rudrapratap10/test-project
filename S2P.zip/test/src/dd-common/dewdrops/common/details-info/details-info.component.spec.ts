import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DewDetailsInfoComponent } from './details-info.component';

describe('AdditionalInfoComponent', () => {
  let component: DewDetailsInfoComponent;
  let fixture: ComponentFixture<DewDetailsInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DewDetailsInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DewDetailsInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
