import { Component, Input, OnInit } from '@angular/core';
import { DateformatPipe } from 'dd-common/dewdrops/common/dateformat/dateformat.pipe';
@Component({
  selector: 'dew-details-info',
  templateUrl: './details-info.component.html',
  styleUrls: ['./details-info.component.scss']
})
export class DewDetailsInfoComponent implements OnInit {

  @Input() detailsInfoArr;
  @Input() colSize = 3;

  constructor(private _datePipe: DateformatPipe) { }

  ngOnInit() { }

  shouldshow(col) {
    if (!col.validation) {
      return true;
    }
    if (!col.validation.invisible) {
      return true;
    } else {
      if (col.value) {
        return true;
      }
    }
    return false;
  }

  getValue(data, row, col) {
    if (this.detailsInfoArr[row][col].validation) {
      if (this.detailsInfoArr[row][col].validation.dateFormat) {
        return this._datePipe.transform(data.value, '');
      }
    }
    return data.value;
  }

}
