import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { Tax } from '../tax/tax';
import { TaxService } from '../tax/tax.service';
import { checkWarningMsg } from '../utility/check-warning-msg.utility';
@Component({
    selector: 'dew-composite-tax',
    templateUrl: './composite-tax.component.html',
    styleUrls: ['./composite-tax.scss']
})
export class CompositeTaxComponent implements OnInit, OnChanges {

    @Input() public taxes = [];
    @Input() public invoiceTaxes = [];
    @Input() public compoundTaxes = [];
    @Input() public freightTaxes = [];
    @Input() public totalAmount = 0;
    @Input() public currency;
    @Input() public discount = 0;
    @Input() public lineTaxesTotal = 0;
    @Input() freightAmount = 0;
    @Input() mode = 'EDIT';
    @Input() showExtraCharges: true;

    @Input() invoiceGrossTotal = 'DEWDROPS_INV_GROSS_TOTAL' as string;
    @Input() taxesOnGrossInvoiceTotal = 'DEWDROPS_GROSS_TAX_HEADER' as string;
    @Input() newGrossInvoiceTotalTitle = 'DEWDROPS_NEW_GROSS_INVOICE_TOTAL' as string;
    @Input() noTaxFaound = 'DEWDROPS_NO_TAX_A_LABEL' as string;
    @Input() noCompoundTaxFound = 'DEWDROPS_NO_COMPOUND_TAX_LABEL' as string;
    @Input() noFreightTaxFound = 'EINVOICE_SECTION_NO_FREIGHT_TAX' as string;
    @Input() noInvoiceTaxTotal = 'DEWDROPS_NO_INVOICE_TAX_TOTAL' as string;
    @Input() apllyTaxesOnGrossInvoiceTotal = 'DEWDROPS_APPLY_TAX_GROSS_LABEL' as string;

    @Input() warnings: any[] = [];
    @Input() errors: any[] = [];

    public checkWarningMsg = checkWarningMsg;
    public showTaxGrid: boolean;
    public showCompoundTaxGrid: boolean;
    public showFreightTaxGrid: boolean;
    public showCtax: boolean;
    public showGrossInvoiceTaxGrid: boolean;
    public showBorneByBuyer = true;
    public compoundTotal = 0;
    public totalIndirectTaxes = 0;
    public enable = false;
    public currentBorneByBuyerTax: any[] = [];
    frightTaxTotal = 0;
    frightTaxSubTotal = 0;
    frightTaxArray = [];
    compondTaxTotal = 0;
    invoiceTotalAmount = 0;
    @Input() extraCharges = 0 as number;
    @Input() insuranceCharges = 0 as number;
    @Input() exciseCharges = 0 as number;
    @Input() predefinedData = false;
    invoiceTaxSubTotal = 0 as number;
    newGrossInvoiceTotal = 0 as number;
    useTaxTypeTotal = 0 as number;
    totalTaxToBeBorneByBuyer = 0 as number;
    decimalPrecisionValue: any;
    @Input() isTaxExempt: boolean = false;
    @Input() supplierName: string;

    @Output() emitTaxes = new EventEmitter<any>();
    @Output() emitCompundTaxes = new EventEmitter<any>();
    @Output() emitFreightTaxes = new EventEmitter<any>();
    @Output() emitGrossTaxes = new EventEmitter<any>();
    @Output() emitFreightAmount = new EventEmitter<Number>();
    @Output() emitInvoiceTaxes = new EventEmitter<any>();
    @Output() emitTotalAmount = new EventEmitter<Number>();
    @Output() emitDiscount = new EventEmitter<Number>();
    @Output() emitLineTaxesTotal = new EventEmitter<Number>();
    @Output() emitExtraCharges = new EventEmitter<Number>();
    @Output() emitInsuanceCharges = new EventEmitter<Number>();
    @Output() emitExciseCharges = new EventEmitter<Number>();
    @Output() emitUseTaxTypeTotal = new EventEmitter<Number>();
    @Output() emitCheckboxChange = new EventEmitter<any>();
    @Output() emitIsUseTaxType = new EventEmitter<Boolean>();
    



    constructor(private taxService: TaxService) {
    }

    ngOnInit() {
        this.compoundTotal = this.totalAmount;
        if (this.predefinedData) {
            this.showTaxGrid = this.taxes.length === 0 ? true : false;
            this.showCompoundTaxGrid = this.compoundTaxes.length === 0 ? false : true;
            this.showFreightTaxGrid = this.freightTaxes.length === 0 ? false : true;
            this.showCtax = this.lineTaxesTotal === 0 ? false : true;
            this.showGrossInvoiceTaxGrid = this.invoiceTaxes.length === 0 ? false : true;
        }
    }

    ngOnChanges() {
        const warnings = this.warnings;
        this.calculateCompundTotal();
        this.decimalPrecision();
        //  this.invoiceTotal();
    }

    generalTaxCheckboxChanged(event) {
        this.emitCheckboxChange.emit({ taxType: 'taxA', checkboxValue: event });
    }
    compoundTaxCheckboxChanged(event) {
        this.emitCheckboxChange.emit({ taxType: 'taxB', checkboxValue: event });
    }

    freightCheckboxChanged(event) {
        this.emitCheckboxChange.emit({ taxType: 'taxD', checkboxValue: event });
    }
    invoiceTaxCheckboxChanged(event) {
        this.emitCheckboxChange.emit({ taxType: 'invoiceTax', checkboxValue: event });
    }
    calculateCompundTotal() {
        this.compoundTotal = this.totalAmount + this.totalIndirectTaxes + (+this.lineTaxesTotal) - (+this.discount);
    }

    taxChange(newTaxArr: any) {
        const tempTax = [];
        newTaxArr.forEach((tax) => {
            if (tax.rate && tax.taxAmount) {
                tempTax.push(tax);
            }
        });
        if (tempTax.length > 0) {
            this.totalIndirectTaxes = 0;
            tempTax.forEach((validTax) => {
                if (validTax.isUseTaxType) {
                    this.emitIsUseTaxType.emit(validTax.isUseTaxType);
                    this.useTaxTypeTotal = 0;
                    this.useTaxTypeTotal = this.useTaxTypeTotal + (+validTax.isUseTaxType);
                    this.emitUseTaxTypeTotal.emit(this.useTaxTypeTotal);
                }
                this.emitIsUseTaxType.emit(validTax.isUseTaxType);
                this.totalIndirectTaxes += validTax.isUseTaxType ? 0 : validTax.taxAmount;
            });
            this.calculateCompundTotal();
            this.emitTaxes.emit(tempTax);
        }
        this.invoiceTotal();
    }

    frightTaxChange(newTaxArr: any) {
        this.emitFreightAmount.emit(this.freightAmount);
        this.frightTaxTotal = 0;
        this.frightTaxSubTotal = 0;
        newTaxArr.forEach((tax) => {
            if (tax.taxAmount) {
                this.frightTaxTotal = !this.showFreightTaxGrid ? this.frightTaxTotal : this.frightTaxTotal + (+tax.taxAmount);
            }
        });
        this.frightTaxSubTotal = (+this.frightTaxTotal) + (+this.freightAmount);
        this.emitFreightTaxes.emit(newTaxArr);
        this.invoiceTotal();
    }

    compoundTaxChange(newTaxArr: any) {
        this.compondTaxTotal = 0;
        newTaxArr.forEach((tax) => {
            if (tax.taxAmount) {
                this.compondTaxTotal = this.compondTaxTotal + (+tax.taxAmount);
            }
        });
        this.emitCompundTaxes.emit(newTaxArr);
        this.invoiceTotal();
    }

    get totalTaxAmount() {
        if (this.showTaxGrid) {
            return this.frightTaxTotal + this.lineTaxesTotal;
        } else if (!this.showTaxGrid && !this.showCompoundTaxGrid) {
            return this.totalIndirectTaxes + this.frightTaxTotal + this.lineTaxesTotal;
        } else
            return this.totalIndirectTaxes + this.frightTaxTotal + this.lineTaxesTotal + this.compondTaxTotal;
    }

    invoiceTotal() {
        let othercharges = 0 as number;
        if (this.extraCharges) {
            this.emitExtraCharges.emit(this.extraCharges);
            othercharges += +this.extraCharges;
        }
        if (this.exciseCharges) {
            this.emitExciseCharges.emit(this.exciseCharges);
            othercharges += +this.exciseCharges;
        }

        if (this.insuranceCharges) {
            this.emitInsuanceCharges.emit(this.insuranceCharges);
            othercharges += +this.insuranceCharges;
        }
        if (!this.freightAmount) {
            this.freightAmount = 0;
        }
        if (!this.totalAmount) {
            this.totalAmount = 0;
        }
        this.emitTotalAmount.emit(this.totalAmount);
        if (!this.discount) {
            this.discount = 0;
        }
        this.emitDiscount.emit(this.discount);
        this.invoiceTotalAmount = (+this.totalTaxAmount) + (+this.freightAmount) +
            (+othercharges) + (+this.totalAmount);
    }

    totalGrossInvoiceTax(newTaxArr: any) {
        this.invoiceTaxSubTotal = 0;
        this.totalTaxToBeBorneByBuyer = 0;
        newTaxArr.forEach((tax: Tax) => {
            if (tax.taxAmount) {
                if (tax.borneByBuyerCheck) {
                    this.totalTaxToBeBorneByBuyer = this.totalTaxToBeBorneByBuyer + (+tax.taxAmount);
                } else {
                    this.invoiceTaxSubTotal = this.invoiceTaxSubTotal + (+tax.taxAmount);
                }
            }
        });
        this.newGrossInvoiceTotal = (+this.invoiceTotalAmount) + (+this.invoiceTaxSubTotal);
        this.emitGrossTaxes.emit(newTaxArr);
    }
    decimalPrecision() {
        let pricision;
        this.taxService.getCurrencyPrecision(pricision).
            subscribe((res) => {
                if (this.currency) {
                    res.data.records.find((decimalArrValue) => {
                        if (decimalArrValue.code === this.currency) {
                            this.decimalPrecisionValue = decimalArrValue.decimalPrecision;
                        }
                    });
                }
            });

    }
}
