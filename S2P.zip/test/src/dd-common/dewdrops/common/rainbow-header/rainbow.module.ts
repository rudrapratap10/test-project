import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RainbowHeaderComponent } from './rainbow-header.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    RainbowHeaderComponent
  ],
  exports:[
    RainbowHeaderComponent
  ]
})
export class RainbowModule { }
