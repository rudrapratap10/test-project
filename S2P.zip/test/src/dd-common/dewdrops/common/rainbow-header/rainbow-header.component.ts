import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'dew-rainbow-header',
  templateUrl: './rainbow-header.component.html',
  styleUrls: ['./rainbow-header.component.scss']
})
export class RainbowHeaderComponent implements OnInit {

  @Input() homeUrl: string;
  
  constructor() { }

  ngOnInit() {
  }

}