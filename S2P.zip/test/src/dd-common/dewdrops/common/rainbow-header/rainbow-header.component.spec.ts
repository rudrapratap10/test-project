import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RainbowHeaderComponent } from './rainbow-header.component';

describe('RainbowHeaderComponent', () => {
  let component: RainbowHeaderComponent;
  let fixture: ComponentFixture<RainbowHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RainbowHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RainbowHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});