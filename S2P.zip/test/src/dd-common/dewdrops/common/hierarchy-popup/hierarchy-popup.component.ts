import { Component, OnInit, Input, TemplateRef, EventEmitter, Output } from '@angular/core';
import { DefaultTreeOptions } from '../../common/tree/tree-options.model';


@Component({
  selector: 'dew-hierarchy-popup',
  templateUrl: './hierarchy-popup.component.html',
  styleUrls: ['./hierarchy-popup.component.scss']
})
export class HierarchyPopupComponent implements OnInit {

  @Input() modalState: boolean;

  @Input() modalHeader: boolean;

  @Input() nodes: Node;

  @Input() nodeTemplate: TemplateRef<HTMLTemplateElement>;

  @Output() closeHierarchyPopup : EventEmitter<boolean> = new EventEmitter<boolean>();

  public option: DefaultTreeOptions = new DefaultTreeOptions({ nodeHeight: 60});

  constructor() {

  }

  ngOnInit() {

  }

  toggleModalState(event){
   this.modalState = event;
   this.closeHierarchyPopup.emit(event);
  }

}
