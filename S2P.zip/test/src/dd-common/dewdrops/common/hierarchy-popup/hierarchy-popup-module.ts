import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from 'ng2-translate';
import { ButtonsModule, ModalModule } from '@dewdrops/bootstrap';
import {  TreeModule } from 'angular-tree-component';
import { HierarchyTemplateComponent } from './hierarchy-template/hierarchy-template.component';
import { HierarchyPopupComponent } from './hierarchy-popup.component';
import { DewTreeModule } from '../tree/tree.module';


@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
    ButtonsModule,
    ModalModule,
    TreeModule.forRoot(),
    DewTreeModule

  ],
  declarations: [HierarchyTemplateComponent,HierarchyPopupComponent],
  exports: [HierarchyTemplateComponent,HierarchyPopupComponent],
})
export class HierarchyPopupModule { }
