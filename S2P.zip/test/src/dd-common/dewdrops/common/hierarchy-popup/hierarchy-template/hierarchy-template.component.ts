import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';


@Component({
  selector: 'dew-hierarchy-template',
  templateUrl: './hierarchy-template.component.html',
  styleUrls: ['./hierarchy-template.component.scss'],
})
export class HierarchyTemplateComponent implements OnInit {

  constructor() { }

  @Input() nodeTitle: string ;

  @Input() nodeSubTitle: string ;

  @Input() tag: string;

  @Input() tagKind: any;

  @Output() onTitleClick = new EventEmitter();

  @Input() nodes: Node;


 
  

  ngOnInit() {
    if(this.tagKind.isRoot){
      this.tagKind = '#3c9237';
    }
    else if (this.tagKind.hasChildren && !this.tagKind.isRoot){
      this.tagKind = '#00a0d7';
    }
    else if (!this.tagKind.hasChildren){
      this.tagKind = '#999999';
    }
  }


 

  NodeTitleClick(){
    this.onTitleClick.emit();
  }

  

}
