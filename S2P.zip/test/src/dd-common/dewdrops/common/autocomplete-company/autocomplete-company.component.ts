import { Component, OnInit, Input, EventEmitter, Output, AfterContentInit, ViewChild } from '@angular/core';
import { CollectionFactory } from '@dewdrops/factories';
import { AutocompleteComponent } from '../../core/bootstrap/autocomplete/autocomplete/autocomplete.component';
import { FormControl, FormGroup, FormBuilder, Validators, FormsModule } from '@angular/forms';
import { APIClientService } from '../../core/services/api-client/api-client.service';
import { map } from 'rxjs/operators';
import { Subscriber } from 'rxjs/Subscriber';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'dew-autocomplete-company',
  templateUrl: './autocomplete-company.component.html',
  styleUrls: ['./autocomplete-company.component.scss']
})
export class AutocompleteCompanyComponent implements OnInit {

  inputBody: any;
  selectedCompany: any = {};

  @Input()
  minLength: number = 0;
  companyList: any = [];
  staticArrData: any = [];
  searchParam: string;
  public loader: boolean;
  public autoCompleteSubscriber: Subscriber<any>;

  @Output()
  public select = new EventEmitter();

  @Output()
  invalid = new EventEmitter();

  private _datasource: CollectionFactory;
  @Input() set datasource(value: CollectionFactory) {
    this._datasource = value;
    this.inputBody = this._datasource.body;
    this._datasource.count(20);
  }

  @Input() companyFormGroupInstance: FormGroup = this.formBuilder.group({
    companyFormGroup  :  [{ value: {}, disabled: false }, Validators.required]
  });

  constructor(private apiClient: APIClientService, private formBuilder: FormBuilder) {
  }


  ngOnInit() {
  }

  modelFnFactory() {
    return (data: any) => {
      return data;
    };
  }

  displayFn() {
    return (data: any) => {
      return data.name;
    };
  }

  viewToModelTranformFactoryFn() {
    return (value: string, model: any) => {
      model = value;
      return model;
    };
  }

  suggestionStreamFactoryFn() {
    return (query: string) => {
      this.loader = true;
      this.companyList = [];
       if (!this._datasource.body.userId) {
        if(this.inputBody.name){
          delete this.inputBody.name;
        }
        this._datasource.body = this.inputBody;
      }
      if(query){
        this._datasource.body.name = query;
        }
        this.inputBody = this._datasource.body;
        this._datasource.applyPaginate().commit();
        return this._datasource.list$.pipe(map(
          (response) => {
            this.loader = false;
            this.companyList = [];
            this.companyList = response;
            return this.companyList;
          }
        )).catch((error) => {
          this.companyList = [];
          return of(error);
        });
      
    };
  }

  onCompanySelect(companyObj){
    this.selectedCompany ={
      name: companyObj.name,
      code: companyObj.code
    }
    this.select.emit(this.selectedCompany)
  }

  setCompanyModel(formValue){
     if(!formValue.companyFormGroup){
       this.select.emit(null);
    }
  }




}
