import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApproveRejectPopUpComponent } from './approve-reject-pop-up.component';

describe('ApproveRejectPopUpComponent', () => {
  let component: ApproveRejectPopUpComponent;
  let fixture: ComponentFixture<ApproveRejectPopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApproveRejectPopUpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApproveRejectPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
