export interface ApproveRejectLinkItems {     
        label : string,
        id : string,
        isLink : boolean   
  }

  export interface ApprovalRejectItem {
      id: string;
      links: ApproveRejectLinkItems[];
  }
  