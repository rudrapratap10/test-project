import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApproveRejectPopUpComponent } from './approve-reject-pop-up.component';
import { RouterModule } from '@angular/router';
import { TabsModule, LayoutModule, ButtonsModule, ModalModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DewDetailsInfoModule } from '../details-info/details-info.module';
import { CharacterCountModule } from 'dd-common/dewdrops/core/bootstrap/character-count/character-count.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    TabsModule,
    TranslateModule,
    LayoutModule,
    DewDetailsInfoModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonsModule,
    ModalModule,
    GlobalUIModule,
    CharacterCountModule
  ],
  declarations: [ApproveRejectPopUpComponent],
  exports: [
    ApproveRejectPopUpComponent
  ]
})
export class ApproveRejectPopUpModule { }
