import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ApprovalRejectItem } from './model/approveRejectModel';


@Component({
  selector: 'dew-approve-reject-pop-up',
  templateUrl: './approve-reject-pop-up.component.html',
  styleUrls: ['./approve-reject-pop-up.component.scss']
})
export class ApproveRejectPopUpComponent implements OnInit {

  @Input() openModel : boolean;
  @Input() data : any;
  @Input() mode : string;
  @Input() model : ApprovalRejectItem[];

  @Output() closeModel = new EventEmitter();
  @Output() onActionClick = new EventEmitter();
  @Output() onRouteClick = new EventEmitter();
  constructor() { }

  comment : any;
  hasComment : boolean = true
  ngOnInit() {
    console.log(this.model + "model")
  }

  toggleModalState(state)
  {
    this.openModel = state;
    this.closeModel.emit(state);
  }
 
  onAction()
  {

    if(this.comment === undefined || (this.comment.trim().length === 0))      
    {            
      this.hasComment = false;
    }
    else
    {
      this.onActionClick.emit(this.comment);
      this.openModel = false;
      this.comment = ''
      this.closeModel.emit(false);
    }
    
  }


  onClickLink(value)
  {
    this.onRouteClick.emit(value);
  }

}
