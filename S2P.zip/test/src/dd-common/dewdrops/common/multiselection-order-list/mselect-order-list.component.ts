import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  OnChanges
} from '@angular/core';
import { DragulaService } from 'ng2-dragula';
import { PopoverToggleComponent } from '../../core/bootstrap/popover/popover-toggle/popover-toggle.component';
import { ModalComponent } from '../../core/bootstrap/modal/modal.component';
import { find } from 'lodash';

@Component({
  selector: "dew-multiselect-ordered-list",
  templateUrl: "./mselect-order-list.html",
  styleUrls: ["./mselect-order-list.component.scss"]
})
export class MultiSelectOrderedListComponent implements OnInit, OnChanges {
  public isClickable: boolean;
  @Input() listItems = [] as any[];

  @Input() listHeader: string;
  @Input() okButtonText = "Apply" as string;
  @Input() nOkButtonText = "Reset" as string;
  @Input() selectAllListTitle = "Select All" as string;

  @Input() sourceButtonTemplate: TemplateRef<any>;

  @Input() labelField = 'label' as string;
  @Input() idField = 'label' as string;
  @Input() cbModalField = 'selected' as string;
  @Input() disabledField = 'disable' as string;

  @Input() isSortable = false as boolean;
  @Input() isFilterable = true as boolean;
  @Input() selectAllNeeded = true as boolean;

  @Input() popWidth = 340 as number;
  @Input() type = "popup" as string;
  @Input() dragId = "xyz" as string;

  @Input() excludeDefault = true as boolean;

  @Input() min = 2;
  @Input() max = 4;

  @Output() afterActionList = new EventEmitter();

  @ViewChild(PopoverToggleComponent) popToggle: PopoverToggleComponent;

  @ViewChild(ModalComponent) popup: ModalComponent;
  addBackgroundColor: boolean = false

  selectAll = false as boolean;
  copyOfList = [] as any[];
  searchTerm = "" as string;
  testModal: boolean;
  errorMessage: string;
  headerInfo = "" as string;
  sampleArray: any[];
  constructor(
    private dragulaService: DragulaService,
    private cdr: ChangeDetectorRef
  ) { }
  ngOnInit() {
    this.sampleArray = [];
    if (this.listItems) {
      this.listItems.forEach(item => {
        const data: any = {};
        data[this.cbModalField] = item[this.cbModalField];
        data[this.labelField] = item[this.labelField];
        data[this.disabledField] = item[this.disabledField];
        data[this.idField] = item[this.idField];
        this.sampleArray.push(data);
      });
    }

    if (this.sampleArray) {
      const selected = find(this.sampleArray, o => {
        return o[this.cbModalField] === false;
      });

      if (!selected) {
        this.selectAll = true;
      }
    }
    this.addBackgroundColor = false;
    // Destroy existing group if any
    try {
      this.dragulaService.destroy(this.dragId);
    } catch { }
    // init
    this.dragulaService.createGroup(this.dragId, {
      moves: (el, container, handle) => {
        return (
          handle.classList.contains("handle") &&
          !handle.classList.contains("no-drag")
        );
      }
    });
    this.popWidth = 400;
    this.copyOfList = JSON.parse(JSON.stringify(this.sampleArray));

    if (this.min && this.max) {
      this.headerInfo = `You can select min ${this.min} and max ${
        this.max
        } fields`;
    } else if (this.min) {
      this.headerInfo = `You need to select atleast ${this.min} fields`;
    } else if (this.max) {
      this.headerInfo = `You can select upto ${this.max} fields`;
    }
  }
  ngOnChanges() {
    this.validateAndSyncSelectAll();
  }

  onOKDone() {
    // this.afterActionList.emit(this.listItems);
    if (this.type === "popover") {
      if (this.errorMessage) {
        return false;
      } else {
        this.popToggle.state.emit();
        this.sampleArray.forEach((item, index) => {
          this.listItems[index].selected = item.selected;
        });
        this.afterActionList.emit(this.listItems);
      }
    } else {
      if (!this.errorMessage) {
        this.sampleArray.forEach((item, index) => {
          this.listItems[index].selected = item.selected;
        });
        this.afterActionList.emit(this.listItems);
        this.toggleModalState(false);
      }
    }

  }

  selectorDeselect() {
    if (this.listItems) {
      if (this.min && !this.selectAll) {
        // show min error
      }

      if (this.max && this.max < this.listItems.length && this.selectAll) {
        // show max error
      }
      if (!this.selectAll) {
        this.isClickable = true;
      }
      else {
        this.isClickable = false;
      }
      let i = 0;
      for (; i < this.sampleArray.length; ++i) {
        if (this.sampleArray[i][this.disabledField] !== true) {
          this.sampleArray[i][this.cbModalField] = this.selectAll;
        }
      }
    }
  }

  validateAndSyncSelectAll(item?: any) {
    if (this.sampleArray) {
      let i = 0;
      const selectedItems = [];
      for (; i < this.sampleArray.length; i++) {
        if (this.sampleArray[i][this.cbModalField]) {
          selectedItems.push(this.sampleArray[i]);
        }
      }
      if (selectedItems.length < 1) { this.isClickable = true } else { this.isClickable = false }
      if (this.min >= selectedItems.length) {
        // show min error
        this.errorMessage = `Please select atleast ${this.min}`;
        this.cdr.detectChanges();
        return;
      } else if (this.max < selectedItems.length) {
        // show max error
        //  item[this.cbModalField] = false;
        this.cdr.detectChanges();
      }

      this.errorMessage = undefined;

      this.selectAll = selectedItems.length === this.sampleArray.length;

    }

  }

  private onCancelDone() {
    this.errorMessage = undefined;
    this.selectAll = false;
    this.sampleArray = JSON.parse(JSON.stringify(this.copyOfList));
    if (this.sampleArray) {
      const selected = find(this.sampleArray, o => {
        return o[this.cbModalField] === false;
      });

      if (!selected) {
        this.selectAll = true;
      }
    }
    this.afterActionList.emit(this.copyOfList);
    if (this.type === "popover") {
      this.popToggle.state.emit();
    } else {
      this.toggleModalState(false);
    }
  }

  private toggleModalState(state): void {
    if (state === false) {
      // this.popup._closeModal();
      // this.message = 'Modal Closed';
    } else {
      // this.message = 'This message will be changed after modal is closed';
    }
    this.testModal = state;
  }
  action(event) {
    this.addBackgroundColor = event;
  }
}
