These two 3rd party modules need to be installd if you want to use this component:

"ng2-dragula" : npm install --save ng2-dragula
"ngx-pipes": npm install --save ngx-pipes

Add dev dependency in package.json as
"@types/dragula": "2.1.33"
