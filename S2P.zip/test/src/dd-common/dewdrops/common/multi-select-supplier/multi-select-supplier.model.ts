import { CriteriaInterface, CriteriaGroupInterface} from '@dewdrops/interfaces';
import { CollectionFactory } from '@dewdrops/factories';

export class InitialSupplierType{
    type: any ='Supplier';
    value: any;
}

export class SupplierOptions{
    datasource: CollectionFactory;
    label: string = 'Supplier'; // i18n key, optional, if not provided then User/Usergroup will be used
    criteriaGroup: CriteriaGroupInterface; // optional, with default criteria of fieldName 'name'
    bindingProperty: string;
    propertyId: string;
    icon: string;
}

export class SupplierGroupOptions{
    datasource: CollectionFactory;
    label: string = 'Supplier Group'; // i18n key, optional, if not provided then User/Usergroup will be used
    criteriaGroup: CriteriaGroupInterface; // optional, with default criteria of fieldName 'name'
    bindingProperty: string;
    propertyId: string;
    icon: string;
}