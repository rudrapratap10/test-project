import { Injectable } from '@angular/core';
import { APIClientService } from '@dewdrops/services';

@Injectable()
export class MultiSelectSupplierService {

    public buyerGroupUsersList = [];
    constructor(private _apiClient: APIClientService) {

    }

    getUsersList(searchVal, supplierObject, filter){
      if(searchVal === ''){
        searchVal = ' ';
      }
        let options = {};
        if (filter) {
          options = {
              criteriaGroup: {
              logicalOperator: supplierObject.criteriaGroup.logicalOperator,
              criteria: [
                {
                  fieldName: supplierObject.criteriaGroup.criteria[0].fieldName,
                  operation:supplierObject.criteriaGroup.criteria[0].operation,
                  value: searchVal
                }
              ]
            }
          };
        }
        return this._apiClient.list(supplierObject.datasource.url, options);
    }
   
    getUserGroupList(searchVal, supplierObject, filter){
      if(searchVal === ''){
        searchVal = ' ';
      }
        let options = {};
        if (filter) {
          options = {
              criteriaGroup: {
              logicalOperator: supplierObject.criteriaGroup.logicalOperator,
              criteria: [
                {
                  fieldName: supplierObject.criteriaGroup.criteria[0].fieldName,
                  operation:supplierObject.criteriaGroup.criteria[0].operation,
                  value: searchVal
                }
              ]
            }
          };
        }
        return this._apiClient.list(supplierObject.datasource.url, options);
    }
}
