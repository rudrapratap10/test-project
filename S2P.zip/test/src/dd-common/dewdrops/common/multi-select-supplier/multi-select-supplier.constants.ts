import { NgModule } from '@angular/core';


export enum  SupplierType {
  SUPPLIER = 'Supplier',
  SUPPLIER_GROUP = 'Supplier Group',
}