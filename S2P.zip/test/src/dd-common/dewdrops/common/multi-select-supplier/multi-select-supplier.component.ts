import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  ContentChild,
  TemplateRef
} from '@angular/core';
import { APIClientService} from '@dewdrops/services';
import { MultiSelectSupplierService } from './multi-select-supplier.service';
import { SupplierOptions, InitialSupplierType, SupplierGroupOptions} from './multi-select-supplier.model';
import { SupplierType } from './multi-select-supplier.constants';
import { FormGroup, FormControl } from '@angular/forms';
import { map } from 'rxjs/operators';
import { CollectionFactory } from '@dewdrops/factories';
import { findIndex } from 'lodash';
import { of } from 'rxjs/observable/of';

@Component({
  selector: 'dew-multi-select-supplier',
  templateUrl: './multi-select-supplier.component.html',
  styleUrls: ['./multi-select-supplier.component.scss']
})
export class MultiSelectSupplierComponent implements OnInit {

  @Input() public supplier : SupplierOptions;
  @Input() public supplierGroup :SupplierGroupOptions;
  @Input() public initialSupplierType = new InitialSupplierType();
  public loader: boolean;
  public selectedList :any =[];
  public supplierType = SupplierType;
  public userOrGroup = [
    {
      value : ''
    },
    {
      value : ''
    }
  ];
  public supplierVal;
  public userData: any;
  public userGroupData: any;
  public newSearch = false;
  public query : string;
  @ContentChild('userItemTemplate') userItemTemplate: TemplateRef<any>;
  @ContentChild('userGroupTemplate') userGroupTemplate: TemplateRef<any>;
  @Output()
  select: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  suggestnewSupplier: EventEmitter<any> = new EventEmitter<any>();
  
  constructor( public supplierService: MultiSelectSupplierService, public apiClient: APIClientService) { 

    this.supplier ={
      datasource:new CollectionFactory('/api/a/isource/suppliers/search', apiClient),
      label : 'Supplier',
      criteriaGroup : {
        logicalOperator: '',
        criteria:[
          {
          fieldName:'',
          operation: ''
          }
        ]
      },
      bindingProperty:'',
      propertyId: '',
      icon: 'people'
    }

    this.supplierGroup ={
      datasource: new CollectionFactory('/api/a/isource/suppliers/search', apiClient),
      label : 'Supplier Group',
      criteriaGroup : {
        logicalOperator: '',
        criteria:[
          {
          fieldName:'',
          operation: ''
          }
        ]
      },
      bindingProperty:'',
      propertyId: '',
      icon: 'people-2'
    }
    this.initialSupplierType ={
      type: this.supplierType.SUPPLIER,
      value: ''
    }
    this.supplier.datasource.count(20);
    }

  ngOnInit() {
    if(this.initialSupplierType.value!==''){
      this.selectedList.push(this.initialSupplierType.value);
    }
    this.userOrGroup[0].value = this.supplier.label;
    this.userOrGroup[1].value = this.supplierGroup.label;
    this.loader = true;
    if(this.initialSupplierType.type === this.supplierType.SUPPLIER){
      this.supplierVal = this.supplier.label;
    }
    else{
      this.supplierVal = this.supplierGroup.label;
    }
  }

  supplierDropdownSelect(value){
    this.supplierVal = value.value;
  }

  displayModelFnFactory(){
    return (data: any) => {
      return data;
    };
  }

  onUserChange(newSearch: boolean){
    return (query: string) => {
      this.newSearch = newSearch;
      if (!newSearch) {
            this.loader = false;
        }
        else{
          this.userData= [];
          this.loader = true;
        }
        this.query = query;
      this.supplier.datasource.applyPaginate();
      return this.supplierService.getUsersList(query, this.supplier, true).pipe(
        map(
          (response) => {
            this.loader = false;
            if (this.newSearch) {
              this.userData=  response.data.records ? response.data.records : this.userData;
            } else {
              this.userData.push(
                ...(response.data.records ?
                    response.data.records :
                    [])
                );
            }
            this.newSearch = false;
            return this.userData; 
          }
        )
      );
    }
  }

  fetchNextUserList(){
    if(!this.loader){
      this.supplier.datasource.next().applyPaginate().applyFilter();
      this.onUserChange(false)(
        this.query
      ).subscribe();
    }
  }

  onSelection(state, data) {
    if (state) {
      this.selectedList.push(this.displayModelFnFactory()(data));
    } else {
      this.onRemove(data, this.selectedList);
    }
    //this.select.emit(this.selectedList)
  }

  ifSelected(data) {
    for (let i = 0; i < this.selectedList.length; ++i) {
      if (this.selectedList[i][this.supplier.propertyId] === data[this.supplier.propertyId]) {
       return true;
      }
    }
    return false;
  }

  onRemove(event, array: any[]) {
    for (let i = 0; i < array.length; ++i) {
      if (array[i][this.supplier.propertyId] === event[this.supplier.propertyId]) {
        array.splice(i, 1);
        break;
      }
    }
    array = [...array];
  }

  onUserGroupChange(newSearch: boolean){
    return (query: string) => {
      this.newSearch = newSearch;
      if (!newSearch) {
            this.loader = false;
        }
        else{
          this.userGroupData= [];
          this.loader = true;
        }
        this.query = query;
      this.supplier.datasource.applyPaginate();
      return this.supplierService.getUserGroupList(query, this.supplierGroup, true).pipe(
        map(
          (response) => {
            this.loader = false;
            if (this.newSearch) {
              this.userGroupData=  response.data.records ? response.data.records : this.userGroupData;
            } else {
              this.userGroupData.push(
                ...(response.data.records ?
                    response.data.records :
                    [])
                );
            }
            this.newSearch = false;
            return this.userGroupData; 
          }
        )
      );
    }
  }

  fetchNextUserGroupList(){
    if(!this.loader){
      this.supplierGroup.datasource.next().applyPaginate().applyFilter();
      this.onUserGroupChange(false)(
        this.query
      ).subscribe();
    }
  }

  onGroupSelection(state, data) {
    if (state) {
      this.selectedList.push(this.displayModelFnFactory()(data));
    } else {
      this.onGroupRemove(data, this.selectedList);
    }
   // this.select.emit(this.selectedList)
  }

  ifGroupSelected(data) {
    for (let i = 0; i < this.selectedList.length; ++i) {
      if (this.selectedList[i][this.supplierGroup.propertyId] === data[this.supplierGroup.propertyId]) {
       return true;
      }
    }
    return false;
  }

  onGroupRemove(event, array: any[]) {
    for (let i = 0; i < array.length; ++i) {
      if (array[i][this.supplierGroup.propertyId] === event[this.supplierGroup.propertyId]) {
        array.splice(i, 1);
        break;
      }
    }
    array = [...array];
  }


  suggestNewSuplier(event){
    this.suggestnewSupplier.emit(event);
  }

  emitSelectedList(){
    this.select.emit(this.selectedList);
  }

}
