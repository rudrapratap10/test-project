import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiSelectSupplierComponent } from './multi-select-supplier.component';

describe('MultiSelectSupplierComponent', () => {
  let component: MultiSelectSupplierComponent;
  let fixture: ComponentFixture<MultiSelectSupplierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiSelectSupplierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiSelectSupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
