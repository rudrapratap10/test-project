import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GlobalUIModule } from '../../core/bootstrap/global-ui.module';
import { UtilityModule } from '../utility/utility.module';
import { MultiSelectSupplierComponent } from './multi-select-supplier.component';
import { MultiSelectSupplierService } from './multi-select-supplier.service';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
     LayoutModule,
     FormsModule,
     ReactiveFormsModule,
     GlobalUIModule,
     UtilityModule
  ],
  declarations: [
    MultiSelectSupplierComponent
  ],
  providers: [MultiSelectSupplierService],
  exports: [
    MultiSelectSupplierComponent
  ]                                                                                                                                                                                                                                                                  
})
export class MultiSelectSupplierModule { }
