import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyBusinessLocationComponent } from './company-business-location.component';

describe('CompanyBusinessLocationComponent', () => {
  let component: CompanyBusinessLocationComponent;
  let fixture: ComponentFixture<CompanyBusinessLocationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyBusinessLocationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyBusinessLocationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
