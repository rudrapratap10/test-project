import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule } from '../../core/bootstrap/layout/layout.module';
import { CompanyBusinessLocationComponent } from './company-business-location.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { GlobalUIModule } from '../../core/bootstrap/global-ui.module';
import { AutocompleteCompanyModule } from '../autocomplete-company/autocomplete-company.module';

@NgModule({
imports: [
    CommonModule,
    TranslateModule,
     LayoutModule,
     FormsModule,
     ReactiveFormsModule,
     GlobalUIModule,
     AutocompleteCompanyModule
],
declarations: [ CompanyBusinessLocationComponent ],
exports: [ CompanyBusinessLocationComponent ],
})
export class CompanyBusinessLocationModule {}
