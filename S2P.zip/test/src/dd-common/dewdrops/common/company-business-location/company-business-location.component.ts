import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators
} from '@angular/forms';
import { CollectionFactory } from '@dewdrops/factories';
import { APIClientService } from '@dewdrops/services';
import { OUModel, Company, BusinessUnit, Location, DataSource} from './company-business-location.model';

@Component({
  selector: 'dew-company-business-location',
  templateUrl: './company-business-location.component.html',
  styleUrls: ['./company-business-location.component.scss']
})

export class CompanyBusinessLocationComponent implements OnInit {

  public bussinessUnitFormGroupInstance: FormGroup;
  public locationFormGroupInstance: FormGroup;
  public companyFormGroupInstance: FormGroup;

  @Input()
  mode: string = "CREATE";
  @Input()
  public dataSource: DataSource;
  @Input()
  public OUValues: OUModel;
  @Input()
  public userId: string;
  @Input()
  companyDisabled: boolean;
  
  public companyDataSource: CollectionFactory;
  public locationDataSource: CollectionFactory;
  public businessUnitDataSource: CollectionFactory;

  @Output()
  selectedOU: EventEmitter<OUModel> = new EventEmitter<OUModel>();

  constructor( private formBuilder: FormBuilder, private api: APIClientService) {
    this.companyDisabled = false;
  }

  ngOnInit() {

  if(this.mode === 'EDIT'){

    this.dataSource.companyDataSource.body ={
      "userId": this.userId
    }
    
    if(this.OUValues && this.OUValues.company && this.OUValues.company.code && this.OUValues.company.code !=""){
      this.dataSource.businessUnitDataSource.body ={
      "userId": this.userId,
      "companyCode": this.OUValues.company.code
      }
    }

    if(this.OUValues && this.OUValues.company && this.OUValues.company.code && this.OUValues.company.code !="" && 
    this.OUValues.businessUnit &&this.OUValues.businessUnit.code && this.OUValues.businessUnit.code !=""){
      this.dataSource.locationDataSource.body ={
      "userId": this.userId,
      "companyCode": this.OUValues.company.code,
      "businessUnitCode": this.OUValues.businessUnit.code
      }
    }

    this.selectedOU.emit(this.OUValues);
    this.companyFormGroupInstance = this.formBuilder.group({
      companyFormGroup  :  [{ value: (this.OUValues && this.OUValues.company && this.OUValues.company.name && this.OUValues.company.name !="") ? 
      (this.OUValues.company) : '' , 
      disabled: (this.companyDisabled)? true:false }, Validators.required]
    });
    this.bussinessUnitFormGroupInstance = this.formBuilder.group({
      bussinessUnit: [{ value: (this.OUValues && this.OUValues.company && this.OUValues.company.name && this.OUValues.company.name !="" 
      && this.OUValues.businessUnit && this.OUValues.businessUnit.name && this.OUValues.businessUnit.name !="") ? 
      (this.OUValues.businessUnit) : '',
       disabled: (this.OUValues && this.OUValues.company && this.OUValues.company.name && this.OUValues.company.name != "") ? 
       false:true }, Validators.required]
    });
    this.locationFormGroupInstance = this.formBuilder.group({
      location: [{ value: (this.OUValues && this.OUValues.company && this.OUValues.company.name && this.OUValues.company.name !="" 
       && this.OUValues.businessUnit && this.OUValues.businessUnit.name && this.OUValues.businessUnit.name !=""
      && this.OUValues.location && this.OUValues.location.name && this.OUValues.location.name!="") ? 
      (this.OUValues.location):'', 
      disabled: (this.OUValues && this.OUValues.company && this.OUValues.company.name && this.OUValues.company.name != "" 
      && this.OUValues.businessUnit && this.OUValues.businessUnit.name && this.OUValues.businessUnit.name !="") ? 
      false : true }, Validators.required]
    });


    this.companyFormGroupInstance.valueChanges.subscribe(
      (companyObj) => {
        if (!companyObj.companyFormGroup) {
          this.bussinessUnitFormGroupInstance.get('bussinessUnit').disable({onlySelf :true});
          this.locationFormGroupInstance.get('location').disable({onlySelf :true});
          this.OUValues.company = null;
        } else {
          this.bussinessUnitFormGroupInstance.get('bussinessUnit').enable({onlySelf :true});
          this.dataSource.businessUnitDataSource.body = {
            "userId": this.userId,
            "companyCode": this.companyFormGroupInstance.get('companyFormGroup').value.code
          }
          this.OUValues.company = {
            name: this.companyFormGroupInstance.get('companyFormGroup').value.name,
            code: this.companyFormGroupInstance.get('companyFormGroup').value.code
          }
        }
        this.bussinessUnitFormGroupInstance.get('bussinessUnit').setValue(null);
        this.locationFormGroupInstance.controls['location'].setValue(null);
        this.OUValues.businessUnit = null;
        this.OUValues.location = null;
      }
    )

    this.bussinessUnitFormGroupInstance.valueChanges.subscribe(
      (businessUnitObj) => {
        if (!businessUnitObj.bussinessUnit) {
          this.locationFormGroupInstance.get('location').disable({onlySelf :true});
          this.OUValues.businessUnit = null;
        } else {
          this.locationFormGroupInstance.get('location').enable({onlySelf :true});
          this.dataSource.locationDataSource.body = {
            "userId": this.userId,
            "companyCode": this.companyFormGroupInstance.get('companyFormGroup').value.code,
            "businessUnitCode": businessUnitObj.bussinessUnit.code
          }
          this.OUValues.businessUnit = {
            name: this.bussinessUnitFormGroupInstance.get('bussinessUnit').value.name,
            code: this.bussinessUnitFormGroupInstance.get('bussinessUnit').value.code
          }
        }
        this.locationFormGroupInstance.controls['location'].setValue(null);
        this.OUValues.location = null;
      }
    )

    this.locationFormGroupInstance.valueChanges.subscribe(
      (locationObj) => {
        if (!locationObj.location) {
          this.OUValues.location = null;
        }
        else{
          this.OUValues.location = {
            name: this.locationFormGroupInstance.get('location').value.name,
            code: this.locationFormGroupInstance.get('location').value.code
          }
        }
        this.onOUSelectedChanged();
      }
    )
  }
}

  onOUSelectedChanged(){
   if(this.OUValues.company && this.OUValues.businessUnit && this.OUValues.location){
     this.selectedOU.emit(this.OUValues)
   }
   else{
     this .selectedOU.emit(null)
   }
  }

}
