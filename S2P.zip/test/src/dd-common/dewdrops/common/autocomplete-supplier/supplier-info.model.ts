export interface supplierInfo
{
    name : string,
    supplierId : string
    erpId : string
}