import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { List } from 'lodash';
import { map } from 'rxjs/operators';
import { FormGroup, FormBuilder } from '@angular/forms';
import { APIClientService } from '../../core/services/api-client/api-client.service';
import { of } from 'rxjs/observable/of';
import { CollectionFactory } from '../../core/factories/collection/collection.factory';
import { CriteriaInterface } from '@dewdrops/interfaces';
import { supplierInfo } from './supplier-info.model';
import { TranslateService } from 'ng2-translate/src/translate.service';
import { elementStart } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'dew-autocomplete-supplier',
  templateUrl: './autocomplete-supplier.component.html',
  styleUrls: ['./autocomplete-supplier.component.scss']
})
export class AutocompleteSupplierComponent implements OnInit {
  public newSearch = false;
  public loader: boolean;
  public query : string;
  public supplierData : List<supplierInfo>;
  @Output()
  select: EventEmitter<any> = new EventEmitter<any>();

  @Output()
  inValid: EventEmitter<any> = new EventEmitter<any>();

  @Input() minLength : number
  @Input() dataSource: CollectionFactory<supplierInfo>;
  @Input() value : supplierInfo
  
  public type = [
    {
      value : this._language.instant('DEWDROPS_LABEL_SUPPLIER')
    },
    {
      value : this._language.instant('DEWDROPS_LABEL_ERPID')
    }
  ];

  
  searchCriteria: CriteriaInterface;
  @Input() searchBy : string
  supplierValue: any;

  constructor(private _language: TranslateService) { }

  ngOnInit() {
    
    this.loader = true;
    if(!this.searchBy)
    {
      this.searchCriteria = {
        fieldName: 'SEARCH_BY_NAME',
        value: '',
        operation: 'EQUALS',
      };      
    }
    else
    {
      this.searchCriteria = {
        fieldName: this.searchBy,
        value: '',
        operation: 'EQUALS',
      };
    }
    this.supplierValue = this._language.instant('DEWDROPS_LABEL_SUPPLIER');
  }
  
  supplierDropdownSelect(value){    
    this.supplierValue = value.value;    
    if(value.value === 'Supplier')
    {
      this.searchCriteria.fieldName = 'SEARCH_BY_NAME';
    }
    else
    {
      this.searchCriteria.fieldName = 'SEARCH_BY_ERP_ID';
    }
  }


  supplierModelFnFactory()
  {
    return (data: supplierInfo) => {
      return {
        erpId: data.erpId,
        name: data.name,
        supplierId: data.supplierId
      };
    };
  }

  supplierdisplayModelFnFactory()
  {
    return (data: supplierInfo) => {
      return data.name;
    };
  }
  setSupplier(event)
  {
    if(!event)
    {
      this.inValid.emit();
    }
  }
  onSupplierChange()
  {
    return (query: string) => {
      this.loader = true;
      this.supplierData= [];
      if (query) {
        if (this.searchCriteria) {
          this.searchCriteria.value = query;
          this.dataSource.filterBy(this.searchCriteria).applyFilter();
        }
      }
      
      return this.dataSource.list$.pipe(map(
        (response)  =>  {
          this.loader = false;
          this.supplierData= [];
          this.supplierData=  response ? response : this.supplierData;
          return this.supplierData;
        }
      ));
    };
  }
  
  onSupplierSelect(event)
  {
    this.select.emit(event);
  }  
}
