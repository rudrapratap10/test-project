import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutocompleteSupplierComponent } from './autocomplete-supplier.component';

describe('AutocompleteSupplierComponent', () => {
  let component: AutocompleteSupplierComponent;
  let fixture: ComponentFixture<AutocompleteSupplierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutocompleteSupplierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutocompleteSupplierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
