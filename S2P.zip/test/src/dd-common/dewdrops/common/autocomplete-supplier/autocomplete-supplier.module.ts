import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AutocompleteSupplierComponent } from './autocomplete-supplier.component';
import { TranslateModule } from 'ng2-translate';
import { LayoutModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UtilityModule } from '../utility/utility.module';

@NgModule({
  imports: [
    CommonModule,
    TranslateModule,
     LayoutModule,
     FormsModule,
     ReactiveFormsModule,
     GlobalUIModule,
     UtilityModule
  ],
  declarations: [AutocompleteSupplierComponent],
  exports :  [AutocompleteSupplierComponent]
})
export class AutocompleteSupplierModule { }
