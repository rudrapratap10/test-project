import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { LayoutModule, ProgressModule, GlobalUIModule } from '@dewdrops/bootstrap';
import { TranslateModule } from 'ng2-translate';
import { SpotlightModule } from '../spotlight/spotlight.module';
import { PageWrapperBlankComponent } from './page-wrapper-blank.component';

@NgModule({
  imports: [
    CommonModule,
    SpotlightModule,
    LayoutModule,
    TranslateModule,
    ProgressModule,
    GlobalUIModule
  ],
  declarations: [PageWrapperBlankComponent],
  exports: [PageWrapperBlankComponent]
})
export class PageWrapperBlankModule { }
