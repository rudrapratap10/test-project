import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'dew-page-wrapper-blank',
  templateUrl: './page-wrapper-blank.component.html',
  styleUrls: ['./page-wrapper-blank.component.scss']
})
export class PageWrapperBlankComponent implements OnInit {

  @Input() pageTitile: string;
  @Input() noAdditionalHeader: boolean;
  @Input() openBlankPageWrapper: boolean;
  @Output()
  closeBlankPagewrapper = new EventEmitter<boolean>();
  constructor() {
    this.openBlankPageWrapper = true;
   }

  ngOnInit() {
    
  }

  closeBlankPageWrapper(state){
    this.closeBlankPagewrapper.emit(false);
  }

}
