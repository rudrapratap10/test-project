import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PageWrapperBlankComponent } from './page-wrapper-blank.component';

describe('PageWrapperBlankComponent', () => {
  let component: PageWrapperBlankComponent;
  let fixture: ComponentFixture<PageWrapperBlankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PageWrapperBlankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PageWrapperBlankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
