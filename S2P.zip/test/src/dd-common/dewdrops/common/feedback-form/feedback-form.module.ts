import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from 'ng2-translate';
import { ModalModule,FormControlModule,ButtonsModule, LayoutModule } from '@dewdrops/bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeedbackFormComponent } from './feedback-form.component';
import { AttachmentModule } from '../attachment/attachment.module';


@NgModule({
    imports: [
        CommonModule,
        TranslateModule,
        FormsModule,
        ReactiveFormsModule,
        ModalModule,
        FormControlModule,
        ButtonsModule,
        AttachmentModule,
        LayoutModule
    ],
    declarations: [FeedbackFormComponent],
    exports: [FeedbackFormComponent]
})

export class feedbackFormModule {}





