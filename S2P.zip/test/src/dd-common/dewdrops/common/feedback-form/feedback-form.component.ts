import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { IFeedbackForm } from './interfaces/feedback-from-interface';
import { IFeedbackFormBrowser } from './interfaces/feedback-browser-interface'
import { List } from 'lodash';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms'

@Component({
  selector: 'dew-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.scss']
})
export class FeedbackFormComponent implements OnInit {
  @Input() modalState: boolean;

  @Output() close: EventEmitter<boolean> = new EventEmitter<boolean>();

  @Input() modules: any;

  @Output() submit = new EventEmitter()

  @Input() attachmentApiOptions: any;

  public formDetails: List<IFeedbackForm> = [];

  public browserDetails: IFeedbackFormBrowser;


  messageType: any = [{
    id: 0,
    name: 'Feedback'
  },
  {
    id: 1,
    name: 'Feature Request'
  },
  {
    id: 2,
    name: 'Functionality Issue (Bug)'
  },
  {
    id: 3,
    name: 'Usability Issue'
  },
  {
    id: 4,
    name: 'Performance Issue'
  },
  {
    id: 4,
    name: 'Other'
  }];

  priority: any = [{
    id: 0,
    name: 'High'
  },
  {
    id: 1,
    name: 'Medium'
  },
  {
    id: 2,
    name: 'Low'
  }];


  public defaultMessType: string;

  public defaultPriority: string;

  public feedbackFormHeader = "Report an Issue";

  feedbackForm: FormGroup;

  constructor(private formBuilder:FormBuilder) { }


  maxlengthSummary = {
    value: 200,
    message: 'Minlength is 4'
  };
  maxlengthDescription = {
    value: 5000,
    message: 'Minlength is 4'
  };
  summaryRequired = {
    value: 'required',
    message: 'Please enter subject'
  };
  descriptionRequired = {
    value: 'required',
    message: 'Please enter description'
  };
  submitted = false;
  
 
  ngOnInit() {
    this.defaultMessType = this.messageType[0].name;
    this.defaultPriority = this.priority[1].name;
    this.feedbackForm = this.formBuilder.group({
      module: ['', Validators.required],
      summary: ['',  Validators.required],
      messageType: [this.defaultMessType,  Validators.required],
      priority: [this.defaultPriority,  Validators.required],
      description: ['',  Validators.required],
    })
  }
  get f() { return this.feedbackForm.controls; }
 
  toggleModalState(event) {
    this.modalState = event;
    this.close.emit(event);
  }
  
  uploadedFileIDs = []
  uploadedAttachIds(event) {
   this.uploadedFileIDs = event
  }


  
  onSubmit(){
    this.submitted = true;
    if(!this.feedbackForm.invalid){
      this.modalState = false;
      this.close.emit(false);
      this.submitted = false;
      let form = this.feedbackForm.controls
      let screenResolution = window.screen.width + 'x' + window.screen.height
      this.browserDetails = { currentUrl: window.location.href, screenResolution: screenResolution, name: window.navigator.appName, version: window.navigator.appVersion, agent: window.navigator.userAgent };
      this.formDetails = [
        { module: form.module.value, subject: form.summary.value, type: form.messageType.value, priority: form.priority.value, description: form.description.value,attachments:this.uploadedFileIDs, browser: this.browserDetails }
      ]
      this.submit.emit(this.formDetails)
    }
  }
}
