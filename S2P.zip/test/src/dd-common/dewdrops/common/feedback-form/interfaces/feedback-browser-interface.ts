export interface IFeedbackFormBrowser {
    currentUrl: string, // The page user is on
    screenResolution: string // 1920 x 1080
    name: string, // Navigator name
    version: string, // Navigator version
    agent: string, // Browser-agent string
}