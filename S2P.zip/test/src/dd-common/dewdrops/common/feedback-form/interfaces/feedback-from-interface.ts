import { IFeedbackFormBrowser } from './feedback-browser-interface'
import { List } from 'lodash';

export interface IFeedbackForm {
    module: string, // One of the module names originally passed by the product
    subject: string, // Entered by the user
    type: string, // Selected by the user
    priority: string, // Selected by the user
    description: string, // Selected by the user
    attachments: List<string> // List of attachmentIds uploaded by the user
    browser: IFeedbackFormBrowser
}