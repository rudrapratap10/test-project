import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SectionTabsComponent } from './section-tabs.component';

describe('SectionTabsComponent', () => {
  let component: SectionTabsComponent;
  let fixture: ComponentFixture<SectionTabsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SectionTabsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SectionTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
