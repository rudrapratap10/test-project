import { Component, OnInit, ContentChildren, QueryList, AfterViewChecked, AfterContentInit, Input, Output, EventEmitter } from '@angular/core';
import {
  Router,
  NavigationEnd
} from '@angular/router';

@Component({
  selector: 'dew-section-tabs',
  templateUrl: './section-tabs.component.html',
  styleUrls: ['./section-tabs.component.scss']
})
export class SectionTabsComponent implements OnInit {

  public tabId:string;
  @Input()showSectionTabs = true;
  @Input()
  sectionTabsObj = [
    {
      label: '',
      id:'',
      replaceUrl: true,
      path: '',
      activeOnLoad: false, 
    }
  ];

  constructor(private router: Router) { }

  ngOnInit() {
    
  }
  
  ngAfterContentInit() {
  }

  onTabChange(event){
    this.tabId = event.id;
    for( let i = 0; i < this.sectionTabsObj.length; i++){
      if(this.tabId === this.sectionTabsObj[i].id){
        this.router.navigate([this.sectionTabsObj[i].path], {
          replaceUrl: this.sectionTabsObj[i].replaceUrl
      });
      }
    }
  }

}
