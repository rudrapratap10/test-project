import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DewTreeComponent } from './tree.component';

describe('TreeComponent', () => {
  let component: DewTreeComponent;
  let fixture: ComponentFixture<DewTreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DewTreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DewTreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
