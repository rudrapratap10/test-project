import {
  AfterContentChecked, Component, Input, OnInit,
  TemplateRef, ViewChild, ViewEncapsulation, AfterViewInit
} from '@angular/core';
import { ITreeOptions, KEYS, TREE_ACTIONS, TreeComponent } from 'angular-tree-component';
import { DefaultTreeOptions } from './tree-options.model';

@Component({
  selector: 'dew-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DewTreeComponent implements OnInit, AfterContentChecked, AfterViewInit {
  @Input() treeNodeTemplate: TemplateRef<HTMLTemplateElement>;
  @Input() nodes;
  @Input() expandAll = true as boolean;
  @Input() options: DefaultTreeOptions = new DefaultTreeOptions();

  @ViewChild(TreeComponent)
  private treeComponent: TreeComponent;

  constructor() {

   }

  ngOnInit() {
  }

  ngAfterContentChecked(): void {
    if (this.treeNodeTemplate) {
      this.treeComponent.treeNodeTemplate = this.treeNodeTemplate;
    }
  }

  ngAfterViewInit(): void {
    if (this.expandAll) {
      this.treeComponent.treeModel.expandAll();
    }
  }

}
