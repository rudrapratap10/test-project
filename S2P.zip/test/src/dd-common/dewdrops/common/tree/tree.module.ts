import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TreeComponent, TreeModule } from 'angular-tree-component';
import { DewTreeComponent } from './tree.component';
@NgModule({
  imports: [
    CommonModule,
    TreeModule.forRoot()
  ],
  declarations: [ DewTreeComponent ],
  exports: [ DewTreeComponent ]
})
export class DewTreeModule { }
