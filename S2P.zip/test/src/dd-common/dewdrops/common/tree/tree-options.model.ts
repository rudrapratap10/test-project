import { ITreeOptions, KEYS, TREE_ACTIONS } from 'angular-tree-component';

export class DefaultTreeOptions {
  options: ITreeOptions = {
    displayField: 'contractTitle',
    isExpandedField: 'expanded',
    childrenField: 'listOfChildren',
    actionMapping: {
      mouse: {
        dblClick: (tree, node, $event) => {
          if (node.hasChildren) {
            TREE_ACTIONS.TOGGLE_EXPANDED(tree, node, $event);
          }
        }
      },
      keys: {
        [KEYS.ENTER]: (tree, node, $event) => {
          node.expandAll();
        }
      }
    },
    nodeHeight: 23,
    allowDrag: (node) => {
      return false;
    },
    allowDrop: (node) => {
      return false;
    },
    levelPadding: 10,
    useVirtualScroll: true,
    animateExpand: true,
    scrollOnActivate: true,
    animateSpeed: 30,
    animateAcceleration: 1.2,
    scrollContainer: document.documentElement // HTML
  };
  constructor(options?: ITreeOptions) {
    if (options) {
      this.options.displayField = options.displayField || 'contractTitle';
      this.options.isExpandedField = options.isExpandedField || 'expanded';
      this.options.childrenField = options.childrenField || 'listOfChildren';
      this.options.actionMapping = options.actionMapping || {
        mouse: {
          dblClick: (tree, node, $event) => {
            if (node.hasChildren) {
              TREE_ACTIONS.TOGGLE_EXPANDED(tree, node, $event);
            }
          }
        },
        keys: {
          [KEYS.ENTER]: (tree, node, $event) => {
            node.expandAll();
          }
        }
      };
      this.options.nodeHeight = options.nodeHeight || 23;
      if (options.allowDrag) {
        this.options.allowDrag = options.allowDrag;
      }
      if (options.allowDrop) {
        this.options.allowDrop = options.allowDrop;
      }
      this.options.levelPadding = options.levelPadding || 10;
      this.options.useVirtualScroll = options.useVirtualScroll || true;
      this.options.animateExpand = options.animateExpand || true;
      this.options.scrollOnActivate = options.scrollOnActivate || true;
      this.options.animateSpeed = options.animateSpeed || 30;
      this.options.animateAcceleration = options.animateAcceleration || 1.2;
    }
  }
}
