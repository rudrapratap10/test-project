import {
  Component,
  OnInit,
  Input,
  ViewChild,
  AfterViewInit
} from '@angular/core';
import { map } from 'rxjs/operators';
import { TimezoneService, APIClientService } from '@dewdrops/services';
import { DateformatPipe } from 'dd-common/dewdrops/common/dateformat/dateformat.pipe';
import { CreateBasicDetails } from './CreateBasicDetails';
import { FormControl } from '@angular/forms';
import { AutocompleteComponent } from 'dd-common/dewdrops/core/bootstrap/autocomplete/autocomplete/autocomplete.component';
import { DatePickerComponent } from 'dd-common/dewdrops/core/bootstrap/picker/datepicker/datepicker.component';
import { Observable } from 'rxjs';

@Component({
  selector: 'dew-eInvoice-basic-details',
  templateUrl: './basic-details.component.html',
  styleUrls: ['./basic-details.component.scss']
})

export class DewBasicEinvoiceDetailsComponent implements OnInit {
  

  @Input() mode : string;
  @Input() basicArr;


  @ViewChild("ac2")
  aBuyer: AutocompleteComponent;

 

  todayDateTimeStamp: any = Date.now();
  todayDate: Date = null;
  today = new Date();
  public reactiveValue: FormControl;
  public reactiveValue1 : FormControl;
  maxDescription: number = 250;
  maxNotes: number = 5000;
  remitAddress = [];
  paymentTerm: any = { code: "PAYT009", name: "shwetapaytem30", creditDays: 30, daysAvailDiscount: 10, percentDiscount: 15 };
  purchaseTypes: any = [];
  buyerFilterList = [];
  requesterFilterList = [];
  dueDateManual: boolean = false;
  buyerLoader = false
  requesterLoader = false
  buyerData : any[];
  minDate : Date
  
  userBody = {
    perPageRecords: 10,
    pageNo: 1,
    userRole: '',
    criteriaGroup: {
      logicalOperator: 'AND',
      criteria: [
        {
          fieldName: 'SEARCH_BY_NAME',
          operation: 'CONTAINS',
          value: ''
        },
        {
          fieldName: 'SEARCH_BY_PRODUCT',
          operation: 'CONTAINS',
          value: 'eInvoice'
        },
        {  
					fieldName:'SEARCH_BY_EMAIL',
					operation:'CONTAINS',
          value:'',
          minValue: 0,
          maxValue: 0
				 } 
      ]
    }
  }

  @Input() detailsObject: CreateBasicDetails;
  modifyDueDate : boolean
  commonObj = {};

  constructor(private apiClient: APIClientService, private timezoneService: TimezoneService, private _datePipe: DateformatPipe) {

    this.todayDate = this._datePipe.transform(this.todayDateTimeStamp, '');
  }

  ngOnInit() {
    this.getEinvoiceAppConfig().subscribe((res)=>
    {
      this.modifyDueDate = res.data.EPROC_INVOICE_MODIFY_INVOICE_DUE_DATE;
      


    });
    this.minDate = new Date();
    this.minDate.setFullYear(1969);
    this.minDate.setMonth(12);
    this.minDate.setDate(1);
    this.getPurchaseTypes();
     this.reactiveValue = new FormControl(null);
     this.reactiveValue1 = new FormControl(null);

    
    //  this.aBuyer.select()
    if(this.mode=='create'){
    if(this.detailsObject.creditDays && this.detailsObject.invoiceDate.value && this.detailsObject.creditDays.value && this.detailsObject.discountDays.value)
    {
      this.detailsObject.invoiceDueDate.value = this._datePipe.transform(this.timezoneService.addToDate(this.detailsObject.invoiceDate.value, this.detailsObject.creditDays.value, 'days'), '');
      this.detailsObject.discountDueDate.value = this._datePipe.transform(this.timezoneService.addToDate(this.detailsObject.invoiceDate.value, this.detailsObject.discountDays.value, 'days'), '');
    }
  }
  }

  getEinvoiceAppConfig(): Observable<any> {
    const url = '/api/a/einvoice/configs/getInvoiceConfig';
    const body = {
      configKeys: [
        'EPROC_INVOICE_MODIFY_INVOICE_DUE_DATE',
      ]
    };
    return this.apiClient.list(url, body);
}
  onChangeInvoiceDate(newValue) {
    this.detailsObject.invoiceDate.value = newValue;
    if(this.detailsObject.creditDays)
    {
      this.detailsObject.invoiceDueDate.value = this._datePipe.transform(this.timezoneService.addToDate(this.detailsObject.invoiceDate.value, this.detailsObject.creditDays.value, 'days'), '');
      this.detailsObject.discountDueDate.value = this._datePipe.transform(this.timezoneService.addToDate(this.detailsObject.invoiceDate.value, this.detailsObject.discountDays.value, 'days'), '');
    }
  }
  onChangeCMDate(newValue : string)
  {

  }

  onChangeInvoiceDueDate(newValue: string) {
    this.detailsObject.invoiceDueDate = this._datePipe.transform(this.timezoneService.convertTimestampToDate(newValue), '');
    this.dueDateManual = true;
  }

  onChangeInvoiceDiscountDate(newValue: string) {
    this.detailsObject.discountDueDate = this._datePipe.transform(this.timezoneService.convertTimestampToDate(newValue), '');
  }

  getPurchaseTypes() {
    let terms = {
      "perPageRecords" : 3,
      "pageNo": 1
    }

    const url = '/api/a/cmd/purchasetypes/list';
    this.apiClient.list(url, terms).subscribe((res)=>
    {
      this.purchaseTypes = res.data.records;
    });
 
  }


  onBuyerSelected(buyer) {
    this.buyerFilterList = [];
    this.detailsObject.buyerId = buyer.Id;
    this.detailsObject.buyerName = buyer.firstName + " " + buyer.lastName;
  }

  onRequesterSelected(requester) {
    this.requesterFilterList = [];
    this.detailsObject.requesterId = requester.Id;
    this.detailsObject.requesterName = requester.firstName + " " + requester.lastName;
  }

  
  displayFn() {
    return (data: any) => data.firstName + ' ' + data.lastName;
  }

  modelFnFactory() {
    return (data: any) => {
      return {
        email: data.emailId,
        name: data.firstName + ' ' + data.lastName
      };
    };
  }
  suggestionStreamFactoryFn(inputField) {
    if (inputField === 'buyer') {
      this.userBody.userRole = 'buyer';
      //this.buyerLoader = true
    } else if (inputField === 'requester') {
      this.userBody.userRole = 'requestor';
    }

    this.userBody.criteriaGroup.criteria[0].fieldName = 'SEARCH_BY_NAME';
    this.userBody.criteriaGroup.criteria[2].fieldName = 'SEARCH_BY_EMAIL';
    return (query: string) => {
      this.buyerFilterList = []
      this.requesterFilterList = []
      if(inputField === 'buyer')
      {
        this.buyerLoader = true
      }
      else
      {
        this.requesterLoader = true
      }
      this.userBody.criteriaGroup.criteria[0].value = query;
      if(this.userBody.criteriaGroup.criteria[0].value.indexOf("@") > 0 && this.userBody.criteriaGroup.criteria[0].value.indexOf(".") > 0){ 
        this.userBody.criteriaGroup.criteria[0].value=' ';
      }
        this.userBody.criteriaGroup.criteria[2].value = query;
      const url = `/api/a/einvoice/users/list`;
      return this.apiClient.create(url, this.userBody).pipe(
          map(
            (response: any) => {
              this.buyerLoader = false
              this.requesterLoader = false;
              if (inputField === 'buyer') {
                if(response.data.records)
                {
                  this.buyerFilterList =  response.data.records;
                  return this.buyerFilterList;
                }
                else
                {
                  this.buyerFilterList =  [];
                  return this.buyerFilterList;
                }
                
              } else {
                if(response.data.records)
                {
                  this.requesterFilterList = response.data.records;
                  return this.requesterFilterList;
                }
                else
                {
                  this.requesterFilterList = [];
                  return this.requesterFilterList;
                }                
              }
            }
          )
        );
    };
  }

  shouldshow(col) {
    if (!col.validation) {
      return true;
    }
    if (!col.validation.invisible) {
      return true;
    } else {
      if (col.value) {
        return true;
      }
    }
    return false;
  }

  getValue(data, row, col) {
    if (this.basicArr[row][col].validation) {
      if (this.basicArr[row][col].validation.dateFormat) {
        return this._datePipe.transform(data.value, '');
      }
    }
    return data.value;
  }
}
