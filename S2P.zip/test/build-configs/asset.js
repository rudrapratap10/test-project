const fs = require('fs');

function addAssetHashSupportForSass(hash) {
  const fileData = `$asset-parent-dir: '${hash}';`;
  fs.writeFileSync('./src/dd-common/build-time-artifacts/asset.scss', fileData);
}

function addAssetSupport(hash) {
  const fileData = `export const ASSETS_PARENT_DIR = '${hash}';`;
  fs.writeFileSync('./src/dd-common/build-time-artifacts/asset.ts', fileData);
}

module.exports = {
  addAssetHashSupport: function (hash) {

    addAssetHashSupportForSass(hash);

    addAssetSupport(hash);
  }
}
